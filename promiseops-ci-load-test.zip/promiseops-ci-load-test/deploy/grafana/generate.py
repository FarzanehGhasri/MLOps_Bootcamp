"""Generate deploy/grafana/{promiseops-service.json,alert-rules.yaml} from one place.

Run from the repo root: python deploy/grafana/generate.py deploy/grafana. Queries use the staff scrape job (job label) and the metrics
exported by src/promiseops/api.py.
"""

import json
import sys
from pathlib import Path

import yaml

DS_UID = "PBAB629F371D08AFE"  # "Team Prometheus" in g03-grafana
JOB = "g03-production"
FOLDER_UID = "promiseops"
FOLDER_TITLE = "PromiseOps"
DS = {"type": "prometheus", "uid": "${ds}"}
J = 'job="$job"'
RUNBOOK = "https://gitlab.mlops.qbootcamp.ir/qbc13/g03/promiseops/-/blob/develop/reports/runbook.md"


def q(expr, legend="__auto", ref="A", instant=False, fmt="time_series"):
    return {"datasource": DS, "expr": expr, "legendFormat": legend, "refId": ref, "range": not instant,
            "instant": instant, "format": fmt}


def thresholds(*steps):
    return {"mode": "absolute", "steps": [{"color": c, "value": v} for c, v in steps]}


def stat(pid, title, x, w, expr, unit="short", th=None, legend="__auto", text_mode="auto", desc="", y=0, h=4,
         mappings=None):
    defaults = {"unit": unit, "noValue": "no data", "thresholds": th or thresholds(("green", None))}
    if mappings:
        defaults["mappings"] = mappings
    return {"id": pid, "type": "stat", "title": title, "description": desc, "datasource": DS,
            "gridPos": {"h": h, "w": w, "x": x, "y": y},
            "targets": [q(expr, legend, instant=True)],
            "fieldConfig": {"defaults": defaults, "overrides": []},
            "options": {"reduceOptions": {"calcs": ["lastNotNull"], "fields": "", "values": False},
                        "colorMode": "background", "graphMode": "none", "textMode": text_mode,
                        "justifyMode": "center", "orientation": "auto"}}


def series(pid, title, x, y, w, h, targets, unit="short", th=None, step=False, desc="", minv=None):
    custom = {"drawStyle": "line", "lineWidth": 2, "fillOpacity": 10, "showPoints": "never",
              "spanNulls": False, "lineInterpolation": "stepAfter" if step else "linear"}
    if th:
        custom["thresholdsStyle"] = {"mode": "line+area"}
    defaults = {"unit": unit, "custom": custom, "thresholds": th or thresholds(("green", None))}
    if minv is not None:
        defaults["min"] = minv
    return {"id": pid, "type": "timeseries", "title": title, "description": desc, "datasource": DS,
            "gridPos": {"h": h, "w": w, "x": x, "y": y}, "targets": targets,
            "fieldConfig": {"defaults": defaults, "overrides": []},
            "options": {"legend": {"displayMode": "list", "placement": "bottom", "showLegend": True},
                        "tooltip": {"mode": "multi", "sort": "desc"}}}


PREDICT = f'{J}, route="/predict"'
ERR_RATIO = (f'sum(rate(promiseops_http_requests_total{{{PREDICT}, status=~"5.."}}[5m])) / '
             f'sum(rate(promiseops_http_requests_total{{{PREDICT}}}[5m]))')


RETRAIN = f"max(promiseops_retraining_required{{{J}}})"
RETRAIN_DESC = ("1 = the latest conclusive monitor-train decision about the served model recommends retraining "
                "(promiseops.decisions, read by /metrics once a minute). The staff alert RetrainingRecommended fires "
                "after 1 minute at 1. Reasons, windows and counts: MLflow experiment promiseops-monitoring, "
                "monitoring.json. No data until the API with !42 is deployed.")
YES_NO = [{"type": "value", "options": {"0": {"text": "No", "color": "green", "index": 0},
                                        "1": {"text": "Yes", "color": "red", "index": 1}}}]


def quantile(p):
    return (f"histogram_quantile({p}, sum by (le) "
            f"(rate(promiseops_http_request_duration_seconds_bucket{{{PREDICT}}}[5m])))")


def dashboard():
    panels = [
        stat(1, "Replicas scraped", 0, 4, f"count(up{{{J}}} == 1)",
             th=thresholds(("red", None), ("orange", 1), ("green", 2)),
             desc="API pods Prometheus scrapes successfully (headless promiseops-metrics Service). "
                  "Production runs 2, HPA allows up to 3."),
        stat(2, "Ready replicas", 4, 4, f"sum(promiseops_ready{{{J}}})",
             th=thresholds(("red", None), ("orange", 1), ("green", 2)),
             desc="Pods whose last /readyz check passed (validated model and reachable DB)."),
        stat(3, "/predict req/s", 8, 4, f"sum(rate(promiseops_http_requests_total{{{PREDICT}}}[1m]))",
             unit="reqps", desc="Load-test target: 10 req/s for 3 minutes."),
        stat(4, "/predict 5xx ratio (5m)", 12, 4, ERR_RATIO, unit="percentunit",
             th=thresholds(("green", None), ("red", 0.01)), desc="Load-test limit: below 1%."),
        stat(5, "/predict p95 (5m)", 16, 4, quantile(0.95), unit="s",
             th=thresholds(("green", None), ("red", 0.5)), desc="Load-test limit: 500 ms."),
        stat(6, "Model version", 20, 4, f"count by (model_version) (promiseops_model_info{{{J}}} == 1)",
             legend="{{model_version}}", text_mode="name",
             th=thresholds(("blue", None)), desc="Versions loaded by scraped pods. More than one "
                                                  "outside a rollout means mixed serving."),
        series(7, "Request rate by route and status", 0, 4, 12, 8,
               [q(f"sum by (route, status) (rate(promiseops_http_requests_total{{{J}}}[5m]))",
                  "{{route}} {{status}}")], unit="reqps"),
        series(8, "/predict latency", 12, 4, 12, 8,
               [q(quantile(0.50), "p50", "A"), q(quantile(0.95), "p95", "B"), q(quantile(0.99), "p99", "C")],
               unit="s", th=thresholds(("transparent", None), ("red", 0.5)), minv=0,
               desc="Red band: above the 500 ms p95 limit (staff alert SlowPredictions)."),
        series(9, "/predict 5xx ratio", 0, 12, 8, 8, [q(ERR_RATIO, "5xx ratio")], unit="percentunit",
               th=thresholds(("transparent", None), ("red", 0.01)), minv=0),
        series(10, "/predict 4xx by status", 8, 12, 8, 8,
               [q(f'sum by (status) (rate(promiseops_http_requests_total{{{PREDICT}, status=~"4.."}}[5m]))',
                  "{{status}}")], unit="reqps",
               desc="401 auth, 404 unknown order, 409 request_id reuse, 422 invalid input."),
        series(11, "Readiness per pod", 16, 12, 8, 8, [q(f"promiseops_ready{{{J}}}", "{{instance}}")],
               step=True, minv=0, desc="1 = last /readyz passed. Not-ready pods stay scraped "
                                       "(publishNotReadyAddresses), so 0 is visible."),
        series(12, "Replicas scraped (HPA)", 0, 20, 8, 8, [q(f"count(up{{{J}}} == 1)", "scraped pods")],
               step=True, minv=0, desc="Scale-up and scale-down evidence for the HPA test."),
        series(13, "Model version per pod", 8, 20, 8, 8,
               [q(f"promiseops_model_info{{{J}}} == 1", "{{instance}} {{model_version}}")], step=True, minv=0),
        {"id": 14, "type": "table", "title": "Firing alerts (Prometheus)", "datasource": DS,
         "gridPos": {"h": 8, "w": 8, "x": 16, "y": 20},
         "targets": [q('ALERTS{alertstate="firing"}', instant=True, fmt="table")],
         "fieldConfig": {"defaults": {}, "overrides": []},
         "transformations": [{"id": "organize", "options": {
             "excludeByName": {"Time": True, "Value": True, "__name__": True},
             "renameByName": {"alertname": "Alert", "alertstate": "State", "job": "Job"}}}],
         "options": {"showHeader": True}},
        series(15, "Retraining recommended", 0, 28, 16, 8, [q(RETRAIN, "retraining required")], step=True,
               minv=0, th=thresholds(("transparent", None), ("red", 1)), desc=RETRAIN_DESC),
        stat(16, "Retraining recommended", 16, 8, RETRAIN, th=thresholds(("green", None), ("red", 1)),
             y=28, h=8, mappings=YES_NO, desc=RETRAIN_DESC),
    ]
    return {
        "uid": "promiseops-service", "title": "PromiseOps — Service", "tags": ["promiseops", "g03"],
        "timezone": "browser", "schemaVersion": 39, "version": 1, "editable": True,
        "refresh": "30s", "time": {"from": "now-3h", "to": "now"},
        "templating": {"list": [
            {"name": "ds", "label": "Data source", "type": "datasource", "query": "prometheus",
             "current": {"text": "Team Prometheus", "value": DS_UID}, "hide": 0},
            {"name": "job", "label": "Scrape job", "type": "custom", "query": JOB,
             "current": {"text": JOB, "value": JOB}, "options": [{"text": JOB, "value": JOB, "selected": True}],
             "hide": 0},
        ]},
        "annotations": {"list": []},
        "links": [{"title": "Runbook", "url": RUNBOOK, "type": "link", "targetBlank": True}],
        "panels": panels,
    }


def rule(uid, title, expr, op, value, for_, severity, summary, description, panel):
    jexpr = expr.replace("$job", JOB)
    return {
        "uid": uid, "title": title, "condition": "C", "for": for_,
        "noDataState": "OK", "execErrState": "Error",
        "labels": {"team": "g03", "service": "promiseops", "severity": severity},
        # Links the rule to its dashboard panel (alert state shows on the panel).
        "annotations": {"summary": summary, "description": description, "runbook_url": RUNBOOK,
                        "__dashboardUid__": "promiseops-service", "__panelId__": str(panel)},
        "data": [
            {"refId": "A", "datasourceUid": DS_UID, "relativeTimeRange": {"from": 600, "to": 0},
             "model": {"refId": "A", "expr": jexpr, "instant": True, "range": False,
                       "intervalMs": 1000, "maxDataPoints": 43200}},
            {"refId": "C", "datasourceUid": "__expr__", "relativeTimeRange": {"from": 0, "to": 0},
             "model": {"refId": "C", "type": "threshold", "expression": "A",
                       "conditions": [{"evaluator": {"type": op, "params": [value]}}]}},
        ],
    }


def rules():
    return [
        rule("promiseops-predict-5xx", "PromiseOps /predict 5xx ratio above 1%", ERR_RATIO, "gt", 0.01, "2m",
             "critical", "More than 1% of /predict requests fail with a server error",
             "5xx share of /predict over 5 minutes is above the 1% load-test limit. Check pod logs, "
             "/readyz and the database (503 = model or DB unavailable).", panel=9),
        rule("promiseops-replica-not-ready", "PromiseOps replica not ready", f"min(promiseops_ready{{{J}}})",
             "lt", 1, "2m", "critical", "At least one API replica fails its readiness check",
             "promiseops_ready is 0 on a scraped pod for 2 minutes: model bundle failed validation or the "
             "database is unreachable. The pod receives no traffic until it recovers.", panel=11),
        rule("promiseops-ready-below-min", "PromiseOps fewer than 2 ready replicas",
             f"sum(promiseops_ready{{{J}}})", "lt", 2, "5m", "warning",
             "Production has fewer than its 2 minimum ready replicas",
             "Sum of promiseops_ready is below the production minimum (2) for 5 minutes.", panel=2),
        rule("promiseops-mixed-model-versions", "PromiseOps serving more than one model version",
             f"count(count by (model_version) (promiseops_model_info{{{J}}} == 1))", "gt", 1, "15m",
             "warning", "Pods serve different model versions for longer than a rollout",
             "More than one model_version is loaded across scraped pods for 15 minutes: a rollout is stuck "
             "or a pod runs an old image. Compare image digests.", panel=13),
    ]


def provisioning(rule_list):
    return {"apiVersion": 1, "groups": [{"orgId": 1, "name": "promiseops-service", "folder": FOLDER_TITLE,
                                         "interval": "1m", "rules": rule_list}]}


if __name__ == "__main__":
    out = Path(sys.argv[1])
    out.mkdir(parents=True, exist_ok=True)
    (out / "promiseops-service.json").write_text(json.dumps(dashboard(), indent=2, ensure_ascii=False) + "\n")
    (out / "alert-rules.yaml").write_text(
        "# Grafana-managed alert rules for the PromiseOps service (Grafana alerting provisioning format).\n"
        "# Generated by deploy/grafana/generate.py; edit that file, not this one.\n"
        + yaml.safe_dump(provisioning(rules()), sort_keys=False, allow_unicode=True, width=110))
    print("written", sorted(p.name for p in out.iterdir()))
