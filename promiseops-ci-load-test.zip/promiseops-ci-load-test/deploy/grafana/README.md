# Grafana: PromiseOps service dashboard and alert rules

Source of truth for what runs in g03-grafana. **Edit `generate.py`, not the generated files.**

| File | What |
|---|---|
| `generate.py` | Builds both files below from one place (queries, thresholds, rule texts). |
| `promiseops-service.json` | Dashboard `PromiseOps — Service` (uid `promiseops-service`), 16 panels. |
| `alert-rules.yaml` | 4 Grafana-managed alert rules, group `promiseops-service` (1 min), folder `PromiseOps`. |

Live: <https://g03-grafana.mlops.qbootcamp.ir/d/promiseops-service> and **Alerting → Alert rules → PromiseOps**.

## Where the data comes from

The staff-managed team Prometheus (data source `Team Prometheus`) has one scrape job, `g03-production`.
It resolves `promiseops-metrics.g03-prod.svc.cluster.local:8080` (the headless Service in the Helm chart),
scrapes `/metrics` on every API pod and sends `X-API-Key` itself. Retention is **2 days**: take evidence
screenshots soon after a test.

Metrics used (all exported by `src/promiseops/api.py`):

| Metric | Meaning |
|---|---|
| `promiseops_http_requests_total{route,status}` | Requests by route template and status, including 422 and 500. |
| `promiseops_http_request_duration_seconds_bucket{route,status}` | `/predict` latency histogram. |
| `promiseops_ready` | 1 when the pod's last `/readyz` passed (model valid, DB reachable). |
| `promiseops_model_info{model_version}` | 1 for the loaded model version. |
| `promiseops_retraining_required` | 1 when the latest conclusive monitor-train decision about the served model recommends retraining (!42; panels 15–16, staff alert `RetrainingRecommended`). |
| `up{job="g03-production"}` | Prometheus could scrape the pod. |

## Alert rules

| Rule | Condition | For | Severity |
|---|---|---|---|
| PromiseOps /predict 5xx ratio above 1% | 5xx share of `/predict` over 5 min > 0.01 | 2m | critical |
| PromiseOps replica not ready | `min(promiseops_ready) < 1` | 2m | critical |
| PromiseOps fewer than 2 ready replicas | `sum(promiseops_ready) < 2` | 5m | warning |
| PromiseOps serving more than one model version | distinct `model_version` values > 1 | 15m | warning |

No data counts as OK for all four: when nothing is scraped, the staff rule `APIUnavailable` fires instead.

Staff rules in Prometheus (`/etc/prometheus/alerts.yaml`, read-only for us) also show in Grafana:
`APIUnavailable` (`up == 0` or absent, 2m), `SlowPredictions` (`/predict` p95 > 0.5 s, 3m) and
`RetrainingRecommended` (`promiseops_retraining_required == 1`, 1m).

## Updating

```bash
python deploy/grafana/generate.py deploy/grafana
```

Then apply in Grafana (signed in through GitLab, Grafana runs as anonymous **Editor**):

- **Dashboard:** Dashboards → New → Import → upload `promiseops-service.json` → keep uid → Import (overwrite).
  It lives in the **General** folder: the anonymous user can create folders but cannot save dashboards
  inside them.
- **Alert rules:** Alerting → Alert rules → edit the rule in folder `PromiseOps`, or `PUT
  /api/v1/provisioning/alert-rules/<uid>` with header `X-Disable-Provenance: true` (keeps rules editable
  in the UI).

Then check that Grafana now equals these files and record it (exit 1 and nothing written if not):

```bash
python scripts/grafana_evidence.py --commit <commit> --auth-header-env GRAFANA_AUTH_HEADER \
    --out reports/monitoring/grafana-live-<date>.json
```

## Evidence: an alert firing and resolving

1. Before the metrics Service reaches prod, `APIUnavailable` is firing: screenshot **Alerting → Alert rules**
   and the dashboard's *Firing alerts* table.
2. Deploy; within ~2 min `up{job="g03-production"}` shows each replica and the alert resolves: screenshot
   again (alert history shows both transitions).
3. Repeatable drill: scale prod to 1 replica, or make one pod fail readiness, and watch
   *PromiseOps fewer than 2 ready replicas* go Pending → Firing → Normal after restoring.

Record times and links in `reports/evidence.md`.
