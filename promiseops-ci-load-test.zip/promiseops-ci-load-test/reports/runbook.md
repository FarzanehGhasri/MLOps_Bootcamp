# Operations handover

Complete: startup from a clean environment; secret delivery; ingest retry/quarantine; model lineage and release; readiness; metrics/alerts; delayed-label retraining; staging and human production approval; rollback by digest; incident recovery; limits; escalation to staff. Include tested commands and evidence references.

## Metrics and alerts

Code: !38 (metrics Service), !39 (readiness and 422/500 metrics), !40 (dashboard and team alert rules as code), !41 (JSON logs on stdout), !42 (retraining metric). Until each MR is merged and deployed, the parts that depend on it are missing in production.

### Where to look

| What | Where |
|---|---|
| Dashboard | Team Grafana https://g03-grafana.mlops.qbootcamp.ir → **PromiseOps — Service** (`/d/promiseops-service`), variable `job = g03-production`, datasource "Team Prometheus" |
| Team alerts | Grafana → Alerting → folder **PromiseOps**, group `promiseops-service` (evaluated every 1m) |
| Staff alerts | Dashboard table "Firing alerts (Prometheus)", or Grafana → Explore: `ALERTS{alertstate="firing"}` |
| Ad-hoc queries | Grafana → Explore → "Team Prometheus" (every PromQL line below runs there) |
| Logs | Pod stdout: one JSON line per event (`prediction`, `unhandled_error`, `retraining_check_failed`). Level: `PROMISEOPS_LOG_LEVEL` (default `INFO`). No order ids, API keys or database URLs are logged. |
| Pods | CI job `inspect-own-namespaces` (`kubectl get pods,deployments,jobs` in `g03-staging`, `g03-prod`, `g03-jobs`) |

### How Prometheus finds the API

The staff Prometheus job `g03-production` resolves the headless Service `promiseops-metrics.g03-prod.svc.cluster.local`, port 8080, path `/metrics`, and sends the `X-API-Key` header itself. The Service (`metricsService.enabled: true` in `values-prod.yaml`) selects only API pods (`component=api`) and also lists pods that are not ready, so a failing pod shows `promiseops_ready 0` instead of disappearing.

Check: `count(up{job="g03-production"} == 1)` equals the number of API replicas (2 to 3 with the HPA).

### Metrics

| Metric | Type, labels | Meaning |
|---|---|---|
| `promiseops_http_requests_total` | counter; `route`, `status` | `/predict` and `/v1/predict` requests, both as `route="/predict"`. 422 and unhandled 500 are counted by exception handlers (!39). |
| `promiseops_http_request_duration_seconds` | histogram; `route`, `status` | `/predict` latency |
| `promiseops_feature_observations_total` | counter; `feature` | Features used per prediction (fixed list of names) |
| `promiseops_model_info` | gauge; `model_version` | 1 for the model the pod serves |
| `promiseops_ready` | gauge | 1 when the pod's last `/readyz` passed (model valid, DB reachable), else 0 (!39) |
| `promiseops_retraining_required` | gauge | 1 when the latest conclusive monitoring decision about the served model recommends retraining (!42) |

Labels are bounded on purpose: route templates only, never raw paths, order ids or request ids.

### Alerts

Staff rules (Prometheus `/etc/prometheus/alerts.yaml`, group `promiseops`; we cannot change them):

| Alert | Condition | For | Meaning | First actions |
|---|---|---|---|---|
| APIUnavailable | `up{job="g03-production"} == 0 or absent(up{job="g03-production"})` | 2m | No API pod is scraped | Run `inspect-own-namespaces`: are the `g03-prod` pods Running and Ready? A stuck rollout or crash loop → roll back by digest (see Rollback). Pods fine but no targets → check the `promiseops-metrics` Service exists. Targets down → the scrape API key does not match `PROMISEOPS_API_KEY`. |
| SlowPredictions | p95 of `/predict` > 0.5 s (`histogram_quantile(0.95, …[5m])`) | 3m | Predictions are slow | Dashboard: req/s and "Replicas scraped (HPA)". At 3 replicas the HPA is at its maximum: reduce load. Otherwise the database is slow (check `/readyz` and the 5xx panel). |
| RetrainingRecommended | `promiseops_retraining_required == 1` | 1m | The latest conclusive `monitor-train` run about the served model recommends retraining | See "Retraining signal" below. |

Team rules (Grafana-managed, `deploy/grafana/alert-rules.yaml` from !40; no data counts as OK, so they stay quiet while nothing is deployed):

| Alert | Condition | For | Severity | First actions |
|---|---|---|---|---|
| PromiseOps /predict 5xx ratio above 1% | 5xx share of `/predict` over 5m > 0.01 | 2m | critical | 503 = model or database unavailable: check `/readyz` (Readiness panel), database reachability, pod logs (`unhandled_error`). |
| PromiseOps replica not ready | `min(promiseops_ready{job="g03-production"})` < 1 | 2m | critical | The pod gets no traffic. Model bundle failed validation (log at startup) or the DB is unreachable from that pod. |
| PromiseOps fewer than 2 ready replicas | `sum(promiseops_ready{job="g03-production"})` < 2 | 5m | warning | Production minimum is 2. Check pods, quota (3 CPU / 3 GiB) and events with `inspect-own-namespaces`. |
| PromiseOps serving more than one model version | more than one `model_version` with `promiseops_model_info == 1` | 15m | warning | A rollout is stuck or a pod runs an old image: compare image digests; finish or roll back the rollout. |

External notifications are not configured (not required by the brief). Alerts are visible in Grafana and Prometheus only.

### Retraining signal (`promiseops_retraining_required`, !42)

1. Each `monitor-train` run persists its report in MLflow (experiment `promiseops-monitoring`, artifact `monitoring.json`). Only after the run reads back as FINISHED does it write one row to `promiseops.monitoring_decisions`. If that write fails, the run is marked FAILED and nothing trains.
2. `/metrics` reads the newest **conclusive** decision about the model version the pod serves, at most once a minute (2 s timeouts). Conclusive means `status = 'assessed'` and enough mature labels. Runs without reference, without prediction history or with too few mature labels never change the alert.
3. The alert resolves when a newer conclusive run recommends no retraining, or when a new model version is deployed (decisions about the old version stop counting).

When it fires: open the newest run in `promiseops-monitoring` with tag `promiseops.retrain_recommended=true`, read the reasons, windows and counts in `monitoring.json`, and follow tag `promiseops.training_run_id` to the training run and its gate decision. Promotion stays a human decision (see Release and approval).

Rollout order for !42: run `promiseops db-init` against the production database (adds `monitoring_decisions`, schema version 4, keeps existing data) **before** the worker image with !42 runs. Otherwise `monitor-train` runs fail on purpose, and the API logs `retraining_check_failed` once a minute and reports 0.

### Dashboard and team rules match Git (evidence)

`scripts/grafana_evidence.py` reads the dashboard and the team alert rules from the Grafana API and writes `reports/monitoring/grafana-live-<date>.json` only when they equal `deploy/grafana` (dashboard field by field; every rule field in `alert-rules.yaml`; group interval 1m; every rule evaluates). Last run: `reports/monitoring/grafana-live-2026-11-20.json`, 4/4 checks ok. Run it again after any change to `deploy/grafana`, and before a demo:

```bash
python scripts/grafana_evidence.py --commit <commit of deploy/grafana> --auth-header-env GRAFANA_AUTH_HEADER \
    --out reports/monitoring/grafana-live-<date>.json
```

A failing check names the panel or rule field that differs: someone edited Grafana in the UI, or the files were changed but not imported. Re-import from `deploy/grafana` (see its README).

### Showing an alert firing and resolving (evidence)

- Firing: `APIUnavailable` while nothing was deployed to production, captured 2026-11-19 11:39 UTC: `reports/monitoring/apiunavailable-firing-2026-11-19.json` (rule, `activeAt`, and the query results for `up`, `absent(up)` and `ALERTS`).
- Resolve: after the first production deploy, run `scripts/alert_evidence.py` (Python standard library only; access header: see the script's docstring):

  ```bash
  python scripts/alert_evidence.py --alert APIUnavailable --expect resolved \
      --commit <deployed commit> --image-digest sha256:<app digest> --model-version <served version> \
      --wait 600 --out reports/monitoring/apiunavailable-resolved-<date>.json
  ```

  It polls every 15 s (2 scrapes plus the 2m `for` take about 3 minutes) and writes the file only when the rule is inactive, `ALERTS` has no `APIUnavailable` series, every `up` is 1, `absent(up)` is empty and the pods serve that model version. Otherwise it prints the failing checks and exits 1. The file has the same rule and queries as the firing file, plus the checks, the deployment and the last firing sample of the previous 30 minutes. Add a row to `reports/evidence.md` and a Grafana screenshot of Alerting and the dashboard over the same time range.

### Limits

- Prometheus scrapes only the API pods. Worker Jobs (`train`, `monitor-train`) have no metrics; their results are in MLflow, and only the retraining decision reaches Prometheus (through the database).
- The staff rules are not ours to change. `SlowPredictions` and `RetrainingRecommended` do not filter by `job`.
- `promiseops_retraining_required` depends on the database: during an outage the last value is kept; a pod started during an outage shows 0 until the database is back.

## Incident detection

How each incident category of day 9 (`docs/ASSESSMENT.fa.md`) shows up, the first check, and where recovery is described. Prometheus scrapes only the API pods: ingestion and worker incidents show up in Airflow, the database and MLflow, not in Grafana. The signals in the API rows need a production deploy; until then `APIUnavailable` fires and the team rules show "no data". Rollback and deploy steps are owned by the deploy section (issues #8, #11); this table only points to them.

Database checks run against the team PostgreSQL (`PROMISEOPS_DATABASE_URL`). Logs are one JSON line per event.

| Incident | What you see | First check | Recover |
|---|---|---|---|
| Ingestion repeated (same batch again) | Nothing breaks. The receipt and log say `replayed` (`batch_replayed`), one more `ingest_attempts` row with status `replayed`, no data row changes (`test_replay_of_same_payload_is_a_no_op`). The same batch ID with **another** payload is a rejection (`batch_id_conflict`, see "broken batch"). | `SELECT status, reason_code, count(*) FROM promiseops.ingest_attempts WHERE batch_id = '<id>' GROUP BY 1, 2;` | Nothing to do. |
| Ingestion interrupted (database or gateway down during a run) | Airflow `promiseops_ingest_feed`: `resolve_feed` fixes company replay time, then `ingest` downloads and consumes files in one task-local directory. Transient download/CLI failures retry twice (2 min apart); corrupt batches raise `AirflowFailException` and are not retried (`test_ingest_task_transient_failure_is_retryable`, `test_ingest_dag_retries_and_asset_outlet`). Log `batch_failed` with the error type; an `ingest_attempts` row with status `failed` if the database was reachable. The batch's transaction rolled back: nothing half-written (`test_failure_in_the_middle_rolls_back_everything`). The ingestion asset and its company `as_of` metadata are emitted only on success. | Airflow task log; `SELECT batch_id, reason_code, finished_at FROM promiseops.ingest_attempts WHERE status = 'failed' ORDER BY finished_at DESC LIMIT 5;` | Fix the cause. Retries replay committed batches as no-ops and commit the rest; after retries are exhausted, clear the task or trigger the DAG again. XCom never carries a filesystem path from another worker. |
| Broken schema or corrupted batch | `ingest` fails at once and is **not** retried: `ingest-feed rejected a batch; payload quarantined in the database` (CLI exit 3, `test_ingest_task_rejected_batch_is_not_retried`). stdout `{"status": "rejected", "batch_id", "reason", "problems"}`; log `batch_rejected` with the reason (`schema_invalid`, `checksum_mismatch`, `invalid_json`, `missing_foreign_key`, `batch_id_conflict`, ... in `promiseops.validation.Reason`). The exact bytes are in `ingest_quarantine`, no rows written (`test_rejected_batch_writes_no_rows_but_is_quarantined`). `ingest-feed` stops at that batch: earlier batches stay committed, later ones wait. | `SELECT batch_id, reason_code, reason_detail, attempts, last_seen_at FROM promiseops.ingest_quarantine ORDER BY last_seen_at DESC LIMIT 5;` | Never edit stored rows. The DAG fails on every run until the batch is fixed at the source: escalate to staff with `batch_id`, `reason_code` and `raw_sha256`. Then re-run the DAG. |
| Drift and label delay | MLflow experiment `promiseops-monitoring`, newest `monitor-as-of-<date>` run: tag `promiseops.monitoring_reasons` and `monitoring.json`. Drift: `current 7-day window: drift >= 0.2 in <feature>=<score> (N orders)` (and the same for `previous`); it counts as persistent only when the same feature drifts in both windows, otherwise `drift is not persistent ...: review only` (`test_drift_in_one_window_only_is_not_persistent`). Label delay: `retraining suppressed: N mature orders ...` and `warning: only X% of predicted orders have a known label` (`test_insufficient_labels_suppress_retraining_even_with_persistent_drift`, `test_low_label_coverage_is_reported_as_a_warning`). With !42 deployed: `RetrainingRecommended` fires only for a conclusive recommendation; an inconclusive run leaves the alert as it was. | Dashboard panels "Retraining recommended"; the newest monitoring run's tags `promiseops.retrain_recommended` and `promiseops.monitoring_status`. | Persistent drift with enough mature labels starts training automatically (`promiseops.training_run_id` on the monitoring run). Too few labels: wait for labels; nothing trains by design. See "Retraining signal" above. |
| Weaker candidate | The training run is FINISHED (not an error) with tag `promiseops.gate_decision = rejected` and the reasons in `promiseops.gate_reasons`. It is not registered, so it cannot be released (`test_rejected_or_unevaluated_candidates_are_never_registered`). Production does not change. | MLflow: the newest `train-as-of-<date>` run's gate tags; compare with `promiseops.champion_model_version`. | Nothing to roll back. Keep the champion; record the decision. |
| Release with broken readiness | `promote-production` waits on the new pod (`helm --atomic --wait --timeout 5m`). The new pod answers `/readyz` 503 (model invalid or database unreachable), so it gets no traffic and the old pods keep serving (`maxUnavailable: 0`). The metrics Service still lists it: `promiseops_ready 0` on that pod, dashboard "Readiness per pod", team alert "PromiseOps replica not ready" after 2 min (`test_readiness_gauge_zero_when_model_missing`, `test_readiness_gauge_drops_when_database_unreachable`). After 5 min Helm rolls back by itself and the job fails. | The `promote-production` job log; `inspect-own-namespaces` (pod Ready 0/1); the new pod's log at startup. | Helm's automatic rollback restores the previous release. Fix the image or bundle and promote again; or roll back by digest (deploy section, issue #8). |
| Pod deleted | The Deployment recreates the pod in seconds (2 replicas minimum, HPA 2 to 3). Dashboard "Ready replicas" (and possibly "Replicas scraped") dips to 1 for a few seconds; the old pod's `up` series ends and a new instance appears. "Fewer than 2 ready replicas" needs 5 min and `APIUnavailable` needs **no** pod for 2 min, so a single deletion normally fires neither. | `inspect-own-namespaces`: new pod name and age, all Ready. `count(up{job="g03-production"} == 1)` in Explore. | Nothing to do if both pods are Ready again. If not, it is the readiness case above. |
| MLflow unavailable | The API is unaffected: serving never calls MLflow (`test_serving_api_never_reaches_mlflow_or_the_registry`). Worker Jobs (`train`, `monitor-train`) fail with one JSON line `{"mode": ..., "status": "failed", ...}` and exit 1 (`test_worker_emits_one_sanitized_json_error`). Marking the run FAILED (tag `promiseops.error`) is a best-effort call at failure time: it works when MLflow fails mid-run but is reachable again, otherwise the run stays RUNNING or was never created (`test_cleanup_redacts_error_and_attempts_status_even_when_tag_fails`, `test_failure_marks_the_monitoring_run_failed`). No new monitoring decision, so `promiseops_retraining_required` keeps its last value. | `python -m promiseops.tracking check` (logs and reads back a smoke run); the Airflow task and Job logs. | Staff-managed service: escalate. Then re-run the monitoring or training DAG; a failed run never published a decision or trained. |
| Version rollback | Dashboard "Model version" and "Model version per pod" show the version each pod serves. During the rollout both versions appear; "PromiseOps serving more than one model version" fires only if that lasts 15 min. | `promiseops_model_info{job="g03-production"} == 1` in Explore. | Roll back by digest: run `promote-production` with `PROMOTE_DIGEST` set (deploy section, issue #8). Then confirm with `scripts/alert_evidence.py ... --model-version <version>` (checks every pod serves it). |

### Escalate to staff

Shared services are run by the course staff: Prometheus and its rules, Grafana, MLflow, the company gateway, the Kubernetes cluster and the registry. If one of them is down, collect the time, what failed (job link, query, error text without secrets) and what still works, and report it to staff. Do not work around it in production.
