# Model card

Scope: rank completed-delivery orders at approval time for a fixed top-10% review budget. Target: local Brazilian delivery date exceeds promised date. Unknown outcomes are excluded from supervised cohorts, never imputed negative. Cancellations and intervention effects are outside this evaluation.

## Verified 32-input reference

- Model: `logistic_regression-52d3211cb171`; SHA256: `52d3211cb17113b7eeea3c9c27f5e81eee462a8683be77ba3c722b26da033657`.
- One fitted sklearn pipeline performs transformations, scaling, encoding and LR (C=0.05). Baseline: training-prevalence constant. Alternative: HistGradientBoosting.
- Inputs: approval-time item/payment aggregates, promise, calendar, geography/category and strictly past-known history. Items/payments are aggregated separately. No target delivery, review or final status is a direct input.
- History policy: `frozen-at-train-end-v1`; queries use knowledge strictly before approval, capped at train end. Serving reconstructs the same frozen policy and verifies receipts.
- Train approval/label cutoff: 2017-12-31T23:59:59Z. Validation approvals: (train_end, 2018-02-28T23:59:59Z]; validation label cutoff: 2018-04-30T00:00:00Z. Embargo: 0 days; label availability remains mandatory.
- Train: 39,837 known-label orders, prevalence 3.906%. Validation: 13,377 orders, 1,165 late (8.709%), K=1,338.
- Validation recall@10%: 0.277253; precision@10%: 0.241405; average precision: 0.190338; Brier: 0.079992. Baseline recall: 0.121030; HGB recall: 0.159657.
- Mean predicted risk 3.171% underestimates actual validation prevalence. Temporal drift, label maturity and calibration remain limitations.

## Experimental 44-input candidate

Historical duration mean/std and promise-distance add 12 inputs. C=0.01 was selected on two temporal windows inside train before evaluating the fixed outer validation.

Validation recall@10% **0.289270**, precision@10% **0.251868**, average precision **0.200688**, Brier **0.079957**: 337 late found versus 323. Comparative gates pass. This candidate is not connected to the worker release/API and is not production approval.

MLflow run: `b9749c4dfdf645c28fc01583aa8794c3`; source: `33087533de58a083c5b6d0888c4523936f0f2e47`. Experimental artifact checksums and source-file hashes are stored in that run. See [aggregate evidence](model/presentation-duration-study-2026-11-16.json) and [Persian interpretation](model/duration-recommendations-summary.fa.md).

No new test scoring was used. Validation was inspected previously, and the paired recall-difference interval includes zero; future improvement is uncertain. Apparent train metrics are not independent generalization evidence. No customer-disjoint performance claim is made. Slice diagnostics are descriptive with minimum sample/positive counts.

## Evidence and review

Standard training produces dataset manifest (receipt/file hashes, source, cutoff, schema, exact extracted-frame hashes), checksum binding in lineage/record, signature, example, sklearn flavor, reliability plot, slice report, maturity report and a run-specific card. Manifest integrity is checked before model unpickling. Artifacts are uploaded and checked before candidate registration.

This study does not move production or existing server aliases. Human review is requested from Pouya and Yasin in GitLab. Review assignment is not model approval.
