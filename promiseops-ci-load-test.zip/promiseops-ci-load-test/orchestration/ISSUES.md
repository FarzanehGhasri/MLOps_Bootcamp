# MLflow / Orchestration & Lifecycle — تسک‌های درسا و یاسین

هر issue = یک شاخهٔ `orchestration/<موضوع>` = یک MR کوچک به `develop`.
تقسیم نقش داخل بخش: درسا مالک MLflow (قوی‌ترین)، یاسین مالک Airflow/Job/bundle (نزدیک به تخصص deploy او). Review متقابل: MRهای درسا ← یاسین (یادگیری)، MRهای یاسین ← درسا.
مرز مشترک با نقش data (آناهیتا): «ingestion تمام شد → receipt ثبت شد → DAG آموزش trigger می‌شود» — روز ۲ قفل شود.

| # | Issue | مسئول | شاخه | وابسته به |
|---|---|---|---|---|
| 1 | MLflow client + experiment setup | درسا | `orchestration/mlflow-setup` | — |
| 2 | Worker train mode | درسا | `orchestration/worker-train` | 1 + مدل اولیه |
| 3 | Model record / lineage کامل | درسا | `orchestration/model-record` | 2 |
| 4 | Training DAG در Airflow | یاسین | `orchestration/training-dag` | 2 |
| 5 | Job submission با request_id درست | یاسین | `orchestration/job-submit` | 4 |
| 6 | Release bundle آماده‌سازی | یاسین | `orchestration/release-bundle` | 3 |
| 7 | Alias/champion بدون سوییچ خاموش | درسا | `orchestration/alias-management` | 6 |
| 8 | Worker monitor-train mode | درسا | `orchestration/worker-monitor-train` | 3 + monitor اولیه |
| 9 | Replay روز ۷ | یاسین | `orchestration/replay` | 4 و 8 |
| 10 | Lineage evidence | هر دو | `orchestration/evidence` | 3–7 |

## 1. MLflow client + experiment setup — درسا — `orchestration/mlflow-setup`

اتصال به `MLFLOW_TRACKING_URI`، ساخت experiment، تست ثبت یک run آزمایشی از محلی.

**معیار قبولی:** run در MLflow UI گروه دیده می‌شود؛ error روشن اگر URI/credential نباشد.

## 2. Worker train mode — درسا — `orchestration/worker-train`

پیاده‌سازی `src/promiseops/worker.py` با mode=train: parse شدن `--train-end/--validation-end/--as-of`، خواندن features از `PROMISEOPS_DATABASE_URL` تا cutoff، فراخوانی `model.py`، ثبت artifact + metrics در MLflow.

**معیار قبولی:** اجرای محلی با fixture سبز؛ در MLflow: params، metrics، artifact مدل+پیش‌پردازش باهم (`README.md:27`).

## 3. Model record / lineage کامل — درسا — `orchestration/model-record`

شناسنامهٔ مدل طبق `docs/CONTRACTS.md:65`: artifact SHA256، source_commit (`CI_COMMIT_SHA`)، نسخه‌های نرم‌افزار، dataset/schema identity، cutoffها، cohort hash، معیارها، تصمیم gate.

**معیار قبولی:** از record بتوان دقیقاً همان مدل را بازتولید/تشخیص داد.

## 4. Training DAG در Airflow — یاسین — `orchestration/training-dag`

DAG واقعی Airflow: بعد از کامل شدن ingestion (از DAG آناهیتا)، cutoffها را تصمیم می‌گیرد، `as_of` و `request_id` می‌سازد و `POST /training` می‌زند. retry و lineage — هر ران ثبت کند چه چیزی در آن لحظه معلوم بوده.

**معیار قبولی:** run_idها و cutoffها در Airflow UI قابل ردیابی؛ retry بدون duplicate.

## 5. Job submission با request_id درست — یاسین — `orchestration/job-submit`

`request_id` از hash مربوط به DagRun ID (تا retry همان ID بماند — `docs/CONTRACTS.md:53`)، رعایت `train_end < validation_end <= as_of`، مدیریت پاسخ 202 (submitted نه completed)، polling وضعیت و لاگ Job در namespace خودتان.

**معیار قبولی:** retry همان ران دوباره Job نمی‌سازد؛ لاگ Job قابل مشاهده است.

## 6. Release bundle آماده‌سازی — یاسین — `orchestration/release-bundle`

آماده‌سازی bundle مورد اعتماد (مدل+preprocessing+متادیتا) که در `/opt/promiseops/release` به worker تزریق می‌شود و `PROMISEOPS_RELEASE` به آن اشاره می‌کند. هماهنگی با یاسینِ deploy ساده است (همان نفر) — image حامل bundle طبق `docs/CONTRACTS.md:57` از image سرویس ساخته می‌شود.

**معیار قبولی:** worker incumbent bundle را می‌خواند و candidate را با آن مقایسه می‌کند.

## 7. Alias/champion بدون سوییچ خاموش — درسا — `orchestration/alias-management`

مدیریت نسخه و alias در MLflow طوری که تغییر alias سرویس در حال اجرا را بی‌صدا عوض نکند (`README.md:35`) — production هرگز از alias mutable resolve نمی‌کند، از digest/bundle ثابت.

**معیار قبولی:** تغییر alias بعد از deploy هیچ تغییری در سرویس running ایجاد نکند (تست شده).

## 8. Worker monitor-train mode — درسا — `orchestration/worker-monitor-train`

mode دوم `worker.py`: اول گزارش monitor را persist می‌کند، فقط اگر retraining توصیه شد fit می‌کند. هیچ‌کدام از دو mode تولید production را تغییر نمی‌دهند (`worker.py:15`).

**معیار قبولی:** با گزارش «بدون توصیه» هیچ آموزشی اجرا نمی‌شود و report ثبت شده است.

## 9. Replay روز ۷ — یاسین — `orchestration/replay`

هماهنگی replay: ingestion بازهٔ بعدی مرحله‌به‌مرحله (با آناهیتا)، ذخیرهٔ پیش‌بینی‌ها، ارزیابی بعد از رسیدن برچسب با همان `as_of`.

**معیار قبولی:** چرخهٔ کامل ingest→train→predict→evaluate با evidence مستند.

## 10. Lineage evidence — هر دو — `orchestration/evidence`

Index در `reports/evidence.md`: run_idهای Airflow، ران‌های MLflow، Job صف‌شده، digestها و نتایج.

**معیار قبولی:** هر آزمایش مهم با commit، digest، نسخهٔ مدل، cohort، فرمان، زمان و نتیجه ثبت شده باشد (`docs/ASSESSMENT.fa.md:32`).

---

## منطق تقسیم

- **درسا:** هرچه هستهٔ MLflow و مدل است (1، 2، 3، 7، 8) — قوی‌ترین نفر.
- **یاسین:** هرچه به Airflow، Kubernetes Job و هماهنگی با deploy می‌خورد (4، 5، 6، 9) — نزدیک به تخصص deploy/CI او؛ ضمناً 6 را چون خودش image حامل bundle را می‌سازد، خودش نگه می‌دارد تا گلوگاه review دو نفره نشود.
- Review متقابل یعنی یاسین با review MRهای MLflow درسا ضعف MLflow خودش را جبران می‌کند و برای دفاع فردی آماده می‌شود.
