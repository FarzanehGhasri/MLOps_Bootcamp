"""ci/fetch_release_relay.py: the archive sha must be stable per run id."""

import hashlib
import importlib.util
import tarfile
from io import BytesIO
from pathlib import Path

_ROOT = Path(__file__).resolve().parent.parent
_SPEC = importlib.util.spec_from_file_location("fetch_release_relay", _ROOT / "ci" / "fetch_release_relay.py")
relay = importlib.util.module_from_spec(_SPEC)
_SPEC.loader.exec_module(relay)


def test_pack_archive_is_deterministic():
    blobs = {"bundle/release.json": b"{}", "bundle/model.joblib": b"m"}
    first, second = relay.pack_archive(blobs), relay.pack_archive(blobs)
    assert first == second
    assert len(hashlib.sha256(first).hexdigest()) == 64
    with tarfile.open(fileobj=BytesIO(first)) as archive:
        assert archive.getnames() == ["bundle/model.joblib", "bundle/release.json"]
        assert all(member.mode == 0o644 and member.mtime == 0 for member in archive)
