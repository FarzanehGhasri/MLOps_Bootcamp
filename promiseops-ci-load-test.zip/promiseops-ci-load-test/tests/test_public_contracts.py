import json
from pathlib import Path

import pytest

from promiseops.contracts import SAFE_ID, Batch, PredictionRequest

ROOT = Path(__file__).resolve().parents[1]


def test_supplied_fixtures_follow_contract():
    for path in (ROOT / "fixtures").glob("synthetic-*.json"):
        Batch.model_validate(json.loads(path.read_text()))


def test_prediction_ids_cannot_be_paths():
    with pytest.raises(ValueError):
        PredictionRequest(order_id="../../secret")


@pytest.mark.parametrize("field", ["order_id", "request_id"])
def test_colons_in_ids_are_rejected_as_documented(field):
    with pytest.raises(ValueError):
        PredictionRequest(**{"order_id": "order-1", field: "audit:example"})


@pytest.mark.parametrize("identifier", ["a", "A9._-", "a" * 128])
def test_documented_identifier_characters_and_length_are_accepted(identifier):
    assert PredictionRequest(order_id=identifier).order_id == identifier


def test_published_schemas_match_the_model_contracts():
    assert SAFE_ID == r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$"
    for model in (Batch, PredictionRequest):
        published = json.loads((ROOT / "contracts" / f"{model.__name__}.schema.json").read_text())
        assert published == model.model_json_schema()


def test_group_adds_behavior_tests():
    # This test documents the starting point; passing fixture validation does not
    # demonstrate an implemented pipeline. Replace this skip with behavioral tests.
    pytest.skip("Add tests for your own ingestion/model/API/monitoring implementation")
