import numpy as np
import pandas as pd
import pytest

from promiseops.history_features import build_history


def inputs():
    orders = pd.DataFrame({"order_id": ["a", "b", "c", "d"],
                           "approved_at": pd.to_datetime(["2018-01-01", "2018-01-03", "2018-01-05", "2018-01-10"], utc=True),
                           "seller": ["s1"] * 4, "customer_state": ["SP"] * 4, "route": ["SP>SP"] * 4})
    labels = pd.DataFrame({"order_id": ["a", "b", "c", "d"], "late": [True, False, True, False],
                          "label_available_at": pd.to_datetime(["2018-01-05", "2018-01-08", "2018-01-12", "2018-01-20"], utc=True)})
    return orders, labels


def test_strict_event_time_blocks_self_future_and_same_timestamp_labels():
    orders, labels = inputs()
    x = build_history(orders, labels)
    assert x.loc["c", "history_global_count"] == 0  # a becomes known exactly at c's approval
    assert x.loc["d", "history_global_count"] == pytest.approx(np.log1p(2))
    assert x.loc["d", "history_global_rate"] == pytest.approx(2 / 22)
    changed = labels.copy()
    changed.loc[changed.order_id.isin(["c", "d"]), "late"] = False
    pd.testing.assert_frame_equal(x, build_history(orders, changed))


def test_freezing_history_prevents_validation_updates():
    orders, labels = inputs()
    x = build_history(orders, labels, freeze_at="2018-01-05T00:00:00Z")
    assert (x.history_global_count == 0).all()


def test_unknown_group_and_input_order_are_safe():
    orders, labels = inputs()
    orders.loc[3, "seller"] = "new"
    x = build_history(orders, labels)
    assert x.loc["d", "history_seller_count"] == 0
    assert x.loc["d", "history_seller_rate"] == x.loc["d", "history_global_rate"]
    pd.testing.assert_frame_equal(x, build_history(orders.iloc[::-1], labels.iloc[::-1]))
    assert np.isfinite(x).all().all()


def test_query_subset_preserves_complete_source_history():
    orders, labels = inputs()
    full = build_history(orders, labels)
    subset = build_history(orders, labels, query_order_ids=["d"])
    pd.testing.assert_frame_equal(subset, full.loc[["d"]])


def test_later_published_target_cannot_enter_frozen_workload_source():
    orders, labels = inputs()
    result = build_history(orders, labels, source_order_ids=["a"], query_order_ids=["d"])
    assert result.loc["d", "history_global_count"] == pytest.approx(np.log1p(1))
    assert result.loc["d", "seller_orders_7d"] == 0  # a is outside 7d; b/c are not source rows


def test_impossible_knowledge_time_is_rejected():
    orders, labels = inputs()
    labels.loc[0, "label_available_at"] = orders.loc[0, "approved_at"]
    with pytest.raises(ValueError, match="after"):
        build_history(orders, labels)


def test_timestamp_resolution_does_not_change_trailing_windows():
    orders, labels = inputs()
    orders.loc[3, "approved_at"] = pd.Timestamp("2018-03-01", tz="UTC")
    labels.loc[3, "label_available_at"] = pd.Timestamp("2018-03-20", tz="UTC")
    expected = build_history(orders, labels)
    assert expected.loc["d", "history_global_recent_count"] == 0
    assert expected.loc["d", "seller_orders_7d"] == 0
    orders["approved_at"] = orders.approved_at.dt.as_unit("us")
    labels["label_available_at"] = labels.label_available_at.dt.as_unit("us")
    pd.testing.assert_frame_equal(expected, build_history(orders, labels))


@pytest.mark.parametrize("approach", ["logistic_regression", "hist_gradient_boosting"])
@pytest.mark.parametrize("rates_only", [False, True])
def test_history_pipeline_fit_roundtrip_and_ablation(approach, rates_only):
    import io

    import joblib
    from test_feature_study import sample

    from promiseops.history_features import HISTORY_NAMES
    from promiseops.history_study import build_model

    x = sample()
    for column in HISTORY_NAMES:
        x[column] = 0.05 if column.endswith("rate") else 0.0
    model = build_model(approach, rates_only=rates_only).fit(x, np.arange(len(x)) % 2 == 0)
    used = model.named_steps["preprocess"].transformers_[0][2]
    assert ("history_global_count" in used) != rates_only
    buffer = io.BytesIO()
    joblib.dump(model, buffer)
    buffer.seek(0)
    np.testing.assert_array_equal(model.predict_proba(x), joblib.load(buffer).predict_proba(x))


def test_identical_predictions_have_zero_paired_difference():
    from promiseops.paired_validation import recall_difference

    result = recall_difference([str(i) for i in range(100)], np.arange(100) % 3 == 0,
                               np.arange(100), np.arange(100), repeats=50)
    assert result["recall_difference_95_percentile_interval"] == [0, 0]
