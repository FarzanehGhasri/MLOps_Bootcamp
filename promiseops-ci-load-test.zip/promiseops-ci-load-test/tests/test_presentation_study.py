import io

import joblib
import numpy as np
import pytest
from test_feature_study import sample

from promiseops.history_features import HISTORY_NAMES
from promiseops.presentation_study import VARIANTS, build_variant, choose


@pytest.mark.parametrize("variant", ["reference", "rates_C01", "nonlinear_rates_C01", "nonlinear_full_C01"])
def test_variant_roundtrip_and_finite_probabilities(variant):
    x = sample()
    for name in HISTORY_NAMES:
        x[name] = .05 if name.endswith("rate") else 0.
    fitted = build_variant(variant).fit(x, np.arange(len(x)) % 2 == 0)
    stream = io.BytesIO()
    joblib.dump(fitted, stream)
    stream.seek(0)
    np.testing.assert_array_equal(fitted.predict_proba(x), joblib.load(stream).predict_proba(x))
    assert np.isfinite(fitted.predict_proba(x)).all()


def test_selection_uses_inner_metrics_and_respects_quality_safeguards():
    models = {name: {"recall_at_10": .2, "pr_auc": .15, "brier": .08} for name in VARIANTS}
    models["original_C01"] = {"recall_at_10": .25, "pr_auc": .16, "brier": .08}
    models["nonlinear_rates_C01"] = {"recall_at_10": .4, "pr_auc": .10, "brier": .09}
    selected, _ = choose([{"models": models}, {"models": models}])
    assert selected == "original_C01"


def test_forest_uses_approval_only_schema_and_serializes():
    from promiseops.forest_presentation import build_forest

    x = sample()
    for name in HISTORY_NAMES:
        x[name] = .05 if name.endswith("rate") else 0.
    model = build_forest("rf_depth8").fit(x, np.arange(len(x)) % 2 == 0)
    stream = io.BytesIO()
    joblib.dump(model, stream)
    stream.seek(0)
    np.testing.assert_allclose(model.predict_proba(x), joblib.load(stream).predict_proba(x), rtol=0, atol=1e-12)
