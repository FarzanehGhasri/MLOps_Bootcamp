"""Worker command line, environment and champion choice (#15): no database, no MLflow; runs in CI.

The full run (database + MLflow): tests/test_training_db.py
Run: $env:PYTHONPATH = "src"; python -m pytest tests/test_worker.py -v
"""

from pathlib import Path

import pytest
from test_bundle import FEATURES, ROOT, lineage, write

from promiseops import bundle as b
from promiseops import training, worker
from promiseops.tracking import TrackingConfigError

ARGS = ["--train-end", "2017-12-31T23:59:59Z", "--validation-end", "2018-02-28T23:59:59Z",
        "--as-of", "2018-04-30T00:00:00Z"]
COMMIT = "b" * 40


# ---------------------------------------------------------------- command line and environment
def test_the_dispatcher_command_line_is_accepted():
    args = worker.parse_args(["--mode", "train", *ARGS])
    assert (args.mode, args.train_end, args.as_of) == ("train", "2017-12-31T23:59:59Z", "2018-04-30T00:00:00Z")
    assert worker.parse_args(ARGS).mode == "train"  # the dispatcher's mode is optional


def test_settings_use_the_contract_defaults():
    settings = worker.settings_from_env({"CI_COMMIT_SHA": COMMIT})
    assert settings.source_commit == COMMIT
    assert settings.artifacts == Path("/tmp/artifacts")
    assert settings.incumbent == Path("/opt/promiseops/release")


def test_local_runs_can_point_to_other_folders(tmp_path):
    settings = worker.settings_from_env({"CI_COMMIT_SHA": COMMIT, "PROMISEOPS_ARTIFACTS": str(tmp_path / "a"),
                                         "PROMISEOPS_INCUMBENT": str(ROOT / "release")})
    assert (settings.artifacts, settings.incumbent) == (tmp_path / "a", ROOT / "release")


@pytest.mark.parametrize("environ", [{}, {"CI_COMMIT_SHA": "abc123"}])
def test_a_model_without_a_full_source_commit_is_refused(environ):
    with pytest.raises(TrackingConfigError, match="CI_COMMIT_SHA"):
        worker.settings_from_env(environ)


def test_wrong_cutoffs_fail_before_connecting_anywhere(capsys):
    # validation_end after as_of: refused with exit code 1, no database or MLflow address is even read.
    code = worker.main(["--train-end", "2018-01-01T00:00:00Z", "--validation-end", "2018-03-01T00:00:00Z",
                        "--as-of", "2018-02-01T00:00:00Z"], environ={})
    assert code == 1
    assert '"status": "failed"' in capsys.readouterr().err


def test_missing_environment_fails_with_exit_code_1(capsys):
    assert worker.main(ARGS, environ={}) == 1
    assert "CI_COMMIT_SHA" in capsys.readouterr().err


def test_monitor_train_checks_its_inputs_like_train(capsys):
    # #21: same command line and environment rules; nothing is opened before they pass.
    assert worker.parse_args(["--mode", "monitor-train", *ARGS]).mode == "monitor-train"
    assert worker.main(["--mode", "monitor-train", *ARGS], environ={}) == 1
    assert '"mode": "monitor-train"' in capsys.readouterr().err


# ---------------------------------------------------------------- champion = copy of the incumbent
def test_incumbent_without_record_means_the_first_candidate_meets_the_baseline(tmp_path):
    # release/ of the repository is the constant mock from MR !3: it has no lineage.json.
    chosen = training.load_champion(ROOT / "release", tmp_path / "run")
    assert chosen.champion is None
    assert chosen.incumbent_model_version == "baseline-constant-v1"
    assert chosen.source.startswith("baseline:")
    assert b.read_bundle(tmp_path / "run" / "champion").manifest.model_version == "baseline-constant-v1"


def test_incumbent_with_record_is_the_champion(tmp_path):
    manifest = write(tmp_path)
    chosen = training.load_champion(tmp_path / "bundle", tmp_path / "run")
    assert chosen.champion is not None
    assert chosen.champion.model_version == manifest.model_version == chosen.incumbent_model_version
    # the copy, not the read-only original, is what gets compared
    assert (tmp_path / "run" / "champion" / b.MODEL_FILE).is_file()


def test_incumbent_trained_on_other_features_is_refused(tmp_path):
    other = FEATURES[:-1]
    write(tmp_path, feature_names=other, lineage=lineage(feature_schema_sha256=b.feature_schema_sha256(other)))
    with pytest.raises(training.TrainingError, match="other features"):
        training.load_champion(tmp_path / "bundle", tmp_path / "run")


def test_a_broken_incumbent_is_never_used(tmp_path):
    write(tmp_path)
    with (tmp_path / "bundle" / b.MODEL_FILE).open("ab") as handle:
        handle.write(b"tampered")
    with pytest.raises(b.BundleError):
        training.load_champion(tmp_path / "bundle", tmp_path / "run")
