"""train_candidate end to end on PostgreSQL: ingest -> labels/cutoffs -> features -> models -> gates.

Skipped without PROMISEOPS_TEST_DATABASE_URL. DROPS the schema (fixture from test_ingestion_db):
use an EMPTY database whose name ends in "_test", never the one holding the real feed.
"""

import pytest
from factories import orders_doc
from test_ingestion_db import URL, conn, ingest  # noqa: F401  (conn is a pytest fixture)

from promiseops import cohorts
from promiseops.model import compare_candidate, train_candidate

pytestmark = pytest.mark.skipif(not URL, reason="PROMISEOPS_TEST_DATABASE_URL is not set")

TRAIN_END, VALIDATION_END, AS_OF = "2017-05-01T00:00:00Z", "2017-05-31T00:00:00Z", "2017-06-15T00:00:00Z"


def _orders(batch_id, prefix, approved, available_at, promises):
    """Orders approved at ``approved``; the i-th gets promised date promises[i] (late ones get an early one)."""
    ids = [f"{prefix}{i:03d}" for i in range(len(promises))]
    doc = orders_doc(batch_id=batch_id, order_ids=ids, available_at=available_at)
    for row, promised in zip(doc["orders"], promises):
        row["approved_at"], row["promised_date"] = approved, promised
    return doc, ids


def _outcomes(batch_id, ids, delivered, known, available_at):
    return {"schema_version": "1.0", "batch_id": batch_id, "available_at": available_at, "kind": "outcomes",
            "outcomes": [{"order_id": oid, "delivered_at": delivered, "available_at": known} for oid in ids]}


@pytest.fixture
def history(conn):  # noqa: F811
    # 150 training orders (approved 04-10, delivered 04-20): promised 04-15 -> late (every 5th), else 04-25.
    train_doc, train_ids = _orders("orders-a", "t", "2017-04-10T12:00:00Z", "2017-04-15T00:00:00Z",
                                   ["2017-04-15" if i % 5 == 0 else "2017-04-25" for i in range(150)])
    # 150 validation orders (approved 05-10, delivered 05-20): promised 05-15 -> late, else 05-25.
    val_doc, val_ids = _orders("orders-b", "v", "2017-05-10T12:00:00Z", "2017-05-11T00:00:00Z",
                               ["2017-05-15" if i % 5 == 0 else "2017-05-25" for i in range(150)])
    ingest(conn, train_doc, as_of=AS_OF)
    ingest(conn, _outcomes("outcomes-a", train_ids, "2017-04-20T12:00:00Z", "2017-04-27T12:00:00Z",
                           "2017-04-28T00:00:00Z"), as_of=AS_OF)
    ingest(conn, val_doc, as_of=AS_OF)
    ingest(conn, _outcomes("outcomes-b", val_ids, "2017-05-20T12:00:00Z", "2017-05-27T12:00:00Z",
                           "2017-05-28T00:00:00Z"), as_of=AS_OF)
    return conn, train_ids, val_ids


def test_train_candidate_end_to_end(history):
    database, _, val_ids = history
    candidate = train_candidate(database, train_end=TRAIN_END, validation_end=VALIDATION_END, as_of=AS_OF)
    assert candidate.train_summary["n"] == 150 and candidate.train_summary["late"] == 30
    assert candidate.cohort.order_ids == sorted(val_ids)
    assert candidate.cohort.sha256 == cohorts.cohort_sha256(val_ids)
    # promise_days separates late from on-time perfectly here, so the candidate finds every late order.
    assert candidate.validation_metrics.recall_at_10 == 0.5  # K = 15 slots for 30 late orders
    assert candidate.validation_metrics.precision_at_10 == 1.0
    decision = compare_candidate(candidate, None, candidate.cohort)
    assert decision.decision == "accepted", decision.reasons


def test_validation_labels_not_yet_known_make_the_cohort_insufficient(history):
    database, *_ = history
    # as_of before the validation outcomes were known (05-27): no validation labels -> reported failure.
    with pytest.raises(cohorts.InsufficientCohort, match="validation cohort is insufficient"):
        train_candidate(database,train_end=TRAIN_END, validation_end="2017-05-25T00:00:00Z",
                        as_of="2017-05-26T00:00:00Z")


def test_training_labels_known_after_train_end_are_not_used(history):
    database, *_ = history
    # train_end before the training outcomes were known (04-27): no usable training labels.
    with pytest.raises(cohorts.InsufficientCohort, match="train cohort is insufficient"):
        train_candidate(database,train_end="2017-04-20T00:00:00Z", validation_end=VALIDATION_END, as_of=AS_OF)
