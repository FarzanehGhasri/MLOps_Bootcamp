"""JUnit reports retain every case, failure, and skip; no real-data performance is inferred."""

import pytest

from promiseops.verification import summarize_junit


def test_junit_counts_cases_and_preserves_names_status_and_duration():
    xml = '''<testsuites><testsuite tests="99"><testcase classname="a" name="one" time="0.25"/>
    <testcase classname="a" name="two"><failure>bad</failure></testcase>
    <testcase classname="b" name="three"><error>oops</error></testcase>
    <testcase classname="b" name="four"><skipped>no DB</skipped></testcase></testsuite></testsuites>'''
    report = summarize_junit(xml)
    assert report["total"] == 4  # count actual cases, not an inconsistent summary attribute
    assert [report[key] for key in ("passed", "failure", "error", "skipped")] == [1, 1, 1, 1]
    assert report["tests"][0] == {"name": "a::one", "status": "passed", "duration_seconds": 0.25}
    assert report["dataset_kind"] == "synthetic_software_tests"


@pytest.mark.parametrize("xml", ["<testsuites/>", "<testsuite tests='3'/> "])
def test_empty_test_reports_are_not_reported_as_success(xml):
    with pytest.raises(ValueError, match="no test cases"):
        summarize_junit(xml)
