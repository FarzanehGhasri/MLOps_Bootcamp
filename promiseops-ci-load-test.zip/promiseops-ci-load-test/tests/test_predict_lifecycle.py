import json
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from promiseops.api import create_app

REPO_ROOT = Path(__file__).resolve().parents[1]
RELEASE_MANIFEST = REPO_ROOT / "release" / "release.json"


@pytest.fixture
def configured_client(monkeypatch):
    monkeypatch.setenv("PROMISEOPS_API_KEY", "test-secret-key")
    monkeypatch.setenv("PROMISEOPS_RELEASE", str(RELEASE_MANIFEST))
    monkeypatch.delenv("PROMISEOPS_DATABASE_URL", raising=False)
    app = create_app()
    return TestClient(app), app


def test_fail_closed_when_api_key_unset(monkeypatch):
    monkeypatch.delenv("PROMISEOPS_API_KEY", raising=False)
    monkeypatch.setenv("PROMISEOPS_RELEASE", str(RELEASE_MANIFEST))
    monkeypatch.delenv("PROMISEOPS_DATABASE_URL", raising=False)
    client = TestClient(create_app())

    res = client.post("/predict", json={"order_id": "ord_1"}, headers={"X-API-Key": "secret"})
    assert res.status_code == 401

    metrics_res = client.get("/metrics", headers={"X-API-Key": "secret"})
    assert metrics_res.status_code == 401


def test_metrics_requires_valid_api_key(configured_client):
    client, _ = configured_client

    assert client.get("/metrics").status_code == 401
    assert client.get("/metrics", headers={"X-API-Key": "wrong-key"}).status_code == 401

    ok_res = client.get("/metrics", headers={"X-API-Key": "test-secret-key"})
    assert ok_res.status_code == 200
    assert "promiseops_http_requests_total" in ok_res.text


def test_503_when_bundle_missing_or_hash_mismatches(monkeypatch, tmp_path):
    monkeypatch.setenv("PROMISEOPS_API_KEY", "test-secret-key")
    monkeypatch.delenv("PROMISEOPS_DATABASE_URL", raising=False)
    headers = {"X-API-Key": "test-secret-key"}

    monkeypatch.setenv("PROMISEOPS_RELEASE", str(tmp_path / "nonexistent" / "release.json"))
    missing_client = TestClient(create_app())
    assert missing_client.get("/readyz").status_code == 503
    assert missing_client.post("/predict", json={"order_id": "ord_1"}, headers=headers).status_code == 503

    tampered_dir = tmp_path / "tampered"
    tampered_dir.mkdir()
    manifest_data = json.loads(RELEASE_MANIFEST.read_text(encoding="utf-8"))
    manifest_path = tampered_dir / "release.json"
    manifest_path.write_text(json.dumps(manifest_data), encoding="utf-8")
    (tampered_dir / "model.joblib").write_bytes(b"corrupted-model-bytes")

    monkeypatch.setenv("PROMISEOPS_RELEASE", str(manifest_path))
    tampered_client = TestClient(create_app())
    assert tampered_client.get("/readyz").status_code == 503
    assert tampered_client.post("/predict", json={"order_id": "ord_1"}, headers=headers).status_code == 503
