"""scripts/alert_evidence.py against a fake Prometheus HTTP API (no network)."""

import importlib.util
import json
from pathlib import Path

import pytest

_PATH = Path(__file__).resolve().parents[1] / "scripts" / "alert_evidence.py"
_SPEC = importlib.util.spec_from_file_location("alert_evidence", _PATH)
alert_evidence = importlib.util.module_from_spec(_SPEC)
_SPEC.loader.exec_module(alert_evidence)

COMMIT = "a" * 40
DIGEST = "sha256:" + "b" * 64
UP = 'up{job="g03-production"}'
ABSENT = f"absent({UP})"
ALERTS = 'ALERTS{alertname="APIUnavailable"}'
MODEL_INFO = 'promiseops_model_info{job="g03-production"} == 1'
READY = 'promiseops_ready{job="g03-production"}'
HISTORY = 'ALERTS{alertname="APIUnavailable"}[30m]'
T = 1795100000.0


def _sample(metric, value="1"):
    return {"metric": metric, "value": [T, value]}


def _state(*, firing, up_values=("1", "1"), model="ensemble-7"):
    """One Prometheus state: the rules API group and the result of every query the script sends."""
    alert = {"labels": {"alertname": "APIUnavailable", "job": "g03-production"}, "state": "firing",
             "activeAt": "2026-11-19T00:54:14Z", "value": "1e+00"}
    rule = {"name": "APIUnavailable", "query": f"{UP} == 0 or {ABSENT}", "duration": 120,
            "state": "firing" if firing else "inactive", "alerts": [alert] if firing else [], "type": "alerting"}
    pods = [{"job": "g03-production", "instance": f"10.0.0.{i}:8080"} for i in range(len(up_values))]
    return {
        "rules": {"groups": [{"name": "promiseops", "file": "/etc/prometheus/alerts.yaml", "rules": [rule]}]},
        UP: [_sample({"__name__": "up", **pod}, v) for pod, v in zip(pods, up_values, strict=True)],
        ABSENT: [_sample({"job": "g03-production"})] if not up_values else [],
        ALERTS: [_sample({"alertname": "APIUnavailable", "alertstate": "firing"})] if firing else [],
        MODEL_INFO: [_sample({"model_version": model, **pod}) for pod in pods],
        READY: [_sample(pod) for pod in pods],
        HISTORY: [{"metric": {"alertname": "APIUnavailable", "alertstate": "firing"},
                   "values": [[T - 600, "1"], [T - 300, "1"]]}],
    }


class _Prometheus:
    """A fake ``Get`` that serves a sequence of states, one per collect() pass."""

    def __init__(self, *states):
        self.states = list(states)
        self.calls = []

    def __call__(self, path, params):
        self.calls.append((path, params))
        state = self.states[0]
        if path == "/api/v1/rules":
            assert params == {"type": "alert"}
            return state["rules"]
        assert path == "/api/v1/query"
        query = params["query"]
        if query == HISTORY:
            result = state[HISTORY]
            if len(self.states) > 1:
                self.states.pop(0)   # HISTORY is the last query of a pass
            return {"resultType": "matrix", "result": result}
        return {"resultType": "vector", "result": state[query]}


def _main(tmp_path, prometheus, *extra, sleeps=None):
    out = tmp_path / "evidence.json"
    code = alert_evidence.main(
        ["--alert", "APIUnavailable", "--out", str(out), "--commit", COMMIT, "--image-digest", DIGEST, *extra],
        get=prometheus, sleep=(sleeps.append if sleeps is not None else lambda seconds: None))
    return code, out


def test_resolved_evidence_records_checks_deployment_and_last_firing(tmp_path):
    code, out = _main(tmp_path, _Prometheus(_state(firing=False)), "--expect", "resolved",
                      "--model-version", "ensemble-7")

    assert code == 0
    evidence = json.loads(out.read_text())
    assert evidence["observed_state"] == "inactive"
    assert all(item["ok"] for item in evidence["checks"])
    assert {item["check"] for item in evidence["checks"]} >= {"every API target is up", "absent(up) is empty",
                                                             "no ALERTS series", "served model version"}
    assert evidence["deployment"] == {"commit": COMMIT, "image_digest": DIGEST, "model_version": "ensemble-7",
                                      "served_model_versions": ["ensemble-7"]}
    assert evidence["lookback"]["last_firing_sample_at"] == "2026-11-19T14:48:20Z"   # T - 300
    assert evidence["staff_rule_group"]["rules"][0]["for_seconds"] == 120
    assert set(evidence["queries"]) == {UP, ABSENT, ALERTS, MODEL_INFO, READY}


def test_still_firing_writes_nothing_and_fails(tmp_path, capsys):
    code, out = _main(tmp_path, _Prometheus(_state(firing=True, up_values=())), "--expect", "resolved")

    assert code == 1
    assert not out.exists()
    assert "FAIL APIUnavailable is inactive: observed firing" in capsys.readouterr().err


def test_firing_evidence_matches_the_19_november_capture(tmp_path):
    code, out = _main(tmp_path, _Prometheus(_state(firing=True, up_values=())), "--expect", "firing")

    assert code == 0
    evidence = json.loads(out.read_text())
    assert evidence["queries"][UP] == []
    assert evidence["queries"][ABSENT][0]["metric"] == {"job": "g03-production"}
    assert evidence["staff_rule_group"]["rules"][0]["alerts"][0]["activeAt"] == "2026-11-19T00:54:14Z"


def test_a_target_down_is_not_resolved_even_if_the_rule_is_inactive(tmp_path):
    code, out = _main(tmp_path, _Prometheus(_state(firing=False, up_values=("1", "0"))), "--expect", "resolved")

    assert code == 1
    assert not out.exists()


def test_wrong_served_model_version_fails(tmp_path):
    code, _ = _main(tmp_path, _Prometheus(_state(firing=False, model="ensemble-6")), "--expect", "resolved",
                    "--model-version", "ensemble-7")

    assert code == 1


def test_wait_polls_until_resolved(tmp_path):
    sleeps = []
    prometheus = _Prometheus(_state(firing=True, up_values=()), _state(firing=False))

    code, out = _main(tmp_path, prometheus, "--expect", "resolved", "--wait", "600", sleeps=sleeps)

    assert code == 0
    assert json.loads(out.read_text())["observed_state"] == "inactive"
    assert sleeps == [alert_evidence.POLL_SECONDS]
    assert sum(path == "/api/v1/rules" for path, _ in prometheus.calls) == 2


@pytest.mark.parametrize("expect,extra", [
    ("firing", ["--commit", "abc123"]), ("firing", ["--image-digest", "sha256:xyz"]),
    ("resolved", ["--commit", COMMIT]), ("resolved", ["--image-digest", DIGEST])])
def test_malformed_or_missing_provenance_is_rejected(tmp_path, expect, extra):
    with pytest.raises(SystemExit) as exit_info:
        alert_evidence.main(["--alert", "APIUnavailable", "--expect", expect, "--out", str(tmp_path / "x"),
                             *extra], get=_Prometheus(_state(firing=True)))
    assert exit_info.value.code == 2
    assert not (tmp_path / "x").exists()


def test_auth_header_is_parsed_and_urls_lose_credentials():
    assert alert_evidence.parse_header("Cookie: _oauth2_proxy=secret") == ("Cookie", "_oauth2_proxy=secret")
    with pytest.raises(ValueError):
        alert_evidence.parse_header("no colon here")
    assert alert_evidence.public_url("https://user:pw@prom.example:9090/api?token=t#x") == \
        "https://prom.example:9090/api"


def test_auth_header_value_never_reaches_the_evidence(tmp_path, monkeypatch):
    monkeypatch.setenv("PROM_HEADER", "Cookie: _oauth2_proxy=topsecret")
    sent = []

    def fake_http_get(base, headers, timeout=20):
        sent.append(headers)
        return _Prometheus(_state(firing=False))

    monkeypatch.setattr(alert_evidence, "http_get", fake_http_get)
    out = tmp_path / "evidence.json"
    code = alert_evidence.main(["--alert", "APIUnavailable", "--expect", "resolved", "--out", str(out),
                                "--commit", COMMIT, "--image-digest", DIGEST, "--auth-header-env", "PROM_HEADER"],
                               sleep=lambda seconds: None)

    assert code == 0
    assert sent == [{"Cookie": "_oauth2_proxy=topsecret"}]
    assert "topsecret" not in out.read_text()
