"""API JSON logs reach stdout (container logs) once per event, at PROMISEOPS_LOG_LEVEL."""

import io
import json
import logging
import sys
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from promiseops.api import create_app
from promiseops.model import ConstantProbabilityEstimator

API_KEY = "logging-test-key"
LOGGER = logging.getLogger("promiseops.api")


def _remove_stdout_handlers() -> None:
    for handler in [h for h in LOGGER.handlers if getattr(h, "_promiseops_stdout", False)]:
        LOGGER.removeHandler(handler)
    LOGGER.setLevel(logging.NOTSET)


@pytest.fixture
def make_app(monkeypatch, tmp_path: Path):
    bundle_dir = tmp_path / "release"
    ConstantProbabilityEstimator(probability=0.2).build_mock_bundle(
        bundle_dir,
        model_version="logging-test-v1",
        features_path="contracts/features.json",
    )
    monkeypatch.setenv("PROMISEOPS_RELEASE", str(bundle_dir / "release.json"))
    monkeypatch.setenv("PROMISEOPS_API_KEY", API_KEY)
    monkeypatch.delenv("PROMISEOPS_DATABASE_URL", raising=False)
    monkeypatch.delenv("PROMISEOPS_LOG_LEVEL", raising=False)
    _remove_stdout_handlers()
    yield create_app
    _remove_stdout_handlers()


def _predict(app) -> None:
    # No database here, so /predict answers 503; its prediction log line is written either way.
    res = TestClient(app).post("/predict", headers={"X-API-Key": API_KEY}, json={"order_id": "ord_log_1"})
    assert res.status_code == 503


def _prediction_lines(out: str) -> list[dict]:
    lines = []
    for line in out.splitlines():
        try:
            entry = json.loads(line)  # the whole line must be JSON: no level/time prefix
        except ValueError:
            continue
        if isinstance(entry, dict) and entry.get("event") == "prediction":
            lines.append(entry)
    return lines


def test_prediction_log_line_reaches_stdout_as_json(make_app, capsys):
    _predict(make_app())

    lines = _prediction_lines(capsys.readouterr().out)
    assert len(lines) == 1
    entry = lines[0]
    assert {"request_id", "model_version", "status", "latency_ms"} <= entry.keys()
    assert entry["model_version"] == "logging-test-v1"
    assert entry["status"] == 503


def test_handler_added_once_across_app_factories(make_app, capsys):
    make_app()
    _predict(make_app())

    assert len(_prediction_lines(capsys.readouterr().out)) == 1
    assert sum(getattr(h, "_promiseops_stdout", False) for h in LOGGER.handlers) == 1


def test_level_from_env_suppresses_info(make_app, monkeypatch, capsys):
    make_app()  # default INFO first: a later app's level must win
    monkeypatch.setenv("PROMISEOPS_LOG_LEVEL", "warning")
    _predict(make_app())

    assert _prediction_lines(capsys.readouterr().out) == []
    assert LOGGER.level == logging.WARNING


@pytest.mark.parametrize("value", ["verbose", "", "NOTSET", "0", "-5"])
def test_invalid_level_falls_back_to_info(make_app, monkeypatch, capsys, value):
    # NOTSET would inherit root's WARNING under uvicorn and drop prediction logs again.
    monkeypatch.setenv("PROMISEOPS_LOG_LEVEL", value)
    app = make_app()

    assert LOGGER.level == logging.INFO
    _predict(app)
    assert len(_prediction_lines(capsys.readouterr().out)) == 1


@pytest.mark.parametrize(("value", "level", "logged"), [
    ("10", logging.DEBUG, 1), (" 20 ", logging.INFO, 1), ("30", logging.WARNING, 0), ("40", logging.ERROR, 0)])
def test_numeric_level(make_app, monkeypatch, capsys, value, level, logged):
    monkeypatch.setenv("PROMISEOPS_LOG_LEVEL", value)
    app = make_app()

    assert LOGGER.level == level
    _predict(app)
    assert len(_prediction_lines(capsys.readouterr().out)) == logged


def test_handler_writes_to_current_stdout_not_the_one_at_startup(make_app, monkeypatch):
    # pytest swaps sys.stdout per test; a handler bound at creation would keep a closed stream.
    app = make_app()
    replacement = io.StringIO()
    monkeypatch.setattr(sys, "stdout", replacement)
    _predict(app)

    assert len(_prediction_lines(replacement.getvalue())) == 1
