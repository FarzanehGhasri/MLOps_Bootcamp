import pandas as pd
import pytest
from test_bundle import lineage, write

from promiseops import bundle
from promiseops.contracts import digest
from promiseops.ml_diagnostics import maturity_report, quality_report
from promiseops.training_evidence import frame_fingerprint


def test_content_hash_is_order_invariant_but_detects_feature_and_label_changes():
    x = pd.DataFrame({"value": [1.0, 2.0]}, index=["a", "b"])
    y = pd.Series([False, True], index=x.index)
    original = frame_fingerprint(x, y)
    assert original == frame_fingerprint(x.iloc[::-1], y)
    changed = x.copy()
    changed.loc["a", "value"] += 1e-12
    assert original != frame_fingerprint(changed, y)
    assert original != frame_fingerprint(x, ~y)


def test_manifest_tampering_is_rejected_before_model_unpickle(tmp_path, monkeypatch):
    manifest = {"dataset_identity": "example", "train": {"row_count": 100}}
    write(tmp_path, lineage=lineage(dataset_manifest_sha256=digest(manifest)), dataset_manifest=manifest)
    bundle.read_bundle(tmp_path / "bundle")
    (tmp_path / "bundle" / "dataset_manifest.json").write_text("{}")
    monkeypatch.setattr(bundle.joblib, "load", lambda *args: pytest.fail("must not unpickle"))
    with pytest.raises(bundle.BundleError, match="dataset manifest"):
        bundle.read_bundle(tmp_path / "bundle")


def test_maturity_curve_uses_available_time_and_fixed_cohort_denominator():
    labels = pd.DataFrame({"order_id": ["a", "b"],
                           "approved_at": pd.to_datetime(["2017-01-01"] * 2, utc=True),
                           "label_available_at": pd.to_datetime(["2017-01-10", "2017-02-10"], utc=True),
                           "late": pd.array([False, True], dtype="boolean")})
    report = maturity_report(labels, approved_end="2017-01-02T00:00:00Z", as_of="2017-04-01T00:00:00Z", ages=(14, 60))
    assert report["complete_for_loaded_cohort"]
    assert report["maturation_curve"][0]["label_coverage"] == .5
    assert report["maturation_curve"][0]["under_reporting_bias"] == 1
    assert report["maturation_curve"][1]["gamma_late_label_coverage"] == 1
    labels.loc[1, "late"] = pd.NA
    assert maturity_report(labels, approved_end="2017-01-02T00:00:00Z", as_of="2017-04-01T00:00:00Z")["maturation_curve"][0]["gamma_late_label_coverage"] is None


def test_global_budget_and_within_slice_top10_are_explicitly_different():
    x = pd.DataFrame({"customer_state": ["SP"] * 100 + ["RJ"] * 100,
                      "primary_payment_type": ["card"] * 200, "promise_days": [10] * 200,
                      "interstate_fraction": [0.] * 200}, index=[f"o{i:03}" for i in range(200)])
    y = pd.Series([i % 4 == 0 for i in range(200)], index=x.index)
    risk = [i / 200 for i in range(200)]
    report = quality_report(x, y, risk)
    sp = next(row for row in report["slices"] if row["axis"] == "customer_state" and row["group"] == "SP")
    assert sp["sufficient"] and sp["global_budget_selected"] == 0
    assert sp["within_slice_top10_metrics"]["recall_at_10"] > 0
