"""Unique mature-order and label-validity boundaries for issue #26."""

import pandas as pd
import pytest
from test_monitor import AS_OF, outcomes, predictions, reference, report, stable  # noqa: F401


def test_duplicate_outcomes_are_rejected_even_below_metric_sample_floor(reference):  # noqa: F811
    preds = stable(n=15)
    labels = outcomes(preds)
    duplicated = pd.concat([labels, labels], ignore_index=True)
    with pytest.raises(ValueError, match="outcomes.*unique"):
        report(preds, duplicated, reference)


@pytest.mark.parametrize("invalid", ["False", "0", 2])
def test_invalid_labels_are_not_silently_converted_to_boolean(reference, invalid):  # noqa: F811
    preds = stable()
    labels = outcomes(preds).astype({"late": object})
    labels.loc[0, "late"] = invalid
    with pytest.raises(ValueError, match="binary labels"):
        report(preds, labels, reference)


@pytest.mark.parametrize("known_count", [99, 100])
def test_exact_maturity_floor_with_two_sufficient_drift_windows(reference, known_count):  # noqa: F811
    preds = pd.concat([
        predictions(100, days_ago_from=14, days_ago_to=7, prefix="p", promise_shift=40),
        predictions(100, days_ago_from=7, days_ago_to=0, prefix="c", promise_shift=40),
    ], ignore_index=True)
    labels = outcomes(preds)
    labels.loc[0, "late"] = True
    labels.loc[1, "late"] = False
    labels.loc[known_count:, "late"] = pd.NA
    result = report(pd.concat([preds, preds], ignore_index=True), labels, reference)
    assert result.counts["unique_orders"] == 200
    assert result.counts["duplicates_ignored"] == 200
    assert [w.unique_orders for w in result.windows] == [100, 100]
    assert result.persistent_drift
    assert result.labels.mature_orders == known_count
    assert result.labels.sufficient == (known_count == 100)
    assert result.retrain_recommended == (known_count == 100)
    assert result.labels.label_coverage == known_count / 200


def test_one_class_labels_suppress_retraining_despite_persistent_drift(reference):  # noqa: F811
    preds = pd.concat([
        predictions(100, days_ago_from=14, days_ago_to=7, prefix="p", promise_shift=40),
        predictions(100, days_ago_from=7, days_ago_to=0, prefix="c", promise_shift=40),
    ], ignore_index=True)
    labels = outcomes(preds)
    labels["late"] = False
    result = report(preds, labels, reference)
    assert result.persistent_drift and result.labels.mature_orders == 200
    assert not result.labels.sufficient and result.labels.metrics is None
    assert not result.retrain_recommended
    assert any("both classes" in reason for reason in result.reasons)
