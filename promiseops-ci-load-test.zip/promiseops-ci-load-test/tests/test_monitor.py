"""Monitoring without a database (runs in CI): PSI/TVD, reference, data quality (promiseops.drift) and
unique orders, windows, label maturity, retraining triggers and suppression (promiseops.monitor).

Run: $env:PYTHONPATH = "src"; python -m pytest tests/test_monitor.py -v
"""

from datetime import timedelta

import numpy as np
import pandas as pd
import pytest

from promiseops.bundle import CategoricalDistribution, EvaluationMetrics, NumericDistribution
from promiseops.contracts import instant
from promiseops.drift import build_reference, data_quality, numeric_distribution, psi, tvd
from promiseops.features import FEATURE_NAMES
from promiseops.monitor import MonitoringReport, build_report

AS_OF = instant("2018-06-01T00:00:00+00:00")
REFERENCE_METRICS = EvaluationMetrics(n=1000, prevalence=0.1, k=100, recall_at_10=0.30, precision_at_10=0.3,
                                      pr_auc=0.20, brier=0.08)


def features(n, rng, *, promise_shift=0.0, category="toys"):
    return pd.DataFrame({
        "item_count": rng.integers(1, 3, n).astype(float),
        "seller_count": np.ones(n),
        "total_price": rng.gamma(2, 60, n),
        "total_freight": rng.gamma(2, 10, n),
        "total_weight_g": rng.gamma(2, 800, n),
        "payment_total": rng.gamma(2, 70, n),
        "max_installments": rng.integers(0, 10, n).astype(float),
        "promise_days": rng.integers(10, 30, n).astype(float) + promise_shift,
        "approval_hour": rng.integers(0, 24, n).astype(float),
        "approval_weekday": rng.integers(0, 7, n).astype(float),
        "interstate_fraction": rng.choice([0.0, 1.0], n),
        "customer_state": rng.choice(["SP", "RJ", "MG"], n),
        "primary_seller_state": rng.choice(["SP", "PR"], n),
        "primary_category": rng.choice([category, "books"], n),
        "primary_payment_type": rng.choice(["credit_card", "boleto"], n),
    })[list(FEATURE_NAMES)]


@pytest.fixture(scope="module")
def reference():
    return build_reference(features(5000, np.random.default_rng(0)), REFERENCE_METRICS, "a" * 64)


def predictions(n, *, days_ago_from, days_ago_to, prefix, seed=1, version="lr-1", **shift):
    """``n`` predictions spread over (as_of - days_ago_from, as_of - days_ago_to]."""
    rng = np.random.default_rng(seed)
    frame = features(n, rng, **shift)
    span = (days_ago_from - days_ago_to) * 86400
    frame["predicted_at"] = [AS_OF - timedelta(days=days_ago_from) + timedelta(seconds=int(s))
                             for s in rng.integers(1, span, n)]
    frame["order_id"] = [f"{prefix}{i:05d}" for i in range(n)]
    # 10% high-risk orders (0.7), the rest low (0.02): with labels drawn from these probabilities the
    # model is both well ranked and calibrated (recall@10% ~ 0.8, Brier ~ 0.04).
    frame["risk_probability"] = np.where(rng.random(n) < 0.1, 0.7, 0.02)
    frame["model_version"] = version
    return frame


def outcomes(preds, *, informative=True, known_days_ago=1, seed=2):
    """Labels for ``preds``: informative = drawn from the predicted risk (a good, calibrated model);
    otherwise unrelated to the risk (the model has stopped working)."""
    rng = np.random.default_rng(seed)
    risk = preds["risk_probability"].to_numpy()
    late = rng.random(len(preds)) < (risk if informative else 0.15)
    return pd.DataFrame({"order_id": preds["order_id"], "late": pd.array(late, dtype="boolean"),
                         "label_available_at": AS_OF - timedelta(days=known_days_ago)})


# ----- drift scores -----------------------------------------------------------------------------
def test_psi_is_zero_for_the_same_distribution_and_grows_with_shift():
    ref = numeric_distribution(pd.Series(np.arange(1000, dtype=float)))
    assert psi(ref, np.arange(1000, dtype=float)) == pytest.approx(0, abs=1e-9)
    assert psi(ref, np.arange(1000, dtype=float) + 300) > 0.2


def test_values_outside_the_reference_range_fall_in_the_outer_bins():
    ref = NumericDistribution(edges=[0, 10, 20], proportions=[0.5, 0.5])
    assert psi(ref, [-100, 5, 15, 1000]) == pytest.approx(0, abs=1e-9)  # 2 below/at bin 1, 2 in bin 2


def test_tvd_examples():
    ref = CategoricalDistribution(proportions={"a": 0.5, "b": 0.5})
    assert tvd(ref, ["a", "b"]) == 0
    assert tvd(ref, ["a", "a"]) == pytest.approx(0.5)
    assert tvd(ref, ["new", "new"]) == pytest.approx(1.0)  # unseen categories count fully


def test_reference_handles_discrete_and_constant_features(reference):
    assert set(reference.numeric) | set(reference.categorical) == set(FEATURE_NAMES)
    assert len(reference.numeric["seller_count"].proportions) == 1          # constant -> one bin
    assert len(reference.numeric["item_count"].proportions) < 10            # repeated quantiles merged
    assert reference.validation_metrics == REFERENCE_METRICS


def test_data_quality_lists_missing_out_of_range_and_unseen_values(reference):
    rows = features(10, np.random.default_rng(5))
    rows.loc[0, "total_price"] = np.nan
    rows.loc[1, "total_price"] = 1e9                       # far above anything seen in training
    rows.loc[2:4, "primary_category"] = "new_category"     # 3 of 10 rows
    findings = data_quality(reference, rows)
    assert findings["total_price"] == {"missing": 0.1, "outside_training_range": 0.1}
    assert findings["primary_category"] == {"unseen_category": 0.3}
    assert "customer_state" not in findings                 # nothing to report


# ----- report -----------------------------------------------------------------------------------
def report(preds, outs, reference):
    result = build_report(preds, outs, reference, as_of=AS_OF)
    MonitoringReport.model_validate_json(result.model_dump_json())  # persisted as JSON by the worker
    return result


def stable(n=300):
    return pd.concat([predictions(n, days_ago_from=14, days_ago_to=7, prefix="p", seed=1),
                      predictions(n, days_ago_from=7, days_ago_to=0, prefix="c", seed=3)], ignore_index=True)


def test_no_drift_and_a_good_model_recommend_nothing(reference):
    preds = stable()
    result = report(preds, outcomes(preds), reference)
    assert [w.unique_orders for w in result.windows] == [300, 300]
    assert not result.persistent_drift and result.labels.sufficient
    assert result.labels.label_coverage == 1.0
    assert result.retrain_recommended is False, result.reasons
    assert result.reasons == []


def test_low_label_coverage_is_reported_as_a_warning(reference):
    preds = stable()
    labels = outcomes(preds)
    labels.loc[labels.index[:300], "late"] = pd.NA          # half the outcomes not known yet
    result = report(preds, labels, reference)
    assert result.labels.label_coverage == 0.5 and result.labels.sufficient
    assert any(reason.startswith("warning: only 50% of predicted orders have a known label")
               for reason in result.reasons)


def test_retries_and_future_predictions_do_not_count(reference):
    preds = stable()
    retries = preds.iloc[:50].copy()
    retries["predicted_at"] = retries["predicted_at"] + timedelta(minutes=5)
    future = predictions(20, days_ago_from=0, days_ago_to=-3, prefix="f")  # after as_of
    result = report(pd.concat([preds, retries, future], ignore_index=True), outcomes(preds), reference)
    assert result.counts == {"received": 670, "future_ignored": 20, "duplicates_ignored": 50, "unique_orders": 600}
    assert result.labels.mature_orders == 600


def test_small_windows_are_not_assessed(reference):
    preds = pd.concat([predictions(60, days_ago_from=14, days_ago_to=7, prefix="p", promise_shift=40),
                       predictions(60, days_ago_from=7, days_ago_to=0, prefix="c", promise_shift=40)])
    result = report(preds, outcomes(preds), reference)
    assert not any(w.sufficient for w in result.windows) and not result.persistent_drift
    assert any("drift not assessed" in reason for reason in result.reasons)


def test_drift_in_one_window_only_is_not_persistent(reference):
    preds = pd.concat([predictions(300, days_ago_from=14, days_ago_to=7, prefix="p"),
                       predictions(300, days_ago_from=7, days_ago_to=0, prefix="c", promise_shift=40)])
    result = report(preds, outcomes(preds), reference)
    assert result.windows[1].drifted == ["promise_days"] and result.windows[0].drifted == []
    assert not result.persistent_drift and not result.retrain_recommended
    assert any("not persistent" in reason for reason in result.reasons)


def test_persistent_drift_with_mature_labels_recommends_retraining(reference):
    preds = pd.concat([predictions(300, days_ago_from=14, days_ago_to=7, prefix="p", promise_shift=40),
                       predictions(300, days_ago_from=7, days_ago_to=0, prefix="c", promise_shift=40,
                                   category="garden")])
    result = report(preds, outcomes(preds), reference)
    assert result.persistent_features == ["promise_days"]  # primary_category drifted only in one window
    assert result.retrain_recommended
    assert any(reason.startswith("persistent drift with sufficient mature outcomes") for reason in result.reasons)


def test_insufficient_labels_suppress_retraining_even_with_persistent_drift(reference):
    preds = pd.concat([predictions(300, days_ago_from=14, days_ago_to=7, prefix="p", promise_shift=40),
                       predictions(300, days_ago_from=7, days_ago_to=0, prefix="c", promise_shift=40)])
    labels = outcomes(preds, known_days_ago=-1)  # outcomes only known AFTER as_of: not usable
    result = report(preds, labels, reference)
    assert result.persistent_drift and result.labels.mature_orders == 0
    assert result.retrain_recommended is False
    assert any(reason.startswith("retraining suppressed: 0 mature orders") for reason in result.reasons)


def test_quality_below_random_review_recommends_retraining(reference):
    preds = stable()
    labels = outcomes(preds, informative=False)  # labels unrelated to the risk: model is useless now
    result = report(preds, labels, reference)
    assert result.labels.sufficient and not result.persistent_drift
    assert result.retrain_recommended
    assert any("< 80% of reference" in reason for reason in result.reasons)


def test_only_predictions_within_60_days_and_the_latest_model_are_evaluated(reference):
    old = predictions(200, days_ago_from=90, days_ago_to=61, prefix="old")
    previous_model = predictions(150, days_ago_from=40, days_ago_to=20, prefix="v1", version="lr-0")
    preds = pd.concat([old, previous_model, stable()], ignore_index=True)
    result = report(preds, outcomes(preds), reference)
    assert result.labels.model_version == "lr-1"
    assert result.labels.predicted_orders == 600  # not the 61+ day old ones, not the older model
