"""An incumbent must not leak future training/selection knowledge into a replay."""

from types import SimpleNamespace

import pytest
from test_bundle import AS_OF, TRAIN_END, VALIDATION_END, lineage, write

from promiseops import cohorts, training

CUTOFFS = cohorts.Cutoffs(train_end=TRAIN_END, validation_end=VALIDATION_END, as_of=AS_OF)


@pytest.mark.parametrize("changes,field", [
    ({"train_end": "2017-11-01T00:00:00Z"}, "train_end"),
    ({"validation_end": "2018-01-01T00:00:00Z"}, "validation_end"),
    ({"as_of": "2018-02-01T00:00:00Z"}, "as_of"),
])
def test_future_champion_is_refused_before_any_fit(tmp_path, monkeypatch, changes, field):
    write(tmp_path, lineage=lineage(**changes))
    settings = training.TrainingSettings(source_commit="a" * 40, artifacts=tmp_path / "runs",
                                         incumbent=tmp_path / "bundle")
    fit_calls = []
    monkeypatch.setattr(training.model, "train_candidate", lambda *a, **kw: fit_calls.append(kw))
    params = {}
    client = SimpleNamespace(set_tag=lambda *a: None,
                             log_param=lambda run, name, value: params.update({name: value}))
    with pytest.raises(training.TrainingError, match=field + "="):
        training._train_in_run(None, client, settings, CUTOFFS, "guard-test")
    assert fit_calls == []
    assert "requested." + field in params and "champion." + field in params


def test_equal_cutoffs_allow_repeat_comparison(tmp_path):
    write(tmp_path)
    champion = training.load_champion(tmp_path / "bundle", tmp_path / "run")
    training.validate_champion_cutoffs(champion, CUTOFFS)


def test_older_champion_can_be_compared_on_later_window(tmp_path):
    write(tmp_path)
    champion = training.load_champion(tmp_path / "bundle", tmp_path / "run")
    later = cohorts.Cutoffs(train_end="2018-01-31T00:00:00Z", validation_end="2018-02-28T00:00:00Z",
                            as_of="2018-04-30T00:00:00Z")
    training.validate_champion_cutoffs(champion, later)


def test_first_candidate_still_uses_prevalence_baseline():
    baseline = training.IncumbentChampion(None, "baseline-constant-v1", "baseline")
    training.validate_champion_cutoffs(baseline, CUTOFFS)
