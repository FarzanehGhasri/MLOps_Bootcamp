import pytest
from fastapi.testclient import TestClient

from promiseops.api import create_app


@pytest.fixture
def client(monkeypatch):
    monkeypatch.setenv("PROMISEOPS_API_KEY", "test-secret-key")
    monkeypatch.delenv("PROMISEOPS_DATABASE_URL", raising=False)
    monkeypatch.delenv("PROMISEOPS_RELEASE", raising=False)
    app = create_app()
    return TestClient(app)

def test_v1_predict_unauthenticated(client):
    # Verify unauthenticated call to /v1/predict returns 401
    res_v1_unauth = client.post("/v1/predict", json={"order_id": "ord_1"})
    assert res_v1_unauth.status_code == 401

    # Verify legacy /predict behaves identically
    res_legacy_unauth = client.post("/predict", json={"order_id": "ord_1"})
    assert res_legacy_unauth.status_code == 401

def test_v1_predict_matches_legacy(client):
    headers = {"X-API-Key": "test-secret-key"}
    res_v1 = client.post("/v1/predict", json={"order_id": "ord_1"}, headers=headers)
    res_legacy = client.post("/predict", json={"order_id": "ord_1"}, headers=headers)
    assert res_v1.status_code == res_legacy.status_code
    assert res_v1.json() == res_legacy.json()
