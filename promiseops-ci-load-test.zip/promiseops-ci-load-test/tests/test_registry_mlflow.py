"""Registry versions and aliases (#20) against a REAL MLflow with a temporary SQLite store.

The last test is the issue's acceptance test: an alias moved AFTER a deploy changes nothing in the
running service. Nothing is sent to any server. Skipped when MLflow is not installed (CI test image).
"""

import numpy as np
import pytest
from fastapi.testclient import TestClient
from sklearn.dummy import DummyClassifier
from test_bundle import lineage, write

from promiseops import api, bundle, record, registry
from promiseops.tracking import TRAINING_EXPERIMENT, TrackingConfig, create_client, ensure_experiment

mlflow = pytest.importorskip("mlflow")
API_KEY = "test-key-registry"


@pytest.fixture
def client(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)  # SQLite backend writes artifacts under the current folder
    monkeypatch.setenv("MLFLOW_DISABLE_TELEMETRY", "true")
    return create_client(TrackingConfig(f"sqlite:///{(tmp_path / 'mlflow.db').as_posix()}"))


def logged_candidate(client, folder, late_share: int = 2) -> tuple[str, record.ModelRecord]:
    """One accepted candidate logged in its own run, like the worker does (#15, #16).

    ``late_share`` changes the fitted model, so every call can produce a different model (other SHA256).
    """
    run_id = client.create_run(ensure_experiment(client, TRAINING_EXPERIMENT)).info.run_id
    model = DummyClassifier(strategy="prior").fit(np.zeros((10, 1)), [0] * (10 - late_share) + [1] * late_share)
    write(folder, model=model, lineage=lineage(gate_decision="accepted", champion_model_version="baseline-x",
                                               mlflow_run_id=run_id))
    return run_id, record.log_record(client, run_id, folder / "bundle")


def test_accepted_candidate_becomes_a_version_with_its_identity(tmp_path, client):
    run_id, logged = logged_candidate(client, tmp_path / "a")
    version = registry.register_candidate(client, run_id, logged)

    assert (version.name, version.version, version.run_id) == (registry.REGISTERED_MODEL, "1", run_id)
    assert (version.model_version, version.artifact_sha256) == (logged.model_version, logged.artifact_sha256)
    stored = client.get_model_version(registry.REGISTERED_MODEL, "1")
    assert stored.source == f"runs:/{run_id}/bundle"
    assert stored.tags[registry.TAG_GATE_DECISION] == "accepted"


def test_retried_registration_does_not_create_a_second_version(tmp_path, client):
    run_id, logged = logged_candidate(client, tmp_path / "a")
    first = registry.register_candidate(client, run_id, logged)
    again = registry.register_candidate(client, run_id, logged)
    assert again == first
    assert len(client.search_model_versions(f"name = '{registry.REGISTERED_MODEL}'")) == 1


def test_alias_moves_and_reports_where_it_was(tmp_path, client):
    v1 = registry.register_candidate(client, *logged_candidate(client, tmp_path / "a", late_share=2))
    v2 = registry.register_candidate(client, *logged_candidate(client, tmp_path / "b", late_share=5))

    assert registry.alias_version(client, registry.ALIAS_CANDIDATE) is None
    assert registry.move_alias(client, registry.ALIAS_CANDIDATE, v1.version) is None
    assert registry.move_alias(client, registry.ALIAS_CANDIDATE, v2.version) == v1.version
    assert registry.alias_version(client, registry.ALIAS_CANDIDATE) == v2


def test_alias_cannot_point_at_a_version_registered_by_someone_else(tmp_path, client):
    run_id, _ = logged_candidate(client, tmp_path / "a")
    client.create_registered_model(registry.REGISTERED_MODEL)
    client.create_model_version(registry.REGISTERED_MODEL, f"runs:/{run_id}/bundle", run_id=run_id)  # no tags
    with pytest.raises(registry.RegistryError, match="not registered by PromiseOps"):
        registry.move_alias(client, registry.ALIAS_PRODUCTION, "1")


def test_download_gives_the_exact_bundle_and_never_overwrites(tmp_path, client):
    run_id, logged = logged_candidate(client, tmp_path / "a")
    version = registry.register_candidate(client, run_id, logged)

    downloaded = registry.download_version(client, version, tmp_path / "release")
    assert downloaded == logged
    assert bundle.sha256_file(tmp_path / "release" / bundle.MODEL_FILE) == version.artifact_sha256
    with pytest.raises(FileExistsError):
        registry.download_version(client, version, tmp_path / "release")


def test_download_refuses_a_bundle_that_does_not_match_the_version_tag(tmp_path, client):
    run_id, logged = logged_candidate(client, tmp_path / "a")
    version = registry.register_candidate(client, run_id, logged)
    client.set_model_version_tag(registry.REGISTERED_MODEL, version.version, registry.TAG_ARTIFACT_SHA256, "f" * 64)
    registry.move_alias(client, registry.ALIAS_CANDIDATE, version.version)
    tampered = registry.alias_version(client, registry.ALIAS_CANDIDATE)  # read back from MLflow
    assert tampered.artifact_sha256 == "f" * 64
    with pytest.raises(registry.RegistryError, match="does not match its SHA256 tag"):
        registry.download_version(client, tampered, tmp_path / "release")
    assert not (tmp_path / "release").exists()


def test_moving_an_alias_after_deploy_does_not_change_the_running_service(tmp_path, client, monkeypatch):
    """Issue #20 acceptance test."""
    from contextlib import nullcontext
    from types import SimpleNamespace

    from test_feature_study import sample

    # This test isolates immutable registry identity; real feature/DB parity is covered in
    # test_api_features_db. It must not need live PostgreSQL to test alias behavior.
    database = SimpleNamespace(execute=lambda *args: SimpleNamespace(fetchone=lambda: None), transaction=lambda: nullcontext())
    monkeypatch.setattr(api.db, "connect", lambda *args: nullcontext(database))
    monkeypatch.setattr(api.inference, "release_features", lambda *args, **kwargs: sample().loc[["o1"]])
    monkeypatch.setenv("PROMISEOPS_AS_OF", "2018-04-30T00:00:00Z")
    v1 = registry.register_candidate(client, *logged_candidate(client, tmp_path / "a", late_share=2))
    v2 = registry.register_candidate(client, *logged_candidate(client, tmp_path / "b", late_share=5))

    # Release (#19): the alias is resolved ONCE, by a human step, into a folder with a fixed SHA256.
    registry.move_alias(client, registry.ALIAS_PRODUCTION, v1.version)
    released = registry.download_version(client, registry.alias_version(client, registry.ALIAS_PRODUCTION),
                                         tmp_path / "image" / "release")
    # Deploy: the service starts from that folder (in the cluster: baked into the image by digest).
    monkeypatch.setenv("PROMISEOPS_RELEASE", str(tmp_path / "image" / "release"))
    monkeypatch.setenv("PROMISEOPS_API_KEY", API_KEY)
    service = TestClient(api.create_app())
    before = service.post("/predict", json={"order_id": "o1"}, headers={"X-API-Key": API_KEY}).json()
    assert before["model_version"] == released.model_version == v1.model_version

    # After deploy, someone moves both aliases to another model in MLflow.
    assert registry.move_alias(client, registry.ALIAS_PRODUCTION, v2.version) == v1.version
    registry.move_alias(client, registry.ALIAS_CANDIDATE, v2.version)

    # The running service is unchanged: same model, same answer, still ready.
    after = service.post("/predict", json={"order_id": "o1"}, headers={"X-API-Key": API_KEY}).json()
    assert after["model_version"] == before["model_version"]
    assert after["risk_probability"] == before["risk_probability"]
    assert service.get("/readyz").status_code == 200
    # Even a restart (new pod from the same image) keeps it: startup reads the folder, not the alias.
    restarted = TestClient(api.create_app())
    again = restarted.post("/predict", json={"order_id": "o1"}, headers={"X-API-Key": API_KEY}).json()
    assert again["model_version"] == v1.model_version != v2.model_version
