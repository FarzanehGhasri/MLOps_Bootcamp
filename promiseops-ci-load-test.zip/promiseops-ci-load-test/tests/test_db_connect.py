"""connect() accepts the platform's SQLAlchemy dialect-form DB secret.

The staff secret arrives as ``postgresql+psycopg://…``; libpq's conninfo parser only
understands the plain scheme, so ``connect`` must strip the driver suffix (regression
for the ingest DAG's ``missing "=" after "postgresql+psycopg://…"`` failure).
"""

from unittest.mock import MagicMock

import pytest

from promiseops import db


@pytest.mark.parametrize("url, expected", [
    ("postgresql+psycopg://app:secret@postgres/app", "postgresql://app:secret@postgres/app"),
    ("postgresql+psycopg://app:secret@postgres/app?options=-c%20statement_timeout%3D1000",
     "postgresql://app:secret@postgres/app?options=-c%20statement_timeout%3D1000"),
    ("postgresql://app:secret@postgres/app", "postgresql://app:secret@postgres/app"),
])
def test_connect_strips_dialect_scheme(url, expected, monkeypatch):
    captured = {}

    def fake_connect(conninfo, **kwargs):
        captured["conninfo"] = conninfo
        captured["kwargs"] = kwargs
        return MagicMock()

    monkeypatch.setattr(db.psycopg, "connect", fake_connect)
    db.connect(url)
    assert captured["conninfo"] == expected
    assert captured["kwargs"] == {"autocommit": True, "application_name": "promiseops"}
