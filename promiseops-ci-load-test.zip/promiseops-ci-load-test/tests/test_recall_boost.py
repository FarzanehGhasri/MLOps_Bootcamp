"""Comprehensive unit and integration tests for recall_boost module."""

import numpy as np
import pandas as pd
import pytest

from promiseops.features import CATEGORICAL_FEATURES, FEATURE_NAMES, NUMERIC_FEATURES
from promiseops.recall_boost import (
    FORBIDDEN_LEAKAGE_COLUMNS,
    BlendedProbabilityClassifier,
    audit_feature_drift,
    build_shallow_constrained_gbm,
    build_weighted_logistic_regression,
    engineer_boosted_features,
)


def _make_dummy_data(n=200, seed=123):
    rng = np.random.default_rng(seed)
    ids = [f"o_{i:05d}" for i in range(n)]
    c_states = rng.choice(["SP", "RJ", "MG", "BA"], n)
    s_states = rng.choice(["SP", "PR"], n)
    interstate = (c_states != s_states).astype(float)
    df = pd.DataFrame(
        {
            "item_count": rng.integers(1, 4, n).astype(float),
            "seller_count": np.ones(n),
            "total_price": rng.gamma(2, 60, n),
            "total_freight": rng.gamma(2, 10, n),
            "total_weight_g": rng.gamma(2, 800, n),
            "payment_total": rng.gamma(2, 70, n),
            "max_installments": rng.integers(1, 10, n).astype(float),
            "promise_days": rng.integers(5, 40, n).astype(float),
            "approval_hour": rng.integers(0, 24, n).astype(float),
            "approval_weekday": rng.integers(0, 7, n).astype(float),
            "interstate_fraction": interstate,
            "customer_state": c_states,
            "primary_seller_state": s_states,
            "primary_category": rng.choice(["toys", "books", "garden"], n),
            "primary_payment_type": rng.choice(["credit_card", "boleto"], n),
        },
        index=pd.Index(ids, name="order_id"),
    )[list(FEATURE_NAMES)]
    labels = rng.choice([True, False], p=[0.1, 0.9], size=n)
    return df, labels


def test_leakage_detection():
    df, _ = _make_dummy_data(10)
    out = engineer_boosted_features(df)
    assert not out.empty

    for forbidden in FORBIDDEN_LEAKAGE_COLUMNS:
        df_leak = df.copy()
        df_leak[forbidden] = "2018-01-01"
        with pytest.raises(ValueError, match="DATA LEAKAGE DETECTED"):
            engineer_boosted_features(df_leak)


def test_feature_drift_audit_independent_and_shifted():
    train_df, _ = _make_dummy_data(500, seed=10)
    val_df_stable, _ = _make_dummy_data(500, seed=20)
    audit_res = audit_feature_drift(train_df, val_df_stable)
    assert set(audit_res["numeric_psi"].keys()) == set(NUMERIC_FEATURES)
    assert set(audit_res["categorical_tvd"].keys()) == set(CATEGORICAL_FEATURES)
    # Stable distribution should have small PSI
    for v in audit_res["numeric_psi"].values():
        assert 0.0 <= v < 0.20

    # Test shifted data
    shifted_val = val_df_stable.copy()
    shifted_val["promise_days"] = shifted_val["promise_days"] * 5.0 + 50.0
    shifted_res = audit_feature_drift(train_df, shifted_val)
    assert shifted_res["numeric_psi"]["promise_days"] > 0.20


def test_blended_probability_classifier_batch_invariance():
    """Crucial: Tests Item 3 from review: singleton (N=1) must equal batch slice."""
    X, y = _make_dummy_data(300, seed=42)
    m1 = build_weighted_logistic_regression(class_weight=None, C=0.05)
    m2 = build_shallow_constrained_gbm(max_depth=2, min_samples_leaf=10, l2_reg=10.0, class_weight=None)
    ensemble = BlendedProbabilityClassifier(m1, m2, alpha=0.65)
    ensemble.fit(X, y)

    # Full batch predictions
    full_probs = ensemble.predict_proba(X)
    assert full_probs.shape == (300, 2)
    assert np.allclose(full_probs.sum(axis=1), 1.0)

    # Singleton predictions for individual orders
    for idx in [0, 15, 120, 299]:
        singleton_input = X.iloc[[idx]]
        singleton_prob = ensemble.predict_proba(singleton_input)
        assert singleton_prob.shape == (1, 2)
        # MUST BE EXACTLY IDENTICAL (invariant to other rows in batch)
        np.testing.assert_allclose(singleton_prob[0], full_probs[idx], rtol=1e-5, atol=1e-5)

    # Chunks prediction
    chunk_1 = ensemble.predict_proba(X.iloc[:50])
    np.testing.assert_allclose(chunk_1, full_probs[:50], rtol=1e-5, atol=1e-5)
