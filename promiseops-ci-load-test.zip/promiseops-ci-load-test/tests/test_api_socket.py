import pytest
from httpx import ASGITransport, AsyncClient

from promiseops.api import create_app


@pytest.fixture
def app(monkeypatch):
    monkeypatch.setenv("PROMISEOPS_API_KEY", "secret")
    monkeypatch.delenv("PROMISEOPS_DATABASE_URL", raising=False)
    return create_app()

@pytest.mark.anyio
async def test_healthz_endpoint(app):
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.get("/healthz")
        assert response.status_code == 200

@pytest.mark.anyio
async def test_readyz_requires_database(app, monkeypatch):
    def unavailable(*args, **kwargs):
        raise RuntimeError("Database unavailable")

    monkeypatch.setattr("promiseops.api.db.connect", unavailable)
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        res = await client.get("/readyz")
        assert res.status_code == 503

@pytest.mark.anyio
async def test_predict_auth_failure(app):
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        res = await client.post("/predict", json={"order_id": "ord_123"})
        assert res.status_code == 401

@pytest.mark.anyio
async def test_predict_schema_validation_failure(app):
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        res = await client.post(
            "/predict",
            headers={"X-API-Key": "secret"},
            json={"order_id": "ord_123", "unexpected_field": "error"},
        )
        assert res.status_code == 422


@pytest.mark.anyio
async def test_predict_without_database_returns_503(app, monkeypatch):
    def unavailable(*args, **kwargs):
        raise RuntimeError("Database unavailable")

    monkeypatch.setattr("promiseops.api.db.connect", unavailable)
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        res = await client.post(
            "/predict",
            headers={"X-API-Key": "secret"},
            json={"order_id": "ord_123"},
        )
        assert res.status_code == 503
