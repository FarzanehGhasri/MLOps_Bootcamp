"""Final test-period evaluation on PostgreSQL (+ a local SQLite MLflow for the optional logging).

Skipped without PROMISEOPS_TEST_DATABASE_URL. DROPS the schema (fixture from test_ingestion_db): use an
EMPTY database whose name ends in "_test", never the one holding the real feed.

Data: test_model_db.history (train April, validation May 2017) plus 150 TEST orders approved 2017-06-05,
released 06-16 (after the training as_of); 100 get their outcome by 06-20, the other 50 on 07-20.
"""

import json

import pytest
from test_ingestion_db import URL, conn, ingest  # noqa: F401  (conn is a pytest fixture)
from test_model_db import _orders, _outcomes, history  # noqa: F401  (history is a pytest fixture)
from test_training_db import CUTOFFS, client, settings, tracking_uri  # noqa: F401  (pytest fixtures)

from promiseops import data, evaluation, training

pytestmark = pytest.mark.skipif(not URL, reason="PROMISEOPS_TEST_DATABASE_URL is not set")
mlflow = pytest.importorskip("mlflow")

START, END = "2017-05-31T00:00:00Z", "2017-06-10T00:00:00Z"   # starts at the model's validation_end


def window(cutoff="2017-06-30T00:00:00Z", start=START):
    return evaluation.HoldoutWindow(start=start, end=END, label_cutoff=cutoff)


@pytest.fixture
def trained(tmp_path, history, client):  # noqa: F811
    database, *_ = history
    model = training.run_train(database, client, settings(tmp_path), cutoffs=CUTOFFS)   # before test data exists
    # New source receipts must arrive AFTER the frozen training snapshot. Backdating a newly
    # inserted receipt to before that as_of would change the model's recorded dataset identity.
    doc, ids = _orders("orders-c", "x", "2017-06-05T12:00:00Z", "2017-06-16T00:00:00Z",
                       ["2017-06-10" if i % 5 == 0 else "2017-06-25" for i in range(150)])
    ingest(database, doc, as_of="2017-08-01T00:00:00Z")
    ingest(database, _outcomes("outcomes-c1", ids[:100], "2017-06-15T12:00:00Z", "2017-06-19T12:00:00Z",
                               "2017-06-20T00:00:00Z"), as_of="2017-08-01T00:00:00Z")
    ingest(database, _outcomes("outcomes-c2", ids[100:], "2017-06-15T12:00:00Z", "2017-07-19T12:00:00Z",
                               "2017-07-20T00:00:00Z"), as_of="2017-08-01T00:00:00Z")
    return database, model, ids


def test_model_and_baseline_are_scored_on_the_mature_test_orders(trained):
    database, model, _ = trained
    result = evaluation.evaluate_bundle(database, model.bundle_path, window())

    assert (result.approved_orders, result.unlabeled_orders, result.model.n) == (150, 50, 100)
    assert result.model.prevalence == pytest.approx(0.2)            # every 5th of the 100 mature orders
    assert result.model_version == model.record.model_version
    assert result.training_run_id == model.run_id
    assert result.model_source_commit == model.record.manifest.source_commit
    assert result.training_dataset_identity == model.record.lineage.dataset_identity
    assert result.evaluation_dataset_identity == data.dataset_identity(database, as_of=window().label_cutoff)
    assert result.validation == model.record.lineage.validation_metrics
    assert result.training_prevalence == pytest.approx(0.2)         # training cohort of history: every 5th late
    assert result.model.recall_at_10 > result.baseline.recall_at_10  # the promise date separates late orders
    assert 0.0 <= result.mean_predicted_risk <= 1.0


def test_later_label_cutoff_includes_the_late_arriving_labels(trained):
    database, model, _ = trained
    result = evaluation.evaluate_bundle(database, model.bundle_path, window(cutoff="2017-07-31T00:00:00Z"))
    assert (result.unlabeled_orders, result.model.n) == (0, 150)


def test_changed_training_snapshot_is_refused(trained):
    database, model, _ = trained
    database.execute("UPDATE promiseops.ingest_batches SET payload_sha256 = %s WHERE batch_id = %s",
                     ("f" * 64, "orders-a"))
    with pytest.raises(evaluation.EvaluationError, match="dataset identity differs"):
        evaluation.evaluate_bundle(database, model.bundle_path, window())


def test_window_inside_the_validation_period_is_refused(trained):
    database, model, _ = trained
    with pytest.raises(evaluation.EvaluationError):
        evaluation.evaluate_bundle(database, model.bundle_path, window(start="2017-05-01T00:00:00Z"))


def test_command_logs_the_report_to_its_own_mlflow_run(tmp_path, trained, tracking_uri, client, capsys):  # noqa: F811
    _, model, _ = trained
    output = tmp_path / "test_evaluation.json"
    code = evaluation.main(["--bundle", str(model.bundle_path), "--test-start", START, "--test-end", END,
                            "--label-cutoff", "2017-06-30T00:00:00Z", "--output", str(output), "--log-to-mlflow"],
                           environ={"PROMISEOPS_DATABASE_URL": URL, "MLFLOW_TRACKING_URI": tracking_uri})
    assert code == 0
    summary = json.loads(capsys.readouterr().out.strip().splitlines()[-1])
    run = client.get_run(summary["mlflow_run_id"])
    assert run.info.status == "FINISHED"
    assert run.data.tags[evaluation.TAG_TRAINING_RUN] == model.run_id
    assert run.data.metrics["test_n"] == 100 and run.data.metrics["unlabeled_orders"] == 50
    saved = evaluation.HoldoutEvaluation.model_validate_json(output.read_text(encoding="utf-8"))
    assert saved.summary() == {key: summary[key] for key in saved.summary()}
