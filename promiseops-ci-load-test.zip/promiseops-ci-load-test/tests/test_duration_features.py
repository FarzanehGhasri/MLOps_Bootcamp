import numpy as np
import pandas as pd

from promiseops.duration_features import duration_stats


def test_future_and_same_time_outcomes_cannot_change_duration_features():
    groups = pd.DataFrame({"order_id": ["a", "b", "c"],
                           "approved_at": pd.to_datetime(["2017-01-01", "2017-01-10", "2017-02-01"], utc=True),
                           "seller": ["s"] * 3, "customer_state": ["SP"] * 3, "route": ["SP>SP"] * 3})
    labels = pd.DataFrame({"order_id": ["a", "b", "c"],
                           "delivered_at": pd.to_datetime(["2017-01-03", "2017-01-20", "2017-02-10"], utc=True),
                           "label_available_at": pd.to_datetime(["2017-01-10", "2017-01-27", "2017-02-17"], utc=True)})
    base = pd.DataFrame({"promise_days": [20., 20., 20.]}, index=["a", "b", "c"])
    x = duration_stats(groups, labels, base, freeze_at="2017-03-01T00:00:00Z")
    assert x.loc["b", "duration_global_mean"] == 15.  # a's outcome exactly equals b's approval: excluded
    labels.loc[2, "delivered_at"] = pd.Timestamp("2018-01-01", tz="UTC")
    pd.testing.assert_frame_equal(x, duration_stats(groups, labels, base, freeze_at="2017-03-01T00:00:00Z"))
    assert np.isfinite(x).all().all()
    frozen = duration_stats(groups, labels, base.loc[["c"]], freeze_at="2017-01-10T00:00:00Z")
    assert frozen.loc["c", "duration_global_mean"] == 15.
