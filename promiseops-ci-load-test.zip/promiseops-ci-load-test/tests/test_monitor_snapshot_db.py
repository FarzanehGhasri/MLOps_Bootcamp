"""Monitor queued-worker inputs from actual API snapshots, never retrospective predictions."""

import json
from pathlib import Path
from unittest.mock import Mock

import pytest
from test_api_features_db import client_for, trained_release  # noqa: F401
from test_ingestion_db import URL, conn, ingest  # noqa: F401
from test_model_db import AS_OF, history  # noqa: F401
from test_training_db import COMMIT, CUTOFFS, client, settings, tracking_uri  # noqa: F401

from promiseops import bundle, drift, monitor_train, prediction_history, training, worker

pytestmark = pytest.mark.skipif(not URL, reason="PROMISEOPS_TEST_DATABASE_URL is not set")
pytest.importorskip("mlflow")


@pytest.fixture
def monitored_release(trained_release):  # noqa: F811
    connection, candidate, release = trained_release
    reference = drift.build_reference(candidate.training_features, candidate.validation_metrics, candidate.cohort.sha256)
    (release / "reference.json").write_text(reference.model_dump_json())
    return connection, candidate, release


def recorded_prediction(monitored_release, monkeypatch):
    connection, candidate, release = monitored_release
    response = client_for(monkeypatch, release).post(
        "/predict", headers={"X-API-Key": "test-key"},
        json={"order_id": candidate.cohort.order_ids[0], "request_id": "monitor-auto-history"})
    assert response.status_code == 200, response.text
    return connection, release, response.json()


def test_monitor_exports_actual_snapshots_without_a_dag_file_path(monitored_release, monkeypatch, tmp_path, client):  # noqa: F811
    connection, release, prediction = recorded_prediction(monitored_release, monkeypatch)
    fit = Mock(side_effect=AssertionError("one label must never cause training"))
    monkeypatch.setattr(training, "run_train", fit)
    result = monitor_train.run_monitor_train(connection, client, settings(tmp_path, incumbent=release), cutoffs=CUTOFFS)
    assert result.record.status == "assessed" and not result.record.retrain_recommended
    fit.assert_not_called()
    run = client.get_run(result.monitoring_run_id)
    assert run.info.status == "FINISHED" and run.data.params["prediction_history_source"] == "database"
    saved = Path(client.download_artifacts(run.info.run_id, "prediction-history/prediction-history.jsonl", str(tmp_path)))
    assert bundle.sha256_file(saved) == result.record.prediction_history_sha256
    row = json.loads(saved.read_text())
    assert row["risk_probability"] == prediction["risk_probability"]
    original = prediction_history.export_history(connection, model_version=prediction["model_version"], as_of=AS_OF)
    assert row == original[0] and len(row) == 4 + 32


def test_empty_database_history_is_explicit_and_does_not_fit(monitored_release, monkeypatch, tmp_path, client):  # noqa: F811
    connection, _, release = monitored_release
    fit = Mock(side_effect=AssertionError("no history must never cause training"))
    monkeypatch.setattr(training, "run_train", fit)
    result = monitor_train.run_monitor_train(connection, client, settings(tmp_path, incumbent=release), cutoffs=CUTOFFS)
    assert result.record.status == "no_prediction_history" and result.training is None
    assert result.record.prediction_history_sha256 is None
    assert client.get_run(result.monitoring_run_id).data.params["prediction_history_source"] == "database"
    fit.assert_not_called()


def test_explicit_history_overrides_database_export(monitored_release, monkeypatch, tmp_path, client):  # noqa: F811
    connection, release, prediction = recorded_prediction(monitored_release, monkeypatch)
    rows = prediction_history.export_history(connection, model_version=prediction["model_version"], as_of=AS_OF)
    supplied = tmp_path / "supplied.jsonl"
    prediction_history.write_export(rows, supplied)
    export = Mock(side_effect=AssertionError("provided file must take precedence"))
    monkeypatch.setattr(prediction_history, "export_history", export)
    result = monitor_train.run_monitor_train(connection, client, settings(tmp_path, incumbent=release),
                                             cutoffs=CUTOFFS, prediction_history=supplied)
    assert result.record.status == "assessed"
    assert result.record.prediction_history_sha256 == bundle.sha256_file(supplied)
    assert client.get_run(result.monitoring_run_id).data.params["prediction_history_source"] == "provided_file"
    export.assert_not_called()


@pytest.mark.parametrize("failure", ["upload", "readback"])
def test_history_persistence_failure_cannot_publish_or_fit(monitored_release, monkeypatch, tmp_path, client, failure):  # noqa: F811
    connection, release, _ = recorded_prediction(monitored_release, monkeypatch)
    fit = Mock(side_effect=AssertionError("unpersisted history must never cause training"))
    monkeypatch.setattr(training, "run_train", fit)
    if failure == "upload":
        def fail(*a, **kw):
            raise OSError("snapshot upload unavailable")
        monkeypatch.setattr(client, "log_artifact", fail)
    else:
        download = client.download_artifacts
        wrong = tmp_path / "wrong.jsonl"
        wrong.write_text("tampered")
        def corrupt(run, artifact, destination):
            return str(wrong) if artifact.startswith("prediction-history/") else download(run, artifact, destination)
        monkeypatch.setattr(client, "download_artifacts", corrupt)
    with pytest.raises((OSError, training.TrainingError)):
        monitor_train.run_monitor_train(connection, client, settings(tmp_path, incumbent=release), cutoffs=CUTOFFS)
    fit.assert_not_called()
    experiment = client.get_experiment_by_name(monitor_train.MONITORING_EXPERIMENT)
    [run] = client.search_runs([experiment.experiment_id])
    assert run.info.status == "FAILED"
    assert connection.execute("SELECT count(*) FROM promiseops.monitoring_decisions").fetchone()[0] == 0


def test_worker_monitor_mode_needs_no_extra_history_environment(monitored_release, monkeypatch, tmp_path,
                                                               tracking_uri, capsys):  # noqa: F811
    _, release, _ = recorded_prediction(monitored_release, monkeypatch)
    env = {"PROMISEOPS_DATABASE_URL": URL, "MLFLOW_TRACKING_URI": tracking_uri, "CI_COMMIT_SHA": COMMIT,
           "PROMISEOPS_ARTIFACTS": str(tmp_path / "artifacts"), "PROMISEOPS_INCUMBENT": str(release)}
    args = ["--mode", "monitor-train", "--train-end", CUTOFFS.train_end.isoformat(),
            "--validation-end", CUTOFFS.validation_end.isoformat(), "--as-of", CUTOFFS.as_of.isoformat()]
    assert worker.main(args, environ=env) == 0
    result = json.loads(capsys.readouterr().out.strip().splitlines()[-1])
    assert result["monitoring_status"] == "assessed" and not result["trained"]
