"""Behavior tests for the model bundle format (see docs/decisions/0001-model-bundle-format.md).

Each test checks one rule from ADR 0001, so a failing test name tells you which rule broke.
Walkthrough (Persian): docs/model/01-bundle-format.fa.md

Run (Linux/WSL):          PYTHONPATH=src .venv/bin/pytest -q tests/test_bundle.py
Run (Windows PowerShell): $env:PYTHONPATH = "src"; .\\.venv\\Scripts\\python.exe -m pytest -q tests/test_bundle.py
One test, verbose:        add  -v -k round_trip

Expected: all passed. release.json is checked against the real API loader (promiseops.api, MR !3).
"""

import json
from datetime import UTC, datetime
from pathlib import Path

import numpy as np
import pytest
from sklearn.dummy import DummyClassifier

from promiseops import bundle as b

ROOT = Path(__file__).resolve().parents[1]
FEATURES = json.loads((ROOT / "contracts" / "features.json").read_text(encoding="utf-8"))
COMMIT = "a" * 40
COHORT = "c" * 64
LOADER_FIELDS = {"model_version", "feature_names", "artifact_sha256", "source_commit"}

TRAIN_END = datetime(2017, 10, 31, 23, 59, 59, tzinfo=UTC)
VALIDATION_END = datetime(2017, 12, 31, 23, 59, 59, tzinfo=UTC)
AS_OF = datetime(2018, 1, 1, tzinfo=UTC)


# ---------------------------------------------------------------- helpers to build valid inputs
def fitted_model() -> DummyClassifier:
    """Smallest real scikit-learn model: always predicts the training late-rate (20%)."""
    X = np.zeros((10, 1))
    y = np.array([0] * 8 + [1] * 2)
    return DummyClassifier(strategy="prior").fit(X, y)


def metrics(n: int = 100) -> b.EvaluationMetrics:
    return b.EvaluationMetrics(
        n=n, prevalence=0.1, k=b.top_k_size(n),
        recall_at_10=0.3, precision_at_10=0.3, pr_auc=0.25, brier=0.08,
    )


def lineage(**overrides) -> b.Lineage:
    values = {
        "approach": "baseline",
        "source_commit": COMMIT,
        "created_at": datetime(2026, 11, 11, tzinfo=UTC),
        "software_versions": b.collect_software_versions(),
        "dataset_identity": "receipts-sha256:" + "d" * 64,
        "feature_schema_sha256": b.feature_schema_sha256(FEATURES),
        "train_end": TRAIN_END,
        "validation_end": VALIDATION_END,
        "as_of": AS_OF,
        "training_label_cutoff": TRAIN_END,
        "validation_label_cutoff": AS_OF,
        "validation_cohort_sha256": COHORT,
        "validation_metrics": metrics(),
        "gate_decision": "not_evaluated",
    }
    values.update(overrides)
    return b.Lineage(**values)


def reference(cohort: str = COHORT) -> b.ValidationReference:
    return b.ValidationReference(
        validation_cohort_sha256=cohort,
        validation_metrics=metrics(),
        numeric={"total_price": b.NumericDistribution(edges=[0, 50, 100], proportions=[0.6, 0.4])},
        categorical={"customer_state": b.CategoricalDistribution(proportions={"SP": 0.7, "RJ": 0.3})},
    )


def write(tmp_path: Path, model=None, **overrides) -> b.ReleaseManifest:
    kwargs = {
        "approach": "baseline", "feature_names": FEATURES, "source_commit": COMMIT,
        "lineage": lineage(), "reference": reference(),
    }
    kwargs.update(overrides)
    return b.write_bundle(tmp_path / "bundle", model or fitted_model(), **kwargs)


# ---------------------------------------------------------------- serving manifest (API loader)
def test_round_trip_returns_same_model_and_documents(tmp_path):
    manifest = write(tmp_path)
    loaded = b.read_bundle(tmp_path / "bundle")

    assert loaded.manifest == manifest
    assert loaded.lineage == lineage()
    assert loaded.reference == reference()
    assert loaded.model.predict_proba(np.zeros((1, 1)))[0][1] == pytest.approx(0.2)


def test_release_json_has_exactly_the_api_loader_fields(tmp_path):
    write(tmp_path)
    release = json.loads((tmp_path / "bundle" / b.RELEASE_FILE).read_text(encoding="utf-8"))
    assert set(release) == LOADER_FIELDS


def test_bundle_is_loaded_by_the_api_loader(tmp_path):
    # The real reader: promiseops.api.load_bundle (MR !3) returns (None, None) on ANY problem,
    # so a non-None manifest proves the API would serve a bundle written by write_bundle.
    from promiseops import api

    manifest = write(tmp_path)
    served_manifest, served_model = api.load_bundle(str(tmp_path / "bundle"))
    assert served_manifest == manifest
    assert served_model.predict_proba(np.zeros((1, 1)))[0][1] == pytest.approx(0.2)


def test_incumbent_release_of_the_repo_can_be_a_champion():
    # release/ (the mock baseline from MR !3) has only the two serving files; the training worker
    # must still read it as the champion. Unpickling it needs promiseops.model.ConstantProbabilityEstimator.
    loaded = b.read_bundle(Path(__file__).resolve().parents[1] / "release")
    assert loaded.lineage is None and loaded.reference is None
    assert 0 <= loaded.model.predict_proba(np.zeros((2, 15)))[0][1] <= 1


def test_model_version_is_content_addressed(tmp_path):
    manifest = write(tmp_path)
    assert manifest.model_version == f"baseline-{manifest.artifact_sha256[:12]}"
    assert manifest.artifact_sha256 == b.sha256_file(tmp_path / "bundle" / b.MODEL_FILE)


# ---------------------------------------------------------------- integrity and immutability
def test_tampered_model_is_rejected_before_unpickling(tmp_path):
    write(tmp_path)
    with (tmp_path / "bundle" / b.MODEL_FILE).open("ab") as handle:
        handle.write(b"tampered")
    with pytest.raises(b.BundleError, match="SHA256"):
        b.read_bundle(tmp_path / "bundle")


def test_unknown_field_in_release_json_is_rejected(tmp_path):
    write(tmp_path)
    path = tmp_path / "bundle" / b.RELEASE_FILE
    release = json.loads(path.read_text(encoding="utf-8"))
    release["metrics"] = {"recall_at_10": 0.5}
    path.write_text(json.dumps(release), encoding="utf-8")
    with pytest.raises(b.BundleError, match="release.json"):
        b.read_bundle(tmp_path / "bundle")


def test_existing_bundle_is_never_overwritten(tmp_path):
    write(tmp_path)
    with pytest.raises(FileExistsError):
        write(tmp_path)


def test_failed_write_leaves_no_partial_bundle(tmp_path, monkeypatch):
    # Simulate a crash AFTER model.joblib was written but BEFORE the bundle is complete.
    def crash(_path):
        raise RuntimeError("simulated crash while hashing the model")

    monkeypatch.setattr(b, "sha256_file", crash)
    with pytest.raises(RuntimeError, match="simulated crash"):
        write(tmp_path)
    assert list(tmp_path.iterdir()) == []  # neither the bundle nor the hidden staging folder


def test_missing_model_file_is_reported(tmp_path):
    write(tmp_path)
    (tmp_path / "bundle" / b.MODEL_FILE).unlink()
    with pytest.raises(b.BundleError, match="missing"):
        b.read_bundle(tmp_path / "bundle")


# ---------------------------------------------------------------- incumbent / champion handling
def test_older_bundle_without_lineage_is_still_readable(tmp_path):
    # The current incumbent (mock baseline from MR !3) has only model.joblib + release.json.
    write(tmp_path)
    (tmp_path / "bundle" / b.LINEAGE_FILE).unlink()
    (tmp_path / "bundle" / b.REFERENCE_FILE).unlink()
    loaded = b.read_bundle(tmp_path / "bundle")
    assert loaded.lineage is None and loaded.reference is None


def test_copy_bundle_produces_verified_identical_copy(tmp_path):
    manifest = write(tmp_path)
    copied = b.copy_bundle(tmp_path / "bundle", tmp_path / "artifacts" / "champion")
    assert copied.manifest == manifest
    assert [p.name for p in (tmp_path / "artifacts").iterdir()] == ["champion"]  # no staging left


def test_copy_bundle_refuses_to_overwrite(tmp_path):
    write(tmp_path)
    (tmp_path / "taken").mkdir()
    with pytest.raises(FileExistsError):
        b.copy_bundle(tmp_path / "bundle", tmp_path / "taken")


# ---------------------------------------------------------------- lineage rules (time & identity)
def test_lineage_requires_ordered_cutoffs():
    with pytest.raises(ValueError, match="train_end < validation_end"):
        lineage(validation_end=TRAIN_END)


def test_training_labels_cannot_come_after_train_end():
    with pytest.raises(ValueError, match="training labels"):
        lineage(training_label_cutoff=VALIDATION_END)


def test_lineage_rejects_timestamps_without_timezone():
    with pytest.raises(ValueError):
        lineage(created_at=datetime(2026, 11, 11))


def test_documents_that_describe_different_models_are_rejected(tmp_path):
    with pytest.raises(ValueError, match="source_commit"):
        write(tmp_path, source_commit="b" * 40)
    with pytest.raises(ValueError, match="different validation cohorts"):
        write(tmp_path, reference=reference(cohort="e" * 64))
    with pytest.raises(ValueError, match="feature_schema"):
        write(tmp_path, feature_names=FEATURES[:-1])
    assert list(tmp_path.iterdir()) == []


# ---------------------------------------------------------------- metrics and reference schemas
@pytest.mark.parametrize(("n", "k"), [(1, 1), (9, 1), (10, 1), (11, 2), (30, 3), (101, 11)])
def test_top_k_size_uses_exact_ceiling(n, k):
    # 0.1 * 30 == 3.0000000000000004 in floating point; a float ceil would wrongly give 4.
    assert b.top_k_size(n) == k


def test_metrics_reject_inconsistent_k():
    with pytest.raises(ValueError, match="k must be"):
        b.EvaluationMetrics(
            n=30, prevalence=0.1, k=4, recall_at_10=0.3, precision_at_10=0.3, pr_auc=0.2, brier=0.1,
        )


def test_distributions_must_be_valid_proportions():
    with pytest.raises(ValueError, match="sum to 1"):
        b.NumericDistribution(edges=[0, 1, 2], proportions=[0.5, 0.6])
    with pytest.raises(ValueError, match="one value per bin"):
        b.NumericDistribution(edges=[0, 1, 2], proportions=[1.0])
    with pytest.raises(ValueError, match="strictly increasing"):
        b.NumericDistribution(edges=[0, 0, 2], proportions=[0.5, 0.5])
    with pytest.raises(ValueError, match="sum to 1"):
        b.CategoricalDistribution(proportions={"SP": 0.7})
