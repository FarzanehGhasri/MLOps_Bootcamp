"""Model record (#16) against a REAL MLflow (version of requirements-tracking.lock) with a temporary
SQLite store. Nothing is sent to any server. Skipped when MLflow is not installed (CI test image).
"""

import pytest
from test_bundle import lineage, write

from promiseops.record import (
    RecordError,
    find_runs_by_artifact,
    load_logged_record,
    load_record,
    log_record,
)
from promiseops.tracking import TRAINING_EXPERIMENT, TrackingConfig, create_client, ensure_experiment

mlflow = pytest.importorskip("mlflow")


@pytest.fixture
def client(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)  # SQLite backend writes artifacts under the current folder
    monkeypatch.setenv("MLFLOW_DISABLE_TELEMETRY", "true")
    return create_client(TrackingConfig(f"sqlite:///{(tmp_path / 'mlflow.db').as_posix()}"))


@pytest.fixture
def run_id(client):
    return client.create_run(ensure_experiment(client, TRAINING_EXPERIMENT)).info.run_id


def test_log_record_stores_everything_and_reads_it_back(tmp_path, client, run_id):
    write(tmp_path)
    logged = log_record(client, run_id, tmp_path / "bundle")
    assert logged == load_record(tmp_path / "bundle")

    data = client.get_run(run_id).data
    assert data.params == logged.mlflow_params()
    assert data.metrics == logged.mlflow_metrics()
    assert all(data.tags[key] == value for key, value in logged.mlflow_tags().items())
    files = {a.path for a in client.list_artifacts(run_id, "bundle")}
    assert files == {"bundle/model.joblib", "bundle/release.json", "bundle/lineage.json", "bundle/reference.json"}
    assert "record.json" in {a.path for a in client.list_artifacts(run_id)}


def test_model_is_found_again_from_its_sha256(tmp_path, client, run_id):
    write(tmp_path)
    logged = log_record(client, run_id, tmp_path / "bundle")
    experiment_id = client.get_run(run_id).info.experiment_id
    assert find_runs_by_artifact(client, logged.artifact_sha256, [experiment_id]) == [run_id]
    assert find_runs_by_artifact(client, "f" * 64, [experiment_id]) == []
    assert load_logged_record(client, run_id) == logged  # identify: the exact same model and record


def test_bundle_claiming_another_run_is_refused(tmp_path, client, run_id):
    write(tmp_path, lineage=lineage(mlflow_run_id="someotherrun"))
    with pytest.raises(RecordError, match="refusing to log"):
        log_record(client, run_id, tmp_path / "bundle")
    assert client.get_run(run_id).data.params == {}  # nothing was logged


def test_bundle_naming_this_run_is_accepted(tmp_path, client, run_id):
    write(tmp_path, lineage=lineage(mlflow_run_id=run_id))
    assert log_record(client, run_id, tmp_path / "bundle").lineage.mlflow_run_id == run_id


def test_artifacts_that_do_not_match_the_run_tag_are_detected(tmp_path, client, run_id):
    write(tmp_path)
    log_record(client, run_id, tmp_path / "bundle")
    client.set_tag(run_id, "promiseops.artifact_sha256", "f" * 64)  # simulate swapped artifacts
    with pytest.raises(RecordError, match="does not match the run's SHA256 tag"):
        load_logged_record(client, run_id)


def test_run_without_a_record_is_reported(client, run_id):
    with pytest.raises(RecordError, match="no model record"):
        load_logged_record(client, run_id)
