"""promiseops.tracking against a REAL MLflow (version of requirements-tracking.lock), with a throw-away
SQLite backend in a temporary folder. Nothing is sent to any server.

Skipped when MLflow is not installed (the CI test image installs only requirements.lock). Run locally:

    pip install -c <constraints from requirements-tracking.lock> mlflow==3.17.2
    PYTHONPATH=src pytest tests/test_tracking_mlflow.py -v
"""

import json

import pytest

from promiseops import tracking  # does not import MLflow itself
from promiseops.tracking import (
    SMOKE_EXPERIMENT,
    TrackingConfig,
    TrackingError,
    create_client,
    ensure_experiment,
    smoke_check,
)

mlflow = pytest.importorskip("mlflow")

COMMIT = "0123456789abcdef0123456789abcdef01234567"


@pytest.fixture
def config(tmp_path, monkeypatch):
    # With a SQLite backend MLflow puts artifacts under ./mlartifacts or ./mlruns of the CURRENT folder:
    # run inside tmp_path so nothing is written into the repository.
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("MLFLOW_DISABLE_TELEMETRY", "true")
    return TrackingConfig(f"sqlite:///{(tmp_path / 'mlflow.db').as_posix()}", SMOKE_EXPERIMENT)


def test_ensure_experiment_is_idempotent(config):
    client = create_client(config)
    first = ensure_experiment(client, "promiseops-test")
    assert ensure_experiment(client, "promiseops-test") == first
    assert len([e for e in client.search_experiments() if e.name == "promiseops-test"]) == 1


def test_deleted_experiment_is_reported_not_recreated(config):
    client = create_client(config)
    client.delete_experiment(ensure_experiment(client, "promiseops-test"))
    with pytest.raises(TrackingError, match="deleted"):
        ensure_experiment(client, "promiseops-test")


def test_smoke_check_logs_and_reads_back_everything(config):
    result = smoke_check(config, source_commit=COMMIT)
    run = create_client(config).get_run(result.run_id)
    assert run.info.status == "FINISHED"
    assert run.data.params == {"check": "tracking-smoke"}
    assert run.data.metrics == {"smoke_value": 1.0}
    assert run.data.tags["promiseops.kind"] == "smoke"
    assert run.data.tags["promiseops.source_commit"] == COMMIT
    assert run.data.tags["mlflow.source.git.commit"] == COMMIT
    assert [a.path for a in create_client(config).list_artifacts(result.run_id)] == ["smoke.txt"]


def test_smoke_check_twice_reuses_the_experiment(config):
    first, second = smoke_check(config), smoke_check(config)
    assert first.experiment_id == second.experiment_id
    assert first.run_id != second.run_id


@pytest.mark.parametrize("finish_raises", [True, False])
def test_smoke_requires_persisted_finished_status(config, monkeypatch, finish_raises):
    client = create_client(config)
    original = client.set_terminated
    failures = []

    def terminate(run_id, status):
        if status == "FINISHED":
            if finish_raises:
                raise RuntimeError("final status update failed")
            return None  # Simulate a server acknowledging without persisting the update.
        failures.append(run_id)
        return original(run_id, status)

    monkeypatch.setattr(client, "set_terminated", terminate)
    with pytest.raises(TrackingError, match="status"):
        smoke_check(config, client=client)
    assert len(failures) == 1
    assert client.get_run(failures[0]).info.status == "FAILED"


def test_failed_logging_marks_the_run_failed(config, monkeypatch):
    client = create_client(config)

    def broken_artifact(*args, **kwargs):
        raise OSError("artifact store is read-only")

    monkeypatch.setattr(client, "log_artifact", broken_artifact)
    with pytest.raises(TrackingError, match="artifact store"):
        smoke_check(config, client=client)
    [run] = client.search_runs([ensure_experiment(client, SMOKE_EXPERIMENT)])
    assert run.info.status == "FAILED"


def test_client_sends_the_configured_host_header(config, monkeypatch):
    # MLflow resolves extra headers only through its request-header provider registry
    # (mlflow/utils/rest_utils.py); create_client registers a provider reading MLFLOW_HOST_HEADER.
    monkeypatch.setenv("MLFLOW_HOST_HEADER", "g03-mlflow.mlops.qbootcamp.ir")
    create_client(config)
    from mlflow.tracking.request_header.registry import resolve_request_headers
    assert resolve_request_headers()["Host"] == "g03-mlflow.mlops.qbootcamp.ir"


def test_check_command_prints_the_run(config, monkeypatch, capsys):
    monkeypatch.setenv("MLFLOW_TRACKING_URI", config.tracking_uri)
    monkeypatch.setenv("CI_COMMIT_SHA", COMMIT)
    assert tracking.main(["check"]) == 0
    result = json.loads(capsys.readouterr().out)
    assert result["status"] == "ok" and result["experiment"] == SMOKE_EXPERIMENT
    assert result["source_commit"] == COMMIT
