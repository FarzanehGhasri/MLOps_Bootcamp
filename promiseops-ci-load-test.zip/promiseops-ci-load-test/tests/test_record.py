"""Model record (#16) without MLflow: contract coverage, consistency checks, reproduction, MLflow mapping.

MLflow-backed tests: tests/test_record_mlflow.py (skipped when MLflow is not installed).
Run: $env:PYTHONPATH = "src"; python -m pytest tests/test_record.py -v
"""

import json
import os
import subprocess
import sys

import pytest
from test_bundle import COHORT, COMMIT, FEATURES, ROOT, lineage, write

from promiseops import bundle as b
from promiseops.record import (
    ModelRecord,
    RecordError,
    find_runs_by_artifact,
    load_record,
)


@pytest.fixture
def record(tmp_path):
    write(tmp_path)
    return load_record(tmp_path / "bundle")


def test_record_covers_every_item_of_the_contract(tmp_path, record):
    # docs/CONTRACTS.md "Evaluation and release": each item must be present and non-empty.
    lin = record.lineage
    items = {
        "model artifact SHA256": record.artifact_sha256,
        "immutable model identity": record.model_version,
        "source commit": record.manifest.source_commit,
        "software versions": lin.software_versions,
        "dataset identity": lin.dataset_identity,
        "schema identity": lin.feature_schema_sha256,
        "train/evaluation cutoffs": (lin.train_end, lin.validation_end, lin.as_of),
        "label cutoff": (lin.training_label_cutoff, lin.validation_label_cutoff),
        "cohort hash": lin.validation_cohort_sha256,
        "metrics": lin.validation_metrics,
        "gate decision": lin.gate_decision,
    }
    assert all(items.values()), [name for name, value in items.items() if not value]
    # "identify": the SHA256 in the record is the SHA256 of the model file itself.
    assert record.artifact_sha256 == b.sha256_file(tmp_path / "bundle" / b.MODEL_FILE)
    assert record.model_version == f"baseline-{record.artifact_sha256[:12]}"


def test_worker_command_reproduces_the_training_call(record):
    assert record.worker_command() == [
        "python", "-m", "promiseops.worker", "--mode", "train",
        "--train-end", "2017-10-31T23:59:59Z", "--validation-end", "2017-12-31T23:59:59Z",
        "--as-of", "2018-01-01T00:00:00Z",
    ]


def test_bundle_without_lineage_has_no_record(tmp_path):
    write(tmp_path)
    (tmp_path / "bundle" / b.LINEAGE_FILE).unlink()  # e.g. the mock baseline: servable, not auditable
    with pytest.raises(RecordError, match="not auditable"):
        load_record(tmp_path / "bundle")


def _edit(path, **changes):
    document = json.loads(path.read_text(encoding="utf-8"))
    document.update(changes)
    path.write_text(json.dumps(document), encoding="utf-8")


def test_lineage_from_another_commit_is_refused(tmp_path):
    write(tmp_path)
    _edit(tmp_path / "bundle" / b.LINEAGE_FILE, source_commit="b" * 40)
    with pytest.raises(RecordError, match="different source commits"):
        load_record(tmp_path / "bundle")


def test_lineage_for_another_feature_list_is_refused(tmp_path):
    write(tmp_path)
    _edit(tmp_path / "bundle" / b.LINEAGE_FILE, feature_schema_sha256=b.feature_schema_sha256(FEATURES[:-1]))
    with pytest.raises(RecordError, match="feature_schema_sha256"):
        load_record(tmp_path / "bundle")


def test_lineage_for_another_approach_is_refused(tmp_path):
    write(tmp_path)
    _edit(tmp_path / "bundle" / b.LINEAGE_FILE, approach="logistic_regression")
    with pytest.raises(RecordError, match="approach"):
        load_record(tmp_path / "bundle")


def test_mlflow_params_hold_the_fixed_training_facts(record):
    params = record.mlflow_params()
    assert params["train_end"] == "2017-10-31T23:59:59Z"
    assert params["validation_end"] == "2017-12-31T23:59:59Z"
    assert params["as_of"] == "2018-01-01T00:00:00Z"
    assert params["training_label_cutoff"] == "2017-10-31T23:59:59Z"
    assert params["validation_label_cutoff"] == "2018-01-01T00:00:00Z"
    assert params["dataset_identity"] == "receipts-sha256:" + "d" * 64
    assert params["validation_cohort_sha256"] == COHORT
    assert params["feature_count"] == str(len(FEATURES))
    assert params["software.scikit-learn"] == record.lineage.software_versions["scikit-learn"]
    assert all(isinstance(value, str) for value in params.values())


def test_mlflow_metrics_are_the_validation_metrics(record):
    assert record.mlflow_metrics() == {
        "validation_n": 100.0, "validation_prevalence": 0.1, "validation_k": 10.0,
        "validation_recall_at_10": 0.3, "validation_precision_at_10": 0.3,
        "validation_pr_auc": 0.25, "validation_brier": 0.08,
    }


def test_mlflow_tags_identify_the_model_and_carry_the_gate(tmp_path):
    write(tmp_path, lineage=lineage(gate_decision="rejected", gate_reasons=["recall@10% decreased"],
                                    champion_model_version="baseline-0123456789ab"))
    tags = load_record(tmp_path / "bundle").mlflow_tags()
    assert tags["promiseops.kind"] == "train"
    assert tags["promiseops.source_commit"] == COMMIT
    assert tags["promiseops.artifact_sha256"] == b.sha256_file(tmp_path / "bundle" / b.MODEL_FILE)
    assert tags["promiseops.gate_decision"] == "rejected"
    assert tags["promiseops.gate_reasons"] == "recall@10% decreased"
    assert tags["promiseops.champion_model_version"] == "baseline-0123456789ab"


def test_record_json_round_trips_and_includes_the_command(record):
    document = json.loads(record.to_json())
    assert document["worker_command"] == record.worker_command()
    del document["worker_command"]  # derived, not stored state
    assert ModelRecord.model_validate(document) == record


def test_find_runs_refuses_a_malformed_sha_before_searching():
    class NoSearch:
        def search_runs(self, *args, **kwargs):
            raise AssertionError("must not search")

    for bad in ("abc", "' OR 1=1 --", "A" * 64, None):
        with pytest.raises(RecordError):
            find_runs_by_artifact(NoSearch(), bad, ["1"])


def test_importing_record_does_not_import_mlflow():
    code = "import sys, promiseops.record; print('mlflow' in sys.modules)"
    env = {key: value for key, value in os.environ.items() if key in ("PATH", "SYSTEMROOT")}
    env["PYTHONPATH"] = str(ROOT / "src")
    result = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, check=True, env=env)
    assert result.stdout.strip() == "False"
