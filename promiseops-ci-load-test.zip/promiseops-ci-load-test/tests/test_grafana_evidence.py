"""scripts/grafana_evidence.py against fake Grafana responses built from deploy/grafana (no network)."""

import copy
import hashlib
import importlib.util
import json
import sys
from pathlib import Path

import pytest
import yaml

_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_ROOT / "scripts"))   # the script imports helpers from scripts/alert_evidence.py
_SPEC = importlib.util.spec_from_file_location("grafana_evidence", _ROOT / "scripts" / "grafana_evidence.py")
grafana_evidence = importlib.util.module_from_spec(_SPEC)
_SPEC.loader.exec_module(grafana_evidence)

COMMIT = "c" * 40
DASHBOARD = json.loads((_ROOT / grafana_evidence.DASHBOARD_FILE).read_text(encoding="utf-8"))
[GROUP] = yaml.safe_load((_ROOT / grafana_evidence.RULES_FILE).read_text(encoding="utf-8"))["groups"]


def _live(state="Normal (NoData)", health="ok"):
    """What Grafana returns after importing the two files: their content plus Grafana's own fields."""
    rules = []
    for number, rule in enumerate(copy.deepcopy(GROUP["rules"]), start=1):
        for query in rule["data"]:
            query["queryType"] = ""
            query["model"].setdefault("intervalMs", 1000)
        rules.append({**rule, "id": number, "orgID": 1, "folderUID": "promiseops", "ruleGroup": GROUP["name"],
                      "updated": "2026-11-16T21:57:00Z", "isPaused": False, "record": None})
    states = [{"uid": r["uid"], "name": r["title"], "state": "inactive", "health": health,
               "lastEvaluation": "2026-11-20T09:47:00Z", "alerts": [{"state": state}]} for r in rules]
    return {
        grafana_evidence.PATHS["dashboard"]: {
            "dashboard": {**copy.deepcopy(DASHBOARD), "id": 7, "version": 2},
            "meta": {"updated": "2026-11-19T12:53:02Z", "folderTitle": "General",
                     "url": "/d/promiseops-service/promiseops-e28094-service"}},
        grafana_evidence.PATHS["rules"]: rules,
        grafana_evidence.PATHS["states"]: {"status": "success", "data": {"groups": [
            {"name": GROUP["name"], "file": "PromiseOps", "interval": 60, "rules": states}]}},
    }


def _main(tmp_path, responses, *extra):
    out = tmp_path / "grafana.json"
    code = grafana_evidence.main(["--commit", COMMIT, "--out", str(out), *extra], get=responses.__getitem__)
    return code, out


def test_matching_grafana_writes_evidence_with_file_digests_and_rule_states(tmp_path):
    code, out = _main(tmp_path, _live())

    assert code == 0
    evidence = json.loads(out.read_text(encoding="utf-8"))
    assert all(item["ok"] for item in evidence["checks"])
    assert evidence["repo"] == {"commit": COMMIT, "files_sha256": {
        path: hashlib.sha256((_ROOT / path).read_bytes()).hexdigest()
        for path in (grafana_evidence.DASHBOARD_FILE, grafana_evidence.RULES_FILE)}}
    assert evidence["dashboard"]["version"] == 2
    assert len(evidence["dashboard"]["panels"]) == len(DASHBOARD["panels"])
    assert [r["uid"] for r in evidence["rules"]] == [r["uid"] for r in GROUP["rules"]]
    assert {r["instances"][0] for r in evidence["rules"]} == {"Normal (NoData)"}


@pytest.mark.parametrize(("change", "failing_check"), [
    ("panel query", "dashboard"), ("dashboard title", "dashboard"), ("rule threshold", "rules"),
    ("rule label", "rules"), ("rule missing", "rules"), ("extra rule in group", "rules")])
def test_any_difference_from_the_repo_files_writes_nothing(tmp_path, capsys, change, failing_check):
    live = _live()
    board = live[grafana_evidence.PATHS["dashboard"]]["dashboard"]
    rules = live[grafana_evidence.PATHS["rules"]]
    states = live[grafana_evidence.PATHS["states"]]["data"]["groups"][0]["rules"]
    if change == "panel query":
        board["panels"][0]["targets"][0]["expr"] = "vector(1)"
    elif change == "dashboard title":
        board["title"] = "edited in the UI"
    elif change == "rule threshold":
        rules[0]["data"][1]["model"]["conditions"][0]["evaluator"]["params"] = [0.5]
    elif change == "rule label":
        rules[1]["labels"]["severity"] = "info"
    elif change == "rule missing":
        rules.pop()
        states.pop()
    else:   # added in the UI: evaluates fine, but is not in the file
        rules.append({**copy.deepcopy(rules[0]), "uid": "added-in-the-ui"})
        states.append({**states[0], "uid": "added-in-the-ui"})

    code, out = _main(tmp_path, live)

    assert code == 1
    assert not out.exists()
    failed = [line for line in capsys.readouterr().err.splitlines() if line.startswith("FAIL")]
    assert [line.split()[1] for line in failed] == [failing_check]


def test_a_rule_that_cannot_evaluate_fails(tmp_path):
    code, out = _main(tmp_path, _live(health="error"))

    assert code == 1 and not out.exists()


def test_saved_responses_keep_their_capture_time(tmp_path):
    saved = tmp_path / "responses.json"
    saved.write_text(json.dumps({"captured_at_utc": "2026-11-20T09:48:33.174Z", "responses": _live()}))
    out = tmp_path / "grafana.json"

    code = grafana_evidence.main(["--commit", COMMIT, "--out", str(out), "--responses", str(saved)])

    assert code == 0
    evidence = json.loads(out.read_text(encoding="utf-8"))
    assert evidence["captured_at_utc"] == "2026-11-20T09:48:33.174Z"
    assert evidence["source"].startswith("saved Grafana API responses (responses.json)")


def test_commit_must_be_a_full_sha(tmp_path):
    with pytest.raises(SystemExit) as exit_info:
        grafana_evidence.main(["--commit", "abc123", "--out", str(tmp_path / "x")], get=_live().__getitem__)
    assert exit_info.value.code == 2


def test_auth_header_value_never_reaches_the_evidence(tmp_path, monkeypatch):
    monkeypatch.setenv("GRAFANA_HEADER", "Cookie: _oauth2_proxy=topsecret")
    sent = []

    def fake_http_get(base, headers, timeout=20):
        sent.append(headers)
        return _live().__getitem__

    monkeypatch.setattr(grafana_evidence, "http_get", fake_http_get)
    out = tmp_path / "grafana.json"
    code = grafana_evidence.main(["--commit", COMMIT, "--out", str(out), "--auth-header-env", "GRAFANA_HEADER"])

    assert code == 0
    assert sent == [{"Cookie": "_oauth2_proxy=topsecret"}]
    assert "topsecret" not in out.read_text(encoding="utf-8")
