"""Monitoring decisions mirrored to PostgreSQL for promiseops_retraining_required (no database: runs in CI).

The decision is published only after the monitoring run is FINISHED in MLflow and read back, so a
run that fails finalization can neither raise nor clear the RetrainingRecommended alert.
Real PostgreSQL: tests/test_monitoring_decisions_db.py
"""

from datetime import UTC, datetime
from types import SimpleNamespace

import pytest

from promiseops import db, decisions, monitor_train

AS_OF = datetime(2018, 4, 30, tzinfo=UTC)


class _RecordingConnection:
    def __init__(self):
        self.calls = []

    def execute(self, sql, params=None):
        self.calls.append((sql, params))
        return self


class _Client:
    """The MLflow client calls run_monitor_train makes before deciding whether to train."""

    def __init__(self, events, *, terminate_error=None, read_back_status="FINISHED"):
        self.events = events
        self.terminate_error = terminate_error
        self.read_back_status = read_back_status

    def create_run(self, experiment_id, tags=None, run_name=None):
        self.events.append(("create_run",))
        return SimpleNamespace(info=SimpleNamespace(run_id="run-1"))

    def log_param(self, run_id, key, value):
        # Source metadata does not change the decision publication ordering under test.
        assert (key, value) == ("prediction_history_source", "none")

    def set_terminated(self, run_id, status="FINISHED"):
        self.events.append(("terminated", status))
        if self.terminate_error is not None:
            raise self.terminate_error

    def get_run(self, run_id):
        self.events.append(("get_run",))
        return SimpleNamespace(info=SimpleNamespace(status=self.read_back_status))


def _record(**changes):
    values = {"as_of": AS_OF, "incumbent_model_version": "x-1", "status": "assessed",
              "retrain_recommended": True, "reasons": ["recall below reference", "persistent drift"]}
    return monitor_train.MonitoringRecord(**{**values, **changes})


@pytest.fixture
def events(monkeypatch, tmp_path):
    """run_monitor_train with MLflow, the bundle, the report and training faked; returns the event log."""
    seen = []
    monkeypatch.setattr(monitor_train.tracking, "ensure_experiment", lambda client, name: "experiment-1")
    monkeypatch.setattr(monitor_train.bundle, "copy_bundle", lambda source, target: SimpleNamespace(reference=None))
    monkeypatch.setattr(monitor_train, "assess", lambda *args, **kwargs: _record(retrain_recommended=False))
    monkeypatch.setattr(monitor_train, "persist_record", lambda client, run_id, record: seen.append(("persist",)))
    monkeypatch.setattr(monitor_train.training, "close_failed",
                        lambda client, run_id, error: seen.append(("failed", type(error).__name__)))
    monkeypatch.setattr(monitor_train.training, "run_train",
                        lambda *args, **kwargs: seen.append(("train",)) or SimpleNamespace(run_id="train-1"))
    monkeypatch.setattr(monitor_train.decisions, "record_decision",
                        lambda connection, run_id, record: seen.append(("decision", connection, run_id)))
    return seen


def _run(events, tmp_path, **client_options):
    settings = SimpleNamespace(source_commit="0" * 40, incumbent=tmp_path, artifacts=tmp_path)
    return monitor_train.run_monitor_train("connection", _Client(events, **client_options), settings,
                                           cutoffs=SimpleNamespace(as_of=AS_OF))


def test_schema_v4_adds_monitoring_decisions_after_the_v3_snapshots():
    assert db.SCHEMA_VERSION == 4
    sql = db.schema_sql()
    assert "CREATE TABLE IF NOT EXISTS promiseops.prediction_snapshots" in sql
    assert "CREATE TABLE IF NOT EXISTS promiseops.monitoring_decisions" in sql
    assert sql.index("VALUES (3)") < sql.index("promiseops.monitoring_decisions") < sql.index("VALUES (4)")


def test_record_decision_stores_the_monitoring_record_fields():
    connection = _RecordingConnection()
    decisions.record_decision(connection, "run-1", _record())   # the real MonitoringRecord, report None

    ((sql, params),) = connection.calls
    assert "INSERT INTO promiseops.monitoring_decisions" in sql
    assert "ON CONFLICT (monitoring_run_id) DO NOTHING" in sql
    assert params == ("run-1", AS_OF, "x-1", "assessed", True, False, 2)


@pytest.mark.parametrize(("status", "sufficient", "expected"), [
    ("assessed", True, True), ("assessed", False, False), ("no_reference", None, False),
    ("no_prediction_history", None, False)])
def test_labels_sufficient_reads_the_report(status, sufficient, expected):
    report = None if sufficient is None else SimpleNamespace(labels=SimpleNamespace(sufficient=sufficient))
    record = SimpleNamespace(status=status, report=report)

    assert decisions.labels_sufficient(record) is expected


def test_decision_is_published_only_after_finished_reads_back(events, tmp_path):
    result = _run(events, tmp_path)

    assert events == [("create_run",), ("persist",), ("terminated", "FINISHED"), ("get_run",),
                      ("decision", "connection", "run-1")]
    assert result.training is None


def test_finalization_error_publishes_no_decision(events, tmp_path):
    with pytest.raises(RuntimeError):
        _run(events, tmp_path, terminate_error=RuntimeError("MLflow unavailable"))

    assert events == [("create_run",), ("persist",), ("terminated", "FINISHED"), ("failed", "RuntimeError")]


def test_acknowledged_but_not_persisted_finished_publishes_no_decision(events, tmp_path):
    # set_terminated returned, but the run did not read back as FINISHED (the !48 barrier).
    with pytest.raises(monitor_train.training.TrainingError):
        _run(events, tmp_path, read_back_status="RUNNING")

    assert ("decision", "connection", "run-1") not in events
    assert events[-1] == ("failed", "TrainingError")


def test_failed_decision_write_fails_the_run_and_skips_training(events, monkeypatch, tmp_path):
    monkeypatch.setattr(monitor_train, "assess", lambda *args, **kwargs: _record(retrain_recommended=True))

    def broken(connection, run_id, record):
        raise RuntimeError("relation promiseops.monitoring_decisions does not exist")

    monkeypatch.setattr(monitor_train.decisions, "record_decision", broken)

    with pytest.raises(RuntimeError):
        _run(events, tmp_path)
    assert events == [("create_run",), ("persist",), ("terminated", "FINISHED"), ("get_run",),
                      ("failed", "RuntimeError")]


def test_recommended_retraining_runs_after_the_decision_is_published(events, monkeypatch, tmp_path):
    monkeypatch.setattr(monitor_train, "assess", lambda *args, **kwargs: _record(retrain_recommended=True))
    monkeypatch.setattr(monitor_train.training, "run_train",
                        lambda *args, **kwargs: events.append(("train",)) or SimpleNamespace(run_id="train-1"))
    tags = []
    monkeypatch.setattr(_Client, "set_tag", lambda self, run_id, key, value: tags.append(run_id), raising=False)

    result = _run(events, tmp_path)

    assert events[-2:] == [("decision", "connection", "run-1"), ("train",)]
    assert result.training.run_id == "train-1"


def test_training_failure_leaves_the_finished_monitoring_run_and_its_decision(events, monkeypatch, tmp_path):
    # Training starts after the monitoring try/except: run_train closes only its own MLflow run as
    # FAILED, so the completed monitoring run stays FINISHED and its published decision stays.
    monkeypatch.setattr(monitor_train, "assess", lambda *args, **kwargs: _record(retrain_recommended=True))

    def broken(*args, **kwargs):
        events.append(("train",))
        raise RuntimeError("training failed")

    monkeypatch.setattr(monitor_train.training, "run_train", broken)

    with pytest.raises(RuntimeError, match="training failed"):
        _run(events, tmp_path)
    assert events == [("create_run",), ("persist",), ("terminated", "FINISHED"), ("get_run",),
                      ("decision", "connection", "run-1"), ("train",)]   # no ("failed", ...) for run-1
