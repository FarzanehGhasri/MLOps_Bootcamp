"""Actual API snapshots, transaction rollback and the monitor-train JSONL boundary."""

import json
from dataclasses import replace

import pytest
from test_api_features_db import client_for, trained_release  # noqa: F401
from test_ingestion_db import URL, conn, ingest  # noqa: F401
from test_model_db import AS_OF, TRAIN_END, history  # noqa: F401

from promiseops import bundle, drift, monitor_train, prediction_history

pytestmark = pytest.mark.skipif(not URL, reason="PROMISEOPS_TEST_DATABASE_URL is not set")


def predict(client, oid, request_id="snapshot-test"):
    return client.post("/predict", headers={"X-API-Key": "test-key"},
                       json={"order_id": oid, "request_id": request_id})


def test_snapshots_roundtrip_and_retry_do_not_change_observed_inputs(trained_release, monkeypatch, tmp_path):  # noqa: F811
    connection, candidate, release = trained_release
    loaded = bundle.read_bundle(release)
    client = client_for(monkeypatch, release)
    oid = candidate.cohort.order_ids[0]
    first = predict(client, oid)
    assert first.status_code == 200, first.text
    rows = prediction_history.export_history(connection, model_version=loaded.manifest.model_version, as_of=AS_OF)
    assert len(rows) == 1
    expected = candidate.cohort.features.loc[oid].to_dict()
    for name, value in expected.items():
        assert rows[0][name] == value
    assert rows[0]["risk_probability"] == first.json()["risk_probability"]
    assert prediction_history.export_history(connection, model_version=loaded.manifest.model_version, as_of=AS_OF,
                                               artifact_sha256=loaded.manifest.artifact_sha256) == rows
    assert prediction_history.export_history(connection, model_version=loaded.manifest.model_version, as_of=AS_OF,
                                               artifact_sha256="f" * 64) == []
    # A restart/retry returns the old response and cannot create another snapshot.
    assert predict(client_for(monkeypatch, release), oid).json() == first.json()
    assert connection.execute("SELECT count(*) FROM promiseops.prediction_snapshots").fetchone()[0] == 1
    assert connection.execute("SELECT artifact_sha256 FROM promiseops.prediction_snapshots").fetchone()[0] == (
        loaded.manifest.artifact_sha256)
    assert prediction_history.export_history(connection, model_version=loaded.manifest.model_version,
                                               as_of=TRAIN_END) == []
    assert prediction_history.export_history(connection, model_version="other-version", as_of=AS_OF) == []
    path = tmp_path / "history.jsonl"
    assert prediction_history.main(["--model-version", loaded.manifest.model_version,
                                    "--as-of", AS_OF, "--output", str(path)]) == 0
    observed = monitor_train.load_prediction_history(path, loaded)
    assert observed.order_id.tolist() == [oid]
    assert len(observed.columns) == 4 + 32
    assert json.loads(path.read_text())["predicted_at"] == rows[0]["predicted_at"]
    monitored = replace(loaded, reference=drift.build_reference(
        candidate.training_features, candidate.validation_metrics, candidate.cohort.sha256))
    report = monitor_train.assess(connection, monitored, as_of=AS_OF, prediction_history=path)
    assert report.status == "assessed"
    assert not report.retrain_recommended  # one label is insufficient, not an automatic retrain
    with pytest.raises(FileExistsError):
        prediction_history.main(["--model-version", loaded.manifest.model_version,
                                 "--as-of", AS_OF, "--output", str(path)])


def test_failed_snapshot_rolls_back_response_and_allows_retry(trained_release, monkeypatch):  # noqa: F811
    connection, candidate, release = trained_release
    client = client_for(monkeypatch, release)
    original = prediction_history.record_snapshot
    def fail(*args, **kwargs):
        raise RuntimeError("snapshot write unavailable")
    monkeypatch.setattr(prediction_history, "record_snapshot", fail)
    oid = candidate.cohort.order_ids[0]
    assert predict(client, oid).status_code == 503
    assert connection.execute("SELECT count(*) FROM promiseops.predictions").fetchone()[0] == 0
    assert connection.execute("SELECT count(*) FROM promiseops.prediction_snapshots").fetchone()[0] == 0
    monkeypatch.setattr(prediction_history, "record_snapshot", original)
    assert predict(client, oid).status_code == 200


def test_legacy_predictions_are_not_backfilled(conn):  # noqa: F811
    conn.execute("INSERT INTO promiseops.predictions (request_id, order_id, risk_probability, model_version) "
                 "VALUES ('legacy', 'o1', 0.2, 'v1')")
    assert prediction_history.export_history(conn, model_version="v1", as_of=AS_OF) == []
