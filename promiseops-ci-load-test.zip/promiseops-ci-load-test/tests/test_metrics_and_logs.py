import json
import logging
from pathlib import Path

from fastapi.testclient import TestClient

from promiseops.api import ALLOWED_FEATURES, create_app
from promiseops.model import ConstantProbabilityEstimator


def _make_client(monkeypatch, tmp_path: Path, api_key: str = "secret-key") -> TestClient:
    bundle_dir = tmp_path / "release"
    ConstantProbabilityEstimator(probability=0.15).build_mock_bundle(
        bundle_dir,
        model_version="metrics-test-v1",
        features_path="contracts/features.json",
    )
    monkeypatch.setenv("PROMISEOPS_RELEASE", str(bundle_dir / "release.json"))
    monkeypatch.setenv("PROMISEOPS_API_KEY", api_key)
    monkeypatch.delenv("PROMISEOPS_DATABASE_URL", raising=False)
    return TestClient(create_app())


def test_probes_require_no_api_key_while_metrics_requires_key(monkeypatch, tmp_path: Path):
    client = _make_client(monkeypatch, tmp_path)

    assert client.get("/healthz").status_code == 200
    assert client.get("/readyz").status_code == 503
    assert client.get("/metrics").status_code == 401

    res = client.get("/metrics", headers={"X-API-Key": "secret-key"})
    assert res.status_code == 200
    assert "text/plain" in res.headers["content-type"]
    assert "# TYPE promiseops_http_requests_total counter" in res.text
    assert "# TYPE promiseops_http_request_duration_seconds histogram" in res.text


def test_metrics_bounded_labels_and_structured_prediction_logs(monkeypatch, tmp_path: Path, caplog):
    client = _make_client(monkeypatch, tmp_path)
    caplog.set_level(logging.INFO, logger="promiseops.api")

    secret_order_id = "ord-sensitive-999"
    secret_req_id = "req-sensitive-888"

    pred_res = client.post(
        "/predict",
        headers={"X-API-Key": "secret-key"},
        json={"order_id": secret_order_id, "request_id": secret_req_id},
    )
    assert pred_res.status_code == 503

    metrics_text = client.get("/metrics", headers={"X-API-Key": "secret-key"}).text

    # Bounded labels present
    assert 'route="/predict"' in metrics_text
    assert 'status="503"' in metrics_text
    for feature in ALLOWED_FEATURES:
        assert f'feature="{feature}"' in metrics_text

    # No high-cardinality or secret leakage in metrics
    assert secret_order_id not in metrics_text
    assert secret_req_id not in metrics_text
    assert "secret-key" not in metrics_text

    # Structured JSON log emitted for prediction
    log_records = [json.loads(rec.getMessage()) for rec in caplog.records if rec.name == "promiseops.api"]
    assert len(log_records) == 1
    entry = log_records[0]
    assert entry["event"] == "prediction"
    assert entry["request_id"] == secret_req_id
    assert entry["model_version"] == "metrics-test-v1"
    assert entry["status"] == 503
    assert isinstance(entry["latency_ms"], float)
    assert "order_id" not in entry
    assert "secret-key" not in json.dumps(entry)
