"""Unit tests for promiseops.tracking that do NOT need MLflow (they run in CI, whose test image has none).

The MLflow-backed tests are in tests/test_tracking_mlflow.py and are skipped when MLflow is not installed.
"""

import json
import os
import subprocess
import sys
import threading
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from types import SimpleNamespace

import pytest

from promiseops import tracking
from promiseops.tracking import (
    TrackingConfig,
    TrackingConfigError,
    TrackingError,
    TrackingUnavailable,
    ensure_experiment,
    probe_server,
    redact_uri,
    run_tags,
    source_commit_from_env,
)

ROOT = Path(__file__).resolve().parents[1]
COMMIT = "0123456789abcdef0123456789abcdef01234567"


# --- configuration ------------------------------------------------------------------------------------
def test_missing_tracking_uri_gives_a_clear_error():
    with pytest.raises(TrackingConfigError, match="MLFLOW_TRACKING_URI is not set"):
        TrackingConfig.from_env({})
    with pytest.raises(TrackingConfigError):
        TrackingConfig.from_env({"MLFLOW_TRACKING_URI": "   "})


@pytest.mark.parametrize("uri", ["mlruns", "/tmp/mlruns", "ftp://host/x", "C:\\mlruns"])
def test_bare_paths_and_unknown_schemes_are_refused(uri):
    with pytest.raises(TrackingConfigError):
        TrackingConfig.from_env({"MLFLOW_TRACKING_URI": uri})


@pytest.mark.parametrize("uri", ["http://mlflow.g03-platform:5000", "https://mlflow.example",
                                 "sqlite:///C:/tmp/mlflow.db", "file:///tmp/mlruns",
                                 "postgresql://u@db/mlflow"])
def test_supported_uris_are_accepted(uri):
    config = TrackingConfig.from_env({"MLFLOW_TRACKING_URI": f"  {uri}  "})
    assert config.tracking_uri == uri
    assert config.experiment_name == tracking.TRAINING_EXPERIMENT


def test_empty_experiment_name_is_refused():
    with pytest.raises(TrackingConfigError):
        TrackingConfig.from_env({"MLFLOW_TRACKING_URI": "http://h"}, experiment_name=" ")


@pytest.mark.parametrize(("uri", "expected"), [
    ("https://user:secret@mlflow.example/x", "https://***@mlflow.example/x"),
    ("https://token@mlflow.example", "https://***@mlflow.example"),
    ("postgresql://db/mlflow?password=secret", "postgresql://db/mlflow?***"),
    ("http://mlflow.g03-platform:5000", "http://mlflow.g03-platform:5000"),
])
def test_redact_uri_hides_credentials(uri, expected):
    assert redact_uri(uri) == expected


def test_repr_and_safe_uri_never_show_the_password():
    config = TrackingConfig.from_env({"MLFLOW_TRACKING_URI": "https://user:secret@mlflow.example"})
    assert "secret" not in repr(config)
    assert "secret" not in config.safe_uri


@pytest.mark.parametrize(("message", "expected"), [
    ("connection refused", "connection refused"),
    ("request 'https://user:secret@host/api' failed", "request 'https://***@host/api' failed"),
    ("bad https://user:secret@[invalid/api", "bad [redacted URI]"),
])
def test_redact_error_handles_prose_and_malformed_urls(message, expected):
    assert tracking.redact_error(RuntimeError(message)) == expected


def test_source_commit_is_optional_but_must_be_valid_when_present():
    assert source_commit_from_env({}) is None
    assert source_commit_from_env({"CI_COMMIT_SHA": COMMIT}) == COMMIT
    for bad in ("abc123", COMMIT.upper(), COMMIT + "0"):
        with pytest.raises(TrackingConfigError):
            source_commit_from_env({"CI_COMMIT_SHA": bad})


def test_run_tags_carry_kind_and_commit():
    assert run_tags("smoke", None) == {"promiseops.kind": "smoke"}
    assert run_tags("train", COMMIT) == {"promiseops.kind": "train", "promiseops.source_commit": COMMIT,
                                         "mlflow.source.git.commit": COMMIT}


# --- MLflow is optional for the rest of the package --------------------------------------------------------
def test_importing_tracking_does_not_import_mlflow():
    # The API image has no MLflow and must keep serving during an MLflow outage (course doc, section 6).
    # A fresh interpreter, because this test process may already have MLflow imported by other tests.
    code = "import sys, promiseops.tracking; print('mlflow' in sys.modules)"
    env = {key: value for key, value in os.environ.items() if key in ("PATH", "SYSTEMROOT")}
    env["PYTHONPATH"] = str(ROOT / "src")
    result = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, check=True, env=env)
    assert result.stdout.strip() == "False"


def test_create_client_without_mlflow_explains_what_to_do(monkeypatch):
    monkeypatch.setitem(sys.modules, "mlflow", None)  # makes "import mlflow" raise ImportError
    with pytest.raises(TrackingUnavailable, match="not installed"):
        tracking.create_client(TrackingConfig("http://h"))


# --- ensure_experiment with a fake client ------------------------------------------------------------------
class FakeClient:
    def __init__(self, existing=None, create_error=None, appears_after_error=None):
        self.existing = existing
        self.create_error = create_error
        self.appears_after_error = appears_after_error
        self.created = []

    def get_experiment_by_name(self, name):
        return self.existing

    def create_experiment(self, name, artifact_location=None, tags=None):
        self.created.append((name, artifact_location, tags))
        if self.create_error is not None:
            self.existing = self.appears_after_error
            raise self.create_error
        return "42"


def _experiment(stage="active", experiment_id="7"):
    return SimpleNamespace(experiment_id=experiment_id, lifecycle_stage=stage)


def test_existing_experiment_is_reused_not_created():
    client = FakeClient(existing=_experiment())
    assert ensure_experiment(client, "e") == "7"
    assert client.created == []


def test_missing_experiment_is_created_without_forcing_an_artifact_location():
    client = FakeClient()
    assert ensure_experiment(client, "e") == "42"
    [(name, artifact_location, tags)] = client.created
    assert (name, artifact_location) == ("e", None)  # the server decides where artifacts live
    assert tags == {"promiseops.project": "late-delivery-risk"}


def test_experiment_created_concurrently_by_someone_else_is_used():
    client = FakeClient(create_error=RuntimeError("RESOURCE_ALREADY_EXISTS"), appears_after_error=_experiment())
    assert ensure_experiment(client, "e") == "7"


def test_create_failure_that_is_not_a_race_is_raised():
    client = FakeClient(create_error=RuntimeError("server down"))
    with pytest.raises(RuntimeError, match="server down"):
        ensure_experiment(client, "e")


def test_deleted_experiment_stops_with_instructions():
    with pytest.raises(TrackingError, match="deleted"):
        ensure_experiment(FakeClient(existing=_experiment(stage="deleted")), "e")


# --- probe_server against a tiny local HTTP server ---------------------------------------------------------
class _Handler(BaseHTTPRequestHandler):
    status = 200
    location = None
    seen_headers = None

    def do_GET(self):  # this exact name is required by BaseHTTPRequestHandler
        type(self).seen_headers = dict(self.headers)
        self.send_response(self.status)
        if self.location:
            self.send_header("Location", self.location)
        self.end_headers()
        self.wfile.write(b"OK")

    def log_message(self, *args):  # keep test output clean
        pass


@pytest.fixture
def http_server():
    handler = type("Handler", (_Handler,), {})
    server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    yield handler, f"http://127.0.0.1:{server.server_port}"
    server.shutdown()
    server.server_close()


def test_probe_accepts_a_healthy_server(http_server):
    _, url = http_server
    probe_server(TrackingConfig(url), environ={})


def test_probe_recognises_the_sign_in_redirect(http_server):
    handler, url = http_server
    handler.status, handler.location = 302, "https://gitlab.example/oauth/authorize?client_id=x"
    with pytest.raises(TrackingUnavailable, match=r"redirects to gitlab\.example \(a sign-in page\)"):
        probe_server(TrackingConfig(url), environ={})


@pytest.mark.parametrize("status", [401, 403])
def test_probe_reports_refused_credentials(http_server, status):
    handler, url = http_server
    handler.status = status
    with pytest.raises(TrackingUnavailable, match="refused the credentials"):
        probe_server(TrackingConfig(url), environ={})


def test_probe_sends_the_standard_mlflow_credentials(http_server):
    handler, url = http_server
    probe_server(TrackingConfig(url), environ={"MLFLOW_TRACKING_TOKEN": "t0ken"})
    assert handler.seen_headers["Authorization"] == "Bearer t0ken"


def test_probe_sends_the_configured_host_header(http_server):
    handler, url = http_server
    probe_server(TrackingConfig(url), environ={"MLFLOW_HOST_HEADER": "g03-mlflow.mlops.qbootcamp.ir"})
    assert handler.seen_headers["Host"] == "g03-mlflow.mlops.qbootcamp.ir"


def test_probe_without_host_header_uses_the_uri_host(http_server):
    handler, url = http_server
    probe_server(TrackingConfig(url), environ={})
    assert handler.seen_headers["Host"] == url.removeprefix("http://")


def test_probe_reports_an_unreachable_server():
    # Port 9 on localhost: nothing listens there, the connection is refused immediately.
    with pytest.raises(TrackingUnavailable, match="cannot reach MLflow"):
        probe_server(TrackingConfig("http://127.0.0.1:9"), timeout=2, environ={})


def test_probe_skips_local_backends():
    probe_server(TrackingConfig("sqlite:///nowhere.db"), environ={})  # no network, no error


def test_check_command_stdout_is_exactly_one_json_line(monkeypatch, capsys):
    # MLflow prints "View run at ..." to stdout; a DAG/CI step must still be able to parse our stdout.
    def noisy_smoke_check(config, source_commit=None):
        print("🏃 View run smoke at: http://127.0.0.1:5000/#/experiments/1/runs/abc")
        return tracking.SmokeResult(config.safe_uri, config.experiment_name, "1", "abc", source_commit)

    monkeypatch.setattr(tracking, "smoke_check", noisy_smoke_check)
    monkeypatch.setenv("MLFLOW_TRACKING_URI", "http://127.0.0.1:5000")
    monkeypatch.delenv("CI_COMMIT_SHA", raising=False)
    assert tracking.main(["check"]) == 0
    captured = capsys.readouterr()
    [line] = captured.out.splitlines()
    assert json.loads(line)["run_id"] == "abc"
    assert "View run" in captured.err


def test_check_command_without_configuration_exits_1_with_a_json_error(monkeypatch, capsys):
    monkeypatch.delenv("MLFLOW_TRACKING_URI", raising=False)
    assert tracking.main(["check"]) == 1
    out = capsys.readouterr().out
    assert '"status": "error"' in out and "MLFLOW_TRACKING_URI is not set" in out


@pytest.mark.parametrize("uri", ["sqlite:///local.db", "file:///tmp/runs", "http://localhost:5000",
                                     "http://127.0.0.2:5000", "http://[::1]:5000"])
def test_group_check_rejects_local_evidence_before_connecting(monkeypatch, capsys, uri):
    monkeypatch.setenv("MLFLOW_TRACKING_URI", uri)
    monkeypatch.setattr(tracking, "smoke_check", lambda *a, **k: pytest.fail("must not connect"))
    assert tracking.main(["check", "--require-server"]) == 1
    result = json.loads(capsys.readouterr().out)
    assert result["error_type"] == "TrackingConfigError"
    assert "non-loopback HTTP(S)" in result["error"]


def test_group_check_uses_configured_server_and_real_source_commit(monkeypatch, capsys):
    monkeypatch.setenv("MLFLOW_TRACKING_URI", "http://mlflow.g03-platform.svc:5000")
    monkeypatch.setenv("CI_COMMIT_SHA", "a" * 40)

    def smoke(config, *, source_commit):
        assert config.experiment_name == "promiseops-group-acceptance"
        assert source_commit == "a" * 40
        return tracking.SmokeResult(config.safe_uri, config.experiment_name, "3", "actual-run", source_commit)

    monkeypatch.setattr(tracking, "smoke_check", smoke)
    assert tracking.main(["check", "--require-server", "--experiment", "promiseops-group-acceptance"]) == 0
    result = json.loads(capsys.readouterr().out)
    assert result["run_id"] == "actual-run" and result["source_commit"] == "a" * 40


@pytest.mark.parametrize("failure_stage", ["create", "log"])
@pytest.mark.parametrize("cleanup_fails", [False, True])
def test_smoke_failure_preserves_safe_error_and_json_contract(
    monkeypatch, capsys, failure_stage, cleanup_fails
):
    """Exercise real smoke_check error handling without importing MLflow or using a server."""
    uri = "https://alice:password-secret@mlflow.example"
    primary = RuntimeError(
        f"API request to {uri}/api/2.0/mlflow/runs failed; "
        "retry https://bob:other-secret@backup.example/api?token=query-secret failed"
    )
    terminated = []

    class FailingClient:
        def get_experiment_by_name(self, name):
            return _experiment()

        def create_run(self, *args, **kwargs):
            if failure_stage == "create":
                raise primary
            return SimpleNamespace(info=SimpleNamespace(run_id="run-123"))

        def log_param(self, *args):
            raise primary

        def set_terminated(self, run_id, status):
            terminated.append((run_id, status))
            if cleanup_fails:
                raise RuntimeError("cleanup-secret: termination unavailable")

    client = FailingClient()
    monkeypatch.setattr(tracking, "probe_server", lambda config: None)
    monkeypatch.setattr(tracking, "create_client", lambda config: client)
    monkeypatch.setenv("MLFLOW_TRACKING_URI", uri)
    monkeypatch.delenv("CI_COMMIT_SHA", raising=False)

    with pytest.raises(TrackingUnavailable) as caught:
        tracking.smoke_check(TrackingConfig(uri), client=client)
    rendered = "".join(traceback.format_exception(caught.value))
    assert tracking.main(["check"]) == 1
    captured = capsys.readouterr()
    [line] = captured.out.splitlines()
    result = json.loads(line)
    assert result["error_type"] == "TrackingUnavailable"
    assert "API request to https://***@mlflow.example" in result["error"]
    assert "https://***@backup.example/api?***" in result["error"]
    for secret in ("alice", "bob", "password-secret", "other-secret", "query-secret", "cleanup-secret"):
        assert secret not in rendered + captured.out + captured.err
    assert terminated == ([] if failure_stage == "create" else [("run-123", "FAILED")] * 2)


def test_failed_cleanup_does_not_replace_existing_tracking_error(monkeypatch):
    primary = TrackingUnavailable("the original logging failure")

    class FailingClient:
        def get_experiment_by_name(self, name):
            return _experiment()

        def create_run(self, *args, **kwargs):
            return SimpleNamespace(info=SimpleNamespace(run_id="run-123"))

        def log_param(self, *args):
            raise primary

        def set_terminated(self, *args):
            raise RuntimeError("cleanup failed")

    monkeypatch.setattr(tracking, "probe_server", lambda config: None)
    with pytest.raises(TrackingUnavailable) as caught:
        tracking.smoke_check(TrackingConfig("http://mlflow.example"), client=FailingClient())
    assert caught.value is primary
