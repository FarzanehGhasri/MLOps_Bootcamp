"""Readiness gauge and 422/500 request counting on /metrics (monitoring dashboard + alert inputs)."""

import logging
from pathlib import Path

import psycopg
import pytest
from fastapi.testclient import TestClient
from prometheus_client.parser import text_string_to_metric_families

from promiseops import api
from promiseops.model import ConstantProbabilityEstimator

API_KEY = "metrics-test-key"
HEADERS = {"X-API-Key": API_KEY}
SECRET_URL = "postgresql://user:db-password@db.internal:5432/promiseops"


class _Database:
    """db.connect for /readyz: answers SELECT 1 while ``up``, refuses (with the URL in the message) otherwise."""

    def __init__(self):
        self.up = True

    def connect(self, url=None, **options):
        if not self.up:
            raise psycopg.OperationalError(f"connection to {SECRET_URL} failed")
        return self

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False

    def execute(self, sql, params=None):
        return self


@pytest.fixture
def database(monkeypatch):
    fake = _Database()
    monkeypatch.setattr(api.db, "connect", fake.connect)
    return fake


def _app(monkeypatch, tmp_path: Path, *, bundle: bool = True, database_url: str | None = SECRET_URL):
    bundle_dir = tmp_path / "release"
    if bundle:
        ConstantProbabilityEstimator(probability=0.2).build_mock_bundle(
            bundle_dir,
            model_version="readiness-test-v1",
            features_path="contracts/features.json",
        )
    monkeypatch.setenv("PROMISEOPS_RELEASE", str(bundle_dir / "release.json"))
    monkeypatch.setenv("PROMISEOPS_API_KEY", API_KEY)
    if database_url is None:
        monkeypatch.delenv("PROMISEOPS_DATABASE_URL", raising=False)
    else:
        monkeypatch.setenv("PROMISEOPS_DATABASE_URL", database_url)
    return api.create_app()


def _sample(client: TestClient, name: str, **labels: str) -> float | None:
    text = client.get("/metrics", headers=HEADERS).text
    for family in text_string_to_metric_families(text):
        for sample in family.samples:
            if sample.name == name and all(sample.labels.get(k) == v for k, v in labels.items()):
                return sample.value
    return None


def test_readiness_gauge_is_zero_until_checked_then_follows_readyz(monkeypatch, tmp_path, database):
    client = TestClient(_app(monkeypatch, tmp_path))

    assert _sample(client, "promiseops_ready") == 0.0
    assert client.get("/readyz").status_code == 200
    assert _sample(client, "promiseops_ready") == 1.0


def test_readiness_gauge_zero_when_model_missing(monkeypatch, tmp_path, database):
    client = TestClient(_app(monkeypatch, tmp_path, bundle=False))

    assert client.get("/readyz").status_code == 503
    assert _sample(client, "promiseops_ready") == 0.0


def test_readiness_gauge_drops_when_database_unreachable(monkeypatch, tmp_path, database):
    client = TestClient(_app(monkeypatch, tmp_path))
    assert client.get("/readyz").status_code == 200
    assert _sample(client, "promiseops_ready") == 1.0

    database.up = False
    assert client.get("/readyz").status_code == 503
    assert _sample(client, "promiseops_ready") == 0.0
    assert "db-password" not in client.get("/metrics", headers=HEADERS).text


@pytest.mark.parametrize("path", ["/predict", "/v1/predict"])
def test_validation_error_is_counted_as_422_under_the_predict_route(monkeypatch, tmp_path, path):
    client = TestClient(_app(monkeypatch, tmp_path, database_url=None))

    res = client.post(path, headers=HEADERS, json={"unexpected": "x"})   # order_id missing
    assert res.status_code == 422
    assert isinstance(res.json()["detail"], list)  # FastAPI's default 422 body is kept

    # Same label as the 200/4xx/503 counts in POST_predict, whichever path was called.
    assert _sample(client, "promiseops_http_requests_total", route="/predict", status="422") == 1.0


def test_unhandled_error_is_counted_as_500_without_leaking_details(monkeypatch, tmp_path, caplog):
    client = TestClient(_app(monkeypatch, tmp_path, database_url=None), raise_server_exceptions=False)
    real_validate_header = api.validate_header

    def broken(api_key):
        raise RuntimeError("boom postgresql://user:leaked-secret@db/promiseops")

    monkeypatch.setattr(api, "validate_header", broken)
    caplog.set_level(logging.ERROR, logger="promiseops.api")
    res = client.get("/metrics", headers=HEADERS)
    assert res.status_code == 500
    assert res.json() == {"detail": "Internal Server Error"}
    assert "leaked-secret" not in res.text

    monkeypatch.setattr(api, "validate_header", real_validate_header)
    assert _sample(client, "promiseops_http_requests_total", route="/metrics", status="500") == 1.0
    errors = [r.getMessage() for r in caplog.records if r.name == "promiseops.api" and r.levelno == logging.ERROR]
    assert any('"error_type": "RuntimeError"' in m and '"route": "/metrics"' in m for m in errors)
    assert not any("leaked-secret" in m for m in errors)


def test_unknown_paths_do_not_create_metric_labels(monkeypatch, tmp_path):
    client = TestClient(_app(monkeypatch, tmp_path, database_url=None))

    assert client.get("/no-such-route/abc123").status_code == 404
    text = client.get("/metrics", headers=HEADERS).text
    assert "abc123" not in text
