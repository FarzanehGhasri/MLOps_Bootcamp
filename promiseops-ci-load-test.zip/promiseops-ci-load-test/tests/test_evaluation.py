"""Final test-period evaluation without a database: the "untouched" rules are checked before any query.

Database end to end: tests/test_evaluation_db.py
Run: $env:PYTHONPATH = "src"; python -m pytest tests/test_evaluation.py -v
"""

from datetime import UTC, datetime

import pytest
from test_bundle import ROOT, VALIDATION_END, write

from promiseops import evaluation


def window(start, end=datetime(2018, 4, 30, 23, 59, 59, tzinfo=UTC), cutoff=datetime(2018, 6, 30, tzinfo=UTC)):
    return evaluation.HoldoutWindow(start=start, end=end, label_cutoff=cutoff)


def test_window_bounds_must_be_ordered():
    with pytest.raises(ValueError, match="start < end <= label_cutoff"):
        window(datetime(2018, 3, 1, tzinfo=UTC), cutoff=datetime(2018, 4, 1, tzinfo=UTC))


def test_test_window_may_start_exactly_at_validation_end():
    evaluation.check_untouched(VALIDATION_END, window(VALIDATION_END))   # no error


def test_window_overlapping_the_validation_period_is_refused_before_any_query(tmp_path):
    write(tmp_path)   # lineage validation_end = 2017-12-31 23:59:59
    with pytest.raises(evaluation.EvaluationError, match="reuse orders the model was chosen on"):
        evaluation.evaluate_bundle(None, tmp_path / "bundle", window(datetime(2017, 12, 1, tzinfo=UTC)))


def test_model_without_record_is_refused():
    # release/ of the repository is the constant mock from MR !3: no lineage.json, so no known cutoffs.
    with pytest.raises(evaluation.EvaluationError, match="no lineage.json"):
        evaluation.evaluate_bundle(None, ROOT / "release", window(datetime(2018, 3, 1, tzinfo=UTC)))


def test_command_reports_a_bad_window_with_exit_code_1(tmp_path, capsys):
    code = evaluation.main(["--bundle", str(tmp_path), "--test-start", "2018-05-01T00:00:00Z",
                            "--test-end", "2018-04-30T00:00:00Z", "--label-cutoff", "2018-06-30T00:00:00Z"],
                           environ={})
    assert code == 1
    assert '"status": "failed"' in capsys.readouterr().err
