import pytest

from promiseops.selection_study import budget_curve


def test_capacity_curve_uses_fixed_budget_ties_and_reports_costs():
    result = budget_curve(["b", "a", "c", "d"], [False, True, True, False], [.8, .8, .2, .1])
    assert result["0.1"] == {"k": 1, "late_found": 1, "false_positives": 0,
                              "late_missed": 1, "recall": .5, "precision": 1., "lift_over_random": 2.}
    with pytest.raises(ValueError):
        budget_curve(["a"], [False], [.5])
