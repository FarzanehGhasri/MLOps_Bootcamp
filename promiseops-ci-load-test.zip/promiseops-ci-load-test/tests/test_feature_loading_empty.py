"""Review regression: no source queries for empty or unavailable cohorts."""

import pandas as pd
import pytest

from promiseops import features


@pytest.mark.parametrize("ids,expected_queries", [([], 0), (["not-released"], 1)])
def test_empty_feature_lookup_avoids_item_and_payment_queries(monkeypatch, ids, expected_queries):
    queries = []
    def no_orders(connection, sql, params, columns):
        queries.append(sql)
        assert sql == features._ORDERS_SQL
        return pd.DataFrame(columns=list(columns))
    monkeypatch.setattr(features, "query_frame", no_orders)
    table = features.load_features(None, iter(ids), as_of="2018-04-30T00:00:00Z")
    assert len(queries) == expected_queries
    assert table.empty and table.index.name == "order_id"
    assert tuple(table.columns) == features.FEATURE_NAMES
    assert all(table[name].dtype == "float64" for name in features.NUMERIC_FEATURES)


def test_empty_lookup_still_rejects_invalid_cutoff():
    with pytest.raises(ValueError):
        features.load_features(None, [], as_of="not-a-timestamp")
