"""Failure handling must preserve diagnostics without publishing URI credentials."""

import json
from types import SimpleNamespace

import pytest

from promiseops import evaluation, training, worker


@pytest.mark.parametrize("tag_fails", [False, True])
def test_cleanup_redacts_error_and_attempts_status_even_when_tag_fails(tag_fails):
    calls = []

    class Client:
        def set_tag(self, run_id, key, value):
            calls.append(("tag", run_id, key, value))
            if tag_fails:
                raise RuntimeError("tag unavailable")

        def set_terminated(self, run_id, status):
            calls.append(("status", run_id, status))
            raise RuntimeError("status unavailable")

    training.close_failed(Client(), "run", RuntimeError("failed https://user:private@host/api?token=hidden"))
    assert calls[-1] == ("status", "run", "FAILED")
    assert "https://***@host/api?***" in calls[0][-1]
    assert "private" not in calls[0][-1] and "hidden" not in calls[0][-1]


def test_worker_emits_one_sanitized_json_error(monkeypatch, capsys):
    def unavailable(config):
        raise RuntimeError("cannot connect https://operator:private@mlflow.example/api?token=hidden")

    monkeypatch.setattr(worker.tracking, "create_client", unavailable)
    args = ["--train-end", "2017-12-31T23:59:59Z", "--validation-end", "2018-02-28T23:59:59Z",
            "--as-of", "2018-04-30T00:00:00Z"]
    assert worker.main(args, environ={"CI_COMMIT_SHA": "a" * 40,
                                      "MLFLOW_TRACKING_URI": "http://mlflow.example"}) == 1
    captured = capsys.readouterr()
    [line] = captured.err.splitlines()
    result = json.loads(line)
    assert result["status"] == "failed" and result["mode"] == "train"
    assert "https://***@mlflow.example/api?***" in result["error"]
    assert not captured.out
    assert "private" not in line and "hidden" not in line


def test_finish_failure_attempts_failed_status(monkeypatch):
    calls = []

    class Client:
        def create_run(self, *args, **kwargs):
            return SimpleNamespace(info=SimpleNamespace(run_id="run"))

        def set_tag(self, *args):
            pass

        def set_terminated(self, run_id, status):
            calls.append(status)
            if status == "FINISHED":
                raise RuntimeError("finish unavailable")

    monkeypatch.setattr(training.tracking, "ensure_experiment", lambda *args: "experiment")
    monkeypatch.setattr(training, "_train_in_run", lambda *args: object())
    settings = SimpleNamespace(experiment="experiment", source_commit="a" * 40)
    cutoffs = training.cohorts.Cutoffs(train_end="2017-12-31T00:00:00Z",
                                      validation_end="2018-02-28T00:00:00Z", as_of="2018-04-30T00:00:00Z")
    with pytest.raises(RuntimeError, match="finish unavailable"):
        training.run_train(None, Client(), settings, cutoffs=cutoffs)
    assert calls == ["FINISHED", "FAILED"]


def test_evaluation_logging_failure_marks_failed_and_preserves_original(monkeypatch):
    pytest.importorskip("mlflow")
    from test_bundle import lineage

    cutoffs = lineage()
    report = evaluation.HoldoutEvaluation(
        model_version="example", artifact_sha256="a" * 64, training_run_id="training-run",
        model_source_commit="c" * 40, training_dataset_identity="training-data",
        evaluation_dataset_identity="evaluation-data",
        trained_with={}, window=evaluation.HoldoutWindow(start="2018-03-01T00:00:00Z",
            end="2018-04-30T00:00:00Z", label_cutoff="2018-06-30T00:00:00Z"),
        cohort_sha256="b" * 64, approved_orders=150, unlabeled_orders=0,
        model=cutoffs.validation_metrics, baseline=cutoffs.validation_metrics,
        validation=cutoffs.validation_metrics, training_prevalence=0.2, mean_predicted_risk=0.2)
    statuses = []

    class Client:
        def create_run(self, *args, **kwargs):
            return SimpleNamespace(info=SimpleNamespace(run_id="evaluation-run"))

        def log_batch(self, *args, **kwargs):
            raise OSError("original logging failure")

        def set_tag(self, *args):
            raise RuntimeError("tag unavailable")

        def set_terminated(self, run_id, status):
            statuses.append(status)
            raise RuntimeError("status unavailable")

    monkeypatch.setattr(evaluation.tracking, "ensure_experiment", lambda *args: "experiment")
    with pytest.raises(OSError, match="original logging failure"):
        evaluation.log_evaluation(Client(), report, source_commit=None)
    assert statuses == ["FAILED"]
