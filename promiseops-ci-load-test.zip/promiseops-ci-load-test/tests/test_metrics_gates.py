"""Contract metrics and gates with hand-computed examples (no database, no model).

Run: $env:PYTHONPATH = "src"; python -m pytest tests/test_metrics_gates.py -v
"""

import numpy as np
import pytest
from sklearn.metrics import average_precision_score

from promiseops.bundle import EvaluationMetrics
from promiseops.gates import apply_gates
from promiseops.metrics import evaluate, top_k


def test_metrics_match_a_hand_computed_example():
    # N = 20 -> K = 2. Late: o00, o05, o10, o15 (4 of 20).
    ids = [f"o{i:02d}" for i in range(20)]
    late = [i % 5 == 0 for i in range(20)]
    risk = [0.9 if i == 0 else 0.8 if i == 1 else 0.7 if i == 5 else 0.1 for i in range(20)]
    m = evaluate(ids, late, risk)
    assert (m.n, m.k, m.prevalence) == (20, 2, 0.2)
    # top 2 = o00 (late), o01 (on time): 1 hit
    assert (m.recall_at_10, m.precision_at_10) == (1 / 4, 1 / 2)
    assert m.pr_auc == pytest.approx(average_precision_score(late, risk))
    assert m.brier == pytest.approx(np.mean((np.array(risk) - np.array(late, dtype=float)) ** 2))


def test_k_uses_integer_ceiling():
    ids = [f"o{i:02d}" for i in range(30)]
    m = evaluate(ids, [i < 3 for i in range(30)], [0.5] * 30)
    assert m.k == 3  # not 4: 0.1 * 30 == 3.0000000000000004 in floating point


def test_ties_are_broken_by_ascending_order_id():
    assert top_k(["b", "a", "c"], [0.5, 0.5, 0.9], 2) == ["c", "a"]
    # With equal risk everywhere, the "lucky" top-K is decided only by the IDs, not by input order.
    ids, late = ["z", "y", "a", "b"] * 1, [False, False, True, False]
    assert evaluate(ids, late, [0.3] * 4).recall_at_10 == 1.0  # K = 1 -> "a"


@pytest.mark.parametrize("ids, late, risk, message", [
    (["a", "b"], [False, False], [0.1, 0.2], "both classes"),
    (["a", "a"], [True, False], [0.1, 0.2], "unique"),
    (["a", "b"], [True, False], [0.1, 1.2], r"\[0, 1\]"),
    (["a", "b"], [True, False], [0.1, float("nan")], r"\[0, 1\]"),
    (["a", "b"], [True], [0.1, 0.2], "same length"),
])
def test_invalid_inputs_are_refused(ids, late, risk, message):
    with pytest.raises(ValueError, match=message):
        evaluate(ids, late, risk)


def metrics(recall=0.4, pr_auc=0.3, brier=0.06, n=1000, prevalence=0.08):
    return EvaluationMetrics(n=n, prevalence=prevalence, k=-(-n // 10), recall_at_10=recall,
                             precision_at_10=0.3, pr_auc=pr_auc, brier=brier)


def test_equal_metrics_pass_every_gate():
    result = apply_gates(metrics(), metrics())
    assert result.decision == "accepted"
    assert len(result.reasons) == 3 and all(reason.startswith("pass") for reason in result.reasons)


@pytest.mark.parametrize("candidate, decision", [
    (metrics(recall=0.399), "rejected"),        # recall cannot decrease at all
    (metrics(pr_auc=0.28), "accepted"),         # exactly -0.02 is allowed
    (metrics(pr_auc=0.2799), "rejected"),
    (metrics(brier=0.065), "accepted"),         # exactly +0.005 is allowed
    (metrics(brier=0.0651), "rejected"),
    (metrics(recall=0.5, pr_auc=0.35, brier=0.05), "accepted"),
])
def test_gate_thresholds(candidate, decision):
    result = apply_gates(candidate, metrics())
    assert result.decision == decision
    assert any(reason.startswith("FAIL") for reason in result.reasons) == (decision == "rejected")


def test_metrics_from_different_cohorts_cannot_be_compared():
    with pytest.raises(ValueError, match="different cohorts"):
        apply_gates(metrics(n=999), metrics(n=1000))
