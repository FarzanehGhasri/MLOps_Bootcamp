"""The standard diagnostic command must support the same release schema as serving."""

import pytest
from test_api_features_db import trained_release  # noqa: F401
from test_ingestion_db import URL, conn  # noqa: F401
from test_model_db import history  # noqa: F401

from promiseops.diagnostics import analyze

pytestmark = pytest.mark.skipif(not URL, reason="PROMISEOPS_TEST_DATABASE_URL is not set")


def test_diagnostics_reproduce_32_feature_release_metrics(trained_release):  # noqa: F811
    connection, _, release = trained_release
    report = analyze(connection, release, seeds=(0,))
    assert all(report["split_audit"]["checks"].values())
    assert report["metric_check"]["matches"]
    assert len(report["seed_results"]) == 2
    assert not report["test_used_for_diagnostics"]
