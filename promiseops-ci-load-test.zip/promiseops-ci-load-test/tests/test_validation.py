"""Unit tests for promiseops.validation — every rejection reason, no database needed (always runs in CI)."""

import json
from datetime import UTC, datetime
from decimal import Decimal
from pathlib import Path

import pytest
from factories import AS_OF, encode, orders_doc, outcomes_doc

from promiseops.contracts import Batch, digest, instant
from promiseops.validation import (
    MAX_REPORTED_PROBLEMS,
    BatchRejected,
    ExistingState,
    ExpectedMetadata,
    Problem,
    Reason,
    check_file_sha256,
    metadata_problems,
    parse_payload,
    publication_problems,
    raw_sha256,
    referenced_keys,
    to_decimal,
    validate_batch,
)

ROOT = Path(__file__).resolve().parents[1]
APPROVED = datetime(2017, 4, 10, 12, tzinfo=UTC)


def rejected(raw: bytes, sha: str) -> BatchRejected:
    with pytest.raises(BatchRejected) as info:
        parse_payload(raw, expected_sha256=sha)
    return info.value


def reasons(problems: list[Problem]) -> set[Reason]:
    return {p.reason for p in problems}


def check(document: dict, existing: ExistingState | None = None, as_of: str = AS_OF) -> list[Problem]:
    state = existing if existing is not None else ExistingState()
    return validate_batch(Batch.model_validate(document), state, as_of=instant(as_of))


# ---------------------------------------------------------------------------------------------
# parse_payload: bytes -> Batch
# ---------------------------------------------------------------------------------------------
def test_valid_payload_parses():
    raw, sha = encode(orders_doc())
    batch = parse_payload(raw, expected_sha256=sha)
    assert batch.batch_id == "orders-1" and len(batch.orders) == 2


def test_formatting_does_not_change_payload_sha256():
    # payload_sha256 is over canonical JSON, so indentation/key order of the file do not matter.
    raw, sha = encode(orders_doc(), indent=2)
    assert parse_payload(raw, expected_sha256=sha).batch_id == "orders-1"


@pytest.mark.parametrize("raw", [
    b"\xff\xfe not utf-8",
    b"{not json",
    b'{"batch_id": "x", "value": NaN}',
    b'{"batch_id": "x", "value": 1e999}',
    b'{"batch_id": "x", "value": -1e999}',
    b'{"batch_id": "x", "nested": [0, {"amount": 1e999}]}',
    b'{"batch_id": "x", "batch_id": "y"}',  # duplicate keys could hide a value
])
def test_unreadable_json_is_rejected(raw):
    assert rejected(raw, "0" * 64).reason is Reason.INVALID_JSON


def test_valid_scientific_notation_keeps_canonical_payload_checksum():
    document = orders_doc()
    document["items"][0]["price"] = 100.0
    raw = json.dumps(document, separators=(",", ":")).encode()
    raw = raw.replace(b'"price":100.0', b'"price":1e2', 1)
    assert b'"price":1e2' in raw
    parsed = parse_payload(raw, expected_sha256=digest(document))
    assert parsed.items[0].price == 100.0


def test_payload_checksum_mismatch_keeps_batch_id():
    raw, _ = encode(orders_doc())
    error = rejected(raw, "0" * 64)
    assert error.reason is Reason.CHECKSUM_MISMATCH
    assert error.batch_id == "orders-1"


@pytest.mark.parametrize("change", [
    lambda d: d["items"][0].update(price=-1.0),                    # negative amount
    lambda d: d["items"][0].update(price="19.9"),                  # string, strict mode: no coercion
    lambda d: d["items"][0].update(discount=1.0),                  # unknown column
    lambda d: d["orders"][0].update(approved_at="2017-04-10T12:00:00"),  # no timezone
    lambda d: d.update(schema_version="2.0"),                      # incompatible schema
    lambda d: d["orders"][0].update(order_id="../etc/passwd"),     # unsafe ID
    lambda d: d.update(outcomes=outcomes_doc()["outcomes"]),       # outcomes inside an orders batch
    lambda d: d["orders"][0].update(approved_at="2017-04-16T00:00:00Z"),  # approved after publication
])
def test_schema_violations_are_rejected(change):
    document = orders_doc()
    change(document)
    raw, sha = encode(document)
    assert rejected(raw, sha).reason is Reason.SCHEMA_INVALID


def test_bad_expected_sha_is_a_caller_error_not_a_rejection():
    raw, _ = encode(orders_doc())
    with pytest.raises(ValueError, match="expected_sha256"):
        parse_payload(raw, expected_sha256="ABC")


def test_file_sha256_check():
    raw, _ = encode(orders_doc())
    check_file_sha256(raw, None)            # no file checksum given -> skipped
    check_file_sha256(raw, raw_sha256(raw))
    with pytest.raises(BatchRejected) as info:
        check_file_sha256(raw + b" ", raw_sha256(raw))
    assert info.value.reason is Reason.CHECKSUM_MISMATCH
    with pytest.raises(ValueError):
        check_file_sha256(raw, "not-a-sha")


def test_supplied_fixtures_pass_all_rules():
    orders_doc_ = json.loads((ROOT / "fixtures/synthetic-orders.json").read_text())
    outcomes_doc_ = json.loads((ROOT / "fixtures/synthetic-outcomes.json").read_text())
    orders = parse_payload(json.dumps(orders_doc_).encode(), expected_sha256=digest(orders_doc_))
    outcomes = parse_payload(json.dumps(outcomes_doc_).encode(), expected_sha256=digest(outcomes_doc_))
    as_of = instant(AS_OF)
    assert validate_batch(orders, ExistingState(), as_of=as_of) == []
    committed = ExistingState(orders={o.order_id: o.approved_at for o in orders.orders})
    assert validate_batch(outcomes, committed, as_of=as_of) == []


# ---------------------------------------------------------------------------------------------
# validate_batch: cross-row and cross-batch rules
# ---------------------------------------------------------------------------------------------
def test_valid_batches_have_no_problems():
    assert check(orders_doc()) == []
    assert check(outcomes_doc(), ExistingState(orders={"o1": APPROVED, "o2": APPROVED})) == []


def test_future_publication():
    assert reasons(check(orders_doc(), as_of="2017-04-14T23:59:59Z")) == {Reason.FUTURE_PUBLICATION}
    assert check(orders_doc(), as_of="2017-04-15T00:00:00Z") == []  # at as_of is allowed


def test_duplicate_keys_inside_batch():
    document = orders_doc(order_ids=["o1"])
    document["payments"].append(dict(document["payments"][0]))
    problems = check(document)
    assert reasons(problems) == {Reason.DUPLICATE_KEY}
    assert "payments key ('o1', 1) appears 2 times" in problems[0].detail


@pytest.mark.parametrize(("table", "column", "value"), [
    ("orders", "customer_id", "c-nobody"),
    ("items", "product_id", "p-nothing"),
    ("items", "seller_id", "s-nobody"),
    ("items", "order_id", "o-unknown"),
    ("payments", "order_id", "o-unknown"),
])
def test_missing_foreign_keys(table, column, value):
    document = orders_doc(order_ids=["o1"])
    document[table][0][column] = value
    assert Reason.MISSING_FOREIGN_KEY in reasons(check(document))


def test_foreign_keys_may_point_to_rows_already_in_the_database():
    document = orders_doc(order_ids=["o3"])
    document["customers"], document["sellers"], document["products"] = [], [], []
    document["orders"][0]["customer_id"] = "c-old"
    existing = ExistingState(customers={"c-old": "SP"}, sellers={"s1": "SP"},
                             products={"p1": ("toys", Decimal(500))})
    assert check(document, existing) == []


def test_incomplete_order():
    document = orders_doc(order_ids=["o1", "o2"])
    document["payments"] = [p for p in document["payments"] if p["order_id"] != "o2"]
    document["items"] = [i for i in document["items"] if i["order_id"] != "o2"]
    problems = check(document)
    assert [p.reason for p in problems] == [Reason.INCOMPLETE_ORDER]
    assert problems[0].detail == "order o2 has no item and no payment"


def test_items_cannot_be_appended_to_a_committed_order():
    document = orders_doc(order_ids=["o2"])
    document["items"].append({"order_id": "o1", "item_id": 2, "product_id": "p1", "seller_id": "s1",
                              "price": 1.0, "freight": 0.0})
    problems = check(document, ExistingState(orders={"o1": APPROVED}))
    assert reasons(problems) == {Reason.APPEND_TO_COMMITTED_ORDER}


def test_order_already_committed_by_another_batch():
    existing = ExistingState(orders={"o1": APPROVED}, customers={"c-o1": "SP"})
    assert reasons(check(orders_doc(order_ids=["o1"]), existing)) == {Reason.ALREADY_COMMITTED}


def test_identical_dimension_rows_are_reused_but_changed_rows_rejected():
    same = ExistingState(customers={"c-o1": "SP"}, sellers={"s1": "SP"},
                         products={"p1": ("toys", Decimal(500))})
    assert check(orders_doc(order_ids=["o1"]), same) == []  # Decimal(500) == 500.0: same value

    changed = ExistingState(sellers={"s1": "RJ"}, products={"p1": ("toys", Decimal("499.5"))})
    problems = check(orders_doc(order_ids=["o1"]), changed)
    assert [p.reason for p in problems] == [Reason.CHANGED_IMMUTABLE_ROW] * 2


def test_outcome_rules():
    assert reasons(check(outcomes_doc(order_ids=["o9"]))) == {Reason.MISSING_FOREIGN_KEY}
    done = ExistingState(orders={"o1": APPROVED}, outcomes=frozenset({"o1"}))
    assert reasons(check(outcomes_doc(order_ids=["o1"]), done)) == {Reason.ALREADY_COMMITTED}
    late_approval = ExistingState(orders={"o1": datetime(2017, 4, 21, tzinfo=UTC)})
    assert reasons(check(outcomes_doc(order_ids=["o1"]), late_approval)) == {Reason.DELIVERY_BEFORE_APPROVAL}


def test_all_problems_are_reported_in_a_stable_order():
    document = orders_doc(order_ids=["o2", "o1"])
    for item in document["items"]:
        item["product_id"] = "p-missing"
    first, second = check(document), check(document)
    assert first == second
    assert [p.detail for p in first] == [
        "item o1#1 references unknown product p-missing",
        "item o2#1 references unknown product p-missing",
    ]


# ---------------------------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------------------------
def test_referenced_keys_cover_definitions_and_references():
    keys = referenced_keys(Batch.model_validate(orders_doc(order_ids=["o1"])))
    assert keys.customers == {"c-o1"} and keys.sellers == {"s1"} and keys.products == {"p1"}
    assert keys.orders == {"o1"}


def test_to_decimal_is_exact():
    assert to_decimal(19.9) == Decimal("19.9")
    assert to_decimal(0.1) + to_decimal(0.2) == Decimal("0.3")


def test_batch_rejected_needs_problems_and_caps_detail():
    with pytest.raises(ValueError):
        BatchRejected([])
    many = [Problem(Reason.DUPLICATE_KEY, str(n)) for n in range(MAX_REPORTED_PROBLEMS + 10)]
    error = BatchRejected(many, batch_id="b")
    assert len(error.detail_records()) == MAX_REPORTED_PROBLEMS
    assert str(error).endswith(f"(+{len(many) - 1} more)")


# ---------------------------------------------------------------------------------------------
# Review of MR !7: publication check on its own, index metadata vs payload
# ---------------------------------------------------------------------------------------------
def test_publication_problems_is_inclusive():
    batch = Batch.model_validate(orders_doc())
    assert publication_problems(batch, as_of="2017-04-15T00:00:00Z") == []
    assert [p.reason for p in publication_problems(batch, as_of="2017-04-14T23:59:59Z")] == [
        Reason.FUTURE_PUBLICATION]


def _meta(**payload):
    envelope = {"batch_id": "orders-1", "kind": "orders", "available_at": "2017-04-15T00:00:00Z"} | payload
    expected = ExpectedMetadata(kind="orders", available_at=instant("2017-04-15T00:00:00Z"),
                                batch_id="orders-1")
    return [p.reason for p in metadata_problems(**envelope, expected=expected)]


def test_metadata_matches_when_payload_agrees_with_index():
    assert _meta() == []
    assert _meta(available_at="2017-04-14T21:00:00-03:00") == []  # same instant, other offset


@pytest.mark.parametrize("payload", [
    {"kind": "outcomes"},
    {"available_at": "2017-04-16T00:00:00Z"},
    {"available_at": "not a time"},
    {"available_at": None},
    {"batch_id": "orders-2"},
])
def test_metadata_mismatch_is_reported(payload):
    assert _meta(**payload) == [Reason.FEED_METADATA_MISMATCH]


def test_batch_id_is_only_compared_when_the_index_has_one():
    expected = ExpectedMetadata(kind="orders", available_at=instant("2017-04-15T00:00:00Z"))
    assert metadata_problems(batch_id="anything", kind="orders", available_at="2017-04-15T00:00:00Z",
                             expected=expected) == []
