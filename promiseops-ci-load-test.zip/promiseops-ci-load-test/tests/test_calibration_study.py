import io

import joblib
import numpy as np
import pandas as pd
import pytest
from sklearn.linear_model import LogisticRegression

from promiseops.calibration_study import calibrate, reliability, temporal_ids
from promiseops.cohorts import Cutoffs


def test_calibration_uses_disjoint_temporal_rows_with_training_label_cutoff():
    labels = pd.DataFrame({
        "order_id": ["base", "boundary_unmature", "calibration", "pending", "validation"],
        "approved_at": pd.to_datetime(["2017-10-01", "2017-10-31T23:59:59Z", "2017-11-01", "2017-12-20", "2018-01-01"], utc=True, format="mixed"),
        "label_available_at": pd.to_datetime(["2017-10-20", "2017-11-05", "2017-12-30", "2018-01-15", "2018-02-05"], utc=True),
        "late": pd.array([False, True, True, True, False], dtype="boolean"),
    })
    cutoff = Cutoffs(train_end="2017-12-31T23:59:59Z", validation_end="2018-02-28T23:59:59Z",
                      as_of="2018-04-30T00:00:00Z")
    _, base, calibration, validation = temporal_ids(labels, cutoff)
    assert base == ("base",) and calibration == ("calibration",) and validation == ("validation",)


@pytest.mark.parametrize("method", ["sigmoid", "isotonic"])
def test_calibration_does_not_refit_base_and_roundtrips(method):
    x = pd.DataFrame({"x": np.linspace(-2, 2, 100)})
    y = np.arange(100) % 3 == 0
    base = LogisticRegression().fit(x.iloc[:50], y[:50])
    before = joblib.hash(base)
    calibrated = calibrate(base, x.iloc[50:], y[50:], method)
    assert joblib.hash(base) == before
    stream = io.BytesIO()
    joblib.dump(calibrated, stream)
    stream.seek(0)
    np.testing.assert_array_equal(calibrated.predict_proba(x), joblib.load(stream).predict_proba(x))


def test_reliability_includes_probability_one_and_counts_every_row():
    report = reliability([False, True, True], [.1, .9, 1.0])
    assert sum(row["n"] for row in report["reliability"]) == 3
    assert report["ece_fixed_10_bins"] == pytest.approx(2 / 30)
