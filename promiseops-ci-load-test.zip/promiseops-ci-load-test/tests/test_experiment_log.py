"""Protocol-level logging tests with a fake client; no real MLflow run is claimed."""

import json
import sys
from pathlib import Path
from types import ModuleType, SimpleNamespace

import pytest

from promiseops import experiment_log


@pytest.fixture
def client(monkeypatch):
    entities = ModuleType("mlflow.entities")
    entities.Metric = lambda key, value, *args: SimpleNamespace(key=key, value=value)
    entities.Param = lambda key, value: SimpleNamespace(key=key, value=value)
    monkeypatch.setitem(sys.modules, "mlflow", ModuleType("mlflow"))
    monkeypatch.setitem(sys.modules, "mlflow.entities", entities)
    monkeypatch.setattr(experiment_log.tracking, "ensure_experiment", lambda *args: "experiment")

    class Client:
        def __init__(self):
            self.texts, self.statuses, self.params, self.tags = {}, [], {}, {}
            self.corrupt = False

        def create_run(self, *args, **kwargs):
            return SimpleNamespace(info=SimpleNamespace(run_id="test-run"))

        def log_batch(self, run_id, params, metrics):
            self.params = {p.key: p.value for p in params}

        def log_text(self, run_id, text, path):
            self.texts[path] = text

        def download_artifacts(self, run_id, path, folder):
            saved = Path(folder) / path
            saved.write_text("{}" if self.corrupt else self.texts[path], encoding="utf-8")
            return str(saved)

        def set_terminated(self, run_id, status):
            self.statuses.append(status)

        def set_tag(self, run_id, key, value):
            self.tags[key] = value

    return Client()


def log(client, **changes):
    args = {"experiment": "verification", "kind": "verification", "source_commit": "a" * 40,
            "report": {"passed": 3}, "params": {"dataset_kind": "synthetic"}, "metrics": {"passed": 3}}
    return experiment_log.log_report(client, **(args | changes))


@pytest.mark.parametrize("successful,status", [(True, "FINISHED"), (False, "FAILED")])
def test_report_readback_and_honest_status(client, successful, status):
    assert log(client, successful=successful) == "test-run"
    assert client.statuses == [status]
    assert json.loads(client.texts["report.json"]) == {"passed": 3}
    assert "software.mlflow" in client.params


def test_corrupted_readback_fails_the_run(client):
    client.corrupt = True
    with pytest.raises(ValueError, match="read-back differs"):
        log(client)
    assert client.statuses == ["FAILED"]


def test_credentialed_urls_are_removed_from_test_logs(client):
    log(client, artifacts={"pytest.log": "failed https://user:private@host/path?token=hidden"})
    assert "private" not in client.texts["pytest.log"]
    assert "hidden" not in client.texts["pytest.log"]
    assert "https://***@host/path?***" in client.texts["pytest.log"]
