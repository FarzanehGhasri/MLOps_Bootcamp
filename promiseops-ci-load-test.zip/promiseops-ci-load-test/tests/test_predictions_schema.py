import pytest
from httpx import ASGITransport, AsyncClient

from promiseops import db
from promiseops.api import create_app


def test_schema_v2_contains_predictions_table_and_indexes():
    assert db.SCHEMA_VERSION == 4  # v3 prediction_snapshots, v4 monitoring_decisions
    sql = db.schema_sql()
    assert "CREATE TABLE IF NOT EXISTS promiseops.predictions" in sql
    assert "request_id        text             PRIMARY KEY" in sql
    assert "predictions_request_id_idx" in sql
    assert "INSERT INTO promiseops.schema_version (version) VALUES (2)" in sql

@pytest.mark.anyio
async def test_predictions_require_database(monkeypatch):
    monkeypatch.setenv("PROMISEOPS_API_KEY", "secret")
    monkeypatch.setenv("PROMISEOPS_RELEASE", "release")
    monkeypatch.delenv("PROMISEOPS_DATABASE_URL", raising=False)
    async with AsyncClient(transport=ASGITransport(app=create_app()), base_url="http://test") as client:
        result = await client.post("/predict", headers={"X-API-Key": "secret"},
                                   json={"order_id": "ord_schema_001", "request_id": "req_schema_001"})
    assert result.status_code == 503
