from datetime import timedelta
from types import SimpleNamespace

import numpy as np
import pandas as pd
import pytest

from promiseops import cohorts
from promiseops.fit_audit import compare_reference, training_subset


def test_learning_subset_is_seeded_stratified_and_cannot_add_ids():
    ids = tuple(f"o{i:03}" for i in range(100))
    y = np.arange(100) % 5 == 0
    subset = training_subset(ids, y, .5)
    assert subset == training_subset(ids, y, .5)
    assert len(subset) == 50 and set(subset) < set(ids)
    assert sum(y[ids.index(oid)] for oid in subset) == 10
    assert training_subset(ids, y, 1.0) == ids
    with pytest.raises(ValueError):
        training_subset(ids, y, 0)


def test_before_after_requires_identical_cutoffs_and_cohort():
    cutoff = cohorts.Cutoffs(train_end="2017-12-31T23:59:59Z", validation_end="2018-02-28T23:59:59Z",
                             as_of="2018-04-30T00:00:00Z")
    table = pd.DataFrame({"x": [0, 1, 2]}, index=["a", "b", "c"])
    y = pd.Series([False, True, False], index=table.index)
    risk = np.array([.1, .8, .3])
    model = SimpleNamespace(predict_proba=lambda x: np.column_stack([1 - risk, risk]))
    lineage = SimpleNamespace(**cutoff.model_dump(), validation_cohort_sha256=cohorts.cohort_sha256(table.index))
    loaded = SimpleNamespace(model=model, lineage=lineage,
                             manifest=SimpleNamespace(model_version="reference", artifact_sha256="a" * 64))
    result = compare_reference(loaded, table, y, risk, cutoff)
    assert result["probabilities_equal_at_1e_12"]
    assert all(v == 0 for v in result["after_minus_before"].values())
    lineage.validation_cohort_sha256 = "b" * 64
    with pytest.raises(ValueError, match="IDs differ"):
        compare_reference(loaded, table, y, risk, cutoff)
    lineage.validation_cohort_sha256 = cohorts.cohort_sha256(table.index)
    lineage.train_end += timedelta(days=1)
    with pytest.raises(ValueError, match="cutoffs differ"):
        compare_reference(loaded, table, y, risk, cutoff)
