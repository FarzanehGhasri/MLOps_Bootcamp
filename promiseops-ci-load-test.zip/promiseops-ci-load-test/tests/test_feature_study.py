import io

import joblib
import numpy as np
import pandas as pd
import pytest
from test_features import frames, item, order, payment

from promiseops.feature_study import build_engineered, engineer
from promiseops.features import compute_features


def sample():
    return compute_features(*frames(
        [order(f"o{i}", promised=f"2017-04-{15 + i % 10:02}") for i in range(40)],
        [item(f"o{i}", price=i, freight=2) for i in range(40)],
        [payment(f"o{i}", value=i + 2) for i in range(40)]))


def test_engineering_is_per_order_finite_and_does_not_mutate_input():
    x = sample()
    before = x.copy(deep=True)
    out = engineer(x)
    pd.testing.assert_frame_equal(x, before)
    pd.testing.assert_frame_equal(engineer(x.iloc[[0]]), out.iloc[[0]])
    assert out.iloc[0].freight_to_price == 2  # zero-price denominator is safe
    assert out.iloc[0].shipping_route == "SP>SP"
    assert np.isfinite(out.select_dtypes(include="number")).all().all()
    with pytest.raises(ValueError, match="schema"):
        engineer(x.assign(late=True))


@pytest.mark.parametrize("approach", ["logistic_regression", "hist_gradient_boosting"])
def test_pipeline_roundtrip_and_unseen_validation_categories(approach):
    x = sample()
    model = build_engineered(approach).fit(x, np.arange(len(x)) % 2 == 0)
    future = x.iloc[:3].copy()
    future["customer_state"] = "ZZ"
    future["total_price"] = 1000000
    before = model.predict_proba(future)
    assert np.isfinite(before).all()
    stream = io.BytesIO()
    joblib.dump(model, stream)
    stream.seek(0)
    np.testing.assert_array_equal(before, joblib.load(stream).predict_proba(future))
    if approach == "logistic_regression":
        scaler = model.named_steps["preprocess"].named_transformers_["numeric"]
        # Prediction on an extreme validation value must not refit training statistics.
        assert scaler.mean_[2] == x.total_price.mean()


def test_outcome_columns_cannot_change_raw_features():
    inputs = frames([order()], [item()], [payment()])
    expected = compute_features(*inputs)
    inputs[0]["delivered_at"] = "2099-01-01"
    inputs[0]["late"] = True
    inputs[0]["status"] = "delivered"
    pd.testing.assert_frame_equal(compute_features(*inputs), expected)
