"""ci/fetch_release.py: verified download from MLflow and archive packaging."""

import hashlib
import os
import sys
import tarfile
from pathlib import Path
from types import SimpleNamespace

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "ci"))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))
import fetch_release

from promiseops import record


class _StubClient:
    def __init__(self, tags, files):
        self._tags, self._files = tags, files

    def get_run(self, run_id):
        return SimpleNamespace(data=SimpleNamespace(tags=self._tags))

    def download_artifacts(self, run_id, path, dst_path):
        dest = Path(dst_path) / path
        dest.mkdir(parents=True, exist_ok=True)
        for name, content in self._files.items():
            (dest / name).write_bytes(content)
        return dest


@pytest.fixture
def _stub_read_bundle(monkeypatch):
    monkeypatch.setattr(fetch_release, "read_bundle",
                        lambda bundle: SimpleNamespace(
                            manifest=SimpleNamespace(artifact_sha256="a" * 64)))


def test_refuses_a_run_without_a_model_record(_stub_read_bundle):
    client = _StubClient({}, {"release.json": b"{}"})
    with pytest.raises(SystemExit, match="promiseops.artifact_sha256"):
        fetch_release.fetch_verified_bundle(client, "run1", Path("out"))


def test_refuses_a_bundle_that_differs_from_the_run_tag(_stub_read_bundle):
    client = _StubClient({record.TAG_ARTIFACT_SHA256: "b" * 64}, {"release.json": b"{}"})
    with pytest.raises(SystemExit, match="does not match the run's tag"):
        fetch_release.fetch_verified_bundle(client, "run1", Path("out"))


def test_matching_tag_downloads_and_archives_the_bundle(tmp_path, _stub_read_bundle):
    client = _StubClient({record.TAG_ARTIFACT_SHA256: "a" * 64},
                         {"release.json": b"{}", "model.joblib": b"m"})
    bundle = fetch_release.fetch_verified_bundle(client, "run1", tmp_path)
    assert (bundle / "release.json").read_bytes() == b"{}"
    archive = fetch_release.archive_bundle(bundle, tmp_path / "promiseops-release.tar.gz")
    with tarfile.open(archive) as tf:
        assert {"bundle/release.json", "bundle/model.joblib"} <= set(tf.getnames())


def test_archive_is_deterministic_per_bundle(tmp_path, _stub_read_bundle):
    client = _StubClient({record.TAG_ARTIFACT_SHA256: "a" * 64},
                         {"release.json": b"{}", "model.joblib": b"m"})
    bundle = fetch_release.fetch_verified_bundle(client, "run1", tmp_path)
    first = fetch_release.archive_bundle(bundle, tmp_path / "one.tar.gz")
    os.utime(bundle / "model.joblib", (12345, 12345))
    second = fetch_release.archive_bundle(bundle, tmp_path / "two.tar.gz")
    assert hashlib.sha256(first.read_bytes()).digest() == hashlib.sha256(second.read_bytes()).digest()
