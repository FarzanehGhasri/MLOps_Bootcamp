"""Unit tests for promiseops.feed: index parsing, publication order, as_of replay, safe paths."""

import json
from pathlib import Path

import pytest
from factories import encode, orders_doc, outcomes_doc
from pydantic import ValidationError

from promiseops.feed import (
    FeedEntry,
    first_inconsistent_entry,
    load_index,
    publication_order,
    published_until,
    read_entry,
)
from promiseops.validation import raw_sha256

SHA = "a" * 64


def entry(file: str, kind: str = "orders", available_at: str = "2017-04-15T00:00:00Z") -> dict:
    return {"file": file, "kind": kind, "available_at": available_at, "payload_sha256": SHA,
            "file_sha256": SHA, "extra_gateway_field": "ignored"}


def test_index_accepts_manifest_gateway_or_list(tmp_path):
    rows = [entry("a.json"), entry("b.json")]
    # Real package manifest.json: metadata + "releases" with per-entry row counts.
    manifest = {"schema_version": "1.0", "interval_days": 14,
                "releases": [r | {"orders": 3, "outcomes": 0} for r in rows]}
    (tmp_path / "manifest.json").write_text(json.dumps(manifest))
    (tmp_path / "gateway.json").write_text(json.dumps({"as_of": "2018-01-15T00:00:00Z", "entries": rows}))
    (tmp_path / "list.json").write_text(json.dumps(rows))
    assert [e.file for e in load_index(tmp_path / "manifest.json")] == ["a.json", "b.json"]
    assert load_index(tmp_path / "gateway.json") == load_index(tmp_path / "manifest.json")
    assert load_index(tmp_path / "list.json") == load_index(tmp_path / "manifest.json")


@pytest.mark.parametrize("document", [{"files": []}, {"releases": [], "entries": []}, {"releases": {}}])
def test_index_with_unknown_or_ambiguous_layout_is_refused(tmp_path, document):
    (tmp_path / "bad.json").write_text(json.dumps(document))
    with pytest.raises(TypeError):
        load_index(tmp_path / "bad.json")


def test_publication_order_puts_orders_before_outcomes_at_equal_time():
    entries = [FeedEntry.model_validate(e) for e in [
        entry("late.json", available_at="2017-05-01T00:00:00Z"),
        entry("outcomes.json", kind="outcomes"),
        entry("orders.json"),
        entry("orders-2.json"),
    ]]
    assert [e.file for e in publication_order(entries)] == [
        "orders.json", "orders-2.json", "outcomes.json", "late.json",
    ]


def test_published_until_is_inclusive_and_timezone_aware():
    entries = [FeedEntry.model_validate(entry("a.json")),
               FeedEntry.model_validate(entry("b.json", available_at="2017-04-15T00:00:01Z"))]
    # 2017-04-14T21:00-03:00 is the same instant as 2017-04-15T00:00Z
    assert [e.file for e in published_until(entries, "2017-04-14T21:00:00-03:00")] == ["a.json"]


@pytest.mark.parametrize("bad", [
    {"file": "../secret.json"},
    {"file": "/etc/passwd"},
    {"file": "dir\\x.json"},
    {"available_at": "2017-04-15T00:00:00"},  # naive timestamp
    {"payload_sha256": "ABC"},
    {"kind": "refunds"},
])
def test_invalid_entries_are_refused(bad):
    with pytest.raises(ValidationError):
        FeedEntry.model_validate(entry("a.json") | bad)


def test_read_entry_returns_exact_bytes(tmp_path):
    (tmp_path / "batches").mkdir()
    (tmp_path / "batches" / "a.json").write_bytes(b'{"x": 1}\n')
    assert read_entry(tmp_path, FeedEntry.model_validate(entry("batches/a.json"))) == b'{"x": 1}\n'


REAL_FEED = Path(__file__).resolve().parents[1] / "data" / "student-company-feed"


@pytest.mark.skipif(not (REAL_FEED / "manifest.json").exists(),
                    reason="real course feed not extracted into data/ (git-ignored; see docs/ingestion)")
def test_real_course_manifest_is_readable_and_ordered():
    entries = load_index(REAL_FEED / "manifest.json")
    assert len(entries) == 42 and {e.kind for e in entries} == {"orders", "outcomes"}
    assert publication_order(entries) == entries  # the package already lists them in publication order
    assert all((REAL_FEED / e.file).is_file() for e in entries)


# ---------------------------------------------------------------------------------------------
# Review of MR !7: the index must agree with every payload BEFORE it drives ordering/filtering
# ---------------------------------------------------------------------------------------------
def _write_feed(folder, documents):
    """Write payload files and return index entries that correctly describe them."""
    entries = []
    for name, document in documents:
        raw, sha = encode(document)
        (folder / name).write_bytes(raw)
        entries.append({"file": name, "kind": document["kind"], "available_at": document["available_at"],
                        "batch_id": document["batch_id"], "payload_sha256": sha,
                        "file_sha256": raw_sha256(raw)})
    return entries


def _first_bad(folder, rows):
    return first_inconsistent_entry(folder, [FeedEntry.model_validate(r) for r in rows])


def test_consistent_index_passes_preflight(tmp_path):
    rows = _write_feed(tmp_path, [("orders.json", orders_doc()), ("outcomes.json", outcomes_doc())])
    assert _first_bad(tmp_path, rows) is None
    rows[0]["available_at"] = "2017-04-14T21:00:00-03:00"  # same instant written differently
    assert _first_bad(tmp_path, rows) is None


@pytest.mark.parametrize("change", [
    {"kind": "outcomes"},                          # index kind differs from payload kind
    {"available_at": "2017-04-14T00:00:00Z"},      # index says earlier than the payload
    {"available_at": "2099-01-01T00:00:00Z"},      # index says later: would be silently skipped
    {"batch_id": "orders-999"},                    # index batch_id differs from payload batch_id
    {"file_sha256": "0" * 64},                     # corrupted / replaced file
    {"payload_sha256": "0" * 64},                  # payload digest differs (checked even if not yet due)
    {"file": "missing.json"},                      # listed file does not exist
])
def test_index_payload_mismatch_is_detected(tmp_path, change):
    rows = _write_feed(tmp_path, [("orders.json", orders_doc()), ("outcomes.json", outcomes_doc())])
    rows[0] = rows[0] | change  # the orders entry now disagrees with its file
    assert _first_bad(tmp_path, rows) == FeedEntry.model_validate(rows[0])


def test_preflight_reads_json_as_strictly_as_ingestion(tmp_path):
    # A duplicated key: plain json.loads keeps the last value, so the digest and metadata still
    # agree with the index, but ingestion rejects the file (invalid_json). Pre-flight must too.
    raw, sha = encode(orders_doc())
    raw = b'{"batch_id": "hidden",' + raw[1:]
    (tmp_path / "orders.json").write_bytes(raw)
    document = orders_doc()
    row = {"file": "orders.json", "kind": "orders", "available_at": document["available_at"],
           "batch_id": document["batch_id"], "payload_sha256": sha, "file_sha256": raw_sha256(raw)}
    assert _first_bad(tmp_path, [row]) == FeedEntry.model_validate(row)


def test_batch_id_is_optional_in_the_index(tmp_path):
    rows = _write_feed(tmp_path, [("orders.json", orders_doc())])
    del rows[0]["batch_id"]
    assert _first_bad(tmp_path, rows) is None
