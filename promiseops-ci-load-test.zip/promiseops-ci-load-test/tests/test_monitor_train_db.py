"""Worker monitor-train mode end to end (#21): incumbent -> re-scored recent orders -> report -> (training).

Real PostgreSQL and a REAL MLflow with a temporary SQLite store: nothing is sent to any server.
Skipped without PROMISEOPS_TEST_DATABASE_URL or without MLflow. DROPS the schema (fixture from
test_ingestion_db): use an EMPTY database whose name ends in "_test", never the one holding the real feed.

Test data (test_model_db.history): 150 validation orders released 2017-05-11, labels known by 05-28,
every 5th late; as_of 2017-06-15, so the 60-day label window holds exactly those 150 orders.
"""

import json
from pathlib import Path

import numpy as np
import pytest
from sklearn.dummy import DummyClassifier
from test_bundle import lineage, reference, write
from test_ingestion_db import URL, conn  # noqa: F401  (pytest fixture)
from test_model_db import history  # noqa: F401  (pytest fixture)
from test_training_db import (  # noqa: F401  (client and tracking_uri are pytest fixtures)
    COMMIT,
    CUTOFFS,
    MOCK_RELEASE,
    client,
    settings,
    tracking_uri,
)

from promiseops import approaches, inference, monitor_train, record, training, worker
from promiseops import bundle as b

pytestmark = pytest.mark.skipif(not URL, reason="PROMISEOPS_TEST_DATABASE_URL is not set")
mlflow = pytest.importorskip("mlflow")


def runs_of(mlflow_client, experiment):
    found = mlflow_client.get_experiment_by_name(experiment)
    return [] if found is None else mlflow_client.search_runs([found.experiment_id])


def overpromising_incumbent(tmp_path):
    """A constant model whose recorded reference claims excellent results: live quality will fall short."""
    model = DummyClassifier(strategy="prior").fit(np.zeros((10, 1)), [False] * 8 + [True] * 2)
    claimed = b.EvaluationMetrics(n=150, prevalence=0.2, k=15, recall_at_10=0.5, precision_at_10=1.0,
                                  pr_auc=0.9, brier=0.01)
    write(tmp_path, model=model,
          lineage=lineage(train_end=CUTOFFS.train_end, validation_end=CUTOFFS.validation_end,
                          as_of=CUTOFFS.as_of, training_label_cutoff=CUTOFFS.training_label_cutoff,
                          validation_label_cutoff=CUTOFFS.validation_label_cutoff),
          reference=reference().model_copy(update={"validation_metrics": claimed}))
    return tmp_path / "bundle"


def recorded_history(database, incumbent, ids, path):
    """Synthetic producer fixture: explicitly record scores before the monitoring call."""
    loaded = b.read_bundle(incumbent)
    table = inference.release_features(database, ids, as_of=CUTOFFS.as_of,
                                       manifest=loaded.manifest, lineage=loaded.lineage)
    predictions = table.reset_index()
    predictions["predicted_at"] = "2017-06-15T00:00:00Z"
    predictions["risk_probability"] = approaches.risk(loaded.model, table).to_numpy()
    predictions["model_version"] = loaded.manifest.model_version
    path.write_text("\n".join(json.dumps(row) for row in predictions.to_dict(orient="records")), encoding="utf-8")
    return path


def test_no_recommendation_means_no_training_and_the_report_is_recorded(tmp_path, history, client):  # noqa: F811
    database, _, val_ids = history
    first = training.run_train(database, client, settings(tmp_path / "first"), cutoffs=CUTOFFS)
    history_path = recorded_history(database, first.bundle_path, val_ids, tmp_path / "predictions.jsonl")
    # The serving model is the one just trained: its live quality equals its own validation reference.
    result = monitor_train.run_monitor_train(database, client, settings(tmp_path, incumbent=first.bundle_path),
                                             cutoffs=CUTOFFS, prediction_history=history_path)

    report = result.record.report
    assert result.record.status == "assessed" and not result.record.retrain_recommended
    assert result.training is None
    assert report.labels.mature_orders == len(val_ids) and report.labels.late == len(val_ids) // 5
    assert report.labels.metrics == first.record.lineage.validation_metrics   # same model, same orders
    assert any("drift not assessed" in reason for reason in report.reasons)  # no orders in the last 14 days

    # persisted and FINISHED; no second training run was created
    run = client.get_run(result.monitoring_run_id)
    assert run.info.status == "FINISHED"
    assert run.data.tags[monitor_train.TAG_RETRAIN] == "false"
    assert run.data.metrics["labels.mature_orders"] == len(val_ids)
    stored = client.download_artifacts(result.monitoring_run_id, monitor_train.MONITORING_FILE, str(tmp_path))
    assert monitor_train.MonitoringRecord.model_validate_json(Path(stored).read_text(encoding="utf-8")) == result.record
    assert [r.info.run_id for r in runs_of(client, "promiseops-late-delivery")] == [first.run_id]


def test_degraded_quality_recommends_retraining_and_then_trains(tmp_path, history, client):  # noqa: F811
    database, _, val_ids = history
    incumbent = overpromising_incumbent(tmp_path / "incumbent")
    history_path = recorded_history(database, incumbent, val_ids, tmp_path / "predictions.jsonl")
    result = monitor_train.run_monitor_train(database, client, settings(tmp_path, incumbent=incumbent),
                                             cutoffs=CUTOFFS, prediction_history=history_path)

    assert result.record.retrain_recommended
    assert any(reason.startswith("recall@10%") for reason in result.record.reasons)
    trained = result.training
    assert trained is not None and trained.decision.decision == "accepted"
    assert trained.decision.champion_model_version == result.record.incumbent_model_version  # re-scored champion
    assert trained.registry_version == "1"

    # report first (FINISHED), then training; linked both ways
    monitoring = client.get_run(result.monitoring_run_id)
    training_run = client.get_run(trained.run_id)
    assert monitoring.info.status == "FINISHED" and monitoring.info.end_time <= training_run.info.start_time
    assert monitoring.data.tags[monitor_train.TAG_TRAINING_RUN] == trained.run_id
    assert training_run.data.tags[monitor_train.TAG_MONITORING_RUN] == result.monitoring_run_id
    assert record.load_logged_record(client, trained.run_id) == trained.record


def test_mock_incumbent_is_recorded_without_measuring_or_training(tmp_path, history, client):  # noqa: F811
    database, *_ = history
    result = monitor_train.run_monitor_train(database, client, settings(tmp_path), cutoffs=CUTOFFS)
    assert (result.record.status, result.training) == ("no_reference", None)
    run = client.get_run(result.monitoring_run_id)
    assert run.data.tags[monitor_train.TAG_STATUS] == "no_reference"
    assert runs_of(client, "promiseops-late-delivery") == []


def test_failure_marks_the_monitoring_run_failed(tmp_path, history, client):  # noqa: F811
    database, *_ = history
    with pytest.raises(b.BundleError):
        monitor_train.run_monitor_train(database, client, settings(tmp_path, incumbent=tmp_path / "missing"),
                                        cutoffs=CUTOFFS)
    [run] = runs_of(client, monitor_train.MONITORING_EXPERIMENT)
    assert run.info.status == "FAILED" and run.data.tags[training.TAG_ERROR].startswith("BundleError")


def test_worker_command_runs_monitor_train(tmp_path, history, tracking_uri, capsys):  # noqa: F811
    environ = {"PROMISEOPS_DATABASE_URL": URL, "MLFLOW_TRACKING_URI": tracking_uri, "CI_COMMIT_SHA": COMMIT,
               "PROMISEOPS_ARTIFACTS": str(tmp_path / "artifacts"), "PROMISEOPS_INCUMBENT": str(MOCK_RELEASE)}
    args = ["--mode", "monitor-train", "--train-end", "2017-05-01T00:00:00Z",
            "--validation-end", "2017-05-31T00:00:00Z", "--as-of", "2017-06-15T00:00:00Z"]
    assert worker.main(args, environ=environ) == 0
    summary = json.loads(capsys.readouterr().out.strip().splitlines()[-1])
    assert summary["status"] == "ok" and summary["mode"] == "monitor-train"
    assert (summary["monitoring_status"], summary["trained"]) == ("no_reference", False)
