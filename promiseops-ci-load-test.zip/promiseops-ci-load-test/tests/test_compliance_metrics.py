"""Reject missing/invalid targets instead of silently treating them as late deliveries."""

import numpy as np
import pytest

from promiseops import approaches, metrics


@pytest.mark.parametrize("invalid", [None, np.nan, "False", "True", 2, -1, float("inf")])
def test_metrics_reject_nonbinary_or_missing_labels(invalid):
    with pytest.raises(ValueError, match="binary labels"):
        metrics.evaluate(["a", "b", "c"], [False, True, invalid], [.1, .8, .2])


def test_metrics_reject_accidental_matrix_inputs():
    with pytest.raises(ValueError, match="one-dimensional"):
        metrics.evaluate(["a", "b"], [False, True], [[.1], [.9]])


def test_binary_numeric_and_boolean_labels_match():
    args = (["a", "b", "c"], [.1, .8, .2])
    assert metrics.evaluate(args[0], [False, True, False], args[1]) == metrics.evaluate(
        args[0], [0, 1, 0], args[1])


@pytest.mark.parametrize("name", approaches.CANDIDATE_APPROACHES)
def test_crossfit_splitter_parameters_are_logged(name):
    params = approaches.hyperparameters(approaches.build(name))
    prefix = "preprocess.target_enc.cv"
    assert params[f"{prefix}.class"] == "StratifiedKFold"
    assert params[f"{prefix}.n_splits"] == "5"
    assert params[f"{prefix}.shuffle"] == "True"
    assert params[f"{prefix}.random_state"] == "0"
