"""Pure diagnostic checks: no database, MLflow server, or model tuning."""

from datetime import UTC, datetime
from types import SimpleNamespace

import pandas as pd
import pytest

from promiseops.diagnostics import bootstrap_recall, manual_metric_check, split_audit


def test_budget_metric_is_independently_reproduced_with_ties():
    result = manual_metric_check(["b", "a", "c", "d"], [False, True, True, False], [0.8, 0.8, 0.1, 0.2])
    assert result["matches"]
    assert result["k"] == 1 and result["late_in_top_k"] == 1 and result["late"] == 2
    assert result["recall_manual"] == 0.5 and result["precision_manual"] == 1


def test_bootstrap_is_reproducible_and_bounded():
    args = ([f"o{i:02}" for i in range(30)], [i % 3 == 0 for i in range(30)], [i / 30 for i in range(30)])
    first = bootstrap_recall(*args, repeats=40, seed=42)
    assert first == bootstrap_recall(*args, repeats=40, seed=42)
    lo, hi = first["recall_95_percentile_interval"]
    assert 0 <= lo <= hi <= 1 and first["valid_repeats"] == 40
    with pytest.raises(ValueError, match="positive"):
        bootstrap_recall(*args, repeats=0)


def labels():
    return pd.DataFrame({
        "order_id": ["t1", "t2", "v1", "v2"],
        "approved_at": pd.to_datetime(["2017-12-01", "2017-12-20", "2018-01-01", "2018-02-01"], utc=True),
        "label_available_at": pd.to_datetime(["2017-12-15", "2018-01-15", "2018-02-01", "2018-03-01"], utc=True),
        "late": pd.array([False, True, True, False], dtype="boolean"),
    })


def cutoffs():
    return SimpleNamespace(train_end=datetime(2017, 12, 31, tzinfo=UTC),
                           validation_end=datetime(2018, 2, 28, tzinfo=UTC), as_of=datetime(2018, 4, 30, tzinfo=UTC))


def test_later_labels_explain_selection_without_entering_training():
    report = split_audit(labels(), ["t1"], ["v1", "v2"], cutoffs())
    assert all(report["checks"].values())
    assert report["training_eligible_orders"] == 1
    assert report["training_labels_not_known_at_cutoff"] == 1
    assert report["training_eligible_prevalence"] == 0
    assert report["training_later_known_prevalence"] == 0.5


def test_bad_split_is_reported_instead_of_silently_accepted():
    report = split_audit(labels(), ["t1", "t2"], ["t1", "v1"], cutoffs())
    assert not report["checks"]["train_label_cutoff"]
    assert not report["checks"]["disjoint_train_validation"]
    assert not report["checks"]["validation_approval_window"]
