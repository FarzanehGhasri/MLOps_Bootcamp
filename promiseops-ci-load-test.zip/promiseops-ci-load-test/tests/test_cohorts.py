"""Labels and cohorts without a database (run in CI): local-date label, cutoff boundaries, hash, sufficiency.

Run: $env:PYTHONPATH = "src"; python -m pytest tests/test_cohorts.py -v
"""

from datetime import date

import pandas as pd
import pytest
from pydantic import ValidationError

from promiseops.cohorts import (
    Cutoffs,
    InsufficientCohort,
    add_labels,
    cohort_sha256,
    describe,
    require_sufficient,
    select_window,
    split,
)

TRAIN_END = "2017-10-31T23:59:59+00:00"
VALIDATION_END = "2017-12-31T23:59:59+00:00"
AS_OF = "2018-03-01T00:00:00+00:00"


def row(order_id, approved_at, delivered_at=None, label_available_at=None, promised="2017-04-25"):
    return {"order_id": order_id, "approved_at": approved_at, "promised_date": date.fromisoformat(promised),
            "delivered_at": delivered_at, "label_available_at": label_available_at}


def test_late_uses_the_local_delivery_date():
    labels = add_labels(pd.DataFrame([
        # 02:00 UTC on the 26th = 23:00 on the 25th in Sao Paulo: delivered ON the promised date.
        row("on_time", "2017-04-10T12:00:00+00:00", "2017-04-26T02:00:00+00:00", "2017-05-03T02:00:00+00:00"),
        # 04:00 UTC on the 26th = 01:00 on the 26th local: one day late.
        row("late", "2017-04-10T12:00:00+00:00", "2017-04-26T04:00:00+00:00", "2017-05-03T04:00:00+00:00"),
        row("unknown", "2017-04-10T12:00:00+00:00"),  # outcome not known yet
    ])).set_index("order_id")
    on_time, late, unknown = labels["late"].tolist()
    assert (on_time, late) == (False, True)
    assert unknown is pd.NA


def test_cutoffs_must_be_ordered_and_aware():
    Cutoffs(train_end=TRAIN_END, validation_end=VALIDATION_END, as_of=VALIDATION_END)  # equal is allowed
    with pytest.raises(ValidationError, match="train_end < validation_end <= as_of"):
        Cutoffs(train_end=VALIDATION_END, validation_end=TRAIN_END, as_of=AS_OF)
    with pytest.raises(ValidationError, match="validation_end <= as_of"):
        Cutoffs(train_end=TRAIN_END, validation_end=AS_OF, as_of=VALIDATION_END)
    with pytest.raises(ValidationError, match="timezone"):
        Cutoffs(train_end="2017-10-31T23:59:59", validation_end=VALIDATION_END, as_of=AS_OF)


def test_split_boundaries_follow_the_contract():
    d = "2017-10-20T00:00:00+00:00"  # delivered (late: promised 2017-04-25)
    labels = add_labels(pd.DataFrame([
        row("t_edge", TRAIN_END, d, TRAIN_END),                                  # both exactly at train_end
        row("t_label_late", "2017-10-01T00:00:00+00:00", d, "2017-11-01T00:00:00+00:00"),  # label after train_end
        row("v_first", "2017-11-01T00:00:00+00:00", d, "2018-01-10T00:00:00+00:00"),
        row("v_edge", VALIDATION_END, d, AS_OF),                                 # label exactly at as_of
        row("v_label_late", "2017-12-01T00:00:00+00:00", d, "2018-03-01T00:00:01+00:00"),
        row("after", "2018-01-01T00:00:00+00:00", d, "2018-01-20T00:00:00+00:00"),  # after validation_end
        row("v_unknown", "2017-12-02T00:00:00+00:00"),
    ]))
    result = split(labels, Cutoffs(train_end=TRAIN_END, validation_end=VALIDATION_END, as_of=AS_OF))
    assert result.train == ("t_edge",)
    # t_label_late is not in train (label unknown at train_end) and not in validation (approved before).
    assert result.validation == ("v_edge", "v_first")


def test_select_window_supports_a_separate_test_period():
    labels = add_labels(pd.DataFrame([
        row("x", "2018-01-15T00:00:00+00:00", "2018-01-30T00:00:00+00:00", "2018-02-06T00:00:00+00:00"),
        row("y", "2018-03-15T00:00:00+00:00", "2018-03-30T00:00:00+00:00", "2018-04-06T00:00:00+00:00"),
    ]))
    assert select_window(labels, start="2017-12-31T23:59:59+00:00", end="2018-02-28T23:59:59+00:00",
                         label_cutoff="2018-06-30T00:00:00+00:00") == ("x",)


def test_cohort_hash_depends_only_on_the_set_of_ids():
    assert cohort_sha256(["b", "a"]) == cohort_sha256(("a", "b", "a"))
    assert cohort_sha256(["a", "b"]) != cohort_sha256(["a", "b", "c"])
    assert len(cohort_sha256([])) == 64


def _labels(late_flags):
    rows = [row(f"o{i:03d}", "2017-05-01T00:00:00+00:00",
                "2017-04-26T12:00:00+00:00" if flag else "2017-04-20T12:00:00+00:00",
                "2017-05-03T12:00:00+00:00") for i, flag in enumerate(late_flags)]
    return add_labels(pd.DataFrame(rows))


def test_insufficient_cohorts_are_reported_not_scored():
    small = _labels([True] + [False] * 49)
    with pytest.raises(InsufficientCohort, match="N=50"):
        require_sufficient("validation", small, small["order_id"])
    one_class = _labels([False] * 150)
    with pytest.raises(InsufficientCohort, match="late=0"):
        require_sufficient("validation", one_class, one_class["order_id"])
    ok = _labels([True] * 10 + [False] * 90)
    require_sufficient("validation", ok, ok["order_id"])


def test_describe_reports_size_prevalence_and_hash():
    labels = _labels([True] * 10 + [False] * 90)
    summary = describe(labels, labels["order_id"])
    assert (summary["n"], summary["late"], summary["prevalence"]) == (100, 10, 0.1)
    assert summary["cohort_sha256"] == cohort_sha256(labels["order_id"])


def test_describe_counts_and_hashes_the_actual_selected_rows():
    labels = _labels([True, False])
    oid = labels["order_id"].iloc[0]
    summary = describe(labels, iter([oid, oid, "missing-order"]))
    assert (summary["n"], summary["late"], summary["prevalence"]) == (1, 1, 1.0)
    assert summary["cohort_sha256"] == cohort_sha256([oid])
    empty = describe(labels, ["missing-order"])
    assert empty == {"n": 0, "late": 0, "prevalence": None, "cohort_sha256": cohort_sha256([]),
                     "approved_from": None, "approved_to": None}
