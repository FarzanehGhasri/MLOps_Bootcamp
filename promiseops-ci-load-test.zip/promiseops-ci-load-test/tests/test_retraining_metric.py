"""promiseops_retraining_required on /metrics: the latest monitoring decision about the served model.

The staff Prometheus alert RetrainingRecommended fires when it is 1 for a minute. The database is
faked here (CI has none); the SQL itself is tested in tests/test_monitoring_decisions_db.py.
"""

import logging
from pathlib import Path

import psycopg
import pytest
from fastapi.testclient import TestClient
from prometheus_client.parser import text_string_to_metric_families

from promiseops import api
from promiseops.model import ConstantProbabilityEstimator

API_KEY = "retraining-test-key"
SECRET_URL = "postgresql://user:db-password@db.internal:5432/promiseops"


class _Clock:
    def __init__(self):
        self.now = 1000.0

    def __call__(self):
        return self.now


class _FakeDatabase:
    """db.connect + decisions.latest_retrain_recommended, answering from ``self.answer``."""

    def __init__(self):
        self.answer: bool | None | Exception = None
        self.queries: list[str] = []
        self.connect_options: list[dict] = []

    def connect(self, url=None, **options):
        self.connect_options.append(options)
        if isinstance(self.answer, Exception):
            raise self.answer
        return self

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False

    def latest(self, connection, model_version):
        self.queries.append(model_version)
        return self.answer


@pytest.fixture
def clock(monkeypatch):
    fake = _Clock()
    monkeypatch.setattr(api, "_clock", fake)
    return fake


@pytest.fixture
def database(monkeypatch):
    fake = _FakeDatabase()
    monkeypatch.setattr(api.db, "connect", fake.connect)
    monkeypatch.setattr(api.decisions, "latest_retrain_recommended", fake.latest)
    return fake


def _client(monkeypatch, tmp_path: Path, *, database_url: str | None = SECRET_URL) -> TestClient:
    bundle_dir = tmp_path / "release"
    ConstantProbabilityEstimator(probability=0.2).build_mock_bundle(
        bundle_dir, model_version="retrain-test-v1", features_path="contracts/features.json")
    monkeypatch.setenv("PROMISEOPS_RELEASE", str(bundle_dir / "release.json"))
    monkeypatch.setenv("PROMISEOPS_API_KEY", API_KEY)
    if database_url is None:
        monkeypatch.delenv("PROMISEOPS_DATABASE_URL", raising=False)
    else:
        monkeypatch.setenv("PROMISEOPS_DATABASE_URL", database_url)
    return TestClient(api.create_app())


def _scrape(client: TestClient) -> tuple[float | None, str]:
    res = client.get("/metrics", headers={"X-API-Key": API_KEY})
    assert res.status_code == 200
    for family in text_string_to_metric_families(res.text):
        for sample in family.samples:
            if sample.name == "promiseops_retraining_required":
                return sample.value, res.text
    return None, res.text


def test_zero_without_database(monkeypatch, tmp_path, clock, database):
    client = _client(monkeypatch, tmp_path, database_url=None)

    assert _scrape(client)[0] == 0.0
    assert database.queries == []


@pytest.mark.parametrize(("attribute", "value"), [("database_url", ""), ("manifest", None)])
def test_missing_database_or_model_keeps_the_last_value(monkeypatch, tmp_path, clock, database, attribute, value):
    database.answer = True
    client = _client(monkeypatch, tmp_path)
    assert _scrape(client)[0] == 1.0

    setattr(client.app.state, attribute, value)
    clock.now += api.RETRAINING_CHECK_SECONDS + 1

    assert _scrape(client)[0] == 1.0          # unknown is not "no retraining needed"
    assert len(database.queries) == 1


def test_one_when_the_served_model_should_be_retrained(monkeypatch, tmp_path, clock, database):
    database.answer = True
    client = _client(monkeypatch, tmp_path)

    assert _scrape(client)[0] == 1.0
    assert database.queries == ["retrain-test-v1"]   # only decisions about the served model count
    # Bounded connect AND query: a locked table or slow DB must not hang the scrape.
    assert database.connect_options == [{"connect_timeout": api.RETRAINING_DB_TIMEOUT_SECONDS,
                                         "statement_timeout_ms": api.RETRAINING_DB_TIMEOUT_SECONDS * 1000}]


def test_zero_when_the_served_model_was_never_assessed(monkeypatch, tmp_path, clock, database):
    database.answer = None
    client = _client(monkeypatch, tmp_path)

    assert _scrape(client)[0] == 0.0


def test_decision_is_cached_between_scrapes(monkeypatch, tmp_path, clock, database):
    database.answer = True
    client = _client(monkeypatch, tmp_path)
    assert _scrape(client)[0] == 1.0

    database.answer = False
    clock.now += api.RETRAINING_CHECK_SECONDS - 1
    assert _scrape(client)[0] == 1.0          # within the cache window: no new query
    assert len(database.queries) == 1

    clock.now += 2
    assert _scrape(client)[0] == 0.0          # window over: the new decision is read
    assert len(database.queries) == 2


def test_database_error_keeps_last_value_and_metrics_still_work(monkeypatch, tmp_path, clock, database, caplog):
    database.answer = True
    client = _client(monkeypatch, tmp_path)
    assert _scrape(client)[0] == 1.0

    database.answer = psycopg.OperationalError(f"connection to {SECRET_URL} failed")
    clock.now += api.RETRAINING_CHECK_SECONDS + 1
    caplog.set_level(logging.WARNING, logger="promiseops.api")
    value, text = _scrape(client)

    assert value == 1.0                       # a DB blip neither fires nor clears the alert
    assert "db-password" not in text
    warnings = [r.getMessage() for r in caplog.records if r.name == "promiseops.api" and r.levelno == logging.WARNING]
    assert any('"event": "retraining_check_failed"' in m and "OperationalError" in m for m in warnings)
    assert not any("db-password" in m for m in warnings)
