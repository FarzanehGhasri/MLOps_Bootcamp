"""Worker preflight is read-only and cannot confuse missing schema with missing labels."""

from unittest.mock import Mock

import pytest
from test_ingestion_db import URL, conn  # noqa: F401

from promiseops import db, worker

pytestmark = pytest.mark.skipif(not URL, reason="PROMISEOPS_TEST_DATABASE_URL is not set")


def test_current_schema_passes_without_writes(conn):  # noqa: F811
    with conn.transaction():
        conn.execute("SET TRANSACTION READ ONLY")
        db.require_schema(conn)


def test_missing_snapshot_table_reports_migration_instead_of_empty_history(conn):  # noqa: F811
    conn.execute("DROP TABLE promiseops.prediction_snapshots")
    with pytest.raises(db.SchemaNotReady, match="prediction_snapshots"):
        db.require_schema(conn)
    assert conn.execute("SELECT to_regclass('promiseops.prediction_snapshots')").fetchone()[0] is None


def test_newer_schema_is_not_silently_accepted(conn):  # noqa: F811
    conn.execute("INSERT INTO promiseops.schema_version(version) VALUES (999)")
    with pytest.raises(db.SchemaNotReady, match="999"):
        db.require_schema(conn)


def test_worker_does_not_fit_when_migration_is_missing(conn, monkeypatch, tmp_path, capsys):  # noqa: F811
    conn.execute("DROP TABLE promiseops.prediction_snapshots")
    fit = Mock(side_effect=AssertionError("preflight failure must not train"))
    monkeypatch.setattr(worker.training, "run_train", fit)
    monkeypatch.setattr(worker.tracking, "create_client", lambda *args: object())
    code = worker.main(["--train-end", "2017-12-31T00:00:00Z", "--validation-end", "2018-02-28T00:00:00Z",
                        "--as-of", "2018-04-30T00:00:00Z"], environ={"CI_COMMIT_SHA": "a" * 40,
        "MLFLOW_TRACKING_URI": "http://mlflow.example", "PROMISEOPS_DATABASE_URL": URL})
    assert code == 1
    assert "SchemaNotReady" in capsys.readouterr().err
    fit.assert_not_called()
