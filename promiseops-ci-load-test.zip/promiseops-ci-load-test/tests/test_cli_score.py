import json
from dataclasses import replace
from datetime import UTC, datetime
from pathlib import Path
from unittest.mock import MagicMock

import numpy as np
import pandas as pd
import pytest

from promiseops import cli, db
from promiseops.bundle import read_bundle
from promiseops.model import ConstantProbabilityEstimator


class _FakeConn:
    def __init__(self, order_ids: list[str]):
        self._order_ids = order_ids
        self.executed_queries: list[tuple[str, tuple]] = []

    def execute(self, query: str, params: tuple = ()):
        self.executed_queries.append((query, params))
        cursor = MagicMock()
        cursor.fetchall.return_value = [(oid,) for oid in self._order_ids]
        return cursor

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False


class _RankByDictModel:
    def __init__(self, scores: dict[str, float]):
        self._scores = scores

    def predict_proba(self, X):
        probs = np.array([self._scores[oid] for oid in X.index], dtype=float)
        return np.column_stack([1.0 - probs, probs])


@pytest.fixture
def sample_bundle(tmp_path: Path):
    bundle_dir = tmp_path / "bundle"
    ConstantProbabilityEstimator(probability=0.12).build_mock_bundle(
        bundle_dir,
        model_version="test-score-v1",
        features_path="contracts/features.json",
    )
    return read_bundle(bundle_dir)


@pytest.mark.parametrize(
    ("n_orders", "expected_k"),
    [
        (1, 1),
        (10, 1),
        (11, 2),
        (30, 3),
    ],
)
def test_score_cohort_top_k_formula_and_tie_breaking(sample_bundle, n_orders: int, expected_k: int, monkeypatch):
    order_ids = [f"ord-{i:03d}" for i in range(n_orders)]
    scores = {oid: 0.5 for oid in order_ids}
    if expected_k >= 3:
        scores["ord-002"] = 0.95
        scores["ord-000"] = 0.80
        scores["ord-001"] = 0.80

    monkeypatch.setattr(
        cli.inference,
        "release_features",
        lambda conn, ids, **kwargs: pd.DataFrame(
            0.0, index=ids, columns=sample_bundle.manifest.feature_names
        ),
    )
    sample_bundle = replace(sample_bundle, model=_RankByDictModel(scores))
    conn = _FakeConn(order_ids)
    as_of = datetime(2026, 11, 13, 3, 0, tzinfo=UTC)

    report = cli.score_cohort(conn, sample_bundle, as_of=as_of)

    assert report["schema_version"] == "1.0"
    assert report["as_of"] == as_of.isoformat()
    assert report["model_version"] == "test-score-v1"
    assert report["scored_count"] == n_orders
    assert report["priority_count"] == expected_k
    assert len(report["priority_orders"]) == expected_k
    assert report["cohort_identity"].startswith("cohort-sha256:")

    if expected_k >= 3:
        assert report["priority_orders"][0]["order_id"] == "ord-002"
        assert report["priority_orders"][0]["rank"] == 1
        assert report["priority_orders"][1]["order_id"] == "ord-000"
        assert report["priority_orders"][2]["order_id"] == "ord-001"


def test_cli_score_command_with_since_and_output_file(monkeypatch, tmp_path: Path, capsys):
    bundle_dir = tmp_path / "release"
    ConstantProbabilityEstimator(probability=0.25).build_mock_bundle(
        bundle_dir,
        model_version="cli-score-v1",
        features_path="contracts/features.json",
    )
    output_file = tmp_path / "out" / "priority.json"
    fake_conn = _FakeConn(["ord-b", "ord-a", "ord-c"])

    manifest_features = json.loads((bundle_dir / "release.json").read_text())["feature_names"]
    monkeypatch.setattr(
        cli.inference,
        "release_features",
        lambda conn, ids, **kwargs: pd.DataFrame(
            0.0, index=ids, columns=manifest_features
        ),
    )

    monkeypatch.setenv("PROMISEOPS_RELEASE", str(bundle_dir / "release.json"))
    monkeypatch.setattr(db, "connect", lambda url=None: fake_conn)

    exit_code = cli.main(
        [
            "score",
            "--since",
            "2026-11-12T03:00:00Z",
            "--as-of",
            "2026-11-13T03:00:00Z",
            "--output",
            str(output_file),
        ]
    )

    assert exit_code == cli.EXIT_OK
    assert output_file.is_file()

    stdout_data = json.loads(capsys.readouterr().out.strip())
    file_data = json.loads(output_file.read_text(encoding="utf-8"))
    assert stdout_data == file_data
    assert stdout_data["scored_count"] == 3
    assert stdout_data["priority_count"] == 1
    assert stdout_data["priority_orders"] == [
        {"rank": 1, "order_id": "ord-a", "risk_probability": 0.25}
    ]
    assert "released_at >" in stdout_data["cohort_selection_rule"]


def test_cli_score_fails_on_empty_cohort(monkeypatch, tmp_path: Path):
    bundle_dir = tmp_path / "release"
    ConstantProbabilityEstimator(probability=0.25).build_mock_bundle(
        bundle_dir,
        model_version="cli-score-v1",
        features_path="contracts/features.json",
    )
    fake_conn = _FakeConn([])

    monkeypatch.setenv("PROMISEOPS_RELEASE", str(bundle_dir))
    monkeypatch.setattr(db, "connect", lambda url=None: fake_conn)

    exit_code = cli.main(["score", "--as-of", "2026-11-13T03:00:00Z"])
    assert exit_code == cli.EXIT_ERROR
