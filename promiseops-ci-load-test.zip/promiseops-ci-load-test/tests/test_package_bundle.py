"""Distribution must preserve exact model bytes, provenance and file allowlist."""

import json
import os
import tarfile

import pytest
from test_bundle import lineage, reference, write

from promiseops import bundle
from promiseops.contracts import digest
from promiseops.package_bundle import FILES, package_candidate


@pytest.fixture
def candidate(tmp_path):
    dataset = {"dataset_kind": "synthetic_software_test"}
    write(tmp_path, lineage=lineage(dataset_manifest_sha256=digest(dataset)), dataset_manifest=dataset)
    return tmp_path / "bundle"


def test_round_trip_preserves_bytes_and_excludes_unrelated_files(candidate, tmp_path):
    (candidate / ".env").write_text("must not be distributed")
    output = tmp_path / "candidate.tar.gz"
    manifest = package_candidate(candidate, output)
    with tarfile.open(output) as archive:
        assert archive.getnames() == list(FILES)
        for member in archive:
            assert member.isfile() and member.mode == 0o644
            assert archive.extractfile(member).read() == (candidate / member.name).read_bytes()
        extracted = tmp_path / "downloaded"
        archive.extractall(extracted, filter="data")
    loaded = bundle.read_bundle(extracted)
    assert loaded.manifest.artifact_sha256 == manifest["artifact_sha256"]
    assert bundle.sha256_file(output) == manifest["archive_sha256"]
    assert manifest["status"] == "candidate_pending_independent_review"
    for name in FILES:
        assert manifest["files"][name]["sha256"] == bundle.sha256_file(extracted / name)


def test_packaging_is_independent_of_filename_and_source_mtime(candidate, tmp_path):
    first, second = tmp_path / "first.tar.gz", tmp_path / "second.tar.gz"
    before = package_candidate(candidate, first)
    for name in FILES:
        os.utime(candidate / name, (12345, 12345))
    after = package_candidate(candidate, second)
    assert before == after and first.read_bytes() == second.read_bytes()


@pytest.mark.parametrize("name", FILES)
def test_incomplete_candidate_is_not_published(candidate, tmp_path, name):
    (candidate / name).unlink()
    output = tmp_path / "candidate.tar.gz"
    with pytest.raises(ValueError, match="regular file"):
        package_candidate(candidate, output)
    assert not output.exists()


def test_corrupt_model_is_rejected_before_archive_creation(candidate, tmp_path):
    (candidate / "model.joblib").write_bytes(b"corrupt")
    output = tmp_path / "candidate.tar.gz"
    with pytest.raises(bundle.BundleError, match="SHA256"):
        package_candidate(candidate, output)
    assert not output.exists()


def test_existing_archive_cannot_be_overwritten(candidate, tmp_path):
    output = tmp_path / "candidate.tar.gz"
    output.write_bytes(b"preserve existing artifact")
    with pytest.raises(FileExistsError):
        package_candidate(candidate, output)
    assert output.read_bytes() == b"preserve existing artifact"


def test_mixed_validation_reference_is_rejected(candidate, tmp_path):
    wrong = reference(cohort="e" * 64)
    (candidate / "reference.json").write_text(wrong.model_dump_json())
    with pytest.raises(ValueError, match="different validation"):
        package_candidate(candidate, tmp_path / "candidate.tar.gz")


def test_mixed_code_lineage_is_rejected(candidate, tmp_path):
    path = candidate / "lineage.json"
    document = json.loads(path.read_text())
    document["source_commit"] = "b" * 40
    path.write_text(json.dumps(document))
    with pytest.raises(ValueError, match="different source commits"):
        package_candidate(candidate, tmp_path / "candidate.tar.gz")
