"""monitor-train (#21) without a database or MLflow: runs in CI.

Database + MLflow end to end: tests/test_monitor_train_db.py
Run: $env:PYTHONPATH = "src"; python -m pytest tests/test_monitor_train.py -v
"""

import json
from datetime import UTC, datetime

import pytest
from test_bundle import ROOT, lineage, write

from promiseops import bundle as b
from promiseops import monitor_train, training
from promiseops.features import FEATURE_NAMES

AS_OF = datetime(2018, 4, 30, tzinfo=UTC)


def test_incumbent_without_reference_is_recorded_and_never_retrained():
    # release/ of the repository is the constant mock from MR !3: no reference.json, no lineage.
    mock = b.read_bundle(ROOT / "release")
    record = monitor_train.assess(None, mock, as_of=AS_OF)   # returns before touching the database
    assert (record.status, record.retrain_recommended, record.report) == ("no_reference", False, None)
    assert record.incumbent_model_version == "baseline-constant-v1"
    assert "--mode train" in record.reasons[0]
    assert monitor_train.report_metrics(record) == {"retrain_recommended": 0.0}


def test_record_survives_the_json_round_trip_used_to_verify_mlflow():
    record = monitor_train.MonitoringRecord(as_of=AS_OF, incumbent_model_version="x-1", status="no_reference",
                                            retrain_recommended=False, reasons=["why"])
    assert monitor_train.MonitoringRecord.model_validate_json(record.model_dump_json(indent=2)) == record


def test_assessed_record_needs_no_unknown_fields():
    with pytest.raises(ValueError):
        monitor_train.MonitoringRecord(as_of=AS_OF, incumbent_model_version="x-1", status="assessed",
                                       retrain_recommended=True, surprise=1)


def test_incumbent_with_other_features_cannot_be_rescored(tmp_path):
    write(tmp_path, feature_names=["only_one"], lineage=lineage(feature_schema_sha256=b.feature_schema_sha256(["only_one"])))
    other = b.read_bundle(tmp_path / "bundle")
    with pytest.raises(training.TrainingError, match="other features"):
        monitor_train.load_prediction_history(tmp_path / "unused.jsonl", other)


def test_missing_prediction_history_is_reported_without_querying_or_training(tmp_path):
    write(tmp_path)
    incumbent = b.read_bundle(tmp_path / "bundle")
    result = monitor_train.assess(None, incumbent, as_of=AS_OF)
    assert result.status == "no_prediction_history"
    assert not result.retrain_recommended and result.report is None


def snapshot(version, **changes):
    return {**dict.fromkeys(FEATURE_NAMES, 1), "order_id": "o1", "predicted_at": "2018-04-29T12:00:00Z",
            "risk_probability": 0.17, "model_version": version, **changes}


def test_history_preserves_recorded_scores_times_and_ignores_other_models(tmp_path):
    write(tmp_path)
    incumbent = b.read_bundle(tmp_path / "bundle")
    path = tmp_path / "predictions.jsonl"
    rows = [snapshot(incumbent.manifest.model_version), snapshot("another-model")]
    path.write_text("\n".join(json.dumps(row) for row in rows), encoding="utf-8")
    result = monitor_train.load_prediction_history(path, incumbent)
    assert len(result) == 1
    assert result.iloc[0]["risk_probability"] == 0.17
    assert result.iloc[0]["predicted_at"].isoformat() == "2018-04-29T12:00:00+00:00"


@pytest.mark.parametrize("changes", [{"risk_probability": 2}, {"risk_probability": float("nan")},
                                    {"risk_probability": True}, {"risk_probability": "0.5"},
                                    {"predicted_at": "2018-04-29"}, {"unexpected": 1}])
def test_malformed_prediction_history_is_refused(tmp_path, changes):
    write(tmp_path)
    incumbent = b.read_bundle(tmp_path / "bundle")
    path = tmp_path / "predictions.jsonl"
    path.write_text(json.dumps(snapshot(incumbent.manifest.model_version, **changes)), encoding="utf-8")
    with pytest.raises(training.TrainingError, match="invalid snapshot"):
        monitor_train.load_prediction_history(path, incumbent)


def test_summary_says_whether_training_ran():
    record = monitor_train.MonitoringRecord(as_of=AS_OF, incumbent_model_version="x-1", status="no_reference",
                                            retrain_recommended=False)
    summary = monitor_train.MonitorTrainResult("run1", record, None).summary()
    assert summary == {"mode": "monitor-train", "monitoring_run_id": "run1", "monitoring_status": "no_reference",
                       "retrain_recommended": False, "incumbent_model_version": "x-1", "trained": False}
