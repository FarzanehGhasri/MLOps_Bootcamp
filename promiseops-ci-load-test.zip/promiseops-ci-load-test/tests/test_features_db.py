"""build_features / load_labels against PostgreSQL: released-by-as_of, labels known-by-as_of, parity.

Skipped when PROMISEOPS_TEST_DATABASE_URL is not set (CI has no database). Every test DROPS the
schema ``promiseops`` (fixture from test_ingestion_db) — use an EMPTY throw-away database whose name
ends in "_test", never the one holding the real feed:

    $env:PROMISEOPS_TEST_DATABASE_URL = "postgresql://promiseops:promiseops-test@127.0.0.1:55432/promiseops_unit_test"
"""

import pandas as pd
import pytest
from factories import APPROVED_AT, ORDERS_AT, OUTCOMES_AT, orders_doc, outcomes_doc
from test_ingestion_db import URL, conn, ingest  # noqa: F401  (conn is a pytest fixture)

from promiseops import cohorts, data
from promiseops.features import FEATURE_NAMES

pytestmark = pytest.mark.skipif(not URL, reason="PROMISEOPS_TEST_DATABASE_URL is not set")

BEFORE_ORDERS = "2017-04-14T23:59:59Z"   # orders batch not yet published
BEFORE_LABELS = "2017-04-30T00:00:00Z"   # orders published, outcomes batch not yet
AFTER_ALL = "2017-06-01T00:00:00Z"


@pytest.fixture
def loaded(conn):  # noqa: F811
    ingest(conn, orders_doc(order_ids=("o1", "o2")))
    ingest(conn, outcomes_doc(order_ids=("o1",)))  # o2 never gets an outcome
    return conn


def test_features_of_released_orders(loaded):
    table = data.build_features(loaded, ["o2", "o1", "missing"], as_of=AFTER_ALL)
    assert list(table.index) == ["o1", "o2"] and list(table.columns) == list(FEATURE_NAMES)
    row = table.loc["o1"]
    # factories: one item 19.9 + 5.1 freight, 500 g, toys, seller SP, customer SP, one 25.0 card payment,
    # approved 2017-04-10 12:00 UTC = 09:00 Monday in Sao Paulo, promised 2017-04-25.
    assert (row.item_count, row.seller_count, row.total_price, row.total_freight) == (1, 1, 19.9, 5.1)
    assert (row.total_weight_g, row.payment_total, row.max_installments) == (500, 25, 1)
    assert (row.approval_hour, row.approval_weekday, row.promise_days, row.interstate_fraction) == (9, 0, 15, 0)
    assert (row.customer_state, row.primary_category, row.primary_payment_type) == ("SP", "toys", "credit_card")


def test_order_not_yet_released_at_as_of_is_absent(loaded):
    assert APPROVED_AT < BEFORE_ORDERS < ORDERS_AT  # approved, but the company has not published it yet
    assert data.build_features(loaded, ["o1"], as_of=BEFORE_ORDERS).empty


def test_one_order_equals_the_same_order_in_a_batch(loaded):
    batch = data.build_features(loaded, ["o1", "o2"], as_of=AFTER_ALL)
    pd.testing.assert_frame_equal(data.build_features(loaded, ["o1"], as_of=AFTER_ALL), batch.loc[["o1"]])


def test_database_session_time_zone_does_not_change_features(loaded):
    utc = data.build_features(loaded, ["o1"], as_of=AFTER_ALL)
    loaded.execute("SET TIME ZONE 'Asia/Tokyo'")  # timestamptz now comes back as +09:00
    pd.testing.assert_frame_equal(data.build_features(loaded, ["o1"], as_of=AFTER_ALL), utc)


def test_labels_appear_only_once_known(loaded):
    assert BEFORE_LABELS < OUTCOMES_AT
    early = data.build_features(loaded, ["o1", "o2"], as_of=BEFORE_LABELS, labeled=True)
    assert early["late"].isna().all()
    late = data.build_features(loaded, ["o1", "o2"], as_of=AFTER_ALL, labeled=True)
    o1 = late.loc["o1", "late"]
    assert o1 is not pd.NA and not o1  # known and on time: delivered 04-20, promised 04-25
    assert pd.isna(late.loc["o2", "late"])  # no outcome at all
    assert "late" not in data.build_features(loaded, ["o1"], as_of=AFTER_ALL).columns


def test_load_labels_and_split_on_the_database(loaded):
    labels = cohorts.load_labels(loaded, as_of=AFTER_ALL)
    assert list(labels["order_id"]) == ["o1", "o2"]
    assert list(cohorts.load_labels(loaded, as_of=AFTER_ALL, order_ids=["o2"])["order_id"]) == ["o2"]
    # Label of o1 known 2017-04-27 12:00 (outcome row) and published 2017-05-01 (batch):
    cut = cohorts.Cutoffs(train_end="2017-04-30T00:00:00Z", validation_end="2017-05-15T00:00:00Z", as_of=AFTER_ALL)
    assert cohorts.split(labels, cut).train == ("o1",)
    assert cohorts.load_labels(loaded, as_of=BEFORE_ORDERS).empty


def test_publishing_outcomes_does_not_change_features(conn):  # noqa: F811
    ingest(conn, orders_doc(order_ids=("o1", "o2")))
    before = data.build_features(conn, ["o1", "o2"], as_of=AFTER_ALL)
    ingest(conn, outcomes_doc(order_ids=("o1",)))
    after = data.build_features(conn, ["o1", "o2"], as_of=AFTER_ALL)
    pd.testing.assert_frame_equal(before, after)


def test_history_uses_past_orders_outside_request(conn):  # noqa: F811
    from promiseops.features import load_features_with_history

    ingest(conn, orders_doc(order_ids=("past",)))
    ingest(conn, outcomes_doc(order_ids=("past",)))
    later = orders_doc(batch_id="later", order_ids=("current",), available_at="2017-05-15T00:00:00Z")
    later["orders"][0]["approved_at"] = "2017-05-10T12:00:00Z"
    later["orders"][0]["promised_date"] = "2017-05-25"
    ingest(conn, later)
    batch = load_features_with_history(conn, ["past", "current"], as_of=AFTER_ALL)
    alone = load_features_with_history(conn, ["current"], as_of=AFTER_ALL)
    pd.testing.assert_frame_equal(alone, batch.loc[["current"]])
    assert alone.loc["current", "history_seller_count"] > 0
