"""Tests for dags/gateway.py: the pure gateway logic (no Airflow needed)."""

import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "dags"))
import promiseops_gateway as gateway


def _fake_request(monkeypatch, responses):
    calls = []

    def fake(url, key, *, method="GET", data=None):
        calls.append((method, url, data))
        return responses.pop(0)

    monkeypatch.setattr(gateway, "_request", fake)
    return calls


def test_request_id_is_stable_per_run_and_differs_between_runs():
    first = gateway.request_id_for("promiseops_training", "scheduled__2026-11-18T00:00:00")
    assert first == gateway.request_id_for("promiseops_training", "scheduled__2026-11-18T00:00:00")
    assert len(first) == 32 and all(c in "0123456789abcdef" for c in first)
    assert first != gateway.request_id_for("promiseops_training", "manual__2026-11-18T00:00:00")


def test_validate_cutoffs_accepts_the_reference_split():
    gateway.validate_cutoffs(
        train_end="2017-10-31T23:59:59Z",
        validation_end="2017-12-31T23:59:59Z",
        as_of="2018-01-01T00:00:00Z",
    )


@pytest.mark.parametrize("train_end,validation_end,as_of", [
    ("2017-12-31T23:59:59Z", "2017-12-31T23:59:59Z", "2018-01-01T00:00:00Z"),  # equal is not <
    ("2017-12-31T23:59:59Z", "2017-10-31T23:59:59Z", "2018-01-01T00:00:00Z"),  # reversed
    ("2017-10-31T23:59:59Z", "2017-12-31T23:59:59Z", "2017-11-30T23:59:59Z"),  # as_of < validation
    ("2017-10-31T23:59:59Z", "2017-12-31T23:59:59Z", "2018-01-01T00:00:00"),   # naive timestamp
])
def test_validate_cutoffs_rejects_bad_ordering(train_end, validation_end, as_of):
    with pytest.raises(ValueError):
        gateway.validate_cutoffs(train_end=train_end, validation_end=validation_end, as_of=as_of)


def test_fetch_feed_writes_manifest_and_files(tmp_path, monkeypatch):
    feed = {"as_of": "2018-01-01T00:00:00Z", "entries": [
        {"file": "b1.json", "payload_sha256": "a" * 64, "file_sha256": "b" * 64},
        {"file": "sub/b2.json", "payload_sha256": "c" * 64, "file_sha256": "d" * 64},
    ]}
    calls = _fake_request(monkeypatch, [
        (200, json.dumps(feed).encode()),
        (200, b"{}"),
        (200, b"[]"),
    ])
    dest = gateway.fetch_feed("2018-01-01T00:00:00Z", tmp_path, url="https://gw.example", key="secret")
    assert dest == tmp_path
    assert (dest / "manifest.json").read_bytes() == json.dumps(feed).encode()
    assert (dest / "b1.json").read_bytes() == b"{}"
    assert (dest / "sub/b2.json").read_bytes() == b"[]"
    assert calls[0][1] == "https://gw.example/feed?as_of=2018-01-01T00%3A00%3A00Z"
    assert calls[1][1] == "https://gw.example/feed/b1.json"
    assert calls[2][1] == "https://gw.example/feed/sub/b2.json"


@pytest.mark.parametrize("shape", [
    [{"file": "b1.json", "payload_sha256": "a" * 64, "file_sha256": "b" * 64}],
    {"releases": [{"file": "b1.json", "payload_sha256": "a" * 64, "file_sha256": "b" * 64}]},
])
def test_fetch_feed_downloads_the_other_documented_index_shapes(tmp_path, monkeypatch, shape):
    body = json.dumps(shape).encode()
    calls = _fake_request(monkeypatch, [(200, body), (200, b"{}")])
    gateway.fetch_feed("2018-01-01T00:00:00Z", tmp_path, url="https://gw.example", key="secret")
    assert (tmp_path / "manifest.json").read_bytes() == body
    assert (tmp_path / "b1.json").read_bytes() == b"{}"
    assert calls[1][1] == "https://gw.example/feed/b1.json"


def test_fetch_feed_fails_loudly_on_an_unknown_manifest_shape(tmp_path, monkeypatch):
    _fake_request(monkeypatch, [(200, json.dumps({"batches": []}).encode())])
    with pytest.raises(gateway.GatewayError) as raised:
        gateway.fetch_feed("2018-01-01T00:00:00Z", tmp_path, url="https://gw.example", key="secret")
    assert "'batches'" in str(raised.value)
    assert not (tmp_path / "b1.json").exists()


def test_fetch_feed_fails_on_gateway_error(tmp_path, monkeypatch):
    def broken(url, key, *, method="GET", data=None):
        raise gateway.GatewayError("gateway GET ... -> HTTP 503")

    monkeypatch.setattr(gateway, "_request", broken)
    with pytest.raises(gateway.GatewayError):
        gateway.fetch_feed("2018-01-01T00:00:00Z", tmp_path, url="https://gw.example", key="secret")


def test_submit_training_returns_the_202_body(tmp_path, monkeypatch):
    calls = _fake_request(monkeypatch, [(202, json.dumps({"job_name": "job-1", "namespace": "g03-jobs"}).encode())])
    payload = {"image": "registry/app@sha256:" + "0" * 64, "source_commit": "1" * 40,
               "train_end": "2017-10-31T23:59:59Z", "validation_end": "2017-12-31T23:59:59Z",
               "as_of": "2018-01-01T00:00:00Z", "mode": "train", "request_id": "r" * 32}
    assert gateway.submit_training(payload, url="https://gw.example", key="secret") == {
        "job_name": "job-1", "namespace": "g03-jobs"}
    method, url, data = calls[0]
    assert (method, url) == ("POST", "https://gw.example/training")
    assert json.loads(data) == payload


def test_submit_training_rejects_non_202(monkeypatch):
    _fake_request(monkeypatch, [(422, b'{"detail":"bad cutoffs"}')])
    with pytest.raises(gateway.GatewayError, match="HTTP 422"):
        gateway.submit_training({"image": "x"}, url="https://gw.example", key="secret")


@pytest.mark.parametrize("image,commit", [("registry/worker:latest", "a" * 40),
    ("registry/worker@sha256:123", "a" * 40), ("registry/worker@sha256:" + "1" * 64, "main"),
    ("registry/worker@sha256:" + "1" * 64, "A" * 40)])
def test_worker_reference_rejects_unpinned_or_untraceable_configuration(image, commit):
    with pytest.raises(ValueError):
        gateway.worker_reference({"image": image, "source_commit": commit})


@pytest.mark.parametrize("plan", ["not json", "[]", '{"train_end":"2017-12-31T00:00:00Z"}',
    '{"train_end":"2017-12-31T00:00:00Z","validation_end":"2018-02-28T00:00:00Z","as_of":"old"}'])
def test_training_requires_an_explicit_valid_split_variable(monkeypatch, plan):
    monkeypatch.setattr(gateway, "variable", lambda name: plan)
    with pytest.raises(ValueError):
        gateway.training_cutoffs({}, "2018-04-30T00:00:00Z")


def test_explicit_split_needs_no_variable(monkeypatch):
    monkeypatch.setattr(gateway, "variable", lambda name: pytest.fail("explicit split must take precedence"))
    result = gateway.training_cutoffs({"train_end": "2017-12-31T00:00:00Z",
                                       "validation_end": "2018-02-28T00:00:00Z"}, "2018-04-30T00:00:00Z")
    assert result["as_of"] == "2018-04-30T00:00:00Z"


def test_request_sends_json_content_type_with_body(monkeypatch):
    """POST bodies must carry Content-Type: application/json, or FastAPI sees a bare string (422)."""
    captured = {}

    class _Response:
        def __enter__(self):
            return self

        def __exit__(self, *exc):
            return False

        status = 200

        def read(self):
            return b"{}"

    def fake_urlopen(request, timeout):
        captured["headers"] = dict(request.header_items())
        return _Response()

    monkeypatch.setattr(gateway.urllib.request, "urlopen", fake_urlopen)
    gateway._request("https://gw.example/training", "secret", method="POST", data=b"{}")
    assert captured["headers"]["Content-type"] == "application/json"

    gateway._request("https://gw.example/feed", "secret")
    assert "Content-type" not in captured["headers"]
