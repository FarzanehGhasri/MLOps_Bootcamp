"""Registry and aliases (#20) without MLflow: these run in CI.

The rule tested here is structural: the serving API has NO path to MLflow, so no alias can ever be
resolved at service startup ("Production startup never resolves a mutable alias", docs/CONTRACTS.md).
Behaviour against a real MLflow: tests/test_registry_mlflow.py.
"""

import ast
import os
import subprocess
import sys

import pytest
from test_bundle import ROOT, lineage, write

from promiseops import record, registry

API_SOURCE = ROOT / "src" / "promiseops" / "api.py"


def _imported_modules(path) -> set[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    names = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            names.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            names.add(node.module)
            names.update(f"{node.module}.{alias.name}" for alias in node.names)
    return names


def test_serving_api_never_reaches_mlflow_or_the_registry():
    imported = _imported_modules(API_SOURCE)
    forbidden = {name for name in imported
                 if name.split(".")[0] == "mlflow" or name in {"promiseops.registry", "promiseops.tracking"}}
    assert not forbidden, f"api.py must load its bundle from disk only, but imports {forbidden}"
    assert "models:/" not in API_SOURCE.read_text(encoding="utf-8"), "api.py must not name a registry URI"


def test_rejected_or_unevaluated_candidates_are_never_registered(tmp_path):
    write(tmp_path, lineage=lineage(gate_decision="rejected", champion_model_version="x-1"))
    rejected = record.load_record(tmp_path / "bundle")
    with pytest.raises(registry.RegistryError, match="only accepted"):
        registry.register_candidate(object(), "abc123", rejected)  # refused before MLflow is touched


def test_record_from_another_run_is_refused(tmp_path):
    write(tmp_path, lineage=lineage(gate_decision="accepted", mlflow_run_id="otherrun"))
    accepted = record.load_record(tmp_path / "bundle")
    with pytest.raises(registry.RegistryError, match="names run otherrun"):
        registry.register_candidate(object(), "abc123", accepted)


def test_importing_registry_does_not_import_mlflow():
    code = "import sys, promiseops.registry; print('mlflow' in sys.modules)"
    env = {key: value for key, value in os.environ.items() if key in ("PATH", "SYSTEMROOT")}
    env["PYTHONPATH"] = str(ROOT / "src")
    result = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, check=True, env=env)
    assert result.stdout.strip() == "False"
