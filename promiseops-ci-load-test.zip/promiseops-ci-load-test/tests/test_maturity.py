"""Boundary and leakage checks for maturity-gap cohorts."""

import pandas as pd
import pytest

from promiseops.cohorts import Cutoffs, split
from promiseops.maturity import mature_train_ids, maturity_summary


def test_gap_removes_recent_approvals_without_admitting_future_labels():
    labels = pd.DataFrame({
        "order_id": ["boundary", "recent", "future_label", "validation"],
        "approved_at": pd.to_datetime(["2017-12-01", "2017-12-02", "2017-11-01", "2018-01-01"], utc=True),
        "label_available_at": pd.to_datetime(["2017-12-31", "2017-12-20", "2018-01-01", "2018-02-01"], utc=True),
        "late": pd.array([True, False, True, False], dtype="boolean"),
    })
    cutoffs = Cutoffs(train_end="2017-12-31T00:00:00Z", validation_end="2018-02-28T00:00:00Z",
                      as_of="2018-04-30T00:00:00Z")
    assert mature_train_ids(labels, cutoffs, 0) == split(labels, cutoffs).train
    assert mature_train_ids(labels, cutoffs, 30) == ("boundary",)
    report = maturity_summary(labels, cutoffs, 30)
    assert report["approved"] == 2 and report["missing_labels_at_training"] == 1
    assert report["label_coverage"] == 0.5
    assert split(labels, cutoffs).validation == ("validation",)
    for invalid in (-1, 0.5, True):
        with pytest.raises(ValueError):
            mature_train_ids(labels, cutoffs, invalid)
