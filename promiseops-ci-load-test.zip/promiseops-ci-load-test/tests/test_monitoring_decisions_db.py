"""monitoring_decisions on a REAL PostgreSQL: what the API exports as promiseops_retraining_required.

Skipped without PROMISEOPS_TEST_DATABASE_URL (CI has no database service). DROPS the schema
(fixture from test_ingestion_db): use an EMPTY database whose name ends in "_test".
"""

import time
from datetime import UTC, datetime
from types import SimpleNamespace

import psycopg
import pytest
from test_ingestion_db import URL, conn  # noqa: F401  (pytest fixture)

from promiseops import db, decisions

pytestmark = pytest.mark.skipif(not URL, reason="PROMISEOPS_TEST_DATABASE_URL is not set")


def decision(version="model-v1", *, day=1, retrain=True, status="assessed", reasons=("recall below reference",),
             labels_sufficient=True):
    # Same attributes as monitor_train.MonitoringRecord (pinned by tests/test_monitoring_decisions.py).
    report = SimpleNamespace(labels=SimpleNamespace(sufficient=labels_sufficient)) if status == "assessed" else None
    return SimpleNamespace(as_of=datetime(2018, 5, day, tzinfo=UTC), incumbent_model_version=version,
                           status=status, retrain_recommended=retrain, reasons=list(reasons), report=report)


def test_no_decision_yet_is_none(conn):  # noqa: F811
    assert decisions.latest_retrain_recommended(conn, "model-v1") is None


def test_recorded_decision_round_trips(conn):  # noqa: F811
    decisions.record_decision(conn, "run-1", decision(retrain=True))

    assert decisions.latest_retrain_recommended(conn, "model-v1") is True
    row = conn.execute("SELECT monitoring_run_id, as_of, incumbent_model_version, status, retrain_recommended, "
                       "labels_sufficient, reasons_count FROM promiseops.monitoring_decisions").fetchall()
    assert row == [("run-1", datetime(2018, 5, 1, tzinfo=UTC), "model-v1", "assessed", True, True, 1)]


def test_decision_about_another_model_is_ignored(conn):  # noqa: F811
    # After a retrained model is deployed, the old model's "retrain" must not keep the alert firing.
    decisions.record_decision(conn, "run-old", decision("model-v1", retrain=True))

    assert decisions.latest_retrain_recommended(conn, "model-v2") is None


def test_newest_as_of_wins_even_when_recorded_earlier(conn):  # noqa: F811
    decisions.record_decision(conn, "run-may-9", decision(day=9, retrain=False))
    decisions.record_decision(conn, "run-may-2-replay", decision(day=2, retrain=True))

    assert decisions.latest_retrain_recommended(conn, "model-v1") is False


def test_retried_run_is_recorded_once(conn):  # noqa: F811
    decisions.record_decision(conn, "run-1", decision(retrain=True))
    decisions.record_decision(conn, "run-1", decision(retrain=True))

    assert conn.execute("SELECT count(*) FROM promiseops.monitoring_decisions").fetchone()[0] == 1


def test_schema_v4_applies_twice(conn):  # noqa: F811
    db.apply_schema(conn)

    versions = [v for (v,) in conn.execute("SELECT version FROM promiseops.schema_version ORDER BY version")]
    assert versions == [1, 2, 3, 4] and db.SCHEMA_VERSION == 4


def test_db_init_upgrades_a_v3_database_and_keeps_its_data(conn):  # noqa: F811
    # A develop-v3 database: everything except monitoring_decisions, with predictions and snapshots in it.
    conn.execute("DROP TABLE promiseops.monitoring_decisions")
    conn.execute("DELETE FROM promiseops.schema_version WHERE version = 4")
    conn.execute("INSERT INTO promiseops.predictions (request_id, order_id, risk_probability, model_version) "
                 "VALUES ('req-1', 'ord-1', 0.25, 'model-v1')")
    conn.execute("INSERT INTO promiseops.prediction_snapshots (request_id, predicted_at, features, artifact_sha256) "
                 "VALUES ('req-1', '2018-05-01T00:00:00Z', '{\"freight_total\": 12.5}', %s)", ("a" * 64,))

    db.apply_schema(conn)   # what `promiseops db-init` runs

    versions = [v for (v,) in conn.execute("SELECT version FROM promiseops.schema_version ORDER BY version")]
    assert versions == [1, 2, 3, 4]
    assert conn.execute("SELECT request_id, order_id, risk_probability FROM promiseops.predictions").fetchall() == [
        ("req-1", "ord-1", 0.25)]
    assert conn.execute("SELECT request_id, features FROM promiseops.prediction_snapshots").fetchall() == [
        ("req-1", {"freight_total": 12.5})]
    decisions.record_decision(conn, "run-1", decision(retrain=True))
    assert decisions.latest_retrain_recommended(conn, "model-v1") is True


@pytest.mark.parametrize("status", ["no_reference", "no_prediction_history"])
def test_newer_run_that_could_not_measure_does_not_clear_the_decision(conn, status):  # noqa: F811
    # A gap in prediction logging must not silently clear a real "retrain" alert.
    decisions.record_decision(conn, "run-may-2", decision(day=2, retrain=True))
    decisions.record_decision(conn, "run-may-9", decision(day=9, retrain=False, status=status))

    assert decisions.latest_retrain_recommended(conn, "model-v1") is True


def test_newer_run_with_insufficient_labels_does_not_clear_the_decision(conn):  # noqa: F811
    # Too few mature labels: quality is unknown, so "no retrain" is not evidence that the model recovered.
    decisions.record_decision(conn, "run-may-2", decision(day=2, retrain=True))
    decisions.record_decision(conn, "run-may-9", decision(day=9, retrain=False, labels_sufficient=False))

    assert decisions.latest_retrain_recommended(conn, "model-v1") is True
    assert conn.execute("SELECT labels_sufficient FROM promiseops.monitoring_decisions "
                        "WHERE monitoring_run_id = 'run-may-9'").fetchone() == (False,)   # still kept for audit


def test_insufficient_labels_alone_never_report_a_decision(conn):  # noqa: F811
    decisions.record_decision(conn, "run-1", decision(retrain=False, labels_sufficient=False))

    assert decisions.latest_retrain_recommended(conn, "model-v1") is None


def test_locked_table_fails_fast_instead_of_hanging_the_scrape(conn):  # noqa: F811
    decisions.record_decision(conn, "run-1", decision())
    with db.connect(URL) as holder, holder.transaction():
        holder.execute("LOCK TABLE promiseops.monitoring_decisions IN ACCESS EXCLUSIVE MODE")
        started = time.monotonic()
        with pytest.raises(psycopg.errors.QueryCanceled), db.connect(URL, statement_timeout_ms=500) as reader:
            decisions.latest_retrain_recommended(reader, "model-v1")
        assert time.monotonic() - started < 3
