"""Small builders for valid batch documents. Each test changes only what it is testing.

Timeline used everywhere (UTC):
  2017-04-10 12:00  orders approved
  2017-04-15 00:00  orders batch published          (ORDERS_AT)
  2017-04-20 12:00  orders delivered
  2017-04-27 12:00  outcome known (delivery + 7 days)
  2017-05-01 00:00  outcomes batch published        (OUTCOMES_AT)
"""

import json
from collections.abc import Iterable
from typing import Any

from promiseops.contracts import digest

ORDERS_AT = "2017-04-15T00:00:00Z"
OUTCOMES_AT = "2017-05-01T00:00:00Z"
APPROVED_AT = "2017-04-10T12:00:00Z"
AS_OF = "2017-06-01T00:00:00Z"  # after everything: nothing is "from the future"


def orders_doc(batch_id: str = "orders-1", order_ids: Iterable[str] = ("o1", "o2"),
               available_at: str = ORDERS_AT) -> dict[str, Any]:
    """An orders batch: one customer per order, shared seller s1 and product p1, one item and payment each."""
    order_ids = list(order_ids)
    return {
        "schema_version": "1.0",
        "batch_id": batch_id,
        "available_at": available_at,
        "kind": "orders",
        "customers": [{"customer_id": f"c-{oid}", "customer_state": "SP"} for oid in order_ids],
        "sellers": [{"seller_id": "s1", "seller_state": "SP"}],
        "products": [{"product_id": "p1", "category": "toys", "weight_g": 500.0}],
        "orders": [{"order_id": oid, "customer_id": f"c-{oid}", "approved_at": APPROVED_AT,
                    "promised_date": "2017-04-25"} for oid in order_ids],
        "items": [{"order_id": oid, "item_id": 1, "product_id": "p1", "seller_id": "s1",
                   "price": 19.9, "freight": 5.1} for oid in order_ids],
        "payments": [{"order_id": oid, "sequence": 1, "payment_type": "credit_card", "installments": 1,
                      "value": 25.0} for oid in order_ids],
    }


def outcomes_doc(batch_id: str = "outcomes-1", order_ids: Iterable[str] = ("o1", "o2"),
                 available_at: str = OUTCOMES_AT,
                 delivered_at: str = "2017-04-20T12:00:00Z") -> dict[str, Any]:
    return {
        "schema_version": "1.0",
        "batch_id": batch_id,
        "available_at": available_at,
        "kind": "outcomes",
        "outcomes": [{"order_id": oid, "delivered_at": delivered_at, "available_at": "2017-04-27T12:00:00Z"}
                     for oid in order_ids],
    }


def encode(document: Any, **dumps_options: Any) -> tuple[bytes, str]:
    """(file bytes, contract payload_sha256). ``dumps_options`` changes only the formatting."""
    return json.dumps(document, **dumps_options).encode("utf-8"), digest(document)
