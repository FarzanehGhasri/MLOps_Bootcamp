"""Issue #21 persistence barrier against real temporary MLflow, without a database.

The policy decision is injected to isolate orchestration; these are synthetic
software tests, not real-data monitoring or group-server acceptance evidence.
The decision row for promiseops_retraining_required (!42) goes to a recording
connection; the real PostgreSQL write is in tests/test_monitoring_decisions_db.py.
"""

from pathlib import Path
from unittest.mock import Mock

import pytest
from test_training_db import CUTOFFS, client, settings, tracking_uri  # noqa: F401

from promiseops import monitor_train, training

pytest.importorskip("mlflow")


def decision(recommend):
    return monitor_train.MonitoringRecord(
        as_of=CUTOFFS.as_of, incumbent_model_version="baseline-constant-v1",
        status="assessed", retrain_recommended=recommend,
        reasons=["synthetic policy decision for persistence-boundary test"],
    )


class RecordingConnection:
    """Stands in for PostgreSQL: run_monitor_train publishes its decision with connection.execute."""

    def __init__(self):
        self.calls = []

    def execute(self, sql, params=None):
        self.calls.append((sql, params))
        return self

    def published(self):
        """(monitoring run id, retrain_recommended) of each decision row written."""
        return [(params[0], params[4]) for sql, params in self.calls
                if "INSERT INTO promiseops.monitoring_decisions" in sql]


@pytest.mark.parametrize("failure", ["upload", "readback", "finish_write", "finish_readback"])
def test_persistence_failure_prevents_training(tmp_path, client, monkeypatch, failure):  # noqa: F811
    record = decision(True)
    monkeypatch.setattr(monitor_train, "assess", lambda *a, **k: record)
    fit = Mock(side_effect=AssertionError("training must not start"))
    monkeypatch.setattr(training, "run_train", fit)
    terminate = client.set_terminated

    if failure == "upload":
        def broken_upload(*args):
            raise RuntimeError("monitoring artifact upload failed")
        monkeypatch.setattr(client, "log_text", broken_upload)
    elif failure == "readback":
        wrong = tmp_path / "wrong-monitoring.json"
        wrong.write_text(record.model_copy(update={"retrain_recommended": False}).model_dump_json(),
                         encoding="utf-8")
        monkeypatch.setattr(client, "download_artifacts", lambda *args: str(wrong))
    else:
        def broken_finish(run_id, status):
            if status == "FINISHED":
                if failure == "finish_write":
                    raise RuntimeError("monitoring final status write failed")
                return None  # Acknowledged, but deliberately not persisted.
            return terminate(run_id, status)
        monkeypatch.setattr(client, "set_terminated", broken_finish)

    connection = RecordingConnection()
    with pytest.raises((RuntimeError, training.TrainingError)):
        monitor_train.run_monitor_train(connection, client, settings(tmp_path), cutoffs=CUTOFFS)
    fit.assert_not_called()
    experiment = client.get_experiment_by_name(monitor_train.MONITORING_EXPERIMENT)
    [run] = client.search_runs([experiment.experiment_id])
    assert run.info.status == "FAILED"
    assert connection.published() == []   # a run that fails persistence publishes no decision


def test_no_recommendation_persists_report_without_calling_training(tmp_path, client, monkeypatch):  # noqa: F811
    record = decision(False)
    monkeypatch.setattr(monitor_train, "assess", lambda *a, **k: record)
    fit = Mock(side_effect=AssertionError("no recommendation must never fit"))
    monkeypatch.setattr(training, "run_train", fit)
    connection = RecordingConnection()
    result = monitor_train.run_monitor_train(connection, client, settings(tmp_path), cutoffs=CUTOFFS)
    fit.assert_not_called()
    assert result.training is None
    assert client.get_run(result.monitoring_run_id).info.status == "FINISHED"
    assert connection.published() == [(result.monitoring_run_id, False)]
    saved = client.download_artifacts(result.monitoring_run_id, monitor_train.MONITORING_FILE,
                                      str(tmp_path / "readback"))
    assert monitor_train.MonitoringRecord.model_validate_json(Path(saved).read_text(encoding="utf-8")) == record


def test_training_starts_only_after_report_and_final_status_readback(tmp_path, client, monkeypatch):  # noqa: F811
    record = decision(True)
    monkeypatch.setattr(monitor_train, "assess", lambda *a, **k: record)
    connection = RecordingConnection()

    class TrainingReached(Exception):
        pass

    def fit(*args, **kwargs):
        experiment = client.get_experiment_by_name(monitor_train.MONITORING_EXPERIMENT)
        [run] = client.search_runs([experiment.experiment_id])
        assert run.info.status == "FINISHED"
        assert connection.published() == [(run.info.run_id, True)]   # decision published before training
        saved = client.download_artifacts(run.info.run_id, monitor_train.MONITORING_FILE,
                                          str(tmp_path / "before-fit"))
        assert monitor_train.MonitoringRecord.model_validate_json(
            Path(saved).read_text(encoding="utf-8")) == record
        raise TrainingReached

    spy = Mock(side_effect=fit)
    monkeypatch.setattr(training, "run_train", spy)
    with pytest.raises(TrainingReached):
        monitor_train.run_monitor_train(connection, client, settings(tmp_path), cutoffs=CUTOFFS)
    spy.assert_called_once()
