"""Database tests for ingest_batch: transactions, idempotent replay, quarantine, audit log, concurrency.

They need a REAL PostgreSQL (constraints, advisory locks and transactions cannot be faked honestly)
and are skipped when PROMISEOPS_TEST_DATABASE_URL is not set — CI has no database service yet.

Run locally (PowerShell), with the throw-away database from compose.test.yaml:

    docker compose -f compose.test.yaml up -d --wait
    $env:PROMISEOPS_TEST_DATABASE_URL = "postgresql://promiseops:promiseops-test@127.0.0.1:55432/promiseops_test"
    pytest tests/test_ingestion_db.py -v

WARNING: every test DROPS the schema ``promiseops``. As a guard, the database name must end in "_test".
"""

import json
import os
import threading
from decimal import Decimal
from pathlib import Path

import psycopg
import pytest
from factories import AS_OF, encode, orders_doc, outcomes_doc
from psycopg.conninfo import conninfo_to_dict

from promiseops import data, db
from promiseops.cli import main as cli_main
from promiseops.contracts import digest, instant
from promiseops.validation import BatchRejected, ExpectedMetadata, Reason, raw_sha256

URL = os.environ.get("PROMISEOPS_TEST_DATABASE_URL")
ROOT = Path(__file__).resolve().parents[1]
pytestmark = pytest.mark.skipif(not URL, reason="PROMISEOPS_TEST_DATABASE_URL is not set")


@pytest.fixture
def conn():
    if not str(conninfo_to_dict(URL).get("dbname", "")).endswith("_test"):
        pytest.fail("refusing to drop schema: test database name must end with '_test'")
    connection = db.connect(URL)
    connection.execute("DROP SCHEMA IF EXISTS promiseops CASCADE")
    db.apply_schema(connection)
    yield connection
    connection.close()


def ingest(conn, document, as_of=AS_OF, **options):
    raw, sha = encode(document)
    return data.ingest_batch(conn, raw, as_of=as_of, expected_sha256=sha, **options)


def reject(conn, raw: bytes, sha: str, as_of=AS_OF, **options) -> BatchRejected:
    with pytest.raises(BatchRejected) as info:
        data.ingest_batch(conn, raw, as_of=as_of, expected_sha256=sha, **options)
    return info.value


def count(conn, table: str) -> int:
    return conn.execute(f"SELECT count(*) FROM promiseops.{table}").fetchone()[0]


def source_row_counts(conn) -> dict[str, int]:
    tables = ("customers", "sellers", "products", "orders", "order_items", "order_payments", "outcomes")
    return {t: count(conn, t) for t in tables}


def attempts(conn) -> list[tuple]:
    return conn.execute(
        "SELECT batch_id, status, reason_code FROM promiseops.ingest_attempts ORDER BY attempt_id").fetchall()


# ---------------------------------------------------------------------------------------------
# Happy path, replay, schema
# ---------------------------------------------------------------------------------------------
def test_schema_can_be_applied_again(conn):
    db.apply_schema(conn)
    versions = conn.execute("SELECT version FROM promiseops.schema_version ORDER BY version").fetchall()
    assert versions == [(1,), (2,), (3,), (4,)]   # v4: promiseops.monitoring_decisions (!42)


def test_orders_then_outcomes_are_committed_with_receipts(conn):
    receipt = ingest(conn, orders_doc(), expected_file_sha256=raw_sha256(encode(orders_doc())[0]),
                     source_commit="abc123")
    assert receipt.status == "committed" and receipt.kind == "orders"
    assert receipt.row_counts["orders"] == 2
    assert ingest(conn, outcomes_doc()).status == "committed"

    assert source_row_counts(conn) == {"customers": 2, "sellers": 1, "products": 1, "orders": 2,
                                       "order_items": 2, "order_payments": 2, "outcomes": 2}
    row = conn.execute("SELECT kind, payload_sha256, file_sha256, source_commit, row_counts->>'items' "
                       "FROM promiseops.ingest_batches WHERE batch_id = 'orders-1'").fetchone()
    assert row == ("orders", digest(orders_doc()), raw_sha256(encode(orders_doc())[0]), "abc123", "2")
    assert attempts(conn) == [("orders-1", "committed", None), ("outcomes-1", "committed", None)]


def test_amounts_are_stored_exactly(conn):
    ingest(conn, orders_doc(order_ids=["o1"]))
    price, freight, weight = conn.execute(
        "SELECT i.price, i.freight, p.weight_g FROM promiseops.order_items i "
        "JOIN promiseops.products p USING (product_id)").fetchone()
    assert (price, freight, weight) == (Decimal("19.9"), Decimal("5.1"), Decimal("500.0"))


def test_replay_of_same_payload_is_a_no_op(conn):
    first = ingest(conn, orders_doc())
    before = source_row_counts(conn)
    # Same payload, different file formatting -> same payload_sha256 -> still the same batch.
    raw, sha = encode(orders_doc(), indent=2)
    again = data.ingest_batch(conn, raw, as_of=AS_OF, expected_sha256=sha)
    assert again.status == "replayed" and again.row_counts == first.row_counts
    assert source_row_counts(conn) == before
    assert count(conn, "ingest_batches") == 1
    assert [a[1] for a in attempts(conn)] == ["committed", "replayed"]


def test_same_batch_id_with_other_payload_is_rejected_and_original_kept(conn):
    ingest(conn, orders_doc())
    changed = orders_doc()
    changed["items"][0]["price"] = 99.0
    error = reject(conn, *encode(changed))
    assert error.reason is Reason.BATCH_ID_CONFLICT
    kept = conn.execute("SELECT price FROM promiseops.order_items WHERE order_id = 'o1'").fetchone()[0]
    assert kept == Decimal("19.9")


def test_order_releases_view_gives_publication_time(conn):
    ingest(conn, orders_doc(order_ids=["o1"]))
    released_at, batch_id = conn.execute(
        "SELECT released_at, batch_id FROM promiseops.order_releases WHERE order_id = 'o1'").fetchone()
    assert released_at.isoformat() == "2017-04-15T00:00:00+00:00" and batch_id == "orders-1"


def test_identical_dimension_reused_by_later_batch(conn):
    ingest(conn, orders_doc(batch_id="orders-1", order_ids=["o1"]))
    ingest(conn, orders_doc(batch_id="orders-2", order_ids=["o2"], available_at="2017-04-16T00:00:00Z"))
    assert conn.execute("SELECT first_batch_id FROM promiseops.sellers").fetchall() == [("orders-1",)]


def test_supplied_fixtures_end_to_end(conn):
    for name in ("synthetic-orders.json", "synthetic-outcomes.json"):
        raw = (ROOT / "fixtures" / name).read_bytes()
        data.ingest_batch(conn, raw, as_of=AS_OF, expected_sha256=digest(json.loads(raw)))
    assert count(conn, "orders") == 300 and count(conn, "outcomes") == 300


# ---------------------------------------------------------------------------------------------
# Rejections: nothing written, evidence kept
# ---------------------------------------------------------------------------------------------
def test_rejected_batch_writes_no_rows_but_is_quarantined(conn):
    document = orders_doc()
    document["payments"] = document["payments"][:1]  # o2 without payment
    raw, sha = encode(document)
    error = reject(conn, raw, sha)
    assert error.reason is Reason.INCOMPLETE_ORDER

    assert sum(source_row_counts(conn).values()) == 0
    assert count(conn, "ingest_batches") == 0
    payload, reason, batch_id = conn.execute(
        "SELECT payload, reason_code, batch_id FROM promiseops.ingest_quarantine").fetchone()
    assert bytes(payload) == raw  # exact bytes, re-checkable later
    assert (reason, batch_id) == ("incomplete_order", "orders-1")
    assert attempts(conn) == [("orders-1", "rejected", "incomplete_order")]


def test_same_bad_bytes_are_quarantined_once_but_every_attempt_logged(conn):
    raw = b"{broken"
    for _ in range(2):
        assert reject(conn, raw, "0" * 64).reason is Reason.INVALID_JSON
    assert conn.execute("SELECT attempts FROM promiseops.ingest_quarantine").fetchall() == [(2,)]
    assert attempts(conn) == [(None, "rejected", "invalid_json")] * 2


@pytest.mark.parametrize("raw", [b'{"amount":1e999}', b'{"nested":[-1e999]}'])
def test_numeric_overflow_rejects_and_quarantines_whole_batch(conn, raw):
    error = reject(conn, raw, "0" * 64)
    assert error.reason is Reason.INVALID_JSON
    assert sum(source_row_counts(conn).values()) == 0
    assert count(conn, "ingest_batches") == 0
    payload, reason = conn.execute(
        "SELECT payload, reason_code FROM promiseops.ingest_quarantine").fetchone()
    assert bytes(payload) == raw and reason == "invalid_json"
    assert attempts(conn) == [(None, "rejected", "invalid_json")]


def test_file_checksum_mismatch_is_quarantined(conn):
    raw, sha = encode(orders_doc())
    assert reject(conn, raw, sha, expected_file_sha256="0" * 64).reason is Reason.CHECKSUM_MISMATCH
    assert count(conn, "ingest_quarantine") == 1 and count(conn, "orders") == 0


@pytest.mark.parametrize(("table", "field", "value"), [
    ("items", "price", True), ("items", "price", "19.9"),
    ("items", "freight", False), ("items", "item_id", True),
    ("payments", "value", True), ("payments", "sequence", True),
    ("payments", "installments", True), ("products", "weight_g", False),
    ("orders", "approved_at", 1491825600), ("orders", "promised_date", 1493078400),
])
def test_wrong_json_types_reject_entire_batch_with_audit(conn, table, field, value):
    document = orders_doc()
    document[table][0][field] = value
    raw, sha = encode(document)
    error = reject(conn, raw, sha)
    assert error.reason is Reason.SCHEMA_INVALID
    assert sum(source_row_counts(conn).values()) == 0
    assert count(conn, "ingest_batches") == 0
    assert count(conn, "ingest_quarantine") == 1
    assert attempts(conn)[0][1:] == ("rejected", "schema_invalid")


@pytest.mark.parametrize(("second", "reason"), [
    # item appended to an order that is already committed
    (lambda d: d["items"].append({"order_id": "o1", "item_id": 2, "product_id": "p1", "seller_id": "s1",
                                  "price": 1.0, "freight": 0.0}), Reason.APPEND_TO_COMMITTED_ORDER),
    # known seller arrives with another state
    (lambda d: d["sellers"][0].update(seller_state="RJ"), Reason.CHANGED_IMMUTABLE_ROW),
])
def test_cross_batch_rules_against_committed_rows(conn, second, reason):
    ingest(conn, orders_doc(order_ids=["o1"]))
    before = source_row_counts(conn)
    document = orders_doc(batch_id="orders-2", order_ids=["o2"], available_at="2017-04-16T00:00:00Z")
    second(document)
    assert reject(conn, *encode(document)).reason is reason
    assert source_row_counts(conn) == before


def test_outcome_for_unknown_order_and_future_batch_are_rejected(conn):
    assert reject(conn, *encode(outcomes_doc())).reason is Reason.MISSING_FOREIGN_KEY
    early = reject(conn, *encode(orders_doc()), as_of="2017-04-14T00:00:00Z")
    assert early.reason is Reason.FUTURE_PUBLICATION
    assert count(conn, "ingest_batches") == 0


# ---------------------------------------------------------------------------------------------
# Transactions and concurrency
# ---------------------------------------------------------------------------------------------
def test_failure_in_the_middle_rolls_back_everything(conn, monkeypatch):
    real_insert_rows = data._insert_rows

    def insert_then_crash(connection, batch):
        real_insert_rows(connection, batch)   # all rows are written inside the transaction ...
        raise RuntimeError("simulated crash")  # ... then something breaks before COMMIT

    monkeypatch.setattr(data, "_insert_rows", insert_then_crash)
    with pytest.raises(RuntimeError):
        ingest(conn, orders_doc())
    assert sum(source_row_counts(conn).values()) == 0
    assert count(conn, "ingest_batches") == 0
    assert attempts(conn) == [("orders-1", "failed", "RuntimeError")]

    monkeypatch.undo()  # a retry after the crash works normally
    assert ingest(conn, orders_doc()).status == "committed"


def test_concurrent_ingestion_of_same_batch_commits_once(conn):
    raw, sha = encode(orders_doc())
    statuses, errors = [], []
    start = threading.Barrier(4)

    def worker():
        try:
            with db.connect(URL) as own:
                start.wait()
                statuses.append(data.ingest_batch(own, raw, as_of=AS_OF, expected_sha256=sha).status)
        except Exception as error:  # noqa: BLE001 — a thread cannot raise into pytest; asserted below
            errors.append(error)

    threads = [threading.Thread(target=worker) for _ in range(4)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join(timeout=60)
    assert errors == []
    assert sorted(statuses) == ["committed", "replayed", "replayed", "replayed"]
    assert count(conn, "orders") == 2


def test_connection_inside_a_transaction_is_refused(conn):
    with psycopg.connect(URL) as manual:  # autocommit off
        raw, sha = encode(orders_doc())
        with pytest.raises(ValueError, match="autocommit"):
            data.ingest_batch(manual, raw, as_of=AS_OF, expected_sha256=sha)


def test_autocommit_connection_inside_explicit_transaction_is_refused(conn):
    # Review of MR !7: autocommit=True alone is not enough — inside `with conn.transaction():`
    # our own transaction would silently become a savepoint of the caller's transaction.
    raw, sha = encode(orders_doc())
    assert conn.autocommit
    with conn.transaction():
        with pytest.raises(ValueError, match="outside any transaction"):
            data.ingest_batch(conn, raw, as_of=AS_OF, expected_sha256=sha)
        with pytest.raises(ValueError, match="outside any transaction"):
            db.apply_schema(conn)
    assert count(conn, "ingest_batches") == 0 and count(conn, "ingest_attempts") == 0
    assert data.ingest_batch(conn, raw, as_of=AS_OF, expected_sha256=sha).status == "committed"


def test_replay_with_as_of_before_publication_is_rejected_not_replayed(conn):
    # Review of MR !7: the as_of rule must hold even for a batch that is already committed.
    raw, sha = encode(orders_doc())
    assert data.ingest_batch(conn, raw, as_of=AS_OF, expected_sha256=sha).status == "committed"
    before = source_row_counts(conn)

    error = reject(conn, raw, sha, as_of="2017-04-14T23:59:59Z")  # one second before publication
    assert error.reason is Reason.FUTURE_PUBLICATION
    assert [a[1:] for a in attempts(conn)] == [("committed", None), ("rejected", "future_publication")]
    assert source_row_counts(conn) == before and count(conn, "ingest_batches") == 1


def test_payload_disagreeing_with_index_metadata_is_rejected(conn):
    raw, sha = encode(orders_doc())
    wrong = ExpectedMetadata(kind="orders", available_at=instant("2017-04-16T00:00:00Z"), batch_id="orders-1")
    assert reject(conn, raw, sha, expected=wrong).reason is Reason.FEED_METADATA_MISMATCH
    assert count(conn, "ingest_batches") == 0 and count(conn, "ingest_quarantine") == 1
    # ... also when the same batch is already committed: not silently counted as a replay.
    right = ExpectedMetadata(kind="orders", available_at=instant("2017-04-15T00:00:00Z"), batch_id="orders-1")
    receipt = data.ingest_batch(conn, raw, as_of=AS_OF, expected_sha256=sha, expected=right)
    assert receipt.status == "committed"
    assert reject(conn, raw, sha, expected=wrong).reason is Reason.FEED_METADATA_MISMATCH


# ---------------------------------------------------------------------------------------------
# dataset_identity (model lineage)
# ---------------------------------------------------------------------------------------------
def test_dataset_identity_depends_only_on_receipts_known_at_as_of(conn):
    empty = data.dataset_identity(conn, as_of=AS_OF)
    ingest(conn, orders_doc())
    after_orders = data.dataset_identity(conn, as_of=AS_OF)
    ingest(conn, outcomes_doc())
    assert len({empty, after_orders, data.dataset_identity(conn, as_of=AS_OF)}) == 3
    # Replay view: at a cutoff before the outcomes batch, the identity is the "orders only" one.
    assert data.dataset_identity(conn, as_of="2017-04-20T00:00:00Z") == after_orders
    assert after_orders.startswith("receipts-sha256:")


# ---------------------------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------------------------
def test_cli_ingest_file_exit_codes(conn, tmp_path, monkeypatch, capsys):
    monkeypatch.setenv(db.DATABASE_URL_ENV, URL)
    good, bad = tmp_path / "good.json", tmp_path / "bad.json"
    good.write_bytes(encode(orders_doc())[0])
    bad.write_bytes(encode(outcomes_doc(order_ids=["o-unknown"]))[0])

    assert cli_main(["payload-sha256", str(good)]) == 0
    sha = capsys.readouterr().out.strip()
    assert cli_main(["ingest-file", str(good), "--as-of", AS_OF, "--expected-sha256", sha]) == 0
    assert json.loads(capsys.readouterr().out)["status"] == "committed"

    bad_sha = digest(outcomes_doc(order_ids=["o-unknown"]))
    assert cli_main(["ingest-file", str(bad), "--as-of", AS_OF, "--expected-sha256", bad_sha]) == 3
    assert json.loads(capsys.readouterr().out)["reason"] == "missing_foreign_key"


def test_cli_ingest_feed_in_publication_order_until_as_of(conn, tmp_path, monkeypatch, capsys):
    monkeypatch.setenv(db.DATABASE_URL_ENV, URL)
    index = []
    # Listed out of order on purpose: outcomes first, orders second.
    for name, document in (("outcomes.json", outcomes_doc()), ("orders.json", orders_doc())):
        raw, sha = encode(document)
        (tmp_path / name).write_bytes(raw)
        index.append({"file": name, "kind": document["kind"], "available_at": document["available_at"],
                      "payload_sha256": sha, "file_sha256": raw_sha256(raw)})
    (tmp_path / "manifest.json").write_text(json.dumps({"schema_version": "1.0", "releases": index}))

    assert cli_main(["ingest-feed", str(tmp_path), "--as-of", "2017-04-20T00:00:00Z"]) == 0
    assert [json.loads(line)["batch_id"] for line in capsys.readouterr().out.splitlines()] == ["orders-1"]
    assert cli_main(["ingest-feed", str(tmp_path), "--as-of", AS_OF]) == 0
    statuses = [json.loads(line)["status"] for line in capsys.readouterr().out.splitlines()]
    assert statuses == ["replayed", "committed"]  # re-running the feed is safe


def test_cli_ingest_feed_refuses_an_index_that_disagrees_with_a_payload(conn, tmp_path, monkeypatch, capsys):
    # Review of MR !7: the index says the orders batch is published AFTER as_of, so plain filtering
    # would silently skip it. The pre-flight must catch this before ordering/filtering is used.
    monkeypatch.setenv(db.DATABASE_URL_ENV, URL)
    index = []
    for name, document in (("orders.json", orders_doc()), ("outcomes.json", outcomes_doc())):
        raw, sha = encode(document)
        (tmp_path / name).write_bytes(raw)
        index.append({"file": name, "kind": document["kind"], "available_at": document["available_at"],
                      "payload_sha256": sha, "file_sha256": raw_sha256(raw)})
    index[0]["available_at"] = "2017-07-01T00:00:00Z"  # payload says 2017-04-15
    (tmp_path / "manifest.json").write_text(json.dumps({"releases": index}))

    assert cli_main(["ingest-feed", str(tmp_path), "--as-of", AS_OF]) == 3
    assert json.loads(capsys.readouterr().out)["reason"] == "feed_metadata_mismatch"
    assert count(conn, "ingest_batches") == 0  # nothing ingested, not even the valid outcomes entry
    assert attempts(conn) == [("orders-1", "rejected", "feed_metadata_mismatch")]


def test_cli_ingest_feed_checks_payload_sha256_of_entries_not_yet_due(conn, tmp_path, monkeypatch, capsys):
    # Second review of MR !7: the outcomes entry is published after as_of, so it is not ingested in
    # this run; its wrong payload_sha256 must still be caught by the pre-flight (before any write).
    monkeypatch.setenv(db.DATABASE_URL_ENV, URL)
    index = []
    for name, document in (("orders.json", orders_doc()), ("outcomes.json", outcomes_doc())):
        raw, sha = encode(document)
        (tmp_path / name).write_bytes(raw)
        index.append({"file": name, "kind": document["kind"], "available_at": document["available_at"],
                      "payload_sha256": sha, "file_sha256": raw_sha256(raw)})
    index[1]["payload_sha256"] = "0" * 64
    (tmp_path / "manifest.json").write_text(json.dumps({"releases": index}))
    between = "2017-04-20T00:00:00Z"  # after ORDERS_AT, before OUTCOMES_AT

    assert cli_main(["ingest-feed", str(tmp_path), "--as-of", between]) == 3
    assert json.loads(capsys.readouterr().out)["reason"] == "checksum_mismatch"
    assert count(conn, "ingest_batches") == 0  # the valid, due orders entry is not ingested either
    assert attempts(conn) == [("outcomes-1", "rejected", "checksum_mismatch")]
