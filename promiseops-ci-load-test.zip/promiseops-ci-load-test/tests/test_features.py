"""Feature rules without a database (run in CI): contract list, no fan-out, local time, ties, refusals.

Database path (released-by-as_of, parity single vs batch): tests/test_features_db.py
Run: $env:PYTHONPATH = "src"; python -m pytest tests/test_features.py -v
"""

import json
from datetime import date
from decimal import Decimal
from pathlib import Path

import pandas as pd
import pytest

from promiseops.features import (
    CATEGORICAL_FEATURES,
    FEATURE_NAMES,
    NUMERIC_FEATURES,
    FeatureError,
    compute_features,
)

ROOT = Path(__file__).resolve().parents[1]


def frames(orders, items, payments):
    return pd.DataFrame(orders), pd.DataFrame(items), pd.DataFrame(payments)


def order(order_id="o1", approved_at="2017-04-10T12:00:00+00:00", promised="2017-04-25", state="SP"):
    return {"order_id": order_id, "approved_at": approved_at, "promised_date": date.fromisoformat(promised),
            "customer_state": state}


def item(order_id="o1", item_id=1, price=10.0, freight=2.0, weight=100.0, category="toys", seller="s1",
         seller_state="SP"):
    return {"order_id": order_id, "item_id": item_id, "price": price, "freight": freight, "weight_g": weight,
            "category": category, "seller_id": seller, "seller_state": seller_state}


def payment(order_id="o1", sequence=1, kind="credit_card", installments=1, value=12.0):
    return {"order_id": order_id, "sequence": sequence, "payment_type": kind, "installments": installments,
            "value": value}


def test_feature_names_match_the_contract_file():
    assert list(FEATURE_NAMES) == json.loads((ROOT / "contracts" / "features.json").read_text(encoding="utf-8"))
    assert set(NUMERIC_FEATURES) | set(CATEGORICAL_FEATURES) == set(FEATURE_NAMES)


def test_items_and_payments_are_aggregated_independently():
    # 2 items x 3 payments: a join before aggregating would count each item 3 times.
    result = compute_features(*frames(
        [order()],
        [item(item_id=1, price=10, freight=1, weight=100), item(item_id=2, price=30, freight=3, weight=200,
                                                                  seller="s2")],
        [payment(sequence=1, value=20, installments=1), payment(sequence=2, value=20, installments=6),
         payment(sequence=3, value=4, kind="voucher", installments=1)],
    ))
    row = result.loc["o1"]
    assert (row.item_count, row.seller_count) == (2, 2)
    assert (row.total_price, row.total_freight, row.total_weight_g) == (40, 4, 300)
    assert (row.payment_total, row.max_installments) == (44, 6)


def test_time_features_use_sao_paulo_local_time():
    # 02:30 UTC on Tuesday 11 April 2017 is 23:30 on Monday 10 April in Sao Paulo (UTC-3).
    row = compute_features(*frames([order(approved_at="2017-04-11T02:30:00+00:00", promised="2017-04-25")],
                                   [item()], [payment()])).loc["o1"]
    assert (row.approval_hour, row.approval_weekday, row.promise_days) == (23, 0, 15)


def test_daylight_saving_time_is_respected():
    # January 2017 was summer time in Sao Paulo (UTC-2): 01:30 UTC -> 23:30 the previous day.
    row = compute_features(*frames([order(approved_at="2017-01-10T01:30:00+00:00", promised="2017-01-20")],
                                   [item()], [payment()])).loc["o1"]
    assert (row.approval_hour, row.promise_days) == (23, 11)


def test_session_time_zone_of_the_input_does_not_matter():
    # The same instant written with different offsets (e.g. DB session in UTC vs Tokyo) is one value.
    utc = compute_features(*frames([order(approved_at="2017-04-11T02:30:00+00:00")], [item()], [payment()]))
    tokyo = compute_features(*frames([order(approved_at="2017-04-11T11:30:00+09:00")], [item()], [payment()]))
    pd.testing.assert_frame_equal(utc, tokyo)


def test_naive_timestamp_is_refused():
    with pytest.raises(ValueError, match="timezone"):
        compute_features(*frames([order(approved_at="2017-04-11T02:30:00")], [item()], [payment()]))


def test_interstate_fraction_counts_items():
    result = compute_features(*frames(
        [order(state="RJ")],
        [item(item_id=1, seller_state="RJ"), item(item_id=2, seller_state="SP"), item(item_id=3, seller_state="RJ")],
        [payment()],
    ))
    assert result.loc["o1", "interstate_fraction"] == pytest.approx(1 / 3)


def test_primary_values_use_largest_amount_then_alphabetical_order():
    result = compute_features(*frames(
        [order("o1"), order("o2")],
        [  # o1: toys 10 + toys 20 = 30 beats books 25 (grouped sums, not the single largest item)
            item("o1", 1, price=10, category="toys", seller_state="MG"),
            item("o1", 2, price=20, category="toys", seller_state="MG"),
            item("o1", 3, price=25, category="books", seller_state="SP"),
            # o2: exact tie after float noise (0.1 + 0.2 vs 0.3) -> alphabetical: "art" before "zoo"
            item("o2", 1, price=0.1, category="zoo", seller_state="RJ"),
            item("o2", 2, price=0.2, category="zoo", seller_state="RJ"),
            item("o2", 3, price=0.3, category="art", seller_state="BA"),
        ],
        [payment("o1", 1, "boleto", value=30), payment("o1", 2, "voucher", value=25),
         payment("o2", 1, "voucher", value=0.3), payment("o2", 2, "credit_card", value=0.3)],
    ))
    assert tuple(result.loc["o1", ["primary_category", "primary_seller_state", "primary_payment_type"]]) == \
        ("toys", "MG", "boleto")
    assert tuple(result.loc["o2", ["primary_category", "primary_seller_state", "primary_payment_type"]]) == \
        ("art", "BA", "credit_card")


def test_one_order_alone_equals_the_same_order_in_a_batch():
    orders = [order("o1"), order("o2", approved_at="2017-05-01T15:00:00+00:00", promised="2017-05-20", state="RJ")]
    items = [item("o1"), item("o2", price=99, seller_state="SP")]
    payments = [payment("o1"), payment("o2", value=99, installments=3)]
    batch = compute_features(*frames(orders, items, payments))
    alone = compute_features(*frames(orders[1:], items, payments))  # other orders' rows are ignored
    pd.testing.assert_frame_equal(alone.loc[["o2"]], batch.loc[["o2"]])


def test_output_shape_and_types():
    result = compute_features(*frames(
        [order("o2"), order("o1")],
        [item("o1", price=Decimal("10.50")), item("o2")],  # PostgreSQL numeric arrives as Decimal
        [payment("o1", value=Decimal("12.50")), payment("o2")],
    ))
    assert list(result.columns) == list(FEATURE_NAMES)
    assert list(result.index) == ["o1", "o2"] and result.index.name == "order_id"  # id is not a feature
    assert all(result[name].dtype == "float64" for name in NUMERIC_FEATURES)
    assert all(isinstance(value, str) for name in CATEGORICAL_FEATURES for value in result[name])
    assert result.loc["o1", "total_price"] == 10.5


@pytest.mark.parametrize("drop", ["items", "payments"])
def test_order_without_items_or_payments_is_an_error_not_a_zero(drop):
    items = [] if drop == "items" else [item()]
    payments = [] if drop == "payments" else [payment()]
    orders, item_frame, payment_frame = frames([order()], items, payments)
    if drop == "items":
        item_frame = pd.DataFrame(columns=list(item().keys()))
    else:
        payment_frame = pd.DataFrame(columns=list(payment().keys()))
    with pytest.raises(FeatureError, match="without items or payments"):
        compute_features(orders, item_frame, payment_frame)


def test_duplicate_order_and_missing_columns_are_refused():
    with pytest.raises(FeatureError, match="duplicate"):
        compute_features(*frames([order(), order()], [item()], [payment()]))
    with pytest.raises(FeatureError, match="missing columns"):
        compute_features(pd.DataFrame([{"order_id": "o1"}]), *frames([], [item()], [payment()])[1:])
