"""Candidate training and gates on synthetic features (no database; runs in CI).

Database end-to-end (train_candidate from ingested batches): tests/test_model_db.py
Run: $env:PYTHONPATH = "src"; python -m pytest tests/test_model.py -v
"""

import io

import joblib
import numpy as np
import pandas as pd
import pytest

from promiseops import approaches, cohorts
from promiseops.features import FEATURE_NAMES
from promiseops.model import Champion, ValidationCohort, compare_candidate, fit_candidate, score

CUTOFFS = cohorts.Cutoffs(train_end="2017-12-31T23:59:59Z", validation_end="2018-02-28T23:59:59Z",
                          as_of="2018-04-30T00:00:00Z")


def synthetic(n=1200, seed=1):
    """Features with a real signal: short promises and interstate shipping are late more often."""
    rng = np.random.default_rng(seed)
    ids = [f"o{i:05d}" for i in range(n)]
    table = pd.DataFrame({
        "item_count": rng.integers(1, 4, n).astype(float),
        "seller_count": np.ones(n),
        "total_price": rng.gamma(2, 60, n),
        "total_freight": rng.gamma(2, 10, n),
        "total_weight_g": rng.gamma(2, 800, n),
        "payment_total": rng.gamma(2, 70, n),
        "max_installments": rng.integers(0, 10, n).astype(float),
        "promise_days": rng.integers(5, 40, n).astype(float),
        "approval_hour": rng.integers(0, 24, n).astype(float),
        "approval_weekday": rng.integers(0, 7, n).astype(float),
        "interstate_fraction": rng.choice([0.0, 1.0], n),
        "customer_state": rng.choice(["SP", "RJ", "MG", "BA"], n),
        "primary_seller_state": rng.choice(["SP", "PR"], n),
        "primary_category": rng.choice(["toys", "books", "garden"], n),
        "primary_payment_type": rng.choice(["credit_card", "boleto"], n),
    }, index=pd.Index(ids, name="order_id"))[list(FEATURE_NAMES)]
    logit = -1.0 - 0.12 * table["promise_days"] + 1.5 * table["interstate_fraction"] + 0.8 * (
        table["customer_state"] == "BA")
    late = rng.random(n) < 1 / (1 + np.exp(-logit))
    approved = ["2017-06-01T12:00:00+00:00" if i < n * 2 // 3 else "2018-01-15T12:00:00+00:00" for i in range(n)]
    labels = pd.DataFrame({"order_id": ids, "approved_at": pd.to_datetime(approved, utc=True),
                           "late": pd.array(late, dtype="boolean")})
    split = cohorts.Split(cutoffs=CUTOFFS, train=tuple(ids[: n * 2 // 3]), validation=tuple(ids[n * 2 // 3:]))
    return table, labels, split


@pytest.fixture(scope="module")
def trained():
    table, labels, split = synthetic()
    return table, labels, split, fit_candidate(table, labels, split)


def test_candidate_is_chosen_among_at_least_two_approaches(trained):
    *_, candidate = trained
    assert set(candidate.approach_metrics) == {"baseline", "logistic_regression", "hist_gradient_boosting"}
    assert candidate.approach in approaches.CANDIDATE_APPROACHES
    best = candidate.approach_metrics[candidate.approach]
    assert candidate.validation_metrics == best
    assert all(best.recall_at_10 >= m.recall_at_10 for name, m in candidate.approach_metrics.items()
               if name != "baseline")
    # every approach was scored on the same orders
    assert len({(m.n, m.prevalence) for m in candidate.approach_metrics.values()}) == 1


def test_candidate_learns_more_than_the_constant_baseline(trained):
    *_, candidate = trained
    baseline = candidate.approach_metrics["baseline"]
    assert candidate.validation_metrics.pr_auc > baseline.pr_auc + 0.05
    # the baseline predicts the TRAINING prevalence for every order
    train_rate = candidate.train_summary["prevalence"]
    assert float(approaches.risk(candidate.baseline, candidate.cohort.features).iloc[0]) == pytest.approx(
        train_rate, abs=1e-4)


def test_training_is_reproducible(trained):
    table, labels, split, candidate = trained
    again = fit_candidate(table, labels, split)
    assert again.approach == candidate.approach and again.approach_metrics == candidate.approach_metrics
    pd.testing.assert_series_equal(approaches.risk(again.model, table), approaches.risk(candidate.model, table))


def test_first_candidate_is_compared_with_the_baseline(trained):
    *_, candidate = trained
    decision = compare_candidate(candidate, None, candidate.cohort)
    assert decision.champion_model_version == "baseline-training-prevalence"
    assert decision.decision == "accepted", decision.reasons
    assert decision.cohort_sha256 == cohorts.cohort_sha256(candidate.cohort.features.index)


class Oracle:
    """A champion that knows the labels: no candidate can beat it."""

    def __init__(self, late: pd.Series):
        self.late = late

    def predict_proba(self, features):
        p = self.late.reindex(features.index).astype(float).clip(0.02, 0.98).to_numpy()
        return np.column_stack([1 - p, p])


def test_better_champion_rejects_the_candidate(trained):
    *_, candidate = trained
    decision = compare_candidate(candidate, Champion("oracle-v1", Oracle(candidate.cohort.late)), candidate.cohort)
    assert decision.decision == "rejected"
    assert any(reason.startswith("FAIL: recall@10%") for reason in decision.reasons)


def test_champion_equal_to_candidate_passes(trained):
    *_, candidate = trained
    decision = compare_candidate(candidate, Champion("same", candidate.model), candidate.cohort)
    assert decision.decision == "accepted"
    assert decision.candidate_metrics == decision.champion_metrics


def test_another_cohort_is_refused(trained):
    table, labels, _, candidate = trained
    other = ValidationCohort.build(table.iloc[:300], labels.set_index("order_id")["late"])
    with pytest.raises(ValueError, match="differs from the candidate's validation cohort"):
        compare_candidate(candidate, None, other)


def test_pipeline_survives_pickling_and_unknown_categories(trained):
    table, _, _, candidate = trained
    buffer = io.BytesIO()
    joblib.dump(candidate.model, buffer)
    loaded = joblib.load(io.BytesIO(buffer.getvalue()))
    new = table.iloc[:3].copy()
    new["primary_category"] = "never_seen_in_training"  # serving must not fail on a new category
    new["customer_state"] = "AC"
    assert approaches.risk(loaded, new).between(0, 1).all()
    pd.testing.assert_series_equal(approaches.risk(loaded, table), approaches.risk(candidate.model, table))


def test_every_approach_handles_unknown_categories():
    table, labels, _ = synthetic(n=600)
    late = labels.set_index("order_id")["late"].astype(bool)
    new = table.iloc[:2].copy()
    new[["customer_state", "primary_category"]] = "unseen"
    for name in ("baseline", *approaches.CANDIDATE_APPROACHES):
        model = approaches.fit(name, table, late)
        assert approaches.risk(model, new).between(0, 1).all(), name


def test_orders_without_features_are_an_error(trained):
    table, labels, split, _ = trained
    with pytest.raises(ValueError, match="have no features"):
        fit_candidate(table.drop(index=split.validation[0]), labels, split)


def test_score_recomputes_on_the_given_cohort(trained):
    *_, candidate = trained
    assert score(candidate.model, candidate.cohort) == candidate.validation_metrics


def test_values_for_mlflow_cover_parameters_and_every_approach(trained):
    *_, candidate = trained
    params = candidate.run_params()
    assert params["approach"] == candidate.approach
    assert params["candidate_approaches"] == "logistic_regression,hist_gradient_boosting"
    assert params["train_n"] == "800"
    assert all(isinstance(value, str) for value in params.values())
    # hyperparameters of the model AND of its preprocessing
    assert any(key.startswith("hp.model.") for key in params)
    assert any(key.startswith("hp.preprocess.") for key in params)
    assert params["approaches.baseline.model.strategy"] == "prior"
    assert params["approaches.logistic_regression.model.C"] == "0.05"
    assert params["approaches.hist_gradient_boosting.model.learning_rate"] == "0.05"
    metrics_by_name = candidate.comparison_metrics()
    assert metrics_by_name["baseline.recall_at_10"] == candidate.approach_metrics["baseline"].recall_at_10
    assert {key.split(".")[0] for key in metrics_by_name} == {"baseline", "logistic_regression",
                                                            "hist_gradient_boosting"}


def test_hyperparameters_name_the_real_settings():
    table, labels, _ = synthetic(n=300)
    late = labels.set_index("order_id")["late"].astype(bool)
    lr = approaches.hyperparameters(approaches.fit("logistic_regression", table, late))
    assert lr["model.C"] == "0.05" and lr["preprocess.categorical.min_frequency"] == "20"
    hgb = approaches.hyperparameters(approaches.fit("hist_gradient_boosting", table, late))
    assert hgb["model.learning_rate"] == "0.05" and hgb["model.early_stopping"] == "False"


def test_unknown_approach_and_wrong_columns_are_refused():
    table, labels, _ = synthetic(n=200)
    late = labels.set_index("order_id")["late"].astype(bool)
    with pytest.raises(ValueError, match="unknown approach"):
        approaches.build("random_forest")
    with pytest.raises(ValueError, match="contract columns"):
        approaches.fit("logistic_regression", table[list(reversed(FEATURE_NAMES))], late)


def test_extended_history_features_train_and_predict_end_to_end():
    from promiseops import features

    table, labels, split = synthetic(n=600, seed=7)
    base_orders = pd.DataFrame({
        "order_id": labels["order_id"],
        "approved_at": labels["approved_at"],
        "promised_date": (labels["approved_at"] + pd.to_timedelta(table["promise_days"].to_numpy(), unit="D")).dt.date,
        "customer_state": table["customer_state"].to_numpy(),
    })
    items = pd.DataFrame({
        "order_id": labels["order_id"],
        "item_id": 1,
        "price": table["total_price"].to_numpy(),
        "freight": table["total_freight"].to_numpy(),
        "weight_g": table["total_weight_g"].to_numpy(),
        "category": table["primary_category"].to_numpy(),
        "seller_id": ["s_" + str(i % 15) for i in range(len(labels))],
        "seller_state": table["primary_seller_state"].to_numpy(),
    })
    payments = pd.DataFrame({
        "order_id": labels["order_id"],
        "sequence": 1,
        "payment_type": table["primary_payment_type"].to_numpy(),
        "installments": table["max_installments"].astype(int).to_numpy(),
        "value": table["payment_total"].to_numpy(),
    })
    labels_with_avail = labels.copy()
    labels_with_avail["label_available_at"] = labels_with_avail["approved_at"] + pd.Timedelta(days=10)

    ext = features.compute_features_with_history(
        base_orders, items, payments, labels_with_avail, freeze_at=CUTOFFS.train_end
    )
    assert list(ext.columns) == list(features.EXTENDED_FEATURE_NAMES)
    cand = fit_candidate(ext, labels_with_avail, split)
    assert cand.run_params()["approaches.logistic_regression.model.C"] == "0.05"
    assert approaches.risk(cand.model, ext.loc[list(split.validation)]).between(0, 1).all()
