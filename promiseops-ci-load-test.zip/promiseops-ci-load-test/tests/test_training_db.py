"""Worker train mode end to end (#15): ingested batches -> candidate -> gates -> bundle -> MLflow.

Real PostgreSQL and a REAL MLflow with a temporary SQLite store: nothing is sent to any server.
Skipped without PROMISEOPS_TEST_DATABASE_URL or without MLflow. DROPS the schema (fixture from
test_ingestion_db): use an EMPTY database whose name ends in "_test", never the one holding the real feed.
"""

import json
from pathlib import Path

import pytest
from test_ingestion_db import URL, conn  # noqa: F401  (pytest fixture)
from test_model_db import AS_OF, TRAIN_END, VALIDATION_END, history  # noqa: F401  (pytest fixture)

from promiseops import bundle as b
from promiseops import cohorts, record, registry, training, worker
from promiseops.model import BASELINE_MODEL_VERSION
from promiseops.tracking import TrackingConfig, create_client

pytestmark = pytest.mark.skipif(not URL, reason="PROMISEOPS_TEST_DATABASE_URL is not set")
mlflow = pytest.importorskip("mlflow")

COMMIT = "c" * 40
CUTOFFS = cohorts.Cutoffs(train_end=TRAIN_END, validation_end=VALIDATION_END, as_of=AS_OF)
MOCK_RELEASE = Path(__file__).resolve().parents[1] / "release"


@pytest.fixture
def tracking_uri(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)  # the SQLite backend writes artifacts under the current folder
    monkeypatch.setenv("MLFLOW_DISABLE_TELEMETRY", "true")
    return f"sqlite:///{(tmp_path / 'mlflow.db').as_posix()}"


@pytest.fixture
def client(tracking_uri):
    return create_client(TrackingConfig(tracking_uri))


def settings(tmp_path, incumbent=MOCK_RELEASE):
    return training.TrainingSettings(source_commit=COMMIT, artifacts=tmp_path / "artifacts", incumbent=incumbent)


def test_first_candidate_is_trained_compared_with_the_baseline_and_logged(tmp_path, history, client):  # noqa: F811
    database, _, val_ids = history
    result = training.run_train(database, client, settings(tmp_path), cutoffs=CUTOFFS)

    # gate: no trained champion yet (the mock has no record) -> the training-prevalence baseline
    assert result.decision.decision == "accepted", result.decision.reasons
    assert result.decision.champion_model_version == BASELINE_MODEL_VERSION
    assert result.decision.cohort_sha256 == cohorts.cohort_sha256(val_ids)

    # the bundle on disk is complete and describes this run
    loaded = b.read_bundle(result.bundle_path)
    assert loaded.reference is not None and loaded.lineage.mlflow_run_id == result.run_id
    assert loaded.lineage.dataset_identity.startswith("receipts-sha256:")
    assert loaded.lineage.gate_decision == "accepted"
    from promiseops.features import EXTENDED_FEATURE_NAMES

    assert tuple(loaded.manifest.feature_names) == EXTENDED_FEATURE_NAMES
    assert loaded.lineage.history_policy == "frozen-at-train-end-v1"
    assert result.record.mlflow_params()["history.smoothing"] == "20.0"
    assert result.record.mlflow_params()["history.knowledge_boundary"] == "strictly_before_approval"
    assert loaded.lineage.dataset_manifest_sha256 == b.sha256_file(result.bundle_path / "dataset_manifest.json")
    manifest = json.loads((result.bundle_path / "dataset_manifest.json").read_text())
    assert manifest["validation"]["order_ids_sha256"] == loaded.lineage.validation_cohort_sha256
    names = {artifact.path for artifact in client.list_artifacts(result.run_id)}
    assert {"sklearn-model", "model_signature.json", "input_example.json", "validation_diagnostics.json",
            "label_maturity.json", "model-card.md", "validation_reliability.png"} <= names

    # MLflow: finished run, the exact bundle stored and verified, every comparison value logged
    run = client.get_run(result.run_id)
    assert run.info.status == "FINISHED"
    assert record.load_logged_record(client, result.run_id) == result.record == record.load_record(result.bundle_path)
    params, metrics, tags = run.data.params, run.data.metrics, run.data.tags
    assert params["approach"] == loaded.lineage.approach and params["train_end"] == "2017-05-01T00:00:00Z"
    assert any(key.startswith("hp.model.") for key in params)
    assert {"baseline.recall_at_10", "logistic_regression.pr_auc", "champion.brier",
            "validation_recall_at_10"} <= set(metrics)
    assert tags[training.TAG_INCUMBENT] == "baseline-constant-v1"
    assert tags[record.TAG_GATE_DECISION] == "accepted"

    # registry (#20): accepted -> version 1, alias "candidate" on it, "production" untouched
    assert result.registry_version == "1"
    assert registry.alias_version(client, registry.ALIAS_CANDIDATE).artifact_sha256 == result.record.artifact_sha256
    assert registry.alias_version(client, registry.ALIAS_PRODUCTION) is None
    assert tags[training.TAG_REGISTRY_VERSION] == f"{registry.REGISTERED_MODEL}/1"


def test_previous_model_is_the_next_champion(tmp_path, history, client):  # noqa: F811
    database, *_ = history
    first = training.run_train(database, client, settings(tmp_path), cutoffs=CUTOFFS)
    second = training.run_train(database, client, settings(tmp_path, incumbent=first.bundle_path), cutoffs=CUTOFFS)

    assert second.run_id != first.run_id
    assert second.decision.champion_model_version == first.record.model_version
    # same data, same code: the champion is re-scored and the candidate equals it -> gates pass
    assert second.decision.champion_metrics == first.decision.candidate_metrics
    assert second.decision.decision == "accepted"
    assert (first.registry_version, second.registry_version) == ("1", "2")
    assert registry.alias_version(client, registry.ALIAS_CANDIDATE).version == "2"
    assert b.read_bundle(first.bundle_path).manifest == first.record.manifest  # incumbent left untouched


def test_failed_training_marks_the_run_failed_with_the_reason(tmp_path, history, client):  # noqa: F811
    database, *_ = history
    too_early = cohorts.Cutoffs(train_end="2017-04-20T00:00:00Z", validation_end=VALIDATION_END, as_of=AS_OF)
    with pytest.raises(cohorts.InsufficientCohort):
        training.run_train(database, client, settings(tmp_path), cutoffs=too_early)
    [run] = client.search_runs([client.get_experiment_by_name("promiseops-late-delivery").experiment_id])
    assert run.info.status == "FAILED"
    assert run.data.tags[training.TAG_ERROR].startswith("InsufficientCohort: train cohort is insufficient")
    assert client.search_registered_models() == []  # a failed run registers nothing


def test_worker_command_runs_the_whole_train_mode(tmp_path, history, tracking_uri, capsys):  # noqa: F811
    environ = {"PROMISEOPS_DATABASE_URL": URL, "MLFLOW_TRACKING_URI": tracking_uri, "CI_COMMIT_SHA": COMMIT,
               "PROMISEOPS_ARTIFACTS": str(tmp_path / "artifacts"), "PROMISEOPS_INCUMBENT": str(MOCK_RELEASE)}
    code = worker.main(["--mode", "train", "--train-end", TRAIN_END, "--validation-end", VALIDATION_END,
                        "--as-of", AS_OF], environ=environ)
    assert code == 0
    summary = json.loads(capsys.readouterr().out.strip().splitlines()[-1])
    assert summary["status"] == "ok" and summary["gate_decision"] == "accepted"
    assert summary["registry_version"] == "1"
    assert summary["model_version"].startswith(("logistic_regression-", "hist_gradient_boosting-"))
