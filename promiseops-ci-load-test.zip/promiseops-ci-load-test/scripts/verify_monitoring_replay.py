"""Exercise real API snapshots and monitor-train on an isolated copy of real data.

Requires the normal database, MLflow and source-commit environment variables.
Never use the original training/evaluation database: the database name must contain
``monitor_replay``. This small smoke cohort proves integration, not model quality.
"""

import argparse
import json
import os
from pathlib import Path
from unittest.mock import patch

from fastapi.testclient import TestClient
from psycopg.conninfo import conninfo_to_dict

from promiseops import api, bundle, db, prediction_history, tracking, worker


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", required=True, type=Path)
    parser.add_argument("--predicted-at", required=True)
    parser.add_argument("--as-of", required=True)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    url = os.environ["PROMISEOPS_DATABASE_URL"]
    if "monitor_replay" not in conninfo_to_dict(url).get("dbname", ""):
        raise ValueError("Only an isolated monitor_replay database is permitted")
    commit = tracking.source_commit_from_env(os.environ)
    loaded = bundle.read_bundle(args.bundle)
    args.output.mkdir(parents=True, exist_ok=False)
    with db.connect() as connection:
        db.apply_schema(connection)
        ids = [row[0] for row in connection.execute(
            "SELECT order_id FROM promiseops.order_releases WHERE released_at <= %s "
            "ORDER BY released_at DESC, order_id LIMIT 5", (args.predicted_at,)).fetchall()]
    if len(ids) != 5:
        raise ValueError("Expected five released real orders")
    os.environ.update(PROMISEOPS_RELEASE=str(args.bundle), PROMISEOPS_AS_OF=args.predicted_at,
                      PROMISEOPS_API_KEY="local-replay-verification")
    client = TestClient(api.create_app())
    assert client.get("/readyz").status_code == 200
    for number, oid in enumerate(ids):
        payload = {"order_id": oid, "request_id": f"verification-{args.output.name}-{number}"}
        response = client.post("/predict", headers={"X-API-Key": os.environ["PROMISEOPS_API_KEY"]}, json=payload)
        assert response.status_code == 200, response.text
        retry = client.post("/predict", headers={"X-API-Key": os.environ["PROMISEOPS_API_KEY"]}, json=payload)
        assert retry.json() == response.json()
    history = args.output / "predictions.jsonl"
    prediction_history.main(["--model-version", loaded.manifest.model_version,
                             "--as-of", args.as_of, "--output", str(history)])
    os.environ.update(PROMISEOPS_INCUMBENT=str(args.bundle), PROMISEOPS_PREDICTION_HISTORY=str(history),
                      PROMISEOPS_ARTIFACTS=str(args.output / "worker"))
    # A five-order smoke cohort must persist a report and suppress automatic fitting.
    with patch("promiseops.training.run_train", side_effect=AssertionError("Insufficient cohort must not fit")) as fit:
        result = worker.main(["--mode", "monitor-train", "--train-end", loaded.lineage.train_end.isoformat(),
                              "--validation-end", loaded.lineage.validation_end.isoformat(), "--as-of", args.as_of])
        assert result == 0
        assert fit.call_count == 0
    report = {"dataset_kind": "real_olist_isolated_local_replay", "source_commit": commit,
              "model_version": loaded.manifest.model_version, "model_sha256": loaded.manifest.artifact_sha256,
              "real_orders": len(ids), "api_requests_with_retries": 2 * len(ids), "training_calls": 0,
              "predicted_at": args.predicted_at, "as_of": args.as_of, "group_runtime_verified": False,
              "model_quality_evaluation": False, "history_sha256": bundle.sha256_file(history)}
    (args.output / "verification.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report))


if __name__ == "__main__":
    main()
