"""Comprehensive benchmark and ablation study under strict leakage & contract gate constraints.

Addressing all 6 peer-review items:
1. Synthetic Nature Disclosure: Clearly identified as a synthetic diagnostic exploration.
2. Identical Reference Baseline: C=0.05 engineered LR vs. unweighted vs. weighted LR (Ablation).
3. Batch-Invariant Ensemble: Uses BlendedProbabilityClassifier instead of batch ranks.
4. Contract-Compliant Top-K: Uses metrics.top_k and metrics.evaluate with tie-breaking.
5. Contract Gate Application: Applies promiseops.gates.apply_gates (Recall, PR-AUC, Brier).
6. Semantic Consistency: Validates customer/seller interstate logic.
"""

import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from promiseops import approaches, cohorts, gates, metrics
from promiseops.features import FEATURE_NAMES
from promiseops.recall_boost import (
    FORBIDDEN_LEAKAGE_COLUMNS,
    BlendedProbabilityClassifier,
    build_shallow_constrained_gbm,
    build_weighted_logistic_regression,
)

CUTOFFS = cohorts.Cutoffs(
    train_end="2017-12-31T23:59:59Z",
    validation_end="2018-02-28T23:59:59Z",
    as_of="2018-04-30T00:00:00Z",
)

def generate_semantically_consistent_cohort(n_train=25000, n_val=13377, seed=42):
    """Generates synthetic cohort with 100% semantic consistency between interstate and states."""
    rng = np.random.default_rng(seed)
    n_total = n_train + n_val
    ids = [f"order_{i:06d}" for i in range(n_total)]

    customer_state = rng.choice(["SP", "RJ", "MG", "BA", "RS", "PR"], p=[0.42, 0.15, 0.12, 0.10, 0.11, 0.10], size=n_total)
    seller_state = rng.choice(["SP", "PR", "SC", "RJ"], p=[0.60, 0.20, 0.10, 0.10], size=n_total)
    # Semantically exact interstate calculation
    interstate = (customer_state != seller_state).astype(float)

    promise_days = rng.integers(5, 45, n_total).astype(float)
    total_freight = rng.gamma(2.5, 12.0, n_total)
    total_price = rng.gamma(2.0, 65.0, n_total)
    total_weight = rng.gamma(2.0, 900.0, n_total)

    table = pd.DataFrame({
        "item_count": rng.integers(1, 4, n_total).astype(float),
        "seller_count": np.ones(n_total),
        "total_price": total_price,
        "total_freight": total_freight,
        "total_weight_g": total_weight,
        "payment_total": total_price + total_freight,
        "max_installments": rng.integers(1, 10, n_total).astype(float),
        "promise_days": promise_days,
        "approval_hour": rng.integers(0, 24, n_total).astype(float),
        "approval_weekday": rng.integers(0, 7, n_total).astype(float),
        "interstate_fraction": interstate,
        "customer_state": customer_state,
        "primary_seller_state": seller_state,
        "primary_category": rng.choice(["bed_bath_table", "health_beauty", "sports_leisure", "computers_accessories"], n_total),
        "primary_payment_type": rng.choice(["credit_card", "boleto", "voucher"], p=[0.75, 0.20, 0.05], size=n_total),
    }, index=pd.Index(ids, name="order_id"))[list(FEATURE_NAMES)]

    base_logit = (
        -8.18
        - 0.16 * (promise_days - 20.0)
        + 2.2 * interstate
        + 1.1 * (customer_state == "BA")
        + 0.9 * (customer_state == "RJ")
        + 0.6 * (total_freight / (promise_days + 1.0))
        + 0.5 * (interstate * (total_weight > 2000.0))
    )

    val_mask = np.arange(n_total) >= n_train
    logit = base_logit.copy()
    logit[val_mask] += 1.52

    prob = 1.0 / (1.0 + np.exp(-logit))
    late = rng.random(n_total) < prob

    train_ids = ids[:n_train]
    val_ids = ids[n_train:]
    split = cohorts.Split(cutoffs=CUTOFFS, train=tuple(train_ids), validation=tuple(val_ids))
    labels = pd.DataFrame({"order_id": ids, "late": pd.array(late, dtype="boolean")})
    return table, labels, split


def run_benchmark():
    print("=" * 85)
    print("PROMISEOPS: SYNTHETIC BENCHMARK & GATE DECISION AUDIT (REVIEW-REVISED)")
    print("NOTE: This benchmark runs on synthetic data for ablation analysis and gate diagnosis.")
    print("=" * 85)

    table, labels, split = generate_semantically_consistent_cohort(n_train=25000, n_val=13377, seed=42)
    train_table = table.loc[list(split.train)]
    val_table = table.loc[list(split.validation)]

    train_y = labels.set_index("order_id").loc[list(split.train), "late"].to_numpy().astype(bool)
    val_y = labels.set_index("order_id").loc[list(split.validation), "late"].to_numpy().astype(bool)
    val_ids = list(split.validation)

    n_val = len(val_y)
    n_late = int(val_y.sum())
    top_k_orders = metrics.top_k_size(n_val)

    print("Cohort Summary:")
    print(f"  Training Orders   : {len(train_y):,} (Late: {train_y.sum():,}, {train_y.mean():.2%})")
    print(f"  Validation Orders : {n_val:,} (Late: {n_late:,}, {val_y.mean():.2%})")
    print(f"  Top 10% Review Budget K: {top_k_orders:,} orders")
    print("-" * 85)

    # 1. Leakage & Semantic Consistency Audit
    leakage = set(table.columns).intersection(FORBIDDEN_LEAKAGE_COLUMNS)
    assert not leakage, f"Leakage detected: {leakage}"
    mismatches = ((table["customer_state"] != table["primary_seller_state"]) != (table["interstate_fraction"] == 1.0)).sum()
    assert mismatches == 0, f"Semantic interstate mismatches found: {mismatches}"
    print("[PASSED] Semantic consistency and approval-time contract verified.")

    # 2. Fit Reference Champion (Incumbent C=0.05 LR)
    champion_pipe = build_weighted_logistic_regression(class_weight=None, C=0.05)
    champion_pipe.fit(train_table, train_y)
    champion_risk = champion_pipe.predict_proba(val_table)[:, 1]
    champion_eval = metrics.evaluate(val_ids, val_y.tolist(), champion_risk.tolist())

    print(f"Champion Reference (Unweighted LR C=0.05): Recall={champion_eval.recall_at_10:.2%}, PR-AUC={champion_eval.pr_auc:.4f}, Brier={champion_eval.brier:.4f}")
    print("-" * 85)

    candidate_pipelines = {
        "1. Baseline (Constant Prior)": approaches.build("baseline"),
        "2. Incumbent Reference (Unweighted LR, C=0.05)": champion_pipe,
        "3. Balanced LR (class_weight='balanced')": build_weighted_logistic_regression(class_weight="balanced", C=0.05),
        "4. Cost-Sensitive LR (Weight 5.0x)": build_weighted_logistic_regression(class_weight={False: 1.0, True: 5.0}, C=0.05),
        "5. Constrained Shallow GBM (depth=2)": build_shallow_constrained_gbm(max_depth=2, min_samples_leaf=150, l2_reg=25.0, class_weight=None),
        "6. Balanced Shallow GBM (depth=2, balanced)": build_shallow_constrained_gbm(max_depth=2, min_samples_leaf=150, l2_reg=25.0, class_weight="balanced"),
    }

    results = []
    for name, pipe in candidate_pipelines.items():
        if name != "2. Incumbent Reference (Unweighted LR, C=0.05)":
            pipe.fit(train_table, train_y)
        risk = pipe.predict_proba(val_table)[:, 1]
        ev = metrics.evaluate(val_ids, val_y.tolist(), risk.tolist())

        # Exact contract top-k computation (resolving Item 4 review bug)
        chosen_ids = set(metrics.top_k(val_ids, risk.tolist(), top_k_orders))
        caught = sum(1 for oid, is_l in zip(val_ids, val_y) if is_l and oid in chosen_ids)

        gate_res = gates.apply_gates(ev, champion_eval)
        results.append({
            "name": name,
            "recall": ev.recall_at_10,
            "caught": caught,
            "pr_auc": ev.pr_auc,
            "brier": ev.brier,
            "gate_decision": gate_res.decision,
            "reasons": gate_res.reasons,
        })

    # Test Blended Probability Classifier (Item 3 review bug resolved)
    blended = BlendedProbabilityClassifier(
        model_a=candidate_pipelines["2. Incumbent Reference (Unweighted LR, C=0.05)"],
        model_b=candidate_pipelines["5. Constrained Shallow GBM (depth=2)"],
        alpha=0.65,
    )
    blended_risk = blended.predict_proba(val_table)[:, 1]
    blended_ev = metrics.evaluate(val_ids, val_y.tolist(), blended_risk.tolist())
    chosen_ids = set(metrics.top_k(val_ids, blended_risk.tolist(), top_k_orders))
    caught = sum(1 for oid, is_l in zip(val_ids, val_y) if is_l and oid in chosen_ids)
    gate_res = gates.apply_gates(blended_ev, champion_eval)
    results.append({
        "name": "7. Blended Pointwise Ensemble (65% LR + 35% GBM)",
        "recall": blended_ev.recall_at_10,
        "caught": caught,
        "pr_auc": blended_ev.pr_auc,
        "brier": blended_ev.brier,
        "gate_decision": gate_res.decision,
        "reasons": gate_res.reasons,
    })

    print(f"{'Model Strategy':<45} | {'Recall@10%':<11} | {'Caught':<9} | {'PR-AUC':<8} | {'Brier':<8} | {'Gate Verdict':<10}")
    print("-" * 95)
    for r in results:
        print(f"{r['name']:<45} | {r['recall']:>10.2%} | {r['caught']:>4d}/{n_late} | {r['pr_auc']:>8.4f} | {r['brier']:>8.4f} | {r['gate_decision']:<10}")
    print("=" * 95)

if __name__ == '__main__':
    run_benchmark()
