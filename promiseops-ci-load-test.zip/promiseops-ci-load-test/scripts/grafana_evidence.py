"""Check that the dashboard and team alert rules running in Grafana are the ones in deploy/grafana.

Read-only: three GETs against the Grafana HTTP API (the dashboard, the provisioned alert rules and
their current state). Every check must pass before the evidence file is written:

* the live dashboard ``promiseops-service`` equals ``deploy/grafana/promiseops-service.json``
  (Grafana's own ``id`` and ``version`` aside);
* the live rules in folder ``promiseops``, group ``promiseops-service`` are exactly the rules in
  ``deploy/grafana/alert-rules.yaml``, every field in the file equal (Grafana adds its own fields);
* the group is evaluated at the file's interval and every rule evaluates (health ``ok``/``nodata``).

The evidence records the commit the repo files come from, their SHA-256, the dashboard version and
each rule's current state::

    export GRAFANA_AUTH_HEADER='Cookie: _oauth2_proxy=<value from your signed-in browser>'
    python scripts/grafana_evidence.py --commit <commit of deploy/grafana> \\
        --auth-header-env GRAFANA_AUTH_HEADER --out reports/monitoring/grafana-live-<date>.json

``--responses FILE`` checks saved responses instead (``{"captured_at_utc": ..., "responses":
{path: body}}``, e.g. fetched from a signed-in browser). The auth header is sent only to
``--grafana`` and never printed or written. Needs PyYAML (in requirements.lock).
"""

import argparse
import hashlib
import json
import os
import sys
import urllib.request
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import yaml
from alert_evidence import COMMIT, parse_header, public_url

DEFAULT_GRAFANA = "https://g03-grafana.mlops.qbootcamp.ir"
DASHBOARD_UID = "promiseops-service"
FOLDER_UID = "promiseops"
DASHBOARD_FILE = "deploy/grafana/promiseops-service.json"
RULES_FILE = "deploy/grafana/alert-rules.yaml"
PATHS = {
    "dashboard": f"/api/dashboards/uid/{DASHBOARD_UID}",
    "rules": "/api/v1/provisioning/alert-rules",
    "states": "/api/prometheus/grafana/api/v1/rules",
}
GRAFANA_FIELDS = ("id", "version")   # set by Grafana on import, not part of the file
HEALTHY = {"ok", "nodata"}
ROOT = Path(__file__).resolve().parents[1]

Get = Callable[[str], Any]   # API path -> decoded JSON body


def http_get(base: str, headers: dict[str, str], timeout: float = 20) -> Get:
    """A ``Get`` for the Grafana HTTP API at ``base``."""

    def get(path: str) -> Any:
        request = urllib.request.Request(f"{base.rstrip('/')}{path}",
                                         headers={"Accept": "application/json", **headers})
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return json.load(response)

    return get


def saved_responses(path: Path) -> tuple[Get, str]:
    """A ``Get`` that serves saved responses, and the time they were captured."""
    saved = json.loads(path.read_text(encoding="utf-8"))
    return (lambda api_path: saved["responses"][api_path]), saved["captured_at_utc"]


def differences(want: Any, have: Any, where: str = "") -> list[str]:
    """Where ``have`` differs from ``want``; keys only in ``have`` (added by Grafana) are ignored."""
    if isinstance(want, dict):
        if not isinstance(have, dict):
            return [f"{where or '.'}: expected an object"]
        return [d for key, value in want.items()
                for d in ([f"{where}.{key}: missing"] if key not in have
                          else differences(value, have[key], f"{where}.{key}"))]
    if isinstance(want, list):
        if not isinstance(have, list) or len(want) != len(have):
            return [f"{where}: expected {len(want)} items"]
        return [d for i, (a, b) in enumerate(zip(want, have, strict=True))
                for d in differences(a, b, f"{where}[{i}]")]
    return [] if want == have else [f"{where}: {str(want)[:60]!r} != {str(have)[:60]!r}"]


def _seconds(interval: str) -> int:
    units = {"s": 1, "m": 60, "h": 3600}
    return int(interval[:-1]) * units[interval[-1]]


def checks(dashboard_file: dict[str, Any], rule_group: dict[str, Any], live: dict[str, Any]) -> list[dict[str, Any]]:
    """Every condition the evidence claims; all must pass before the file is written."""
    board = live["dashboard"]["dashboard"]
    file_core = {k: v for k, v in dashboard_file.items() if k not in GRAFANA_FIELDS}
    live_core = {k: v for k, v in board.items() if k not in GRAFANA_FIELDS}
    board_diff = differences(file_core, live_core) + [f".{k}: not in the file" for k in live_core
                                                     if k not in file_core]
    in_group = {r["uid"]: r for r in live["rules"]
                if r.get("folderUID") == FOLDER_UID and r.get("ruleGroup") == rule_group["name"]}
    rule_diff = [f"{r['uid']}{d}" for r in rule_group["rules"]
                 for d in (differences(r, in_group[r["uid"]]) if r["uid"] in in_group else [": missing"])]
    rule_diff += [f"{uid}: not in the file" for uid in in_group if uid not in {r["uid"] for r in rule_group["rules"]}]
    group_state = next((g for g in live["states"]["data"]["groups"] if g["name"] == rule_group["name"]), None)
    health = {r["uid"]: r["health"] for r in (group_state or {}).get("rules", [])}
    return [
        {"check": f"dashboard {DASHBOARD_UID} equals {DASHBOARD_FILE}", "ok": not board_diff,
         "detail": board_diff[:5] or f"{len(board['panels'])} panels, {len(board['templating']['list'])} variables"},
        {"check": f"rules in folder {FOLDER_UID}, group {rule_group['name']} equal {RULES_FILE}", "ok": not rule_diff,
         "detail": rule_diff[:5] or f"{len(in_group)} rules"},
        {"check": f"group evaluated every {rule_group['interval']}",
         "ok": group_state is not None and group_state["interval"] == _seconds(rule_group["interval"]),
         "detail": "group not evaluated" if group_state is None else f"interval {group_state['interval']} s"},
        {"check": "every rule evaluates", "ok": bool(health) and set(health) == set(in_group)
         and set(health.values()) <= HEALTHY, "detail": health},
    ]


def build_evidence(live: dict[str, Any], results: list[dict[str, Any]], *, rule_group: dict[str, Any],
                   source: str, captured_at: str, commit: str, files: dict[str, str]) -> dict[str, Any]:
    board, meta = live["dashboard"]["dashboard"], live["dashboard"]["meta"]
    group_state = next(g for g in live["states"]["data"]["groups"] if g["name"] == rule_group["name"])
    states = {r["uid"]: r for r in group_state["rules"]}
    return {
        "captured_at_utc": captured_at,
        "source": source,
        "repo": {"commit": commit, "files_sha256": files},
        "dashboard": {"uid": board["uid"], "title": board["title"], "version": board["version"],
                      "updated": meta.get("updated"), "folder": meta.get("folderTitle"), "url": meta.get("url"),
                      "panels": [[p["id"], p["type"], p["title"]] for p in board["panels"]],
                      "variables": [v["name"] for v in board["templating"]["list"]]},
        "rules": [{"uid": r["uid"], "title": r["title"], "for": r["for"], "severity": r["labels"].get("severity"),
                   "state": states[r["uid"]]["state"], "health": states[r["uid"]]["health"],
                   "instances": [a.get("state") for a in states[r["uid"]].get("alerts", [])],
                   "last_evaluation": states[r["uid"]].get("lastEvaluation")} for r in rule_group["rules"]],
        "checks": results,
    }


def parse_args(argv: list[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--commit", required=True, help="commit the deploy/grafana files come from")
    parser.add_argument("--out", required=True, type=Path, help="JSON file to write when all checks pass")
    parser.add_argument("--grafana", default=os.environ.get("PROMISEOPS_GRAFANA_URL", DEFAULT_GRAFANA))
    parser.add_argument("--auth-header-env", help="environment variable holding one 'Name: value' header")
    parser.add_argument("--responses", type=Path, help="check saved API responses instead of calling Grafana")
    parser.add_argument("--repo", type=Path, default=ROOT, help="repository root holding deploy/grafana")
    args = parser.parse_args(argv)
    if not COMMIT.match(args.commit):
        parser.error(f"not a 40-character commit SHA: {args.commit!r}")
    return args


def main(argv: list[str] | None = None, *, get: Get | None = None) -> int:
    args = parse_args(argv)
    if args.responses is not None:
        get, captured_at = saved_responses(args.responses)
        source = f"saved Grafana API responses ({args.responses.name}) from {public_url(args.grafana)} (read-only)"
    else:
        captured_at = datetime.now(UTC).isoformat().replace("+00:00", "Z")
        source = f"Grafana HTTP API at {public_url(args.grafana)} (read-only)"
        if get is None:
            headers = {}
            if args.auth_header_env:
                name, value = parse_header(os.environ.get(args.auth_header_env, ""))
                headers[name] = value
            get = http_get(args.grafana, headers)
    raw = {name: (args.repo / path).read_bytes() for name, path in (("dashboard", DASHBOARD_FILE),
                                                                    ("rules", RULES_FILE))}
    dashboard_file = json.loads(raw["dashboard"])
    [rule_group] = yaml.safe_load(raw["rules"])["groups"]
    live = {name: get(path) for name, path in PATHS.items()}
    results = checks(dashboard_file, rule_group, live)
    for item in results:
        print(f"{'ok  ' if item['ok'] else 'FAIL'} {item['check']}: {item['detail']}", file=sys.stderr)
    if not all(item["ok"] for item in results):
        print("not written: Grafana differs from deploy/grafana", file=sys.stderr)
        return 1
    files = {DASHBOARD_FILE: hashlib.sha256(raw["dashboard"]).hexdigest(),
             RULES_FILE: hashlib.sha256(raw["rules"]).hexdigest()}
    evidence = build_evidence(live, results, rule_group=rule_group, source=source, captured_at=captured_at,
                              commit=args.commit, files=files)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(evidence, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"wrote {args.out}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
