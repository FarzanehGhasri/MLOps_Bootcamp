"""Compare the saved frozen-history LR to the saved engineered LR on the same validation IDs."""

import argparse
import hashlib
import json
import os
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from mlflow import MlflowClient

from promiseops import bundle, features, metrics
from promiseops.paired_validation import recall_difference

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--history-run", required=True)
parser.add_argument("--reference-run", required=True)
parser.add_argument("--original-bundle", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
client = MlflowClient(tracking_uri=os.environ["MLFLOW_TRACKING_URI"])
reports = []
for fold in ("earlier", "current"):
    key = f"{fold}.frozen.logistic_regression"
    evidence = pd.read_parquet(client.download_artifacts(args.history_run, f"validation-evidence/{key}.parquet"))
    candidate = joblib.load(client.download_artifacts(args.history_run, f"experimental-pipelines/{key}.joblib"))
    risk = candidate.predict_proba(evidence.drop(columns=["late", "risk"]))[:, 1]
    np.testing.assert_array_equal(risk, evidence.risk.to_numpy())
    reference = joblib.load(client.download_artifacts(args.reference_run, f"experimental-pipelines/{fold}.engineered_lr.joblib"))
    refs = {"engineered_lr": reference}
    if fold == "current":
        refs["original_registered_lr"] = bundle.read_bundle(args.original_bundle).model
    for name, model in refs.items():
        ref_risk = model.predict_proba(evidence[list(features.FEATURE_NAMES)])[:, 1]
        cm = metrics.evaluate(evidence.index.tolist(), evidence.late.tolist(), risk.tolist())
        rm = metrics.evaluate(evidence.index.tolist(), evidence.late.tolist(), ref_risk.tolist())
        reports.append({"fold": fold, "reference": name, "candidate": cm.model_dump(),
                        "reference_metrics": rm.model_dump(), "recall_difference": cm.recall_at_10 - rm.recall_at_10,
                        "bootstrap": recall_difference(evidence.index, evidence.late, risk, ref_risk)})
report = {"history_run": args.history_run, "reference_run": args.reference_run, "comparisons": reports,
          "separate_process_pipeline_predictions_match_saved": True,
          "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          "test_used": False, "selection_adjusted": False}
text = json.dumps(report, indent=2)
args.output.write_text(text, encoding="utf-8")
client.log_text(args.history_run, text, "paired-validation-uncertainty.json")
print(text)
