"""Capture firing or resolved alert evidence from Prometheus as one JSON file for reports/monitoring/.

Read-only: it calls only the Prometheus HTTP API (``/api/v1/rules`` and instant queries). The output
has the same shape as ``reports/monitoring/apiunavailable-firing-2026-11-19.json``, plus the checks
that passed and the deployment it describes (commit, image digest, model version). The file is
written only when every check passes. With ``--wait`` the script polls every 15 s until they pass,
for example while the alert's ``for`` period runs out after a deploy.

Resolve evidence for APIUnavailable after a production deploy::

    export PROMETHEUS_AUTH_HEADER='Cookie: _oauth2_proxy=<value from your signed-in browser>'
    python scripts/alert_evidence.py --alert APIUnavailable --expect resolved \\
        --commit <deployed commit> --image-digest sha256:<deployed app digest> --wait 600 \\
        --out reports/monitoring/apiunavailable-resolved-<date>.json

Access: the team Prometheus is reached through the team Grafana datasource proxy (the default
``--prometheus``), which sits behind GitLab sign-in. ``--auth-header-env`` names an environment
variable holding one ``Name: value`` request header. It is sent only to ``--prometheus`` and is
never printed or written to the output. Python standard library only (no project install needed).
"""

import argparse
import json
import os
import re
import sys
import time
import urllib.parse
import urllib.request
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

DEFAULT_PROMETHEUS = "https://g03-grafana.mlops.qbootcamp.ir/api/datasources/proxy/uid/PBAB629F371D08AFE"
DEFAULT_JOB = "g03-production"
RULE_GROUP = "promiseops"
LOOKBACK = "30m"
POLL_SECONDS = 15
COMMIT = re.compile(r"^[0-9a-f]{40}$")
DIGEST = re.compile(r"^sha256:[0-9a-f]{64}$")
EXPECTED_STATE = {"firing": "firing", "resolved": "inactive"}

Get = Callable[[str, dict[str, str]], Any]   # (API path, query parameters) -> the response's "data"


def queries(alert: str, job: str) -> dict[str, str]:
    """The instant queries saved in the evidence, by role."""
    up = f'up{{job="{job}"}}'
    return {
        "up": up,
        "absent": f"absent({up})",
        "alerts": f'ALERTS{{alertname="{alert}"}}',
        "model_info": f'promiseops_model_info{{job="{job}"}} == 1',
        "ready": f'promiseops_ready{{job="{job}"}}',
    }


def parse_header(line: str) -> tuple[str, str]:
    """``"Name: value"`` -> ``("Name", "value")``."""
    name, separator, value = line.partition(":")
    if not separator or not name.strip() or not value.strip():
        raise ValueError("the auth header must look like 'Name: value'")
    return name.strip(), value.strip()


def public_url(url: str) -> str:
    """``url`` without user info, query or fragment, safe to write into the evidence."""
    parts = urllib.parse.urlsplit(url)
    host = parts.hostname or ""
    netloc = host if parts.port is None else f"{host}:{parts.port}"
    return urllib.parse.urlunsplit((parts.scheme, netloc, parts.path, "", ""))


def http_get(base: str, headers: dict[str, str], timeout: float = 20) -> Get:
    """A ``Get`` for the Prometheus HTTP API at ``base``."""

    def get(path: str, params: dict[str, str]) -> Any:
        url = f"{base.rstrip('/')}{path}?{urllib.parse.urlencode(params)}"
        request = urllib.request.Request(url, headers={"Accept": "application/json", **headers})
        with urllib.request.urlopen(request, timeout=timeout) as response:
            body = json.load(response)
        if body.get("status") != "success":
            raise RuntimeError(f"Prometheus {path} returned status {body.get('status')!r}")
        return body["data"]

    return get


def _vector(data: Any) -> list[dict[str, Any]]:
    return [{"metric": item["metric"], "value": item["value"]} for item in data["result"]]


def _iso(seconds: float) -> str:
    return datetime.fromtimestamp(seconds, UTC).isoformat().replace("+00:00", "Z")


def collect(get: Get, alert: str, job: str) -> dict[str, Any]:
    """Read the staff rule group, the instant queries and the recent ALERTS history."""
    groups = get("/api/v1/rules", {"type": "alert"})["groups"]
    group = next((g for g in groups if g["name"] == RULE_GROUP), None)
    rules = [] if group is None else [
        {"name": r["name"], "query": r["query"], "for_seconds": r.get("duration", 0),
         "state": r.get("state"), "alerts": r.get("alerts", [])}
        for r in group["rules"]]
    results = {query: _vector(get("/api/v1/query", {"query": query})) for query in queries(alert, job).values()}
    history = get("/api/v1/query", {"query": f'ALERTS{{alertname="{alert}"}}[{LOOKBACK}]'})["result"]
    firing = [float(ts) for series in history if series["metric"].get("alertstate") == "firing"
              for ts, _ in series["values"]]
    return {
        "staff_rule_group": None if group is None else {"name": group["name"], "file": group.get("file"),
                                                         "rules": rules},
        "queries": results,
        "lookback": {"query": f'ALERTS{{alertname="{alert}"}}[{LOOKBACK}]',
                     "last_firing_sample_at": _iso(max(firing)) if firing else None},
    }


def observed_state(snapshot: dict[str, Any], alert: str, job: str) -> str:
    """``firing``, ``pending`` or ``inactive``: the rule's state, or ALERTS when the rule is missing."""
    group = snapshot["staff_rule_group"]
    rule = None if group is None else next((r for r in group["rules"] if r["name"] == alert), None)
    if rule is not None and rule["state"]:
        return rule["state"]
    states = {item["metric"].get("alertstate") for item in snapshot["queries"][queries(alert, job)["alerts"]]}
    return "firing" if "firing" in states else "pending" if "pending" in states else "inactive"


def model_versions(snapshot: dict[str, Any], job: str) -> list[str]:
    """The model versions with ``promiseops_model_info == 1`` (one per pod image)."""
    series = snapshot["queries"][queries("", job)["model_info"]]
    return sorted({item["metric"].get("model_version", "") for item in series})


def checks(snapshot: dict[str, Any], *, alert: str, job: str, expect: str,
           model_version: str | None) -> list[dict[str, Any]]:
    """Every condition the evidence claims; all must pass before the file is written."""
    q = queries(alert, job)
    state = observed_state(snapshot, alert, job)
    result = [
        {"check": "staff rule group present", "ok": snapshot["staff_rule_group"] is not None,
         "detail": RULE_GROUP},
        {"check": f"{alert} is {EXPECTED_STATE[expect]}", "ok": state == EXPECTED_STATE[expect],
         "detail": f"observed {state}"},
    ]
    if expect == "resolved":
        alerts = snapshot["queries"][q["alerts"]]
        result.append({"check": "no ALERTS series", "ok": not alerts, "detail": f"{len(alerts)} series"})
        if alert == "APIUnavailable":
            up = snapshot["queries"][q["up"]]
            values = [item["value"][1] for item in up]
            result.append({"check": "every API target is up", "ok": bool(values) and set(values) == {"1"},
                           "detail": f"up values {values}"})
            result.append({"check": "absent(up) is empty", "ok": not snapshot["queries"][q["absent"]],
                           "detail": q["absent"]})
    if model_version is not None:
        served = model_versions(snapshot, job)
        result.append({"check": "served model version", "ok": served == [model_version],
                       "detail": f"promiseops_model_info shows {served}"})
    return result


def build_evidence(snapshot: dict[str, Any], results: list[dict[str, Any]], *, alert: str, job: str,
                   expect: str, prometheus: str, captured_at: datetime, commit: str | None,
                   image_digest: str | None, model_version: str | None) -> dict[str, Any]:
    return {
        "captured_at_utc": captured_at.isoformat().replace("+00:00", "Z"),
        "source": f"Prometheus HTTP API at {public_url(prometheus)} (read-only)",
        "alert": alert,
        "job": job,
        "expected": expect,
        "observed_state": observed_state(snapshot, alert, job),
        "deployment": {"commit": commit, "image_digest": image_digest, "model_version": model_version,
                       "served_model_versions": model_versions(snapshot, job)},
        "checks": results,
        **snapshot,
    }


def capture(get: Get, *, alert: str, job: str, expect: str, model_version: str | None, wait: float,
            sleep: Callable[[float], None] = time.sleep,
            clock: Callable[[], float] = time.monotonic) -> tuple[dict[str, Any], list[dict[str, Any]], bool]:
    """Poll until every check passes or ``wait`` seconds have passed; returns the last snapshot."""
    deadline = clock() + wait
    while True:
        snapshot = collect(get, alert, job)
        results = checks(snapshot, alert=alert, job=job, expect=expect, model_version=model_version)
        if all(item["ok"] for item in results) or clock() >= deadline:
            return snapshot, results, all(item["ok"] for item in results)
        sleep(POLL_SECONDS)


def _pattern(regex: re.Pattern[str], what: str) -> Callable[[str], str]:
    def check(value: str) -> str:
        if not regex.match(value):
            raise argparse.ArgumentTypeError(f"not a {what}: {value!r}")
        return value
    return check


def parse_args(argv: list[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--alert", required=True, help="staff alert name, e.g. APIUnavailable")
    parser.add_argument("--expect", required=True, choices=sorted(EXPECTED_STATE))
    parser.add_argument("--out", required=True, type=Path, help="JSON file to write when all checks pass")
    parser.add_argument("--job", default=DEFAULT_JOB)
    parser.add_argument("--prometheus", default=os.environ.get("PROMISEOPS_PROMETHEUS_URL", DEFAULT_PROMETHEUS))
    parser.add_argument("--auth-header-env", help="environment variable holding one 'Name: value' header")
    parser.add_argument("--commit", type=_pattern(COMMIT, "40-character commit SHA"))
    parser.add_argument("--image-digest", type=_pattern(DIGEST, "sha256: image digest"))
    parser.add_argument("--model-version", help="fail unless promiseops_model_info shows exactly this version")
    parser.add_argument("--wait", type=float, default=0, help="seconds to keep polling until the checks pass")
    args = parser.parse_args(argv)
    if args.expect == "resolved" and (args.commit is None or args.image_digest is None):
        parser.error("--expect resolved needs --commit and --image-digest of the deployment it describes")
    return args


def main(argv: list[str] | None = None, *, get: Get | None = None,
         sleep: Callable[[float], None] = time.sleep) -> int:
    args = parse_args(argv)
    if get is None:
        headers = {}
        if args.auth_header_env:
            name, value = parse_header(os.environ.get(args.auth_header_env, ""))
            headers[name] = value
        get = http_get(args.prometheus, headers)
    snapshot, results, passed = capture(get, alert=args.alert, job=args.job, expect=args.expect,
                                        model_version=args.model_version, wait=args.wait, sleep=sleep)
    for item in results:
        print(f"{'ok  ' if item['ok'] else 'FAIL'} {item['check']}: {item['detail']}", file=sys.stderr)
    if not passed:
        print(f"not written: {args.alert} is not {args.expect} yet", file=sys.stderr)
        return 1
    evidence = build_evidence(snapshot, results, alert=args.alert, job=args.job, expect=args.expect,
                              prometheus=args.prometheus, captured_at=datetime.now(UTC), commit=args.commit,
                              image_digest=args.image_digest, model_version=args.model_version)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(evidence, indent=2) + "\n", encoding="utf-8")
    print(f"wrote {args.out}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
