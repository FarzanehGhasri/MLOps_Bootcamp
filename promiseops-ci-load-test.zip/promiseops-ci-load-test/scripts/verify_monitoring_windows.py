"""Record two real-data batch replay windows, then persist early/later monitoring reports.

Only an isolated monitor_replay database is permitted. This exercises shared
release features, fitted preprocessing and snapshot storage; it is not an API load
test, production traffic, new model training or an unbiased final evaluation.
"""

import argparse
import json
import os
from datetime import timedelta
from pathlib import Path

from psycopg.conninfo import conninfo_to_dict

from promiseops import approaches, bundle, db, inference, monitor_train, prediction_history, tracking
from promiseops.contracts import instant


def record_window(connection, loaded, *, at, count, prefix):
    """Select recent released orders without an outcome known at prediction time.

    Selection never uses later label values or eventual delivery times. Fixed
    deterministic ordering and sample size are demonstration choices, not tuning.
    """
    ids = [row[0] for row in connection.execute(
        """SELECT o.order_id FROM promiseops.orders o
           JOIN promiseops.order_releases r USING (order_id)
           WHERE r.released_at <= %(at)s AND o.approved_at <= %(at)s
             AND o.approved_at > %(start)s
             AND NOT EXISTS (SELECT 1 FROM promiseops.outcomes x
                             WHERE x.order_id=o.order_id AND x.available_at <= %(at)s)
             AND NOT EXISTS (SELECT 1 FROM promiseops.predictions p
                             WHERE p.order_id=o.order_id AND p.model_version=%(version)s)
           ORDER BY o.approved_at DESC, o.order_id LIMIT %(count)s""",
        {"at": at, "start": at - timedelta(days=7), "count": count,
         "version": loaded.manifest.model_version},
    ).fetchall()]
    if len(ids) != count:
        raise ValueError(f"Need {count} eligible new orders, found {len(ids)}")
    table = inference.release_features(connection, ids, as_of=at,
                                       manifest=loaded.manifest, lineage=loaded.lineage)
    table = table.loc[ids, loaded.manifest.feature_names]
    risk = approaches.risk(loaded.model, table)
    for number, (oid, probability) in enumerate(zip(ids, risk, strict=True)):
        request_id = f"{prefix}-{number}"
        connection.execute(
            "INSERT INTO promiseops.predictions (request_id,order_id,risk_probability,model_version) "
            "VALUES (%s,%s,%s,%s)",
            (request_id, oid, float(probability), loaded.manifest.model_version),
        )
        prediction_history.record_snapshot(
            connection, request_id=request_id, predicted_at=at, feature_row=table.loc[[oid]],
            artifact_sha256=loaded.manifest.artifact_sha256,
        )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", type=Path, required=True)
    parser.add_argument("--previous-at", type=instant, required=True)
    parser.add_argument("--current-at", type=instant, required=True)
    parser.add_argument("--as-of", type=instant, required=True)
    parser.add_argument("--later-as-of", type=instant, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--orders-per-window", type=int, default=100)
    args = parser.parse_args()
    if "monitor_replay" not in conninfo_to_dict(os.environ["PROMISEOPS_DATABASE_URL"]).get("dbname", ""):
        raise ValueError("Only an isolated monitor_replay database is permitted")
    loaded = bundle.read_bundle(args.bundle)
    if loaded.lineage is None or loaded.reference is None:
        raise ValueError("A trained incumbent with lineage/reference is required")
    if not (loaded.lineage.as_of <= args.previous_at < args.current_at <= args.as_of < args.later_as_of):
        raise ValueError("Prediction windows must follow model availability and precede evaluation")
    if not (args.as_of - timedelta(days=14) < args.previous_at <= args.as_of - timedelta(days=7)
            < args.current_at and args.orders_per_window >= 100):
        raise ValueError("Require >=100 new orders in each distinct seven-day window")
    commit = tracking.source_commit_from_env()
    if commit is None:
        raise ValueError("CI_COMMIT_SHA is required for replay provenance")
    args.output.mkdir(parents=True, exist_ok=False)
    with db.connect() as connection:
        db.apply_schema(connection)
        count = connection.execute("SELECT count(*) FROM promiseops.predictions").fetchone()[0]
        if count:
            raise ValueError("Use a fresh isolated replay database with no predictions")
    for name, at in (("previous", args.previous_at), ("current", args.current_at)):
        with db.connect() as connection:
            record_window(connection, loaded, at=at, count=args.orders_per_window,
                          prefix=f"{args.output.name}-{name}")
    with db.connect() as connection:
        rows = prediction_history.export_history(connection, model_version=loaded.manifest.model_version,
                                                  as_of=args.as_of)
    history = args.output / "predictions.jsonl"
    history.write_text("".join(json.dumps(row, sort_keys=True, allow_nan=False) + "\n" for row in rows),
                       encoding="utf-8")
    client = tracking.create_client(tracking.TrackingConfig.from_env())
    results = []
    for phase, at in (("two_windows", args.as_of), ("later_labels", args.later_as_of)):
        with db.connect() as connection:
            record = monitor_train.assess(connection, loaded, as_of=at, prediction_history=history)
        experiment = tracking.ensure_experiment(client, monitor_train.MONITORING_EXPERIMENT)
        run_id = client.create_run(experiment, tags=tracking.run_tags("monitor", commit),
                                   run_name=f"replay-{phase}-{at:%Y%m%d}").info.run_id
        try:
            monitor_train.persist_record(client, run_id, record)
            client.set_tag(run_id, "promiseops.replay_only", "true")
            client.set_terminated(run_id, "FINISHED")
            if client.get_run(run_id).info.status != "FINISHED":
                raise ValueError("Monitoring FINISHED status did not read back")
        except BaseException as error:
            tracking.close_failed_run(client, run_id, error)
            raise
        # Keep the downloaded server copy, not only the in-memory record.
        saved = Path(client.download_artifacts(run_id, monitor_train.MONITORING_FILE, str(args.output / phase)))
        results.append({"phase": phase, "run_id": run_id, "record": json.loads(saved.read_text()),
                        "record_sha256": bundle.sha256_file(saved)})
    summary = {"dataset_kind": "real_olist_isolated_batch_replay", "source_commit": commit,
               "model_version": loaded.manifest.model_version, "model_sha256": loaded.manifest.artifact_sha256,
               "history_sha256": bundle.sha256_file(history), "predictions_recorded": len(rows),
               "group_runtime_verified": False, "training_calls": 0, "production_changed": False,
               "selection": "latest released approvals in previous seven days, no label known at prediction",
               "model_quality_evaluation_scope": "selected pending-order replay; not final-test evaluation",
               "phases": results}
    (args.output / "verification.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps({"predictions_recorded": len(rows), "monitoring_runs": [r["run_id"] for r in results]}))


if __name__ == "__main__":
    main()
