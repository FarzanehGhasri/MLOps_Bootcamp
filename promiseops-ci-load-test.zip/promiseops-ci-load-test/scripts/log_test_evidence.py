"""Upload a pytest JUnit result and log to MLflow without training or changing aliases."""

import argparse
import hashlib
import json
import os
import xml.etree.ElementTree as ET
from pathlib import Path

from promiseops import experiment_log, tracking


def read_log(path):
    raw = path.read_bytes()
    # Windows PowerShell redirection writes UTF-16; container stdout logs usually use UTF-8.
    encoding = "utf-16" if raw.startswith((b"\xff\xfe", b"\xfe\xff")) else "utf-8-sig"
    return raw.decode(encoding)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    commit = tracking.source_commit_from_env(os.environ)
    if commit is None:
        raise ValueError("CI_COMMIT_SHA required: identify the code that produced these test files")
    cases = list(ET.parse(args.junit).getroot().iter("testcase"))
    if not cases:
        raise ValueError("refusing a test report without collected tests")
    counts = {key: sum(case.find(key) is not None for case in cases) for key in ("failure", "error", "skipped")}
    counts["passed"] = len(cases) - sum(counts.values())
    counts["collected"] = len(cases)
    report = {"kind": "software-regression-tests", "dataset_kind": "synthetic_test_fixtures",
              "source_commit": commit, "counts": counts, "real_data_metrics": False,
              "junit_sha256": hashlib.sha256(args.junit.read_bytes()).hexdigest(),
              "log_sha256": hashlib.sha256(args.log.read_bytes()).hexdigest(),
              "source_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                                for p in sorted(Path("src/promiseops").glob("*.py"))}}
    client = tracking.create_client(tracking.TrackingConfig.from_env(os.environ))
    successful = counts["failure"] == counts["error"] == 0
    run_id = experiment_log.log_report(
        client, experiment="promiseops-software-tests", kind="regression-tests", source_commit=commit,
        report=report, params={"real_data_metrics": "false"}, metrics=counts,
        artifacts={"pytest.log": read_log(args.log),
                   "junit.xml": args.junit.read_text(encoding="utf-8")}, successful=successful)
    args.output.write_text(json.dumps({**report, "mlflow_run_id": run_id}, indent=2), encoding="utf-8")
    print(json.dumps({"mlflow_run_id": run_id, "counts": counts}))
    return 0 if successful else 1


if __name__ == "__main__":
    raise SystemExit(main())
