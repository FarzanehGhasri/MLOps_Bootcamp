"""Train an isolated registry candidate, then verify its real-data API probabilities.

Run inside the project environment with PYTHONPATH=src, database and MLflow variables set.
The isolated SQLite registry does not move any existing tracking server aliases.
"""

import hashlib
import json
import os
import uuid
from pathlib import Path

import numpy as np
from fastapi.testclient import TestClient
from mlflow import MlflowClient

from promiseops import api, bundle, cohorts, db, experiment_log, inference, metrics, tracking, training

commit = tracking.source_commit_from_env(os.environ)
if commit is None:
    raise ValueError("CI_COMMIT_SHA required")
source_hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                 for p in sorted(Path("src/promiseops").glob("*.py"))}
folder = Path("/app/artifacts") / f"integration32-{uuid.uuid4().hex}"
folder.mkdir()
isolated_uri = f"sqlite:///{folder / 'mlflow.db'}"
isolated = MlflowClient(tracking_uri=isolated_uri, registry_uri=isolated_uri)
settings = training.TrainingSettings(source_commit=commit, artifacts=folder,
                                      incumbent=Path("/app/release"), experiment="integration32-training")
cutoffs = cohorts.Cutoffs(train_end="2017-12-31T23:59:59Z", validation_end="2018-02-28T23:59:59Z",
                          as_of="2018-04-30T00:00:00Z")
with db.connect() as connection:
    connection.execute("SET default_transaction_read_only=on")
    result = training.run_train(connection, isolated, settings, cutoffs=cutoffs)
    print(json.dumps({"stage": "training_finished", "run_id": result.run_id}), flush=True)
    loaded = bundle.read_bundle(result.bundle_path)
    labels = cohorts.load_labels(connection, as_of=cutoffs.as_of)
    ids = cohorts.split(labels, cutoffs).validation
    table = inference.release_features(connection, ids, as_of=cutoffs.as_of,
                                       manifest=loaded.manifest, lineage=loaded.lineage)
    risk = loaded.model.predict_proba(table)[:, 1]
    y = labels.set_index("order_id").late.loc[table.index].astype(bool)
    observed_metrics = metrics.evaluate(table.index.tolist(), y.tolist(), risk.tolist())
    for key, value in observed_metrics.model_dump().items():
        assert abs(value - loaded.lineage.validation_metrics.model_dump()[key]) < 1e-12
os.environ["PROMISEOPS_RELEASE"] = str(result.bundle_path)
os.environ["PROMISEOPS_AS_OF"] = cutoffs.as_of.isoformat()
os.environ["PROMISEOPS_API_KEY"] = uuid.uuid4().hex
client = TestClient(api.create_app())
assert client.get("/readyz").status_code == 200
sample_ids = list(table.index[:20])
responses = []
for oid in sample_ids:
    response = client.post("/predict", headers={"X-API-Key": os.environ["PROMISEOPS_API_KEY"]},
                           json={"order_id": oid})
    assert response.status_code == 200, response.text
    responses.append(response.json()["risk_probability"])
    print(json.dumps({"stage": "api_checked", "count": len(responses)}), flush=True)
np.testing.assert_allclose(responses, loaded.model.predict_proba(table.loc[sample_ids])[:, 1], rtol=0, atol=1e-12)
unknown = client.post("/predict", headers={"X-API-Key": os.environ["PROMISEOPS_API_KEY"]},
                       json={"order_id": "nonexistent-order"})
assert unknown.status_code == 404
report = {"dataset_kind": "real_olist", "phase": "train-validation-api-integration", "test_used": False,
          "production_changed": False, "existing_server_aliases_changed": False,
          "isolated_training_registry": isolated_uri, "training_run_id": result.run_id,
          "bundle": str(result.bundle_path), "model_version": result.record.model_version,
          "artifact_sha256": result.record.artifact_sha256, "schema_columns": len(loaded.manifest.feature_names),
          "history_policy": loaded.lineage.history_policy, "gate": result.decision.decision,
          "dataset_manifest_sha256": loaded.lineage.dataset_manifest_sha256,
          "validation": observed_metrics.model_dump(), "api_real_orders_checked": len(sample_ids),
          "api_pipeline_probabilities_match": True, "unknown_order_status": unknown.status_code,
          "base_commit": commit, "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          "source_sha256": source_hashes,
          "software_versions": bundle.collect_software_versions()}
main = MlflowClient(tracking_uri=os.environ["MLFLOW_TRACKING_URI"])
assert source_hashes == {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                         for p in sorted(Path("src/promiseops").glob("*.py"))}, "Source changed during verification"
run_id = experiment_log.log_report(main, experiment="promiseops-serving-integration", kind="serving-integration",
                                   source_commit=commit, report=report, params={"test_used": "false"},
                                   metrics=observed_metrics.model_dump())
report["integration_report_run_id"] = run_id
training_artifacts = isolated.download_artifacts(result.run_id, "")
main.log_artifacts(run_id, training_artifacts, artifact_path="training-evidence")
path = Path(os.environ.get("PROMISEOPS_VERIFICATION_REPORT", "/app/artifacts/integration32-real-data-2026-11-16.json"))
path.write_text(json.dumps(report, indent=2), encoding="utf-8")
print(json.dumps(report, indent=2))
