"""Training DAGs: submit the queued worker Job via the company gateway.

One factory, two DAGs (same gateway contract, different mode):

    promiseops_training        triggered by the ingestion asset; mode=train
    promiseops_monitor_train   weekly; mode=monitor-train (report first, fit only if recommended)

No fit call happens in the scheduler: the DAG resolves cutoffs, records the
dataset identity as lineage, and POSTs /training with a request_id hashed from
the DagRun identity (retries reuse it; a new run gets a new one — CONTRACTS.md).
The 202 response means submitted, not completed: observe the Job in your own
jobs namespace.
"""

from __future__ import annotations

import json
from datetime import UTC, datetime, timedelta

import promiseops_gateway as gateway
from airflow.sdk import Param, dag, task
from ingest import INGESTED_ASSET


def _company_as_of(params, context):
    if params.get("as_of"):
        return params["as_of"], "explicit"
    events = context.get("triggering_asset_events") or {}
    try:
        events = events.get(INGESTED_ASSET.uri, [])
    except TypeError:
        # Airflow 3.1+ keys triggering_asset_events by Asset objects, not URI strings.
        events = events.get(INGESTED_ASSET, [])
    if events:
        return gateway.event_as_of(events), "triggering_ingestion"
    inlet = context.get("inlet_events")
    if inlet is None:
        raise ValueError("Company as_of is required: supply it explicitly or consume an ingestion event")
    history = inlet[INGESTED_ASSET]
    if not history:
        raise ValueError("No successful ingestion event; company as_of is unknown")
    return gateway.event_as_of([history[-1]]), "latest_ingestion"


def _build_training_dag(*, dag_id: str, schedule, mode: str, description: str):
    @dag(
        dag_id=dag_id,
        schedule=schedule,
        start_date=datetime(2026, 11, 18, tzinfo=UTC),
        catchup=False,
        max_active_runs=1,
        params={
            "as_of": Param(None, type=["null", "string"], format="date-time",
                           description="Company cutoff; default: successful ingestion event metadata"),
            "train_end": Param(None, type=["null", "string"], format="date-time",
                               description="Reviewed split; default: Variable promiseops_training_cutoffs"),
            "validation_end": Param(None, type=["null", "string"], format="date-time"),
            "image": Param(
                None,
                type=["null", "string"],
                description="worker image ref; default: Variable promiseops_worker_image",
            ),
            "source_commit": Param(
                None,
                type=["null", "string"],
                description="40-hex commit of the image; default: Variable promiseops_worker_commit",
            ),
        },
        tags=["promiseops", "training"],
        description=description,
    )
    def pipeline():
        @task(inlets=[INGESTED_ASSET])
        def resolve_cutoffs(**context):
            params = context["params"]
            as_of, source = _company_as_of(params, context)
            cutoffs = gateway.training_cutoffs(params, as_of)
            worker = gateway.worker_reference(params)
            identity = gateway.run_cli(["dataset-identity", "--as-of", cutoffs["as_of"]])
            if identity.returncode != 0:
                raise RuntimeError(f"dataset-identity failed: {identity.stderr[-500:]}")
            lineage = json.loads(identity.stdout)
            print(json.dumps({"event": "training_lineage", "mode": mode, **cutoffs, **worker,
                              "as_of_source": source,
                              "dataset_identity": lineage["dataset_identity"]}, sort_keys=True))
            return cutoffs | worker | {"dataset_identity": lineage["dataset_identity"]}

        @task(retries=2, retry_delay=timedelta(minutes=5))
        def submit_job(cutoffs: dict, **context):
            dag_run = context["dag_run"]
            payload = {
                "image": cutoffs["image"],
                "source_commit": cutoffs["source_commit"],
                "train_end": cutoffs["train_end"],
                "validation_end": cutoffs["validation_end"],
                "as_of": cutoffs["as_of"],
                "mode": mode,
                "request_id": gateway.request_id_for(dag_run.dag_id, dag_run.run_id),
            }
            job = gateway.submit_training(payload)
            print(json.dumps({"event": "training_submitted", "mode": mode, **payload, "job": job},
                             sort_keys=True))
            return {"request_id": payload["request_id"], "mode": mode, "as_of": cutoffs["as_of"], "job": job}

        submit_job(resolve_cutoffs())

    return pipeline()


training_dag = _build_training_dag(
    dag_id="promiseops_training",
    schedule=[INGESTED_ASSET],
    mode="train",
    description="Queued candidate training after ingestion (gateway POST /training, mode=train)",
)
monitor_train_dag = _build_training_dag(
    dag_id="promiseops_monitor_train",
    schedule="@weekly",
    mode="monitor-train",
    description="Maturity-aware monitoring/retraining (gateway POST /training, mode=monitor-train)",
)
