"""Company gateway client used by the Airflow DAGs (docs/CONTRACTS.md).

Only this module talks to the gateway: ``GET /feed`` (replay-controlled
ingestion) and ``POST /training`` (queued worker submission). It depends on the
standard library only, so it is importable and testable without Airflow; the
Airflow Variables are read lazily inside the functions that need them.

Configuration (platform-provided environment, never in Git):

    COMPANY_GATEWAY_URL        gateway base URL, e.g. https://gateway.../ (no /feed suffix)
    COMPANY_FEED_KEY           team bearer key for /feed and /training
    COMPANY_DATABASE_URL       own-team PostgreSQL for the promiseops CLI
    promiseops_worker_image   digest-pinned worker image for POST /training
    promiseops_worker_commit  40-hex commit the worker image was built from
    promiseops_company_as_of  explicit company-time replay cutoff for scheduled ingestion
    promiseops_training_cutoffs  JSON with reviewed train_end and validation_end
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import urllib.error
import urllib.parse
import urllib.request
from collections.abc import Mapping
from datetime import datetime
from pathlib import Path

# Platform-provided environment (staff-declared names).
ENV_GATEWAY_URL = "COMPANY_GATEWAY_URL"
ENV_FEED_KEY = "COMPANY_FEED_KEY"
ENV_DATABASE_URL = "COMPANY_DATABASE_URL"
VARIABLE_WORKER_IMAGE = "promiseops_worker_image"
VARIABLE_WORKER_COMMIT = "promiseops_worker_commit"
VARIABLE_COMPANY_AS_OF = "promiseops_company_as_of"
VARIABLE_TRAINING_CUTOFFS = "promiseops_training_cutoffs"


class GatewayError(RuntimeError):
    """The gateway refused or misbehaved on one of our requests."""


def variable(name: str) -> str:
    """Read an Airflow Variable (lazily: this module must import without Airflow)."""
    from airflow.sdk import Variable

    return Variable.get(name)


def request_id_for(dag_id: str, run_id: str) -> str:
    """Request ID derived from the DagRun identity.

    The gateway deduplicates by request_id: retries of the same DagRun reuse it
    (same hash), a new scheduled run gets a new one (CONTRACTS.md, "Queued
    worker interface"). Hex is inside the allowed 1-128 alphanumeric characters.
    """
    return hashlib.sha256(f"{dag_id}:{run_id}".encode()).hexdigest()[:32]


def validate_cutoffs(*, train_end: str, validation_end: str, as_of: str) -> None:
    """Fail fast locally on the rule the gateway enforces: train_end < validation_end <= as_of."""
    train, validation, cutoff = (_parse_instant(v) for v in (train_end, validation_end, as_of))
    if not (train < validation <= cutoff):
        raise ValueError(
            f"cutoffs must satisfy train_end < validation_end <= as_of; got "
            f"{train_end!r} < {validation_end!r} <= {as_of!r}"
        )


def _parse_instant(value: str) -> datetime:
    if not isinstance(value, str):
        raise TypeError("company cutoff must be an aware ISO timestamp string")
    parsed = datetime.fromisoformat(value)
    if parsed.tzinfo is None:
        raise ValueError(f"{value!r}: timezone-aware timestamp required")
    return parsed


def ingestion_as_of(params: Mapping) -> str:
    """Company replay time is explicit configuration, never the scheduler wall clock."""
    value = params.get("as_of") or variable(VARIABLE_COMPANY_AS_OF)
    _parse_instant(value)
    return value


def event_as_of(events) -> str:
    """Queued ingestion events can be coalesced; use their latest declared company cutoff."""
    values = []
    for event in events:
        if not isinstance(event.extra, Mapping) or not event.extra.get("as_of"):
            raise ValueError("Ingestion event has no company as_of metadata; rerun the updated ingestion DAG")
        values.append(event.extra["as_of"])
    if not values:
        raise ValueError("No ingestion event with company as_of; supply an explicit replay cutoff")
    return max(values, key=_parse_instant)


def training_cutoffs(params: Mapping, as_of: str) -> dict:
    """Use a reviewed split from params or one nonsecret JSON Airflow Variable."""
    plan = {}
    if not all(params.get(name) for name in ("train_end", "validation_end")):
        try:
            plan = json.loads(variable(VARIABLE_TRAINING_CUTOFFS))
        except (KeyError, ValueError, TypeError):
            raise ValueError(f"Set train_end/validation_end or JSON Variable {VARIABLE_TRAINING_CUTOFFS}") from None
        if not isinstance(plan, dict) or set(plan) != {"train_end", "validation_end"}:
            raise ValueError("training cutoff Variable must contain exactly train_end and validation_end")
    cutoffs = {name: params.get(name) or plan[name] for name in ("train_end", "validation_end")}
    cutoffs["as_of"] = as_of
    validate_cutoffs(**cutoffs)
    return cutoffs


def worker_reference(params: Mapping) -> dict:
    """Resolve once per run; retrying submission must not pick up changed Variables."""
    image = params.get("image") or variable(VARIABLE_WORKER_IMAGE)
    commit = params.get("source_commit") or variable(VARIABLE_WORKER_COMMIT)
    if not isinstance(image, str) or not re.fullmatch(r"[^\s@]+@sha256:[0-9a-f]{64}", image):
        raise ValueError("Worker image must be pinned by a full sha256 digest")
    if not isinstance(commit, str) or not re.fullmatch(r"[0-9a-f]{40}", commit):
        raise ValueError("Worker source_commit must be 40 lowercase hexadecimal characters")
    return {"image": image, "source_commit": commit}


def _config() -> tuple[str, str]:
    """Gateway URL and feed key from the platform-provided environment."""
    url = os.environ.get(ENV_GATEWAY_URL)
    key = os.environ.get(ENV_FEED_KEY)
    if not url or not key:
        raise GatewayError(f"Gateway is unconfigured: env {ENV_GATEWAY_URL!r} and {ENV_FEED_KEY!r} must be set")
    return url.rstrip("/"), key


def _request(url: str, key: str, *, method: str = "GET", data: bytes | None = None) -> tuple[int, bytes]:
    request = urllib.request.Request(url, data=data, method=method)
    request.add_header("Authorization", f"Bearer {key}")
    if data is not None:
        # urllib defaults to application/x-www-form-urlencoded when Content-Type is unset;
        # FastAPI then sees the JSON body as a bare string and rejects it with 422.
        request.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(request, timeout=60) as response:
            return response.status, response.read()
    except urllib.error.HTTPError as error:
        body = error.read(300)
        raise GatewayError(
            f"gateway {method} {url} -> HTTP {error.code}: {body.decode(errors='replace')!r}"
        ) from None
    except urllib.error.URLError as error:
        raise GatewayError(f"gateway {method} {url} unreachable: {error.reason}") from None


def _entry_list(document: object, source: str) -> list:
    """Entry list of a feed index, in the shapes promiseops.feed.load_index accepts.

    A bare list, ``{"entries": [...]}`` (gateway contract) or ``{"releases": [...]}`` (the course
    package manifest the gateway may serve verbatim). Anything else is a hard error naming the
    observed shape: silently downloading nothing would only surface later as a confusing
    missing-file failure inside the CLI pre-flight.
    """
    if isinstance(document, list):
        return document
    if isinstance(document, dict):
        for key in ("entries", "releases"):
            if isinstance(document.get(key), list):
                return document[key]
    keys = sorted(document) if isinstance(document, dict) else type(document).__name__
    raise GatewayError(f"{source} has no recognized entry list (top-level: {keys})")


def fetch_feed(as_of: str, dest: str | Path, *, url: str | None = None, key: str | None = None) -> Path:
    """Download the feed entries published by ``as_of`` into ``dest`` and write the index.

    The gateway's ``GET /feed?as_of=...`` response is written verbatim as
    ``manifest.json`` (the format promiseops.feed.load_index accepts) and every listed batch file
    next to it. Checksums are verified later by the CLI pre-flight, not here.
    """
    dest = Path(dest)
    base, key = (url, key) if url and key else _config()
    status, body = _request(f"{base}/feed?as_of={urllib.parse.quote(as_of, safe='')}", key)
    if status != 200:
        raise GatewayError(f"GET /feed -> HTTP {status}")
    entries = _entry_list(json.loads(body), "GET /feed response")
    (dest / "manifest.json").write_bytes(body)
    for entry in entries:
        name = urllib.parse.quote(entry["file"], safe="/")
        status, file_bytes = _request(f"{base}/feed/{name}", key)
        if status != 200:
            raise GatewayError(f"GET /feed/{entry['file']} -> HTTP {status}")
        target = dest / entry["file"]
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(file_bytes)
    return dest


def submit_training(payload: Mapping[str, str], *, url: str | None = None, key: str | None = None) -> dict:
    """POST /training; a 202 means submitted for admission, not completed (CONTRACTS.md)."""
    base, key = (url, key) if url and key else _config()
    status, body = _request(f"{base}/training", key, method="POST", data=json.dumps(payload).encode())
    if status != 202:
        raise GatewayError(f"POST /training -> HTTP {status}: {body.decode(errors='replace')[:300]!r}")
    return json.loads(body)


def run_cli(arguments: list[str]) -> subprocess.CompletedProcess[str]:
    """Run a ``promiseops`` CLI command with the team DB URL.

    Invoked as ``python -m promiseops.cli`` with the task interpreter, not via the
    installed ``promiseops`` script: on the platform Airflow that entry point can be
    a mounted file without the execute bit (PermissionError). The team package is
    not installed there either (the platform ships an older starter ``promiseops``
    without ``cli``), so ``sync-dags`` publishes ``promiseops.zip`` — built from
    ``src/promiseops`` — next to the DAG files, and it goes first on PYTHONPATH so
    the subprocess imports the real package instead of the starter.
    a mounted file without the execute bit (PermissionError). The team package is
    not installed there either (the platform ships an older starter ``promiseops``
    without ``cli``), so ``sync-dags`` publishes ``promiseops.zip`` — built from
    ``src/promiseops`` — next to the DAG files, and it goes first on PYTHONPATH so
    the subprocess imports the real package instead of the starter.
    """
    import sys

    env = os.environ.copy()
    if database := os.environ.get(ENV_DATABASE_URL):
        # COMPANY_DATABASE_URL arrives in SQLAlchemy dialect form ("postgresql+psycopg://…",
        # the platform's generic DB-secret format); the CLI's psycopg needs the plain scheme.
        scheme, _, rest = database.partition("://")
        env.setdefault("PROMISEOPS_DATABASE_URL",
                       f"postgresql://{rest}" if scheme.startswith("postgresql") else database)
    here = Path(__file__).resolve().parent
    entries = []
    if (here / "promiseops.zip").is_file():
        entries.append(str(here / "promiseops.zip"))
    if existing := env.get("PYTHONPATH"):
        entries.append(existing)
    env["PYTHONPATH"] = os.pathsep.join(entries)
    return subprocess.run([sys.executable, "-m", "promiseops.cli", *arguments],
                          check=False, capture_output=True, text=True, env=env)
