"""Ingestion DAG: fetch the feed from the company gateway and run the idempotent CLI.

Daily schedule; each run ingests every entry published by its company ``as_of``
(explicit param or promiseops_company_as_of Variable; never the scheduler clock). ``promiseops ingest-feed``
replays already-committed batches as no-ops, so the full re-ingest is safe and
keeps every run self-contained.

Download and ingestion share one task's temporary directory, so task executors
never exchange machine-local filesystem paths through XCom.
"""

from __future__ import annotations

import json
import tempfile
from datetime import UTC, datetime, timedelta
from pathlib import Path

import promiseops_gateway as gateway
from airflow.exceptions import AirflowException, AirflowFailException
from airflow.sdk import Asset, Param, dag, task

# The training DAGs are scheduled on this asset: ingestion success triggers training.
INGESTED_ASSET = Asset("promiseops://feed/ingested")


@dag(
    dag_id="promiseops_ingest_feed",
    schedule="@daily",
    start_date=datetime(2026, 11, 18, tzinfo=UTC),
    catchup=False,
    max_active_runs=1,
    params={
        "as_of": Param(
            None,
            type=["null", "string"],
            format="date-time",
            description="Company cutoff; default: Variable promiseops_company_as_of (never wall clock)",
        ),
    },
    tags=["promiseops", "ingestion"],
)
def ingest_feed():
    @task
    def resolve_feed(**context):
        return {"as_of": gateway.ingestion_as_of(context["params"])}

    @task(retries=2, retry_delay=timedelta(minutes=2), outlets=[INGESTED_ASSET])
    def ingest(ref: dict, **context):
        # Download and consume in ONE task: separate Airflow workers do not share /tmp.
        with tempfile.TemporaryDirectory(prefix="promiseops-feed-") as folder:
            gateway.fetch_feed(ref["as_of"], Path(folder))
            result = gateway.run_cli(["ingest-feed", folder, "--as-of", ref["as_of"]])
        if result.returncode == 3:
            # Exit 3 = a batch was rejected (corrupted data): retrying cannot help.
            raise AirflowFailException("ingest-feed rejected a batch; payload quarantined in the database")
        if result.returncode != 0:
            raise AirflowException(f"ingest-feed failed (exit {result.returncode}): {result.stderr[-1000:]}")
        receipts = [json.loads(line) for line in result.stdout.splitlines() if line]
        if context.get("outlet_events") is not None:
            context["outlet_events"][INGESTED_ASSET].extra = {"as_of": ref["as_of"]}
        return {"as_of": ref["as_of"], "receipts": receipts}

    ingest(resolve_feed())


ingest_feed_dag = ingest_feed()
