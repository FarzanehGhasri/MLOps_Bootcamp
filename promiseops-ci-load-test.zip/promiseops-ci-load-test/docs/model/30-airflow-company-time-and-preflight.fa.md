# تکمیل اتصال ML و Airflow قبل از فعال‌کردن automation

## ترتیب تغییرات و محدوده

MR !63 محتوای reviewشده را به develop برگرداند. اصلاحات زمانی champion و export تاریخچه در MR !64 از قبل آماده بود؛ این مرحله همان MR را با اصلاح DAGها و preflight کامل می‌کند. مدل، feature، cutoffهای خود bundle، hyperparameter یا metricهای بستهٔ منتشرشده تغییر نکرده‌اند.

## ۱. زمان شرکت از ingestion منتقل می‌شود

قبلاً ingestion از تاریخ سیستم scheduler استفاده می‌کرد و training نیز سه تاریخ ثابت قدیمی داشت. اکنون:

- `dags/ingest.py`: cutoff از پارامتر صریح `as_of` یا Variable غیرمحرمانهٔ `promiseops_company_as_of` می‌آید. تاریخ واقعی اجرای scheduler جایگزین زمان تاریخی شرکت نمی‌شود.
- بعد از ingestion موفق، metadata رویداد `promiseops://feed/ingested` شامل `as_of` است. batch ردشده رویداد موفق تولید نمی‌کند.
- `dags/train.py`: برای training زمان رویدادهای triggering خوانده می‌شود؛ در صورت تجمیع چند رویداد، بیشترین cutoff زمانی معتبر آن‌ها انتخاب می‌شود. monitoring هفتگی از آخرین رویداد ingestion موفق استفاده می‌کند. پارامتر صریح اولویت دارد.
- نبود رویداد/metadata/زمان معتبر باعث خطای واضح می‌شود؛ fallback به ساعت سیستم یا یک تاریخ ساختگی وجود ندارد.
- `train_end` و `validation_end` باید صریح یا در JSON Variable با نام `promiseops_training_cutoffs` تعیین شوند؛ تاریخ قدیمی starter دیگر پیش‌فرض نیست. این تنظیم انتخاب مدل‌سازی است، نه چیزی که کد برای بهترشدن recall تغییر دهد.

از سازوکار رسمی `outlet_events`، `triggering_asset_events` و `inlet_events` استفاده شده است؛ [مستند رسمی Airflow](https://airflow.apache.org/docs/apache-airflow/stable/authoring-and-scheduling/assets.html). این APIها قبل از Airflow 3.4 نیز وجود داشته‌اند؛ نسخه و اجرای واقعی گروه همچنان باید بررسی شوند. Asset metadata فقط زمان شرکت دارد، نه credential یا دادهٔ خام سفارش.

## ۲. مسیر فایل بین workerهای Airflow جابه‌جا نمی‌شود

قبلاً task دانلود، مسیر `/tmp` خود را با XCom به task دیگری می‌داد؛ روی executorهای جدا، آن فایل ممکن بود موجود نباشد. اکنون `resolve_feed` فقط زمان را تعیین می‌کند و task `ingest` در یک `TemporaryDirectory`، دانلود و مصرف فایل‌ها را انجام می‌دهد. فایل‌ها بعد از پایان همان task پاک می‌شوند و XCom مسیر ماشین دیگری را حمل نمی‌کند.

خطای موقت شبکه/CLI دو بار با فاصلهٔ دو دقیقه retry می‌شود. خطای کیفیت batch با `AirflowFailException` بدون retry رد می‌شود؛ quarantine در PostgreSQL باقی می‌ماند. تکرار ingestion همچنان idempotent است و batchهای ثبت‌شده no-op می‌شوند. `reports/runbook.md` با همین رفتار به‌روزرسانی شده است.

## ۳. image و commit در طول retry ثابت می‌مانند

`dags/promiseops_gateway.py` فقط image دارای `@sha256:` با ۶۴ hex و source commit با ۴۰ hex کوچک را قبول می‌کند. این دو در `resolve_cutoffs` یک بار resolve و همراه cutoffها ذخیره می‌شوند. `submit_job` دوباره Variableها را نمی‌خواند؛ بنابراین تغییر Variable بین دو retry باعث ارسال payload متفاوت با همان request_id نمی‌شود.

این بررسی syntax را اثبات می‌کند، نه منشأ واقعی image را. مالک build باید digest را از `worker-build.json` همان pipeline و commit را از همان build بگیرد؛ یک جفت ظاهراً معتبر ولی نامرتبط، شاهد قابل قبول نیست. درگاه همچنان مالکیت image و درخواست را کنترل می‌کند. payload قرارداد gateway تغییر نکرده است.

## ۴. worker قبل از شروع، schema را بررسی می‌کند

`src/promiseops/db.py:require_schema` فقط خواندن انجام می‌دهد: وجود جدول‌های لازم و schema version برابر نسخهٔ ۴ بررسی می‌شود. `worker.py` قبل از train یا monitor-train آن را فراخوانی می‌کند.

نبود `prediction_snapshots` دیگر به‌عنوان «تاریخچه‌ای وجود ندارد» معرفی نمی‌شود؛ پیام `SchemaNotReady` می‌گوید migration reviewشده باید توسط مالک استقرار اجرا شود. worker خودش migration تولیدی اجرا نمی‌کند. نسخهٔ schema جدیدتر و ناشناخته نیز پذیرفته نمی‌شود. پایداری این بررسی در transaction فقط‌خواندنی تست شده است.

## تنظیمات لازم در Airflow

| Variable | مقدار/کاربرد |
|---|---|
| `promiseops_gateway_url` | نشانی gateway گروه |
| `promiseops_feed_key` | credential؛ در secret/backend امن، بدون ثبت در Git یا خروجی ارائه |
| `promiseops_database_url` | اتصال DB؛ در secret/backend امن |
| `promiseops_worker_image` | worker image گروه با digest کاملِ build تأییدشده |
| `promiseops_worker_commit` | commit کامل و مربوط به همان image |
| `promiseops_company_as_of` | cutoff شرکت برای ingestion زمان‌بندی‌شده؛ با clock واقعی سیستم اشتباه نشود |
| `promiseops_training_cutoffs` | JSON دقیقاً شامل `train_end` و `validation_end` با timezone |

نمونهٔ replay سازگار با lineage بستهٔ `logistic_regression-52d3211cb171`:

```json
{"train_end":"2017-12-31T23:59:59Z","validation_end":"2018-02-28T23:59:59Z"}
```

برای بازتولید همان snapshot، `promiseops_company_as_of` برابر `2018-04-30T00:00:00Z` است. این نمونه یک سیاست خودکارِ جابه‌جایی split یا مجوز استفاده از test برای tuning نیست؛ قبل از replay جدید، بازه‌ها باید انتخاب و مستند شوند. تا وقتی این Variableها و image آماده نشده‌اند، DAGها را فعال نکنید.

## مانع واقعی ساخت worker image

در pipeline اصلی `1038`، job `prepare-release` به شمارهٔ `3690` با پیام **`RELEASE_BUNDLE_URL is not set`** شکست خورده است؛ در نتیجه buildهای app و worker skipped شدند. این خطا از آموزش مدل یا recall نیست.

حساب `qbc13-g03-05` نقش Developer با access level 30 دارد؛ تنظیم Variableهای محافظت‌شدهٔ پروژه باید توسط Maintainer انجام شود. مقادیر غیرمحرمانهٔ آماده:

```text
RELEASE_BUNDLE_URL=https://gitlab.mlops.qbootcamp.ir/api/v4/projects/4/packages/generic/promiseops-model-bundle/candidate-52d3211cb171/bundle.tar.gz
RELEASE_BUNDLE_SHA256=d0db9e2687166f11565ece2315e32e256a5157569688d12a7b05a445340daac1
```

مالک release باید دسترسی خصوصی registry را نیز مطابق `ci/prepare_release.py` با متغیر masked مناسب تنظیم کند؛ مقدار token را در چت یا Git نگذارد. سپس pipeline باید بسته را دریافت/verify کند و app و worker را بسازد. خروجی `worker-build.json` همان pipeline مبنای Airflow Variableهاست. این تغییرات کد، خودبه‌خود Variable محافظت‌شده را تنظیم یا تولید را deploy نکرده‌اند.

## آزمون و پذیرش نهایی

آزمون‌های رفتاری DAG و gateway بدون Airflow واقعی، اما با شکل context رسمی اجرا می‌شوند. آزمون schema از PostgreSQL disposable استفاده می‌کند. پوشش جدید شامل metadata موفق/ردشده، چند cutoff، نبود clock fallback، plan ناقص، image غیرقابل ردیابی، ثابت‌ماندن payload در retry و جلوگیری از fit در نبود migration است.

نتیجهٔ کد `7125ff67b5c0aaee511dcbf02a88d78483d841e1`: **۴۴ تست متمرکز موفق؛ کل suite شامل ۶۰۴ تست موفق، یک تست نمونهٔ قدیمی skipped و صفر failure/error** در ۱۲۲٫۳۶ ثانیه. Ruff کامل روی checkout بومی Linux موفق شد. هشدار Starlette/httpx قبلی باقی است. گزارش، لاگ و JUnit در `reports/model/airflow-company-time-2026-11-20.*` ثبت شده‌اند. اجرای نرم‌افزاری در MLflow محلی، experiment `promiseops-verification`، run `f58e45ffb6de486db12e5517c794a343` ثبت شد؛ این run آموزش یا اجرای گروه نیست.

برای پذیرش روی گروه، مالک Airflow/deploy باید جداگانه این موارد را ثبت کند:

1. migration schema v4 و parse بدون خطای DAGها در Airflow واقعی؛
2. یک ingestion کنترل‌شده با `as_of` مشخص و asset event دارای همان metadata؛
3. training Job با image digest/commit ثبت‌شده؛ پاسخ ۲۰۲ فقط submission است؛
4. تکمیل Job و run متناظر MLflow، همراه data/cohort identity و model/preprocessing artifacts؛
5. اجرای monitor-train با snapshotهای واقعاً ثبت‌شده، یا گزارش صریح ناکافی‌بودن history/labels؛
6. نبود promotion خودکار تولید؛ رد شدن candidate نتیجهٔ معتبر است.

شاهد آزمایش محلی را جایگزین این اجرای گروه نکنید. هیچ تاریخچه یا label مصنوعی برای گرفتن نتیجهٔ بهتر ساخته نشده است.
