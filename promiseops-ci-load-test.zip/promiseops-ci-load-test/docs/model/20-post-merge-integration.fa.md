# یکپارچه‌سازی پس از مرج پویا — ۱۸ نوامبر ۲۰۲۶

## ترتیب کار و ارتباط با تسک‌ها

| اولویت | تسک‌های دورسا | کار قابل بررسی | محل اصلی |
|---|---|---|---|
| ۱ | #24، #12، #20 | اتصال feature واقعی ۱۵/۳۲ ستونی به API و score، حفظ bundle ثابت و پاسخ تکراری | `api.py`، `inference.py`، `cli.py`، `bundle.py` |
| ۲ | #13، #24، #25 | کنترل تراکنش و schema، مرز برچسب، تقسیم زمانی و معیارها | `data.py`، `validation.py`، `features.py`، `cohorts.py`، `metrics.py` |
| ۳ | #14، #15، #16 | آموزش و ثبت مدل، preprocessing، نسخه داده، cutoff و checksum | `training.py`، `tracking.py`، `record.py`، `training_evidence.py` |
| ۴ | #21، #26 | گزارش drift و برچسب بالغ، آموزش فقط با توصیه مستند | `monitor.py`، `monitor_train.py`، `worker.py` |
| ۵ | #25 | نگهداری شواهد مقایسه و calibration بدون تغییر خودکار production | `calibration_study.py`، `presentation_study.py`، `reports/model/` |

نام فایل‌های جدول نسبت به `src/promiseops/` است مگر مسیر کامل‌تر داده شده باشد.

## اصلاح لازم در اتصال به develop

تغییرات جدید API در develop ذخیره‌سازی درخواست و metrics را اضافه کرده بود، اما هنوز ورودی صفر می‌ساخت. شاخه قدیمی feature واقعی داشت، اما ذخیره‌سازی درخواست را نداشت. ادغام باید هر دو رفتار معتبر را حفظ کند:

- `PROMISEOPS_RELEASE` هم پوشه و هم مسیر `release.json` را می‌پذیرد؛ checksum و lineage قبل از استفاده بررسی می‌شوند.
- API و فرمان score از `inference.release_features` استفاده می‌کنند؛ fallback صفر حذف شده است.
- API زمان replay شرکت را استفاده می‌کند، نه ساعت امروز برای تشخیص سفارش قابل دسترس.
- پاسخ اولین درخواست در PostgreSQL ثبت می‌شود. تکرار همان شناسه همان پاسخ قبلی را می‌دهد؛ استفاده برای سفارش دیگر خطای 409 دارد. قفل درخواست پیش از snapshot دیتابیس، رقابت دو درخواست هم‌زمان را کنترل می‌کند.
- نبود دیتابیس یا مدل خطای 503 دارد؛ API key تنظیم‌نشده پذیرفته نمی‌شود.
- featureهای score بر اساس شناسه سفارش مرتب و با cohort تطبیق داده می‌شوند؛ احتمال نامعتبر رد می‌شود.

## اجرای بررسی

در محیط Python 3.12 پروژه، از ریشه repository:

```bash
python -m pytest -q
```

برای اجرای تست‌های PostgreSQL، `PROMISEOPS_TEST_DATABASE_URL` باید به دیتابیس **آزمایشی با نام منتهی به `_test`** اشاره کند؛ fixtureها schema آن را پاک و بازسازی می‌کنند. از دیتابیس واقعی آموزش برای تست استفاده نکنید.

```bash
python -m pytest tests/test_api_features_db.py tests/test_ingestion_db.py tests/test_registry_mlflow.py -v
python -m promiseops.cli score --as-of 2018-04-30T00:00:00Z --output artifacts/priority.json
```

فرمان score علاوه بر دیتابیس، به bundle معتبر در `PROMISEOPS_RELEASE` نیاز دارد. `--since` برای cohort سفارش‌های تازه منتشرشده قابل استفاده است.

## مرز نتایج و کارهای وابسته

مرج !37 ابزار آزمایشی داده مصنوعی است؛ حدود ۶۷٪ را نباید نتیجه داده واقعی معرفی کرد. مرجع واقعی قبلی worker با ۳۲ feature برابر ۲۷٫۷۳٪ recall@10% است. مطالعه ۴۴ feature حدود ۲۸٫۹۳٪ دارد اما به release سرویس متصل نیست؛ این سند ادعای آموزش جدید یا افزایش recall ندارد.

monitor-train به فایل `PROMISEOPS_PREDICTION_HISTORY` با snapshot واقعی featureها، زمان پیش‌بینی و نسخه مدل نیاز دارد. جدول ساده `predictions` به‌تنهایی این ورودی را تأمین نمی‌کند. بدون فایل، گزارش نبود سابقه ثبت می‌شود و retraining خودکار متوقف می‌ماند؛ این رفتار نباید با ساختن سابقه گذشته از روی داده فعلی دور زده شود.

رؤیت run در MLflow محیط گروه و تأیید هم‌تیمی، با تست SQLite محلی یکسان نیست. تسک‌ها صرفاً به دلیل تست محلی بسته نمی‌شوند. تغییرات Helm، DAG و استقرار افراد دیگر در این کار ادغام خودکار نمی‌شوند.

شاخه محلی `model/37-duration-tail-study` و فایل‌های untracked قبلی حفظ شده‌اند. آن شاخه با MR !37 پویا متفاوت است و آزمایش‌هایش به production ارتقا داده نشده‌اند.
