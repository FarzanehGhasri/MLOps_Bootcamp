# اتصال پیش‌بینی واقعی به پایش — تسک‌های #21 و #26

## مشکل و تغییر

قبلاً API فقط احتمال و نسخه مدل را ذخیره می‌کرد. worker پایش به featureهایی نیاز دارد که **واقعاً هنگام پیش‌بینی دیده شده‌اند**؛ محاسبه مجدد آن‌ها از دیتابیس فعلی، سابقه تاریخی معتبر نمی‌سازد.

اکنون API در همان تراکنش پاسخ، یک ردیف در `promiseops.prediction_snapshots` ثبت می‌کند: `request_id`، زمان replay شرکت (`predicted_at`)، featureهای همان ردیف مدل و SHA256 artifact. اگر ثبت snapshot شکست بخورد، پاسخ هم commit نمی‌شود. retry همان پاسخ و snapshot اول را نگه می‌دارد. ردیف‌های قدیمی عمداً backfill نمی‌شوند.

این قابلیت schema را از ۲ به ۳ می‌برد؛ جدول جدید با دستور idempotent `db-init` ساخته می‌شود. سفارش‌ها و outcomeها تغییر نمی‌کنند. ثبت snapshot به معنای مجوز تغییر production نیست.

## اجرای مرحله‌به‌مرحله در محیط پروژه

۱. آدرس PostgreSQL را در `PROMISEOPS_DATABASE_URL` تنظیم و schema را اعمال کنید:

```bash
python -m promiseops.cli db-init
```

۲. API را با `PROMISEOPS_RELEASE`، `PROMISEOPS_API_KEY` و زمان replay در `PROMISEOPS_AS_OF` اجرا و `/predict` را فراخوانی کنید. زمان شرکت باید زمان واقعی آن مرحله از replay باشد؛ درخواست گذشته را با تاریخ ساختگی به گذشته نسبت ندهید. زمان ثبت فیزیکی در `predictions.created_at` جدا از زمان شرکت نگهداری می‌شود.

۳. نسخه دقیق مدل را از پاسخ API یا `release.json` بردارید و snapshotها را صادر کنید:

```bash
python -m promiseops.prediction_history --model-version MODEL_VERSION --as-of 2018-04-30T00:00:00Z --output artifacts/predictions-20180430.jsonl
```

فرمان فقط همان نسخه مدل و snapshotهای موجود تا cutoff را می‌خواند؛ بدون داده واقعی خطا می‌دهد و فایل خروجی موجود را بازنویسی نمی‌کند. خروجی شامل featureهای ۱۵ یا ۳۲ ستونی متناسب با مدل است.

۴. مسیر فایل را در `PROMISEOPS_PREDICTION_HISTORY` بگذارید؛ `MLFLOW_TRACKING_URI` و `CI_COMMIT_SHA` نیز باید تنظیم باشند. از همان bundle به عنوان incumbent استفاده کنید:

```bash
python -m promiseops.worker --mode monitor-train --train-end 2017-12-31T23:59:59Z --validation-end 2018-02-28T23:59:59Z --as-of 2018-04-30T00:00:00Z
```

گزارش در experiment پایش MLflow ثبت می‌شود. کمبود نمونه یا برچسب بالغ، توصیه آموزش خودکار تولید نمی‌کند. برای دیدن drift به حداقل ۱۰۰ سفارش یکتا در پنجره و برای drift پایدار به دو پنجره جدا نیاز است؛ چند بار فراخواندن یک سفارش این حد را پر نمی‌کند.

## تست و محدودیت

`tests/test_prediction_history_db.py` تطابق دقیق feature ذخیره‌شده، فیلتر cutoff و نسخه مدل، roundtrip با loader پایش، عدم backfill، rollback و retry را با PostgreSQL بررسی می‌کند. `tests/test_api_features_db.py` هم‌زمانی و برابری خروجی API/CLI با pipeline را پوشش می‌دهد.

این تغییر فقط پیش‌بینی‌های جدید API را ثبت می‌کند؛ فرمان score گزارش دسته‌ای تولید می‌کند و در این تغییر تولیدکننده snapshot نیست. برای نمایش چرخه واقعی پایش، باید ابتدا ترافیک API در replay ثبت شود و سپس ارزیابی برچسب‌های همان سفارش‌ها انجام شود. هیچ بهبود تازه‌ای برای recall ادعا نشده است.

## اجرای واقعی ثبت‌شده در ۱۸ نوامبر

`scripts/verify_monitoring_replay.py` روی کپی جداگانه داده واقعی با نام `promiseops_monitor_replay_20261118` اجرا شد. پنج سفارش از API عبور کردند؛ هر درخواست یک بار تکرار شد و پاسخ قبلی حفظ شد. پنج snapshot صادر و worker در زمان شرکت ۱۵ مه اجرا شد. گزارش MLflow با شناسه `7aa95959af24488abe3fd2d0ee049722` وضعیت `assessed` و `retrain_recommended=false` دارد؛ هیچ fit اجرا نشد. گزارش ذخیره‌شده از MLflow دوباره دریافت شده و در `reports/model/monitor-replay-record-2026-11-18.json` قرار دارد؛ خلاصه و checksum در `reports/model/monitor-replay-2026-11-18.json` است.

این smoke test مسیر واقعی داده را بررسی می‌کند و ارزیابی عملکرد آماری نیست. دیتابیس اصلی آموزش و ارزیابی تغییر نکرد. run در MLflow محلی است؛ اجرای کلاستر گروه همچنان به دسترسی معتبر همان محیط نیاز دارد. روی این کامپیوتر `kubectl config current-context` تنظیم نیست.
