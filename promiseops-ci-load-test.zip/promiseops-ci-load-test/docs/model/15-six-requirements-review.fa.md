# ممیزی شش الزام داده و مدل — ۲۰۲۶/۱۱/۱۶

این گزارش وضعیت کد را در ادامهٔ commit پایه `0718d61` بررسی می‌کند. اصلاحات این ممیزی ابتدا محلی‌اند.
هدف، صحت اجرای الزامات است؛ در این ممیزی مدل یا hyperparameter با دادهٔ test انتخاب نشده است.

## ۱. PostgreSQL، روابط، schema و checksum

`schema.sql` برای هفت جدول منبع، کلید اصلی و خارجی دارد. `data.ingest_batch` پیش از نوشتن،
checksum بایت فایل (وقتی از feed تأمین شود)، checksum canonical payload، schema و قواعد بین ردیف‌ها را بررسی می‌کند.
`ingest-feed` هر دو checksum و metadata فایل/manifest را بررسی و فایل‌ها را به ترتیب انتشار مصرف می‌کند.
`ingest-file` همیشه payload checksum می‌خواهد؛ checksum فایل ورودی اختیاری جداگانه دارد.

ایراد تأییدشده: Pydantic قبلاً `price: true` را 1.0 و `installments: true` را 1 می‌کرد و
عدد timestamp را نیز می‌توانست به تاریخ تبدیل کند. اکنون مبلغ، وزن و شمارنده‌ها strict هستند؛
timestamp فقط مقدار دارای timezone و promised_date فقط تاریخ تقویمی معتبر می‌پذیرد.
تست ۱۰ ورودی نامعتبر در PostgreSQL ثابت می‌کند هر batch کامل رد می‌شود، source/receipt خالی می‌مانند
و payload و reason=`schema_invalid` در quarantine و attempt ثبت می‌شوند.

محل شواهد: `tests/test_ingestion_db.py::test_wrong_json_types_reject_entire_batch_with_audit`،
`tests/test_validation.py` و ممیزی مستقل منبع در `reports/model/six-requirements-data-audit-2026-11-16.json`.
تطبیق با feed آماده‌شده است؛ بازتولید آماده‌سازی از CSVهای خام اولیه در این ممیزی انجام نشده است.

## ۲. تراکنش، replay و جمع اقلام/پرداخت‌ها

ثبت receipt، تمام ردیف‌ها و attempt موفق داخل یک transaction و advisory lock است.
خطا در میانهٔ insert، همهٔ آن‌ها را rollback می‌کند. رد batch و quarantine سپس در transaction جدا ثبت می‌شوند.
همان batch_id و همان payload یک replay بدون insert است؛ payload متفاوت زیر همان batch_id خطاست.
ثبت مجدد fact در batch متفاوت، به‌جای ساختن duplicate رد می‌شود؛ dimension یکسان قابل استفادهٔ مجدد است.

`features._item_features` و `_payment_features` مستقل aggregate می‌شوند و بعد به سفارش join می‌شوند.
بنابراین دو قلم و سه پرداخت به شش ردیف برای جمع مبالغ تبدیل نمی‌شوند.
تست‌های rollback، replay، conflict، هم‌زمانی، FK و aggregation در اجرای این ممیزی دوباره اجرا شدند.
در این بخش ایراد جدیدی پیدا نشد و منطق بدون دلیل بازنویسی نشد.

## ۳. ویژگی زمان تأیید و preprocessing مشترک

SQL پایه از outcomes، review و وضعیت نهایی نمی‌خواند. شناسهٔ سفارش index است و predictor نیست.
ویژگی‌های تاریخچه از outcome سفارش‌های قبلی فقط با شرط `label_available_at < approved_at` سفارش هدف
استفاده می‌کنند؛ outcome خود هدف و رویداد زمان مساوی ممنوع‌اند. این «نتیجهٔ تحویلِ سفارش هدف» نیست.
CONTRACTS صریحاً historical aggregate از outcomeهای پیشینِ قابل‌دانستن را مجاز می‌داند.

در release دارای سابقه، snapshot منبع به lineage.as_of و dataset_identity و زمان پرس‌وجو به train_end مقید است.
هویت receiptها باید برابر باشد؛ اطلاعات تازهٔ target وارد منبع frozen نمی‌شود.
`inference.release_features` در API، ارزیابی و champion scoring مشترک است. API pipeline ذخیره‌شده را فقط
predict می‌کند و دوباره scaler/encoder را fit نمی‌کند. مدل‌های ۱۵ و ۳۲ستونه در تست دیتابیس پوشش دارند.

ایراد تأییدشده و اصلاح‌شده: `diagnostics.analyze` هنوز فقط builder ۱۵ستونه را فراخوانی می‌کرد و برای
release ۳۲ستونه شکست می‌خورد. اکنون از builder همان release استفاده و مدل‌های seed-check را با schema درست می‌سازد.
تست جدید `test_diagnostics_reproduce_32_feature_release_metrics` cohort، schema، SQL labels و معیار frozen را کنترل می‌کند.

## ۴. تقسیم زمانی و زمان دانش

تقسیم انتخاب‌شده و علت آن در `docs/features/01-features-labels-split.fa.md` و ممیزی تفصیلی
`docs/model/13-selection-and-cutoff-audit.fa.md` ثبت است:

| بخش | زمان تأیید سفارش | cutoff برچسب | تعداد cohort ثبت‌شدهٔ واقعی |
|---|---|---|---:|
| train | تا 2017-12-31T23:59:59Z | همان train_end | ۳۹۸۳۷ |
| validation | پس از train_end تا 2018-02-28T23:59:59Z | 2018-04-30T00:00:00Z | ۱۳۳۷۷ |
| test | پس از validation_end تا 2018-04-30T23:59:59Z | 2018-06-30T00:00:00Z | ۱۳۷۱۲ |

عضویت مستقل SQL با کد یکسان و هم‌پوشانی شناسه‌ها صفر است. برچسب train بعد از train_end وارد fit نمی‌شود.
train_end < validation_end <= as_of کنترل می‌شود؛ دادهٔ ناکافی یا تک‌کلاسه خطای گزارش‌شده است.

دو محدودیت مهم:

1. بستهٔ اولیه در ۲۰۱۸/۰۱/۰۱ منتشر شده، ولی سفارش و زمان تاریخی دانش برچسب پیش از آن است.
   مطابق CONTRACTS، زمان انتشار batch برای replay از زمان تاریخی دانش تفکیک می‌شود. این آموزش،
   بازسازی تاریخی با snapshot بعداً منتشرشده است. اگر «در دسترس» را انتشار فیزیکی batch در همان train_end
   معنی کنیم، train فعلی خالی می‌شود؛ نباید ادعای اجرای زنده با دسترسی واقعی در سال ۲۰۱۷ کرد.
2. test قبلاً در پروژه گزارش شده است؛ دیگر نمی‌توان ادعای «هیچ‌وقت دیده‌نشده» کرد.
   کد می‌تواند عدم هم‌پوشانی زمانی را کنترل کند؛ مشاهده یا tuning بیرون از آن را نمی‌تواند اثبات یا جلوگیری کند.
   متن `evaluation.py` اصلاح شد تا این کنترل را تضمین untouched بودن معرفی نکند.

در این ممیزی cutoffها برای گرفتن عدد بهتر جابه‌جا نشدند. تست‌های نرم‌افزاری از دادهٔ مصنوعی استفاده می‌کنند؛
این کار با ارزیابی روی cohort آزمون واقعی متفاوت است. هیچ test prediction جدیدی برای انتخاب مدل محاسبه نشد.

## ۵. baseline، دو مدل و معیارهای cohort

`model.fit_candidate` baseline با فراوانی train، Logistic Regression و HistGradientBoosting را روی train fit
و روی همان شناسه‌های validation ارزیابی می‌کند. `metrics.evaluate` چهار معیار را همراه N و prevalence می‌دهد.
K=max(1,ceil(0.1*N))، ترتیب تساوی order_id و PR-AUC به تعریف average precision است.
candidate و champion باید شناسه و برچسب یکسان داشته باشند؛ featureهای تاریخی هر release جدا بازسازی می‌شوند.

ایراد جدید: تبدیل مستقیم برچسب به bool ممکن بود مقادیر نامعتبر مانند رشتهٔ "False" یا NaN را True کند.
اکنون فقط برچسب معلوم binary (boolean یا عدد ۰/۱) و آرایه‌های تک‌بعدی پذیرفته می‌شوند؛
برچسب مفقود/نامعتبر و ماتریس ناخواسته خطا می‌دهند. این اصلاح بی‌صدا معیار ساختگی تولید نمی‌کند.
تست‌های مستقل تساوی، top-K، AP، Brier، گیت و input validation اجرا می‌شوند.

آخرین نتیجهٔ واقعی موجود برای نسخهٔ قبلی همین pipeline: recall=۲۷٫۷۳٪، precision=۲۴٫۱۴٪،
AP=0.190338، Brier=0.079992 روی N=۱۳۳۷۷ با prevalence=۸٫۷۱٪.
این ممیزی نتیجهٔ fit جدید یا افزایش recall جدید ادعا نمی‌کند.

## ۶. MLflow و بازتولید

worker پارامترهای هر سه روش و preprocessing، معیارهای هر سه روش و champion، bundle شامل model.joblib
و preprocessing، model record و reference را log می‌کند. دانلود دوبارهٔ artifact با checksum و record کنترل می‌شود.
مدل دارای source commit، software versions، dataset identity، feature schema hash، cutoffها،
validation cohort hash و model SHA256 است. خطا، run را FAILED می‌کند؛ cleanup خطای اصلی را جایگزین نمی‌کند.

دو کمبود logging رفع شد:

- شیء `StratifiedKFold` داخل TargetEncoder قبلاً از پارامترهای scalar حذف می‌شد؛ اکنون class، n_splits،
  shuffle و random_state به‌صورت صریح در `approaches.hyperparameters` ثبت می‌شوند.
- ثابت‌های سیاست تاریخچه شامل prior، smoothing، پنجرهٔ ۳۰روزه، حجم هفت‌روزه و مرز زمانی دانش،
  از همان ثابت‌های مصرف‌شده در محاسبه به پارامترهای `history.*` در record نگاشت می‌شوند.
  تغییر این ثابت‌ها نیازمند نسخهٔ جدید history_policy است.

نسخهٔ کد واقعیِ اصلاحات محلی هنوز commit جدید ندارد؛ لاگ‌های این ممیزی parent commit را همراه
hash فایل‌های اصلاح‌شده ثبت می‌کنند. source commit پایه را نباید به‌تنهایی معرف کد تغییرکرده معرفی کرد.
تست‌های نرم‌افزاری از نتایج ML روی دادهٔ واقعی جدا گزارش می‌شوند.

## نتیجهٔ اجرای نهایی

- مجموعهٔ کامل: **۳۸۲ passed، یک skipped**؛ skip مربوط به placeholder عمومی قدیمی است.
- بررسی Ruff روی فایل‌های تغییرکرده و `git diff --check` موفق بود.
- run تست: `76f36d7e87cb489d908fc3988096f8b6` در `promiseops-verification`.
- run ممیزی داده: `3a96e975ed4943e9a056be1f8a37e3e3` در `promiseops-data-audit`.
- فایل `reports/model/six-requirements-review-2026-11-16.json` شامل parent commit و hash تمام فایل‌های Python
  منبع و تست است و به artifactهای همان run پیوست شد. tag `promiseops.source_state` نشان می‌دهد اصلاحات هنوز محلی و commit‌نشده‌اند.
- checksum هر ۴۲ فایل درست بود؛ هر ۲۶ batch موردانتظار snapshot حاضر است و در هفت جدول هیچ ردیف
  مفقود، اضافه یا متفاوتی نسبت به منبع آماده‌شده پیدا نشد. بازسازی مستقل برچسب اختلاف صفر داشت.
- فایل‌های JUnit و log کامل در `reports/model/six-requirements-tests-2026-11-16.*` ذخیره شدند.

## اجرا

در محیط کانتینر و با `PYTHONPATH=/app/src`:

```bash
# فقط دیتابیس دورریختنی تست؛ هرگز دیتابیس واقعی را برای این متغیر قرار ندهید:
export PROMISEOPS_TEST_DATABASE_URL='postgresql://promiseops:promiseops-test@host.docker.internal:55432/promiseops_test'
/opt/venv/bin/python -m pytest tests -q
```

فایل‌های اصلی اصلاح‌شده: `contracts.py`، `metrics.py`، `diagnostics.py`، `approaches.py`،
`history_features.py`، `record.py` و توضیح ارزیابی در `evaluation.py`.
این ممیزی production یا aliasهای مدل را جابه‌جا نمی‌کند.
