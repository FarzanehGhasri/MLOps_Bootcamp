# اصلاحات ممیزی قرارداد داده — ۲۰ نوامبر ۲۰۲۶

## مرحله و محدوده

این تغییر پس از ممیزی سه بخش اول سند پروژه، روی branch `data/13-contract-validation-fixes` انجام شد. هدف، رفع دو نقص در پذیرش ورودی و تکمیل شواهد آزمون است؛ مدل، feature، cutoff و hyperparameter تغییر نکرده‌اند. تسک‌های مرتبط: #13 و #24. درخواست merge باید توسط پویا بررسی شود.

## چه اصلاح شد و چرا؟

1. در `src/promiseops/validation.py`، عدد JSON مانند `1e999` قبلاً به infinity تبدیل می‌شد و بعداً خطای عمومی ایجاد می‌کرد؛ batch در quarantine ثبت نمی‌شد. اکنون parse عدد غیرمتناهی را رد می‌کند و همان مسیر `INVALID_JSON`، quarantine فایل اصلی و ثبت علت اجرا می‌شود. هیچ ردیفی از batch وارد جدول‌ها نمی‌شود. عدد علمی معتبر مثل `1e2` همچنان پذیرفته می‌شود و checksum محتوای یکسان تغییر نمی‌کند.
2. در `src/promiseops/contracts.py`، الگوی شناسه با قرارداد مستند هماهنگ شد: حرف/عدد در ابتدا و سپس حرف، عدد، نقطه، خط تیره یا underscore، حداکثر ۱۲۸ نویسه. شناسه دارای `:` اکنون عمداً رد می‌شود؛ این تغییر رفتار ورودی باید در review دیده شود.
3. `contracts/Batch.schema.json` و `contracts/PredictionRequest.schema.json` از مدل‌های Pydantic دوباره تولید شدند تا schema منتشرشده با runtime یکسان باشد.
4. تست‌های `tests/test_validation.py`، `tests/test_ingestion_db.py` و `tests/test_public_contracts.py` overflow مستقیم و تو‌در‌تو، quarantine، صفر بودن ردیف‌ها/receipt، scientific notation معتبر، مرز طول شناسه و برابری schema منتشرشده با runtime را بررسی می‌کنند.

## نتیجه واقعی آزمون

- commit کد آزموده‌شده: `cc7a73d6f31bd0112ca1f22e80b67a5231fecb55`؛ commit بعدی فقط گزارش و شاهد آزمون را اضافه می‌کند.
- Ruff کامل روی استخراج بومی Linux از همان commit: موفق.
- اجرای تمام تست‌ها با PostgreSQL اختصاصی تست: **۵۵۰ موفق، صفر failure/error، یک تست نمونه قدیمی skipped**؛ زمان ۱۳۲٫۸۷ ثانیه.
- یک هشدار deprecation مربوط به Starlette/httpx باقی است؛ خطای تست نیست.
- لاگ، JUnit و hash فایل‌ها: `reports/model/contract-audit-fixes-2026-11-20.*`.
- MLflow **محلی**: experiment `promiseops-verification`، run `9987c1c9fdba4c9ba74b2049deafe0af`، نشانی `http://127.0.0.1:5000/#/experiments/4/runs/9987c1c9fdba4c9ba74b2049deafe0af`.

این run آزمون نرم‌افزار است؛ نتیجه آموزش روی داده واقعی یا اجرای سرور گروه نیست. این اصلاحات ادعای افزایش recall ندارند.

## بازتولید

در محیط Linux پروژه با dependencyهای قفل‌شده، `PYTHONPATH=src` و پایگاه اختصاصی با نام پایان‌یافته به `_test`:

```bash
python -m ruff check .
python -m pytest tests -q --junitxml=artifacts/contract-fixes-full.xml
```

آزمون‌های دیتابیس schema را پاک می‌کنند؛ متغیر `PROMISEOPS_TEST_DATABASE_URL` فقط باید به پایگاه disposable تست اشاره کند، نه پایگاه داده واقعی یا سرویس.

## موارد باقی‌مانده در تحویل گروه

1. اجرای smoke در MLflow گروه موفق بوده، اما به‌تنهایی شاهد train واقعی یا ثبت مدل نیست. registry بررسی‌شده worker image جاری نداشت؛ ساخت image باید از مسیر release موجود !57 و CI انجام شود. source commit و image digest باید به اجرای gateway متصل باشند.
2. قبل از فعال‌کردن worker جدید، مالک استقرار باید migration مربوط به schema v4 را اجرا کند؛ این MR migration تولیدی اجرا نمی‌کند.
3. credential تاریخی در issue محرمانه #27 به مالک ارجاع شده است. فعال/باطل بودن آن تأیید نشده؛ مقدار credential در این گزارش یا لاگ‌ها نیست.
4. ارزیابی زمانی بعدی باید قبل از مشاهده معیارها، مدل و بازه را freeze کند. عدد ۶۷٪ داده مصنوعی، معیار داده واقعی نیست؛ نتیجه validation قبلی نیز نباید test جدید نامیده شود.
