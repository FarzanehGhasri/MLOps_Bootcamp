﻿# بررسی Recall، تقسیم زمانی و نسخه‌های MLflow — تسک‌های #25، #24 و #16

## نتیجهٔ بررسی واقعی

روی دادهٔ واقعی و همان مدل ثابت، نتیجهٔ validation دقیقاً بازتولید شد. در کنترل‌های اجراشده، خطای محاسبهٔ معیار، هم‌پوشانی train/validation، عبور از cutoff، اختلاف برچسب Python و PostgreSQL یا اثر seed پیدا نشد. این بررسی اثبات نمی‌کند مدل بهینه است یا تمام خطاهای احتمالی پروژه حذف شده‌اند.

| بررسی | نتیجهٔ اندازه‌گیری‌شده |
|---|---|
| شناسه‌های یکتا و train/validation جدا | موفق |
| زمان تأیید و دسترسی به برچسب | مطابق cutoffهای ثبت‌شده |
| dataset identity و cohort hash | مطابق شناسنامهٔ مدل |
| محاسبهٔ مستقل برچسب با PostgreSQL و America/Sao_Paulo | مطابق Python |
| محاسبهٔ مستقل top-10% و Brier | مطابق معیارهای ثبت‌شده |
| اندازهٔ validation | 13,377 سفارش، 1,165 دیرکرد |
| ظرفیت بررسی | 1,338 سفارش |
| دیرکرد در top-10% | 281 مورد؛ recall = 281 / 1165 = 24.1202٪ |
| Bootstrap روی validation | فاصلهٔ صدکی ۹۵٪ حدود 22.10٪ تا 26.40٪؛ 300 تکرار با seed=42 |
| توقف Logistic Regression | solver=lbfgs، 55 iteration از سقف 2000؛ به سقف iteration نرسیده است |

Bootstrap فقط عدم‌قطعیت بازنمونه‌گیری همین validation را نشان می‌دهد؛ تضمین عملکرد روی آینده نیست. Recall@10% با accuracy یا recall در یک threshold آزاد متفاوت است. بررسی تصادفی حدود ۱۰٪ دیرکردها را پیدا می‌کند؛ مقدار ۲۴٪ از آن بهتر است، ولی مطلوبیت کسب‌وکار یا بهینه‌بودن مدل را به‌تنهایی ثابت نمی‌کند.

## seed علت این نتیجه نبود

همهٔ تنظیمات و cohort ثابت ماندند و فقط `random_state` عوض شد. هیچ seed برنده‌ای انتخاب نشد.

| مدل | seed 0 | seed 7 | seed 42 |
|---|---:|---:|---:|
| Logistic Regression، recall@10% | 0.2412017 | 0.2412017 | 0.2412017 |
| HistGradientBoosting، recall@10% | 0.2145923 | 0.2145923 | 0.2145923 |

برای تنظیمات بررسی‌شده، معیارهای Brier هم بین این seedها یکسان بودند. نتیجه را به همهٔ solverها، نمونه‌گیری‌ها یا تنظیمات آینده تعمیم نمی‌دهیم. تقسیم داده در این پروژه زمانی است و seed آن را random نمی‌کند.

## محدودیت واقعی: انتخاب ناشی از بلوغ برچسب

از 43,609 سفارش تأییدشده تا پایان سال، فقط 39,837 سفارش برچسب قابل استفاده در cutoff آموزش داشتند. **3,772 سفارش** به‌درستی از آموزش کنار گذاشته شدند. مشکل آماری این است که برچسب سفارش دیرکرددار معمولاً دیرتر معلوم می‌شود؛ بنابراین subset زودبرچسب‌خورده نمایندهٔ کامل همان سفارش‌ها نیست.

| cohort یا ماه سفارش | نرخ دیرکرد در subset مجاز آموزش | نرخ دیرکرد پس از معلوم‌شدن برچسب‌های بیشتر تا as_of |
|---|---:|---:|
| کل سفارش‌های قبل از cutoff آموزش | 3.9059٪ | 5.6165٪ |
| نوامبر 2017 | 6.2660٪ | 12.1978٪ |
| دسامبر 2017 | 0.4977٪ | 7.8131٪ |

برای دسامبر، از 5,673 سفارش فقط 2,411 سفارش در cutoff واجد شرایط بودند؛ تا as_of تعداد 5,670 سفارش برچسب داشتند. برچسب‌های بعدی **فقط برای توضیح این انتخاب آماری** بررسی شدند و وارد fit نشدند.

همچنین prevalence ثبت‌شده از حدود 3.91٪ در train به 8.71٪ در validation و 11.99٪ در test تغییر کرده است. میانگین احتمال مدل روی test حدود 4.33٪ بود؛ نتیجهٔ قبلی test از نو برای این تشخیص یا تنظیم مدل مصرف نشده است. این‌ها محدودیت بلوغ برچسب و تغییر توزیع را نشان می‌دهند، اما سهم علّی هر عامل در recall=24٪ را به‌تنهایی تعیین نمی‌کنند.

### قدم بعدی معتبر برای بهبود

پیش از آزمایش، سیاست یک پنجرهٔ approval با فاصلهٔ بلوغ ثابت از cutoff را با اطلاعات گذشته تعیین کنیم؛ سپس همان cohort، هر دو مدل و gateهای قبلی را فقط روی validationهای زمانی گذشته مقایسه کنیم. calibration هم فقط با دادهٔ مجاز آموزش/validation بررسی شود. این پیشنهاد در این MR روی مدل اعمال نشده است؛ نباید برای بالا بردن عدد، label آینده را وارد train، تقسیم را random، یا test را برای tuning استفاده کنیم. مدل فعلی و candidate alias عوض نشده‌اند.

## سه مفهوم «نسخه»

| مفهوم | مقدار فعلی و تأییدشده |
|---|---|
| نرم‌افزار MLflow client و server | هر دو **3.17.2**؛ server از `/version` خوانده شد |
| نسخهٔ Model Registry | **1** برای `promiseops-late-delivery` |
| هویت immutable مدل | `logistic_regression-bbce02b78c9a` |

MLflow یک ثبت‌کنندهٔ آزمایش است؛ نسخهٔ نرم‌افزار آن را با نسخهٔ مدل اشتباه نگیریم. `requirements-tracking.lock` هم 3.17.2 را pin می‌کند. **کد قدیمی نسخهٔ MLflow را داخل run ذخیره نمی‌کرد**؛ این نقص ردیابی اصلاح شد. نسخهٔ امروز را به‌عنوان نسخهٔ قطعی زمان اجرای run قدیمی جا نمی‌زنیم.

اکنون bundleهای جدید در `software_versions.mlflow`، آموزش در پارامتر `software.mlflow`، و ارزیابی جدید در `evaluation_software.mlflow` نسخه را ثبت می‌کنند. diagnostic و verification هم نسخهٔ runtime را خودکار ذخیره می‌کنند. هیچ metadata تاریخی با حدس بازنویسی نشده است.

## فهرست اجراها برای مشاهده در GitLab و MLflow محلی

| نوع | experiment | run_id | commit اجرا | نسخهٔ MLflow ثبت‌شده در همان run |
|---|---|---|---|---|
| آموزش و validation روی دادهٔ واقعی | `promiseops-late-delivery` | `2a36f281380347fda4d519d514c360a6` | `657f375` | قبلاً ثبت نشده بود |
| test نهایی مدل ثابت روی دادهٔ واقعی | `promiseops-evaluation` | `60508475ae1a4262ac82fc26fc76c8d3` | `63e6b21` | قبلاً ثبت نشده بود |
| بررسی split، seed و recall روی دادهٔ واقعی | `promiseops-diagnostics` | `5cac1fcfc0024a4b961bd44f0af1708e` | `6492860` | **3.17.2** |
| تست نرم‌افزاری با fixtureهای مصنوعی و PostgreSQL/MLflow واقعی | `promiseops-verification` | `f47b4f8bcb74461392434deb4d3d9834` | `6492860` | **3.17.2** |

همه FINISHED هستند. این سرویس MLflow **محلی** است؛ اجرای MLflow گروه/cluster ادعا نشده است. با forward کردن پورت 5000 در VS Code، experiment را در `http://127.0.0.1:5000` باز و run_id را جست‌وجو کنید. GitLab کد، گزارش‌ها و index را نگه می‌دارد؛ خود رابط MLflow را میزبانی نمی‌کند.

فایل `reports/model/mlflow-run-index-2026-11-15.json` نسخهٔ نرم‌افزار، شناسهٔ run/model، زمان UTC، commit، معیارها و مسیر artifactها را کنار هم دارد. گزارش واقعی بررسی: `reports/model/recall-diagnostics-2026-11-15.json`.

## لاگ تست‌ها در MLflow

**218 تست موفق، صفر skip** در Python 3.12.16 اجرا شد؛ یک هشدار deprecation مربوط به Starlette/httpx وجود داشت. fixtureهای تست، دادهٔ واقعی Olist برای سنجش کیفیت مدل نیستند؛ برای همین experiment آن‌ها جداست.

در runِ verification این artifactها موجودند:

- `report.json`: نام، نتیجه و مدت هر تست، تعداد pass/fail/skip، commit و نسخه‌های runtime؛
- `junit.xml`: گزارش استاندارد تست؛
- `pytest.log`: خروجی کامل تست‌ها؛ URIهای احتمالی حاوی credential پاک‌سازی می‌شوند.

نسخهٔ قابل مشاهده در GitLab نیز زیر `reports/model/` ذخیره شده: `software-test-verification-2026-11-15.json`، `software-tests-2026-11-15.xml` و `software-tests-2026-11-15.log`. hashهای report ورودی اصلی را مشخص می‌کنند؛ نسخهٔ artifact پس از redaction ممکن است بایت‌های متفاوتی داشته باشد.

## اجرای مجدد داخل کانتینر

کد همین branch باید در `/tmp/promiseops-mlflow-review/src` کپی شده باشد؛ `CI_COMMIT_SHA` را با commit کامل همان کد تنظیم کنید. از محیط Python 3.12 و MLflow موجود استفاده کنید. برای diagnostic، اتصال دیتابیس واقعی ارزیابی و `PGOPTIONS='-c default_transaction_read_only=on'` لازم است.

```bash
export PYTHONPATH=/tmp/promiseops-mlflow-review/src
export MLFLOW_TRACKING_URI=http://127.0.0.1:5000
python -m promiseops.diagnostics \
  --bundle /app/artifacts/train-2a36f281380347fda4d519d514c360a6/candidate \
  --output /app/artifacts/recall-diagnostics.json
```

پیشرفت هر seed در artifactهای `checks/` از ابتدا در MLflow ثبت می‌شود. مدل‌های تشخیصی register یا deploy نمی‌شوند. برای ثبت نتیجهٔ تستی که واقعاً اجرا کرده‌اید:

```bash
python -m promiseops.verification \
  --junit /app/artifacts/recall-check-tests.xml \
  --log /app/artifacts/recall-check-pytest.log
```

این فرمان تستی نمی‌سازد و تست را اجرا نمی‌کند؛ فایل خروجی اجرای واقعی pytest را می‌خواند. وجود failure یا error باعث وضعیت FAILED می‌شود؛ skipها صریح گزارش می‌شوند. تست‌های دیتابیس فقط روی `promiseops_test` اجرا شدند و دادهٔ آموزش/ارزیابی تغییر نکرد.

## محل تغییرات

- `diagnostics.py`: بررسی مستقل معیار، split و maturity، bootstrap و اجرای seedها؛
- `verification.py`: خواندن JUnit و ثبت لاگ تست؛
- `experiment_log.py`: ثبت report و artifact، read-back و status؛
- `bundle.py` و `evaluation.py`: ثبت نسخهٔ MLflow برای اجراهای آینده؛
- `tracking.py` و `training.py`: یک مسیر مشترکِ best-effort برای خطا، بدون پوشاندن خطای اصلی.

فایل‌های CI، Airflow، API، deployment و index شواهد گروه که متعلق به هم‌تیمی‌هاست تغییر نکرده‌اند. Reviewer این کار یاسین است.
