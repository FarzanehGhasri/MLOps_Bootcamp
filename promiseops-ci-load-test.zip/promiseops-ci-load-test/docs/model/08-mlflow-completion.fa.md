﻿# تکمیل مؤلفه‌های MLflow درسا — 2026-11-15

## محدوده و اولویت

| ترتیب | issue | مسئولیت |
|---|---|---|
| 1 | #14 | tracking client، experiment و smoke check؛ MR !14 |
| 2 | #16، #15 | record قابل پیگیری و worker آموزش |
| 3 | #20 | registry version و alias؛ سرویس از bundle ثابت استفاده می‌کند |
| 4 | #21 | ثبت گزارش پایش پیش از تصمیم آموزش مجدد |
| پشتیبان | #24، #25، #26 | cutoff، مقایسهٔ مدل‌ها، معیارها و منطق پایش |

#12 و #13 قبلاً merge شده‌اند. تسک‌های #17، #18، #19، #22 و #23 متعلق به یاسین هستند و در این تغییر انجام نمی‌شوند. فایل‌های CI، Airflow، Helm، API و index شواهد گروه تغییر نکرده‌اند.

## تغییرات و دلیل

- `training.run_train`: بستن موفق run داخل مسیر مدیریت خطا قرار گرفته؛ شکست مرحلهٔ FINISHED نیز برای FAILED گزارش می‌شود.
- `training.close_failed`: پیام خطا با سیاست redaction تسک #14 ذخیره می‌شود. شکست ثبت tag مانع تلاش مستقل برای ثبت status نمی‌شود. هیچ خطای cleanup نباید خطای اصلی را بپوشاند؛ در قطع کامل MLflow ممکن است run از راه دور RUNNING بماند.
- `worker.main`: یک JSON خطای پاک‌سازی‌شده چاپ می‌شود؛ traceback خامِ حاوی URI احتمالی چاپ نمی‌شود.
- `model.Candidate.run_params`: علاوه بر تنظیمات مدل منتخب، hyperparameterهای هر سه روشِ واقعاً fit‌شده ثبت می‌شوند؛ همهٔ معیارها قبلاً ثبت می‌شدند.
- `monitor_train`: ورودی JSONLِ snapshot ثبت‌شده جایگزین امتیازدهی مجدد با تاریخ ساختگی شده است. نبود history به گزارش بدون آموزش منجر می‌شود. قرارداد در راهنمای 06 آمده است.
- `evaluation`: baseline با داده‌های قابل مشاهده در snapshot آموزشی مدل بازسازی می‌شود؛ گزارش MLflow قبل از FINISHED بازخوانی و تطبیق داده می‌شود. خطاها پاک‌سازی و وضعیت شکست گزارش می‌شود.

هر فایل یک مسئولیت دارد: worker تطبیق CLI/environment، training ترتیب عملیات، record نگاشت شناسنامه به MLflow، registry نسخه/alias، monitor منطق تصمیم و monitor_train ترتیب ثبت و تصمیم. وابستگی‌های دیتابیس و client به توابع داده می‌شوند.

## نتیجهٔ واقعی موجود، قبل از اصلاحات جدید

run آموزش محلی: `2a36f281380347fda4d519d514c360a6`، وضعیت FINISHED؛ candidate registry version 1.

- train: 39,837 سفارش؛ validation: 13,377 سفارش، prevalence حدود 8.71٪؛
- Logistic Regression انتخاب و در برابر baseline پذیرفته شد؛
- validation recall@10%: 0.2412017167؛ precision@10%: 0.2100149477؛ AP: 0.1642249644؛ Brier: 0.0802454106؛
- bundle: `/app/artifacts/train-2a36f281380347fda4d519d514c360a6/candidate`.

این run از کد پیش از اصلاحات جدید تولید شده است. نتیجهٔ validation، نتیجهٔ test نهایی یا اجرای cluster نیست. شناسهٔ کد/دادهٔ authoritative در record همان run است. فایل مدل با تغییر مستندات یا آزمون‌ها دوباره آموزش داده نمی‌شود.

## تست و اجرا

پروژه Python 3.12 می‌خواهد. برای بررسی تغییرات worktree، کد را به پوشهٔ جداگانهٔ کانتینر کپی کنید؛ `/app` همچنان checkout قبلی شماست.

از PowerShell:

```powershell
docker exec promiseops-dev mkdir -p /tmp/promiseops-mlflow-review
docker cp C:\MLops_Bootcamp\promiseops-workflow\src promiseops-dev:/tmp/promiseops-mlflow-review/
docker cp C:\MLops_Bootcamp\promiseops-workflow\tests promiseops-dev:/tmp/promiseops-mlflow-review/
docker cp C:\MLops_Bootcamp\promiseops-workflow\release promiseops-dev:/tmp/promiseops-mlflow-review/
docker cp C:\MLops_Bootcamp\promiseops-workflow\fixtures promiseops-dev:/tmp/promiseops-mlflow-review/
docker cp C:\MLops_Bootcamp\promiseops-workflow\contracts promiseops-dev:/tmp/promiseops-mlflow-review/
docker cp C:\MLops_Bootcamp\promiseops-workflow\pyproject.toml promiseops-dev:/tmp/promiseops-mlflow-review/
docker exec -it -w /tmp/promiseops-mlflow-review promiseops-dev bash
```

سپس داخل کانتینر:

```bash
source /opt/venv/bin/activate
export PYTHONPATH=/tmp/promiseops-mlflow-review/src
export MLFLOW_DISABLE_TELEMETRY=true
# فقط دیتابیس دورریختنی تست؛ تست‌ها schema را پاک می‌کنند:
export PROMISEOPS_TEST_DATABASE_URL=postgresql://promiseops:promiseops-test@host.docker.internal:55432/promiseops_test
python -m pytest tests/test_training_failures.py tests/test_tracking.py tests/test_tracking_mlflow.py tests/test_record.py tests/test_record_mlflow.py tests/test_worker.py tests/test_training_db.py tests/test_registry.py tests/test_registry_mlflow.py tests/test_model.py tests/test_metrics_gates.py tests/test_monitor_train.py tests/test_monitor_train_db.py tests/test_evaluation.py tests/test_evaluation_db.py -q
```

تست‌ها از PostgreSQL آزمایشی و storeهای SQLite موقت MLflow استفاده می‌کنند؛ مدل و alias اجرای شخصی شما را عوض نمی‌کنند. نتیجهٔ تغییر alias در تست صرفاً استقلال مدل بارشده از registry را ثابت می‌کند؛ تکمیل API واقعی در محدودهٔ این MR نیست.

## باقی‌مانده برای پذیرش گروه

- smoke check روی MLflow خود گروه و در دسترس بودن از Job؛ نتیجهٔ local جای آن را نمی‌گیرد؛
- اتصال snapshotهای واقعی producer/replay به worker پایش؛
- مرور یاسین و merge به‌ترتیب وابستگی‌ها؛
- ارزیابی نهایی test و شواهد اجرای cluster، جدا از validation موجود.

برای موارد انجام‌نشده issue را خودکار نمی‌بندیم و production را تغییر نمی‌دهیم.

## نتیجهٔ تست این بازبینی

در 2026-11-15 مجموعهٔ فوق با Python 3.12.16 اجرا شد: **155 passed**، بدون skip؛ یک هشدار deprecation مربوط به وابستگی Starlette/httpx وجود داشت. PostgreSQL فقط `promiseops_test` بود و storeهای MLflow تست موقتی بودند. Ruff روی فایل‌های تغییرکرده با قواعد `E4,E7,E9,F,I`، target Python 3.12 و `--isolated` موفق بود؛ این نتیجه ادعای lint کامل repository یا CI نیست. `git diff --check` هم موفق بود.
