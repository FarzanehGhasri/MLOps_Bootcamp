# نسخه‌ها و aliasها در MLflow Model Registry (issue #20)

این راهنما می‌گوید مدل‌ها چطور در Model Registry ثبت می‌شوند، aliasها چه معنایی دارند، و چرا جابه‌جا کردن alias سرویسِ در حال اجرا را عوض نمی‌کند.

## ۱. خواسته

**از issue #20:**
- نسخه و alias در MLflow طوری مدیریت شوند که تغییر alias سرویس در حال اجرا را بی‌صدا عوض نکند.
- production هیچ‌وقت از alias تغییرپذیر استفاده نمی‌کند. همیشه از bundle ثابت با digest مشخص استفاده می‌کند.
- **معیار قبولی:** تغییر alias بعد از deploy هیچ تغییری در سرویس در حال اجرا ایجاد نکند، و این تست شده باشد.

**از قرارداد (`docs/CONTRACTS.md`) و `README.md` بند ۶:**
- «ثبت candidate در MLflow به معنی انتشار production نیست.»
- «شروع سرویس production هرگز alias تغییرپذیر را resolve نمی‌کند.»
- «تغییر alias در MLflow نباید سرویس در حال اجرا را بی‌صدا عوض کند.»

## ۲. ایدهٔ اصلی: alias فقط یک «اسم» است

| چیز | قابل تغییر؟ | به چه اشاره می‌کند |
|---|---|---|
| alias (مثلاً `candidate`) | بله، هر کسی در MLflow می‌تواند جابه‌جایش کند | به یک شمارهٔ نسخه |
| نسخهٔ registry (1، 2، …) | نه | به bundle یک run مشخص (`runs:/<run_id>/bundle`) |
| bundle | نه | `model.joblib` با SHA256 ثابت |

این دو دنیا **فقط یک بار** به هم می‌رسند: وقتی یک انسان release را آماده می‌کند.

```
worker (#15) ──register_candidate──► نسخهٔ N   ◄── alias «candidate» (worker جابه‌جا می‌کند)
                                          │
تأیید انسانی / release (#19) ──alias_version + download_version──► پوشهٔ bundle (SHA256 ثابت)
                                          │
CI آن پوشه را داخل image می‌گذارد و با digest image را deploy می‌کند
                                          │
API (create_app) هنگام شروع فقط پوشهٔ PROMISEOPS_RELEASE را از دیسک می‌خواند و هیچ‌وقت با MLflow حرف نمی‌زند
```

پس بعد از deploy، جابه‌جا کردن هر alias فقط روی **release بعدی** اثر دارد. سرویس در حال اجرا همان بایت‌هایی را دارد که داخل image است.

## ۳. aliasهای پروژه

| alias | معنی | چه کسی جابه‌جا می‌کند |
|---|---|---|
| `candidate` | آخرین candidate که gateها را پاس کرده | worker، بعد از هر run پذیرفته‌شده |
| `production` | چیزی که الان deploy شده (فقط برای اطلاع) | مرحلهٔ release، بعد از ثبت شواهد deploy (#19 / #23) |

worker هیچ‌وقت به `production` دست نمی‌زند. قرارداد می‌گوید هیچ‌کدام از دو حالت worker نباید production را عوض کنند.

## ۴. فایل‌ها و توابع

| کجا | چه می‌کند | دلیل |
|---|---|---|
| `src/promiseops/registry.py` → `register_candidate` | candidate **پذیرفته‌شده** را نسخهٔ جدید می‌کند. در tagهای نسخه این‌ها می‌آید: `artifact_sha256`، `model_version` و `gate_decision` | با SHA256 همیشه می‌شود فهمید نسخه دقیقاً کدام مدل است |
| همان → `move_alias` | alias را به یک نسخه می‌برد و نسخهٔ قبلی را برمی‌گرداند، برای ثبت در گزارش | alias نمی‌تواند به نسخه‌ای اشاره کند که tag SHA256 ندارد، یعنی قابل بررسی نیست |
| همان → `alias_version` | alias الان به کدام نسخه اشاره می‌کند (یا None) | فقط هنگام آماده کردن release استفاده می‌شود، نه هنگام شروع سرویس |
| همان → `download_version` | bundle دقیق یک نسخه را در پوشهٔ **جدید** کپی و بررسی می‌کند | اینجا جایی است که alias دیگر اهمیتی ندارد. #19 (یاسین) می‌تواند برای ساختن release از همین تابع استفاده کند |
| `src/promiseops/training.py` → `_register_if_accepted` | در worker، بعد از `record.log_record`: اگر accepted بود، نسخه می‌سازد و `candidate` را جابه‌جا می‌کند. شمارهٔ نسخه در tag `promiseops.registry_version` و در خروجی JSON worker (`registry_version`) می‌آید | قرارداد: «`train` fits/evaluates/registers» |

**ترتیب اعتماد در `download_version`** (مثل `record.load_logged_record`):
1. SHA256 داخل `release.json` دانلودشده باید با tag نسخه برابر باشد.
2. بعد `bundle.copy_bundle` SHA256 فایل `model.joblib` را بررسی می‌کند.
3. فقط بعد از این دو، مدل باز (unpickle) می‌شود.

پس bundle جابه‌جاشده در artifact store قبل از اجرای هر کدی کشف می‌شود.

## ۵. تصمیم‌ها و راه‌های رد شده

| تصمیم | راه رد شده | دلیل رد |
|---|---|---|
| فقط candidateهای **accepted** ثبت می‌شوند | ثبت همه، حتی rejected، با یک tag | registry فهرست مدل‌هایی است که انسان می‌تواند منتشر کند. مدل ردشده اگر آنجا باشد ممکن است اشتباهی انتخاب شود. مدل ردشده همچنان در run خودش با bundle و record کامل هست |
| ثبت دوباره برای همان run همان نسخه را برمی‌گرداند | هر بار یک نسخهٔ جدید | Jobی که retry می‌شود نباید برای یک مدل دو نسخه بسازد |
| API فقط از دیسک می‌خواند | API هنگام شروع از `models:/promiseops-late-delivery@production` بخواند | دقیقاً همان چیزی است که قرارداد ممنوع کرده. با هر جابه‌جایی alias، pod بعدی که restart شود بی‌صدا مدل دیگری می‌گرفت |
| source نسخه `runs:/<run_id>/bundle` است | `mlflow.sklearn.log_model` و «logged model» در MLflow 3 | bundle ما (چهار فایل با SHA256) خودش قالب release است. یک قالب دوم با فایل‌های دیگر دو منبع حقیقت می‌ساخت |
| یک ماژول جدا (`registry.py`) | گذاشتن ثبت در `record.py` | `record.py` فقط ثبت در run است و اثر جانبی ندارد. registry وضعیت مشترک تیم را عوض می‌کند (اصل تک‌مسئولیتی) |

## ۶. تست‌ها

| تست | کجا اجرا می‌شود | چه چیزی را ثابت می‌کند |
|---|---|---|
| `tests/test_registry.py` | CI (بدون MLflow) | `api.py` نه MLflow را import می‌کند، نه `registry` را، و `models:/` هم ندارد، پس **ساختاراً** نمی‌تواند alias را resolve کند. مدل ردشده یا مدل run دیگر ثبت نمی‌شود. import کردن `registry` خود MLflow را import نمی‌کند |
| `tests/test_registry_mlflow.py` | محلی، با MLflow واقعی روی SQLite موقت | ثبت، تکرار بی‌اثر، جابه‌جایی alias، رد شدن نسخهٔ بدون tag، دانلود دقیق، رد شدن tag دستکاری‌شده |
| همان → `test_moving_an_alias_after_deploy_does_not_change_the_running_service` | محلی | **تست قبولی #20.** دو نسخه ساخته می‌شود و `production` روی نسخهٔ 1 گذاشته می‌شود. نسخه دانلود و API از آن شروع می‌شود. بعد هر دو alias به نسخهٔ 2 می‌روند. پاسخ `/predict` (model_version و احتمال) عوض نمی‌شود، `/readyz` همچنان 200 است، و حتی بعد از restart سرویس همان نسخهٔ 1 است |
| `tests/test_training_db.py` | محلی، با DB | run اول → نسخهٔ 1 و `candidate` روی آن. run دوم → نسخهٔ 2. run شکست‌خورده هیچ چیزی ثبت نمی‌کند. `production` دست نخورده |

```powershell
$env:PYTHONPATH = "src"
python -m pytest tests/test_registry.py tests/test_registry_mlflow.py -v
```

**اجرای واقعی (2026-11-13):** دادهٔ واقعی فقط‌خواندنی بود و MLflow محلی و تازه (SQLite) بود.
- worker با کد خروج 0 تمام شد و `registry_version` برابر `"1"` بود.
- registry: مدل `promiseops-late-delivery`، aliasها `{candidate: 1}`، و `production` تنظیم نشده.
- source نسخه `runs:/<run_id>/bundle` است و tagها `logistic_regression-0cd8064a6cc2` و `accepted` هستند.

## ۷. وابستگی‌ها و قدم بعد

- این branch (`model/20-alias-management`) روی `model/15-worker-train` ساخته شده، چون ثبت درست بعد از `log_record` در worker انجام می‌شود. MR آن بعد از MR مربوط به #15 تمیز می‌شود.
- **#19 (یاسین، release bundle):** برای انتخاب مدل می‌تواند `alias_version(client, "candidate")` و `download_version(...)` را صدا بزند و خروجی را در `release/` بگذارد. بعد از deploy، `move_alias(client, "production", version)` را صدا بزند تا MLflow نشان دهد چه چیزی منتشر شده.
- **هماهنگی با پویا:** تست ساختاری می‌گوید `api.py` نباید MLflow را import کند. اگر روزی لازم شد، اول باید دربارهٔ قرارداد صحبت کنیم.
