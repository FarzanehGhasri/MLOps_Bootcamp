# تسک #21 — ذخیره گزارش قبل از آموزش

## در کجای پروژه هستیم؟

این بخش ادامه چرخه پایش و آموزش است، نه آزمایش جدید برای افزایش recall. قرارداد `docs/CONTRACTS.md` می‌گوید worker ابتدا گزارش را ذخیره کند و فقط در صورت توصیه retraining آموزش دهد؛ هیچ mode اجازه تغییر production ندارد. معیار مستقیم #21: بدون توصیه، report ثبت شود و هیچ آموزشی اجرا نشود.

## ترتیب اجرا و فایل‌ها

1. `src/promiseops/worker.py` آرگومان `--mode monitor-train`، cutoffها و تنظیمات محیط را می‌خواند و به `run_monitor_train` می‌دهد.
2. `src/promiseops/monitor_train.py` یک run پایش جداگانه می‌سازد و bundle فعلی را با checksum کپی و اعتبارسنجی می‌کند.
3. `assess` همان‌جا snapshotهای واقعی صادرشده توسط `prediction_history.py` را می‌خواند. از score، زمان پیش‌بینی و featureهای ثبت‌شده استفاده می‌شود؛ داده فعلی دوباره امتیازدهی و به گذشته نسبت داده نمی‌شود. فقط مدل incumbent ارزیابی می‌شود.
4. `src/promiseops/monitor.py` با outcomeهای در دسترس تا `as_of`، تعداد سفارش یکتا، کف نمونه، drift و کیفیت delayed-label را بررسی می‌کند. نبود history/reference یا کف نمونه ناکافی مجوز ساخت نتیجه یا آموزش نیست.
5. `persist_record` در `monitor_train.py` فایل `monitoring.json`، متریک‌ها و tagهای تصمیم را در MLflow ثبت می‌کند؛ فایل را دانلود و با همان رکورد مقایسه می‌کند.
6. تغییر این MR: بعد از درخواست FINISHED، وضعیت از MLflow دوباره خوانده می‌شود. اگر FINISHED واقعاً ثبت نشده باشد، worker خطا می‌دهد و آموزش شروع نمی‌شود. خطا در upload، read-back یا پایان run نیز همین مسیر را دارد؛ ثبت FAILED به صورت best effort انجام می‌شود.
7. بدون توصیه، خروجی `trained=false` است. با توصیه و پس از عبور از مرحله ذخیره، `training.run_train` فراخوانی می‌شود؛ مدل جدید همچنان باید از gateها عبور کند. این مسیر production alias را عوض نمی‌کند.

## چرا این اصلاح لازم بود؟

قبلاً محتوای JSON خوانده و بررسی می‌شد، ولی worker پاسخ `set_terminated` را بدون بازخوانی وضعیت نهایی می‌پذیرفت. در صورت تأیید ظاهری سرور بدون ذخیره FINISHED، امکان شروع آموزش با run پایش هنوز RUNNING وجود داشت. اکنون شرط «اول گزارش نهایی و قابل بازیابی، سپس آموزش» صریح است. اگر ثبت انجام شود ولی پاسخ قابل خواندن نباشد، رفتار محافظه‌کارانه توقف است.

## تست‌ها را کجا ببینیم؟

- `tests/test_monitor_persistence.py`: شش تست با MLflow واقعی و SQLite موقت. تصمیم policy تزریق می‌شود تا فقط ترتیب ذخیره/آموزش بررسی شود؛ داده آن مصنوعی است. چهار شکست upload، محتوای read-back، نوشتن FINISHED و ماندن RUNNING مانع فراخوانی آموزش می‌شوند. دو تست دیگر عدم فراخوانی آموزش در تصمیم منفی و ذخیره نهایی قبل از ورود به آموزش در تصمیم مثبت را ثابت می‌کنند.
- `tests/test_monitor_train_db.py`: مسیر PostgreSQL + MLflow، تصمیم منفی و مثبت، ارتباط دو run و CLI واقعی.
- `scripts/verify_monitoring_replay.py`: smoke test محلی روی کپی ایزوله داده واقعی. پنج سفارش، هر کدام دو درخواست API، snapshot اصلی و خروجی JSONL، سپس اجرای worker با ممنوع‌کردن فراخوانی train. این نمونه کوچک آزمون کیفیت آماری مدل نیست.

```bash
python -m pytest tests/test_monitor_train.py tests/test_monitor_persistence.py tests/test_monitor_train_db.py -v
```

تست‌های دیتابیس schema را پاک و بازسازی می‌کنند؛ فقط دیتابیس خالی و موقت با نام منتهی به `_test` برای `PROMISEOPS_TEST_DATABASE_URL` مجاز است. آن را به دیتابیس داده واقعی اشاره ندهید.

## اجرای worker

محیط باید `PROMISEOPS_DATABASE_URL`، `MLFLOW_TRACKING_URI`، `CI_COMMIT_SHA`، مسیر bundle معتبر در `PROMISEOPS_INCUMBENT`، مسیر قابل نوشتن `PROMISEOPS_ARTIFACTS` و فایل snapshot صادرشده در `PROMISEOPS_PREDICTION_HISTORY` داشته باشد. cutoffها را متناسب با bundle و replay مستندشده تعیین کنید:

```bash
python -m promiseops.worker --mode monitor-train \
  --train-end 2017-12-31T23:59:59Z \
  --validation-end 2018-02-28T23:59:59Z \
  --as-of 2018-05-15T00:00:00Z
```

در MLflow، experiment به نام `promiseops-monitoring` را باز کنید؛ `monitoring.json`، tag تصمیم و وضعیت FINISHED را ببینید. در تصمیم منفی نباید training run جدید ایجاد شده باشد. گزارش شواهد این تغییر در `reports/model/issue21-acceptance-2026-11-18.json`، نسخه دانلودشده report کنار آن، و لاگ کامل تست‌ها در MLflow verification ثبت می‌شوند.

اتصال MLflow گروه موضوع مستقل #14 است و هنوز به endpoint معتبر نیاز دارد. نتیجه محلی را نباید اجرای کلاستر یا بهبود recall معرفی کرد. بستن #21 پس از بررسی هم‌تیمی انجام می‌شود؛ این MR آن را خودکار نمی‌بندد.

## نتیجه ثبت‌شده این نسخه

- commit اجرای کد: `0de27a2fce394e9043fe41647882074f1eeba07b`؛ commit بعدی فقط مستندات و شواهد را اضافه می‌کند.
- تست‌های مرتبط: ۴۱ موفق. کل regression با PostgreSQL موقت و MLflow واقعی: **۴۳۱ موفق، صفر failure/error، یک placeholder ردشده**؛ یک warning موجود درباره dependency تست API.
- لاگ و JUnit کامل: `issue21-tests-2026-11-18.log/xml` در `reports/model`؛ run تست MLflow: `9ae79c57403743ab93d9832f580fd657`.
- run پایش داده واقعی: `767c5edd441c4e80847a6ffae53a09d6`، با وضعیت FINISHED، `retrain_recommended=false` و صفر فراخوانی آموزش.
- export تجمعی دارای ۱۰ snapshot بود: پنج سفارش یکتا و پنج snapshot تکراری نادیده گرفته شدند. ده درخواست API این اجرای smoke، شامل retryها، تعداد سفارش یکتا را بالا نبرد.
- هیچ آموزش، ارزیابی جدید recall، تغییر alias یا deployment در replay رخ نداد. مسیر مثبت آموزش در تست integration موجود با داده مصنوعی پوشش داده شد.
