# شناسنامهٔ مدل (issue #16)

> کد: `src/promiseops/record.py` — تست‌ها: `tests/test_record.py` (بدون MLflow) و `tests/test_record_mlflow.py` (با MLflow واقعی)
> پیش‌نیاز: قالب bundle (#12، `bundle.py`) و اتصال MLflow (#14، `tracking.py`)

## ۱. خواسته

`docs/CONTRACTS.md` (بخش Evaluation and release):

> A model record includes model artifact SHA256, immutable model identity, source commit, software versions, dataset/schema identity, train/evaluation cutoffs, label cutoff, cohort hash, metrics and gate decision.

سند پروژه، بخش سوم: «نسخه‌ی کد و داده، cutoffها، cohort ارزیابی و checksum مدل باید مشخص باشند» و همه در MLflow ثبت شوند.

معیار قبولی issue #16: «از record بتوان دقیقاً همان مدل را **بازتولید** یا **تشخیص** داد.»

## ۲. هر بند قرارداد کجاست؟

| بند قرارداد | فیلد | فایل |
|---|---|---|
| SHA256 مدل | `artifact_sha256` (با خود `model.joblib` چک می‌شود) | `release.json` |
| شناسهٔ تغییرناپذیر مدل | `model_version` = `<approach>-<۱۲ کاراکتر اول SHA256>` | `release.json` |
| commit کد | `source_commit` (دو فایل باید یکی باشند) | هر دو |
| نسخهٔ نرم‌افزارها | `software_versions` | `lineage.json` |
| شناسهٔ داده و schema | `dataset_identity` (اثر انگشت receiptهای ثبت داده تا `as_of`، MR !7) و `feature_schema_sha256` (فهرست مرتب featureها) | `lineage.json` |
| cutoffهای آموزش و ارزیابی | `train_end`، `validation_end`، `as_of` | `lineage.json` |
| cutoff برچسب | `training_label_cutoff`، `validation_label_cutoff` | `lineage.json` |
| hash مجموعهٔ ارزیابی | `validation_cohort_sha256` | `lineage.json` |
| معیارها | `validation_metrics` (N، فراوانی دیرکرد، K، recall/precision@10%، PR-AUC، Brier) | `lineage.json` |
| تصمیم gate | `gate_decision`، `gate_reasons`، `champion_model_version` | `lineage.json` |

تست `test_record_covers_every_item_of_the_contract` همین جدول را چک می‌کند: هیچ بندی خالی نباشد.

## ۳. انتخاب‌ها و دلیلشان

### ۳.۱ schema جدید نساختیم؛ شناسنامه از خود bundle ساخته می‌شود
- **چرا:** #12 همهٔ این اطلاعات را در `release.json` و `lineage.json` دارد. اگر یک فایل «شناسنامه» جدا با همان اطلاعات می‌ساختیم، دو نسخه از یک واقعیت داشتیم که ممکن بود با هم فرق کنند.
- **کار #16:** `ModelRecord` همان دو سند را کنار هم می‌گذارد و **چک می‌کند که دربارهٔ یک مدل باشند**: commit یکی، فهرست featureها با hash یکی، `model_version` با `approach` جور. `write_bundle` این را موقع نوشتن چک می‌کند، ولی bundle بعداً ممکن است دستی ویرایش یا قاطی شود.
- **ردشده:** فایل شناسنامهٔ جدا با تکرار اطلاعات.

### ۳.۲ bundle بدون `lineage.json` شناسنامه ندارد
- مدل ساختگی فعلی (احتمال ثابت ۰٫۰۸) فقط `release.json` و `model.joblib` دارد. سرویس می‌تواند آن را بار کند، ولی **قابل حسابرسی و بازتولید نیست**؛ پس `load_record` آن را رد می‌کند با پیام «not auditable».

### ۳.۳ در MLflow هر چیز کجا ثبت می‌شود
| نوع MLflow | چه چیزی | چرا این نوع |
|---|---|---|
| **params** | cutoffها، شناسهٔ داده و schema و cohort، نسخهٔ نرم‌افزارها (`software.<package>`) | این‌ها هنگام آموزش ثابت‌اند؛ param در MLflow بعداً عوض نمی‌شود، که دقیقاً درست است |
| **metrics** | معیارهای ارزیابی (`validation_recall_at_10` و …) | تا runها در UI مرتب و مقایسه شوند |
| **tags** | `artifact_sha256`، `model_version`، commit، تصمیم gate | tag قابل جستجوست و قابل تغییر؛ تصمیم gate **بعد از** آموزش (مقایسه با champion) گرفته می‌شود و param نمی‌توانست بعداً عوض شود |
| **artifacts** | کل bundle با همان بایت‌ها زیر `bundle/` و `record.json` | قرارداد: «bundle دقیق و metadata را در MLflow نگه دارید، نه فقط فایل‌های موقت Job» |

همهٔ params، metrics و tags با **یک** درخواست `log_batch` فرستاده می‌شوند: رفت‌وبرگشت کمتر و همه با هم می‌رسند.

### ۳.۴ بعد از آپلود، دوباره دانلود و چک می‌شود
- سرور MLflow ممکن است run را ثبت کند ولی ذخیره‌گاه فایل‌هایش خراب باشد (مثل #14). پس `log_record` در آخر bundle را دانلود می‌کند و با شناسنامهٔ اصلی مقایسه می‌کند.

### ۳.۵ ترتیب اعتماد هنگام خواندن از MLflow
- `load_logged_record` اول tag `promiseops.artifact_sha256` را از run می‌خواند (جدا از فایل‌ها ثبت شده)، بعد `release.json` دانلودشده را با آن مقایسه می‌کند، و **فقط بعد** `read_bundle` مدل را با SHA256 چک و unpickle می‌کند.
- **چرا:** unpickle کردن یعنی اجرای کد. اگر کسی bundle را در ذخیره‌گاه عوض کند، قبل از اجرای هر کدی گیر می‌افتد.

### ۳.۶ run را worker می‌سازد، نه این ماژول
- `log_record(client, run_id, bundle)` روی runی که worker (#15) ساخته ثبت می‌کند، تا لاگ‌های آموزش و شناسنامه در یک run باشند.
- اگر `lineage.mlflow_run_id` پر باشد و run دیگری را نام ببرد، رد می‌شود (bundle قاطی شده) و **هیچ چیز ثبت نمی‌شود**.

### ۳.۷ ثبت در Model Registry اینجا نیست
- آن کار #20 (alias) است. قرارداد می‌گوید «ثبت candidate در MLflow یعنی انتشار نیست»؛ جدا نگه داشتن آن، این مرحله را بی‌اثر جانبی نگه می‌دارد.

### ۳.۸ ماژول جدا (`record.py`)
- `bundle.py` نباید MLflow را import کند (image سرویس MLflow ندارد) و `tracking.py` فقط اتصال است. شناسنامه هر دو را لازم دارد، پس ماژول خودش را دارد. MLflow فقط داخل تابع‌های ثبت import می‌شود (تست دارد).

## ۴. «تشخیص» و «بازتولید» در عمل

**تشخیص:** سرویس `model_version` را در هر پاسخ برمی‌گرداند و `release.json` آن `artifact_sha256` دارد:

```python
from promiseops.record import find_runs_by_artifact, load_logged_record
run_ids = find_runs_by_artifact(client, "<artifact_sha256>", [experiment_id])
record = load_logged_record(client, run_ids[0])   # همان مدل، چک‌شده
```

SHA256 قبل از رفتن به فیلتر جستجو چک می‌شود (۶۴ کاراکتر hex) تا نشود فیلتر را دستکاری کرد.

**بازتولید:** `record.worker_command()` دستور دقیق قرارداد را می‌دهد، مثلاً:

```
python -m promiseops.worker --mode train --train-end 2017-10-31T23:59:59Z --validation-end 2017-12-31T23:59:59Z --as-of 2018-01-01T00:00:00Z
```

با این شرط‌ها همان مدل ساخته می‌شود:
1. image از همان `source_commit` ساخته شده باشد؛
2. دیتابیس در آن `as_of` همان `dataset_identity` را بدهد (`promiseops dataset-identity --as-of ...` از MR !7)؛
3. نسخهٔ نرم‌افزارها همان `software_versions` باشد (image قفل‌شده این را تضمین می‌کند).

این دستور در `record.json` هم ذخیره می‌شود.

## ۵. اجرا و تست

```powershell
$env:PYTHONPATH = "src"
python -m pytest tests/test_record.py tests/test_record_mlflow.py -v
```

- `tests/test_record.py` (۱۲ تست، در CI هم اجرا می‌شود): پوشش بندهای قرارداد، رد ناسازگاری‌ها، دستور بازتولید، نگاشت به MLflow، import نکردن MLflow.
- `tests/test_record_mlflow.py` (۶ تست، با MLflow 3.17.2 و SQLite موقت): ثبت کامل و خواندن دوباره، پیدا کردن با SHA256، رد bundle متعلق به run دیگر، کشف فایل‌های عوض‌شده.
- آزمون دستی روی MLflow محلی (`http://127.0.0.1:5000`): یک bundle نمونه ثبت، با SHA256 پیدا و دوباره تشخیص داده شد؛ tagها در UI دیده می‌شوند.

## ۶. محدودیت‌ها و وابستگی‌ها

- **این branch روی #12 و #14 ساخته شده** که هنوز merge نشده‌اند (MR !15 و !14). MR این بخش بعد از آن‌ها معنا دارد؛ اگر reviewerها در آن دو تغییری بخواهند، این بخش هم به‌روز می‌شود.
- **`dataset_identity` واقعی** از MR !7 (ثبت داده) می‌آید؛ در تست‌ها مقدار نمونه است.
- **cutoffها، cohort hash و معیارهای واقعی** را بخش features/مدل می‌سازد که هنوز صاحب ندارد؛ این ماژول فقط ثبت و چک‌شان می‌کند.
- **digest image** در شناسنامهٔ آموزش نیست: قرارداد آن را برای «شواهد انتشار» می‌خواهد (همراه نام تأییدکننده)، و Job آموزش آن را در متغیرهای محیطی ندارد.
- ثبت در Model Registry و aliasها: #20.
