# بستهٔ مدل (Model Bundle) — چه بود، چه کردیم، چرا، چطور اجرا کنیم

- مسئول: qbc13-g03-05 (بخش مدل و MLflow) — issue: #12 — branch: `model/12-bundle-format`
- تاریخ: 2026-11-11
- تصمیم رسمی (انگلیسی): [`docs/decisions/0001-model-bundle-format.md`](../decisions/0001-model-bundle-format.md)
- کد: [`src/promiseops/bundle.py`](../../src/promiseops/bundle.py) — تست: [`tests/test_bundle.py`](../../tests/test_bundle.py)

## ۱. بستهٔ مدل چیست و چرا لازم است؟

مدلی که در worker آموزش داده می‌شود باید به API برسد. راه رسیدن آن یک **پوشه** است که به آن «بسته» (bundle) می‌گوییم:

```
<bundle>/
    model.joblib     خود مدل: یک Pipeline از scikit-learn (پیش‌پردازش + طبقه‌بند)
    release.json     شناسنامهٔ سرویس: دقیقاً ۴ فیلدی که API می‌خواند
    lineage.json     شناسنامهٔ کامل: cutoffها، cohort، معیارها، نسخه‌ها، تصمیم gate
    reference.json   مرجع پایش: معیارهای validation و توزیع featureها
```

همین پوشه در MLflow ذخیره می‌شود، در image برنامه در `/opt/promiseops/release` کپی می‌شود و API یک بار در شروع آن را بار می‌کند. اگر همهٔ بخش‌ها (worker، API، CI، پایش) سر شکل این پوشه توافق نداشته باشند، سیستم کار نمی‌کند. این ماژول همان توافق است.

## ۲. قبل از این کار چه وجود داشت؟

| چیز | وضعیت |
|---|---|
| `src/promiseops/model.py` و `worker.py` در starter | فقط تابع خالی با `NotImplementedError` |
| شکل بستهٔ مدل | هیچ‌جا تعریف نشده بود |
| MR !3 از g03-01 (در develop merge شده، 2026-11-13) | loader در `api.py`: پوشه با `model.joblib` + `release.json`؛ hash مدل را چک می‌کند؛ `release.json` با کلاس `ReleaseManifest` فقط **۴ فیلد** دارد و **فیلد اضافه را رد می‌کند** |
| `docs/CONTRACTS.md` | برای هر مدل شناسنامهٔ کامل می‌خواهد: SHA256، commit، نسخهٔ نرم‌افزار، هویت داده، cutoffها، hash cohort، معیارها و تصمیم gate |
| `requirements.lock` (image برنامه) | MLflow ندارد؛ یعنی API نباید به MLflow وابسته باشد |
| develop | job جدید `lint` (`ruff check .`) روی هر MR به develop |

**تعارض:** قرارداد اطلاعات زیادی می‌خواهد، ولی API فقط ۴ فیلد قبول می‌کند.

## ۳. تصمیم

`release.json` دقیقاً با ۴ فیلد API می‌ماند و اطلاعات اضافه در **فایل‌های جدا** (`lineage.json`، `reference.json`) در همان پوشه قرار می‌گیرد. loader فعلی API این فایل‌ها را نمی‌بیند، پس **کد هیچ هم‌تیمی‌ای نباید تغییر کند**. دلیل‌ها و راه‌های ردشده در ADR آمده است.

## ۴. مرحله‌به‌مرحله: چه کردیم و چرا

| # | کار | چرا |
|---|---|---|
| 1 | ساخت branch محلی از `origin/develop` | main و develop دست نخورند؛ MRهای گروه به develop می‌روند؛ به MR !3 گره نخوریم |
| 2 | قطع اتصال branch به develop (`git branch --unset-upstream`) | یک `git push` اشتباه نتواند به develop برود |
| 2b | ساخت issue #12 و تغییر نام branch به `model/12-bundle-format` | هم‌سبک با g03-04؛ GitLab branch و MR را خودکار به issue وصل می‌کند |
| 3 | نوشتن ADR 0001 | دلیل تصمیم برای review و دفاع ثبت شود |
| 4 | نوشتن `bundle.py` | تعریف یک‌جا و قابل تست از شکل بسته (جزئیات پایین) |
| 5 | نوشتن ۲۰ تست در `test_bundle.py` | هر قانون بسته یک تست دارد؛ اگر کسی آن را خراب کند CI قرمز می‌شود |
| 6 | اجرای همهٔ تست‌ها | مطمئن شویم چیزی از تست‌های قبلی خراب نشده |
| 7 | چک با کد واقعی MR !3 (در پوشهٔ موقت، بدون تغییر branch آن‌ها) | ثابت شود loader واقعی API بستهٔ ما را باز می‌کند |
| 8 | اجرای ruff و رفع ۴ ایراد | job `lint` در CI همین را اجرا می‌کند |

### تصمیم‌های داخل `bundle.py`

| تصمیم | چرا |
|---|---|
| MLflow import نمی‌شود | image برنامه MLflow ندارد و API باید در قطعی MLflow هم کار کند |
| برای هر فایل یک کلاس (`ReleaseManifest`، `Lineage`، `ValidationReference`) | اصل S از SOLID: هر کلاس یک مسئولیت و یک دلیل برای تغییر |
| `release.json` مستقیماً با `contracts.ReleaseManifest` (همان کلاسِ loader در API) ساخته می‌شود؛ کلاس جداگانه‌ای در `bundle.py` نداریم | قبلاً یک کپی (`ServingManifest`) داشتیم چون MR !3 هنوز merge نشده بود. بعد از merge، کپی حذف شد (اصل DRY): یک تعریف یعنی نویسنده (worker) و خواننده (API) هرگز از هم جدا نمی‌شوند |
| `model_version = <approach>-<12 حرف اول SHA256>` مثل `baseline-aa856d50bae2` | از محتوای مدل ساخته می‌شود، پس تغییرناپذیر است و به شمارهٔ MLflow وابسته نیست (اصل D) |
| SHA256 قبل از باز کردن مدل چک می‌شود | باز کردن pickle کد اجرا می‌کند؛ فایل دستکاری‌شده نباید باز شود |
| نوشتن atomic (اول پوشهٔ موقت، بعد rename) | کرش وسط کار، بستهٔ نیمه‌کارهٔ «ظاهراً سالم» باقی نمی‌گذارد |
| بستهٔ موجود هرگز بازنویسی نمی‌شود | مدل منتشرشده باید ثابت بماند |
| فقط `predict_proba` از مدل خواسته می‌شود | اصل I و L: هر مدل scikit-learn بدون تغییر کد جایگزین‌پذیر است |
| فقط اشیای scikit-learn pickle می‌شوند | pickle مسیر import کلاس را ذخیره می‌کند؛ کلاس سفارشی بسته را به یک مسیر کد قفل می‌کند |
| `lineage.json` و `reference.json` در خواندن اختیاری‌اند | بستهٔ mock فعلی آن‌ها را ندارد ولی باید بتواند champion باشد |
| K با عدد صحیح حساب می‌شود (`top_k_size`) | در پایتون `0.1*30 = 3.0000000000000004` و `ceil` آن ۴ می‌شود، نه ۳ |
| cutoffها چک می‌شوند: `train_end < validation_end <= as_of` | قانون قرارداد؛ تاریخ بدون منطقهٔ زمانی هم رد می‌شود |
| فایل‌های یک بسته باید با هم جور باشند (commit، cohort، featureها) | جلوگیری از قاطی شدن اطلاعات دو مدل مختلف |

## ۵. چطور اجرا کنم؟

### روش رسمی پروژه (Linux یا WSL، Python 3.12، بستهٔ آفلاین)
همان دستورهای `START_HERE.fa.md`:
```bash
python3.12 -m venv .venv
.venv/bin/python -m pip install --no-index --find-links wheelhouse --require-hashes -r requirements.lock
.venv/bin/python -m pip install --no-deps --no-build-isolation .
PYTHONPATH=src .venv/bin/pytest -q tests/test_bundle.py
.venv/bin/ruff check .
```

### روش سریع روی ویندوز (PowerShell، فقط برای چک محلی)
اگر Python 3.12 ندارید، با 3.13 هم تست‌ها اجرا می‌شوند؛ ضمانت نهایی همان CI است. پوشهٔ `.venv` در `.gitignore` است و وارد Git نمی‌شود.
```powershell
cd C:\MLops_Bootcamp\promiseops
py -3.13 -m venv .venv
.\.venv\Scripts\python.exe -m pip install scikit-learn==1.9.0 pandas==3.0.5 numpy==2.5.3 pydantic==2.13.5 joblib==1.6.0 pytest==9.1.1 ruff==0.17.2 scipy==1.18.1
$env:PYTHONPATH = "src"
.\.venv\Scripts\python.exe -m pytest -q tests/test_bundle.py
.\.venv\Scripts\ruff.exe check .
```
نصب پروژه با `pip install .` روی 3.13 خطا می‌دهد، چون `pyproject.toml` فقط 3.12 را قبول می‌کند؛ برای همین از `PYTHONPATH=src` استفاده می‌کنیم.

### دیدن جزئیات یک تست
```powershell
.\.venv\Scripts\python.exe -m pytest -v tests/test_bundle.py -k round_trip
```
نتیجهٔ مورد انتظار: همهٔ تست‌ها `passed`. دو تست با کد واقعی MR !3 کار می‌کنند: `test_bundle_is_loaded_by_the_api_loader` (بستهٔ ما را `api.load_bundle` باز می‌کند) و `test_incumbent_release_of_the_repo_can_be_a_champion` (بستهٔ فعلی `release/` به‌عنوان champion خوانده می‌شود).

## ۶. چه چیزی هنوز باقی است؟

- ⏳ **`dataset_identity`** در `lineage.json` باید از receiptهای ingestion (بخش داده) بیاید؛ فعلاً در تست‌ها مقدار ساختگی است.
- **API (MR !3)** باید مدل را با یک pandas DataFrame با ستون‌های `feature_names` صدا بزند؛ مدل واقعی ستون‌ها را با نام انتخاب می‌کند.
- محاسبهٔ توزیع featureها برای `reference.json` در مرحلهٔ آموزش (issue بعدی).
- تست روی Python 3.12 در CI هنگام MR.
