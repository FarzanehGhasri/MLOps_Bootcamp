# MLflow client: MR !14 review corrections

Yasin's three review comments concern two credential leaks and an exception raised during cleanup.
This change addresses those comments without changing the tracking client interface or experiment format.

## Requirements and scope

The project PDF, section 3, requires parameters, metrics, model/preprocessing artifacts and lineage in
MLflow. The smoke check establishes the underlying write/read path; it does not replace model logging.
The final notes prohibit credentials in Git and logs. Section 8 requires diagnosis and recovery evidence.
The local command also promises one JSON result and exit code 1 on a tracking failure.

## Production code, line by line

| Changed statement | What it does and why |
|---|---|
| `def redact_error(error: Exception) -> str:` | Gives exception-message sanitization one responsibility, separate from connection and run management. |
| `def replace(match: re.Match[str]) -> str:` | Processes one URL found inside a longer message. An exception sentence is not itself a URL, so applying `redact_uri` to the entire sentence would miss credentials. |
| `try:` | Protects error reporting from malformed URLs in third-party messages. |
| `return redact_uri(match.group())` | Reuses the existing policy: hide URL user information and query strings, and remove fragments. |
| `except ValueError:` | Handles URL parser rejection, such as an invalid IPv6 address. |
| `return "[redacted URI]"` | Removes the unsafe URL rather than returning its raw credentials or replacing the primary error with a parser error. |
| `return re.sub(...)` | Finds every scheme-based URL in the message and replaces it using the helper; text around the URLs remains useful for diagnosis. Whitespace, quotes and angle brackets delimit the URL. |
| First `TrackingUnavailable(...redact_error(error)...)` | Sanitizes experiment/run creation failures before they reach the CLI JSON response. |
| First `from None` | Prevents ordinary formatted tracebacks from displaying the original, unredacted exception chain. The sanitized error retains the failure description. |
| `with contextlib.suppress(Exception):` | Makes updating a failed run best effort; a second network failure must not hide the original logging failure. It does not suppress process-control exceptions such as `KeyboardInterrupt`. |
| `client.set_terminated(run_id, "FAILED")` | Still attempts the failed-run update exactly as before, now inside the protected cleanup block. |
| Existing `if isinstance(error, TrackingError): raise` | Preserves an existing application error unchanged, even if cleanup failed. |
| Second `TrackingUnavailable(...redact_error(error)...)` | Applies the same sanitization to parameter, metric, artifact, and read-back failures. |
| Second `from None` | Also prevents this path from re-exposing credentials through exception chaining. |

If the server cannot accept the failed-run update, the run may remain RUNNING. This fix preserves the
primary diagnostic; it cannot guarantee a remote state transition during an outage. This is URL
redaction for these error paths, not a general-purpose filter for arbitrary secrets or MLflow's own logs.

## Regression tests, step by step

- `traceback` is imported to check ordinary formatted tracebacks in addition to CLI output.
- The sanitizer cases cover plain diagnostic prose, a quoted credentialed URL, and malformed URL input.
- The main regression test runs both creation and logging failure paths with cleanup available or broken.
- Its injected client implements only the operations needed for those failures; no MLflow server is used.
- Two fake URLs contain distinct user information and a query token, so sanitizing just the configured
  tracking address cannot accidentally satisfy the test.
- `probe_server` and `create_client` are replaced at the test boundary; the real `smoke_check` and CLI
  error handling execute, including the cleanup call.
- The test checks exit code 1, exactly one JSON line, the original diagnostic, sanitized URLs, and absence
  of the fake secrets in stdout, stderr, and the formatted traceback.
- It checks that cleanup happens only after a run exists.
- A separate test checks object identity: an existing `TrackingUnavailable` must survive a cleanup failure.

This follows single responsibility by separating sanitization from orchestration, reuses the existing
URI policy, and preserves dependency injection through the supplied client. No new class hierarchy or
production dependency is needed.

## Validation

Before the production fix, the five failure-path regression cases failed and 34 existing tests passed.
After the fix and three sanitizer cases, 42 tests passed. The real-MLflow test module was skipped because
MLflow is absent from the local interpreter. Local execution used Python 3.13.9; the project targets
Python 3.12, so the merge-request pipeline must establish compatibility with the course environment.

```powershell
$env:PYTHONPATH = "src"
python -m pytest tests/test_tracking.py tests/test_tracking_mlflow.py -q
python -m ruff check src/promiseops/tracking.py tests/test_tracking.py
git diff --check
```

The local check does not establish connectivity to the team's MLflow server or acceptance of issue #14's
requirement that a smoke run be visible in its UI.
