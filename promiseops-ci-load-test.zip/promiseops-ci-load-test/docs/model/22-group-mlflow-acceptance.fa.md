# پذیرش اتصال MLflow گروه — تسک #14

## هدف و وضعیت

معیار پذیرش #14 مشاهده یک run واقعی در MLflow گروه و خطای روشن برای تنظیمات یا credential نامعتبر است. این تغییر مدل را آموزش نمی‌دهد، recall را تغییر نمی‌دهد و deployment انجام نمی‌دهد.

بررسی لاگ‌های GitLab نشان داد:

- job شماره 2570 موفق بود، اما smoke run با SQLite موقت داخل CI ساخته شده بود؛ بنابراین اثبات اتصال به گروه نیست.
- job شماره 2743 بعد از موفقیت شش تست، به دلیل نبود `MLFLOW_TRACKING_URI` شکست خورد.
- روی کامپیوتر فعلی Kubernetes current-context تنظیم نیست. آدرس داخلی را نباید حدس زد یا از آدرس UI جایگزین کرد.

## فایل‌ها و دلیل تغییر

1. `src/promiseops/tracking.py`: گزینه `--require-server` ذخیره محلی، SQLite و HTTP loopback را رد می‌کند. HTTP بودن به‌تنهایی اثبات تعلق سرور به گروه نیست؛ آدرس باید از تنظیمات معتبر گروه بیاید و run در UI تأیید شود.
2. همین فایل: ثبت FINISHED و خواندن مجدد وضعیت داخل مسیر مدیریت خطا قرار گرفت. اگر ذخیره وضعیت شکست بخورد یا وضعیت نهایی واقعاً ثبت نشده باشد، خروجی موفق صادر نمی‌شود؛ تلاش برای FAILED کردن، خطای اصلی را نمی‌پوشاند.
3. `.gitlab-ci.yml`: job دستی `group-mlflow-check`، با dependencyهای قفل‌شده موجود، همان smoke check را اجرا می‌کند. job فایل `artifacts/group-mlflow-check.json` را حتی هنگام شکست نگه می‌دارد. اختیاری بودن این job به معنی پذیرش #14 نیست.
4. `tests/test_tracking.py` و `tests/test_tracking_mlflow.py`: رد شواهد محلی، انتقال source commit و شکست ذخیره یا خواندن FINISHED بررسی می‌شود. تست‌های SQLite فقط صحت نرم‌افزار را نشان می‌دهند.

## اجرای گروه، به ترتیب

1. آدرس قابل دسترس برنامه‌ها را از منتور/مسئول محیط بگیرید؛ URI را در متغیر CI به نام `MLFLOW_TRACKING_URI` قرار دهید. اگر احراز هویت لازم است از متغیرهای masked برای `MLFLOW_TRACKING_TOKEN` یا `MLFLOW_TRACKING_USERNAME` و `MLFLOW_TRACKING_PASSWORD` استفاده کنید. متغیرهای protected در MR شاخه غیرمحافظت‌شده ممکن است در دسترس نباشند؛ محدودیت حفاظتی را برای این تست حذف نکنید.
2. در GitLab، pipeline این MR یا develop را باز کنید و job دستی `group-mlflow-check` را اجرا کنید. این job در محیط CI معمولی اجرا می‌شود؛ Pod یا Job آموزشی دستی ایجاد نمی‌کند. دسترسی شبکه CI به سرور باید توسط محیط مجاز باشد.
3. JSON artifact باید `status=ok`، experiment، experiment_id، run_id و source_commit واقعی داشته باشد. smoke check پارامتر، متریک، فایل و وضعیت FINISHED را می‌نویسد و دوباره می‌خواند.
4. وارد `https://g03-mlflow.mlops.qbootcamp.ir` شوید؛ experiment به نام `promiseops-group-acceptance` و دقیقاً همان run_id را پیدا کنید. این run آزمایش اتصال است، نه نتیجه مدل روی داده واقعی.
5. لینک job، artifact و لینک run در UI را در #14 ثبت کنید. سپس پذیرش هم‌تیمی و بسته‌شدن issue انجام شود. تا قبل از این شاهد، تسک باز می‌ماند.

دستور معادل در محیط مجاز و دارای متغیرهای بالا:

```bash
python -m promiseops.tracking check --require-server --experiment promiseops-group-acceptance
```

## اعتبارسنجی این تغییر

روی Python 3.12.16 با MLflow واقعی و SQLite موقت: **56 تست موفق**. این نتیجه، اتصال گروه را اثبات نمی‌کند. هیچ alias، مدل ثبت‌شده یا داده PostgreSQL تغییر نکرده است.
