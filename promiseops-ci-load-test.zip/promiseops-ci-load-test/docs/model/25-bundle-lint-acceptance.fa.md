# تکمیل پذیرش bundle — تسک #12

## هدف

شکل bundle از قبل پیاده‌سازی و merge شده است. هدف این مرحله تکمیل شرط `ruff check .` و بررسی مجدد سازگاری bundle با API است، نه تغییر مدل یا افزایش recall. branch این کار `model/12-bundle-lint-acceptance` است و از develop ساخته شده؛ تغییرات هنوز در حال review مربوط به #26 وارد این branch نشده‌اند.

## bundle فعلی چه دارد؟

| فایل | نقش |
|---|---|
| `model.joblib` | pipeline fitted شامل preprocessing و classifier؛ آموزش و سرویس همین شیء را استفاده می‌کنند. |
| `release.json` | چهار فیلد model_version، feature_names، artifact_sha256 و source_commit؛ قرارداد API عوض نشده است. |
| `lineage.json` | نسخه کد/نرم‌افزار/داده، cutoffها، label cutoff، cohort، معیارها و تصمیم gate. |
| `reference.json` | معیارهای validation و توزیع featureهای train برای پایش. |
| `dataset_manifest.json` | شاهد داده و cohort برای releaseهای جدید؛ checksum آن در lineage بررسی می‌شود. |

`src/promiseops/bundle.py` checksum را قبل از unpickle بررسی می‌کند، فایل‌ها را در پوشه موقت می‌نویسد و سپس rename می‌کند؛ bundle قبلی overwrite نمی‌شود. `api.py` با همین reader بارگذاری می‌کند و برای سرویس به MLflow زنده وابسته نیست. این موارد در این MR تغییر نکردند.

هویت داده دیگر dependency پیاده‌سازی‌نشده نیست: `training.py` از `data.dataset_identity` و receiptهای ingestion استفاده می‌کند. وجود checksum داخل بسته، به‌تنهایی اثبات قابل‌اعتمادبودن منبع pickle نیست؛ کنترل منبع release و تأیید deploy owner همچنان لازم است.

## چه اصلاح شد و چرا؟

1. بررسی اولیه Docker mount ویندوز ۱۳۸ finding نشان می‌داد؛ ۱۰۳ مورد EXE002 به این دلیل بود که mount فایل‌های معمولی Git با mode 100644 را executable نشان می‌دهد. به جای افزودن shebang به همه فایل‌ها یا خاموش‌کردن rule، همان commit با `git archive` روی filesystem بومی Linux استخراج شد.
2. checkout بومی ۳۶ finding واقعی داشت: یک mode نادرست، importهای استفاده‌نشده/نامرتب، چند عبارت کوچک و موارد exception boundary.
3. `scripts/experiment_recall_boost.py`، `src/promiseops/recall_boost.py` و تست‌های مرتبط: importها تمیز شدند. `calibration_study.py` یک تبدیل int اضافی نداشت؛ iteration تست PSI از `.values()` استفاده می‌کند. پارامتر مدل، وزن، cutoff و داده عوض نشدند.
4. `src/promiseops/cli.py`: logger با نام ماژول جای فراخوانی root logger را گرفت؛ محتوای JSON و exit code قبلی حفظ شد.
5. `ci/prepare_release.py`: به دلیل داشتن shebang، Git executable bit از 100644 به 100755 اصلاح شد؛ محتوای اسکریپت دست‌نخورده است.
6. چهارده catch عمومی در مرز API/CLI/MLflow عمداً حفظ شدند و با توضیح جداگانه `noqa: BLE001` گرفتند؛ این مرزها باید failureهای کتابخانه‌ها را به پاسخ امن یا خطای بدون credential تبدیل کنند. محدودکردن بی‌دلیل exceptionها می‌توانست خروجی امن را دور بزند. برای `contracts.instant` هم ValueError عمداً حفظ و `TRY004` فقط در همان خط توضیح داده شد، چون validator باید خطای ورودی را به validation error تبدیل کند. این‌ها ۱۵ استثنای محلی و قابل review هستند؛ هیچ rule یا مجموعه فایل به‌طور سراسری exclude نشده است.
7. `.gitlab-ci.yml`: قبل از pytest در job `contracts` دستور کامل `ruff check .` اضافه شد تا پذیرش lint فقط ادعای محلی نباشد.

## چطور بررسی کنیم؟

در checkout بومی Linux یا CI، با dependencyهای قفل‌شده پروژه:

```bash
python -m ruff check .
python -m pytest tests/test_bundle.py -v
```

تست‌های bundle شامل round-trip، چهار فیلد manifest، بارگذاری توسط API، رد فایل دستکاری‌شده قبل از unpickle، atomic write، ممنوعیت overwrite، copy معتبر و cutoff/label cutoff هستند. برای full suite دارای تست دیتابیس، فقط دیتابیس موقت با نام منتهی به `_test` استفاده شود؛ fixtureها schema را حذف می‌کنند.

اجرای مستقیم lint روی Windows bind mount در Docker ممکن است دوباره EXE002 مصنوعی بدهد. نتیجه CI یا checkout استخراج‌شده با modeهای Git را ملاک قرار دهید؛ rule را برای دورزدن این مشکل حذف نکنید.

## پذیرش نهایی

نتیجه اجرای commit `ab13037f969322338dd3b6fe7145d1cb10c6142b`: lint کامل موفق بود. full suite روی checkout بومی ۴۴۰ تست موفق و دو skip داشت؛ یکی placeholder قدیمی و دیگری تست manifest داده واقعی که در Git archive وجود ندارد. تست دوم جداگانه با داده موجود اجرا شد و موفق بود؛ این دو اجرای جدا در گزارش تفکیک شده‌اند. هیچ failure یا error وجود نداشت و یک warning قدیمی dependency تست API ثبت شد. نتیجه جدیدی برای recall تولید نشده است.

شواهد در `reports/model/issue12-acceptance-2026-11-19.json` و فایل‌های `issue12-*` کنار آن هستند. MLflow محلی: full suite برابر `54c854ac62d24567891808db2b21617c` و تست manifest واقعی برابر `7784eae7a79f4077a450dc2f3599b2a3`. تست manifest فقط بررسی metadata داده است، نه آموزش یا ارزیابی مدل واقعی.

پویا از قبل bundle اصلی !15 را تأیید کرده بود. برای این cleanup دوباره از او review خواسته می‌شود. #12 تا تأیید deploy owner یاسین باز می‌ماند؛ این کار به معنی تأیید منبع release، merge، rollout یا پذیرش credentialهای MLflow گروه نیست. #14 همچنان endpoint معتبر گروه را لازم دارد.
