# آماده‌سازی ML worker برای Airflow — مرحله‌به‌مرحله

## مبنای کار و علت Draft بودن تحویل

کار جدید از آخرین نسخهٔ reviewشده `6ccdae2a35e61a14aea2c02c586059559411aceb` شروع شد. GitLab نشان می‌دهد حساب `qbc13-g03-04` در ۲۰ نوامبر، ساعت 17:00:58 UTC شاخهٔ develop را حذف و در 17:05:01 UTC با commit قدیمی `d32dbe3` ایجاد کرده است. دلیل این اقدام مشخص نیست؛ نام حساب، به‌تنهایی نیت فرد را اثبات نمی‌کند.

بررسی تکمیلی نشان داد یاسین پیش از حذف شاخه، !57 را در ساعت 17:00:48 UTC در main مرج کرده است؛ main در commit `035150fbb9274605910c748e9fe609b8a4d677f1` تمام محتوای reviewشده را دارد. بنابراین نیاز به نوشتن دوبارهٔ اصلاحات نیست؛ develop باید با main هماهنگ شود. فایل‌های main با نسخهٔ حفظ‌شده برابر بودند، هرچند تاریخچه‌ها متفاوت بود.

MR بازیابی !63 هر دو تاریخچه را با merge عادی حفظ و محتوای main را برای develop پیشنهاد می‌کند؛ عمداً Draft است. بازیابی همچنین سیاست CI main را برمی‌گرداند که build/release را به default branch محدود می‌کند؛ مالک deploy باید قصد خود را دربارهٔ این تفاوت با develop قدیمی روشن کند. کار ML جدید جدا از بازیابی review می‌شود و تا حل مبنا نباید وارد develop شود. هیچ force-push یا merge به develop انجام نشده است. package 20 مستقل از شاخه و همچنان موجود است.

## مرحلهٔ ۱ — جلوگیری از مقایسهٔ زمانی نامعتبر

در `src/promiseops/training.py`:

1. شناسنامهٔ champion با `ModelRecord` بررسی می‌شود تا commit و schema مدل با lineage ناسازگار نباشد.
2. پیش از `model.train_candidate`، تابع `validate_champion_cutoffs` تاریخ‌های incumbent را با درخواست مقایسه می‌کند.
3. اگر `train_end` مدل قبلی بعد از شروع validation کاندیدا باشد، مدل قبلی ممکن است روی همان بازه آموزش دیده باشد؛ اجرا رد می‌شود.
4. اگر `validation_end` یا snapshot `as_of` مدل قبلی از مقدار متناظر درخواست جلوتر باشد، آن مقایسهٔ backdated نیز رد می‌شود.
5. تاریخ‌های درخواست و champion با پارامترهای `requested.*` و `champion.*` در MLflow ثبت می‌شوند. خطا، run را FAILED می‌کند؛ هیچ fit یا ثبت candidate انجام نمی‌شود.

cutoffهای برابر برای تکرار همان مقایسهٔ مستند مجازند؛ champion قدیمی روی بازهٔ بعدی نیز مجاز است. اولین مدل، همچنان با baseline فراوانی train مقایسه می‌شود. این guard اثبات دست‌نخورده‌بودن test نیست و مجوز استفاده از test برای تنظیم مدل نمی‌دهد.

### نتیجهٔ بررسی مدل واقعی

مدل `logistic_regression-52d3211cb171` تا پایان دسامبر ۲۰۱۷ آموزش دیده است. پیش‌فرض فعلی `dags/train.py`، train تا اکتبر و validation تا دسامبر است؛ guard جدید این درخواست را **پیش از fit** رد می‌کند. درخواست با cutoffهای خود lineage مدل از guard عبور می‌کند؛ این بررسی فقط سازگاری زمانی است، نه آموزش جدید یا تأیید یک سیاست دائمی retraining.

فایل تست: `tests/test_training_time.py`. مرز برابر، بازهٔ بعدی، آینده‌بودن train/validation/as_of، و عدم فراخوانی fit در حالت خطا پوشش دارند. fixture مدل مصنوعی در `tests/test_monitor_train_db.py` نیز تاریخ‌های سازگار با replay آزمایشی گرفت؛ معیارهای قبولی نرم‌تر نشده‌اند.

## مرحلهٔ ۲ — اتصال خودکار تاریخچهٔ مشاهده‌شده به monitor-train

در `src/promiseops/prediction_history.py` و `src/promiseops/monitor_train.py`:

1. اگر `PROMISEOPS_PREDICTION_HISTORY` صریح تنظیم شده باشد، همان فایل اولویت دارد.
2. در غیر این صورت، worker برای incumbent دارای reference از `prediction_snapshots` و `predictions` در PostgreSQL خروجی می‌گیرد؛ نسخهٔ مدل، SHA256 artifact و `predicted_at <= as_of` فیلتر می‌شوند.
3. فقط score، زمان و featureهای واقعاً ثبت‌شده مصرف می‌شوند؛ `predict_proba` برای ساخت تاریخچهٔ گذشته فراخوانی نمی‌شود. labelهای جاری جای featureهای قدیمی را نمی‌گیرند.
4. فایل JSONL در پوشهٔ اختصاصی همان monitoring run ساخته می‌شود؛ فایل قبلی overwrite نمی‌شود. SHA آن در گزارش و منبع ورودی در پارامتر `prediction_history_source` با مقدار `database`، `provided_file` یا `none` ثبت می‌شود.
5. گزارش و فایل تاریخچه در MLflow ذخیره و بازخوانی می‌شوند. checksum تاریخچهٔ دانلودشده باید با فایل ارزیابی‌شده برابر باشد؛ سپس FINISHED نیز بازخوانی می‌شود و تازه تصمیم پایش در DB منتشر می‌شود.
6. اگر upload/readback/finalization شکست بخورد، run FAILED می‌شود و نه تصمیم منتشر می‌شود و نه fit اجرا می‌شود.
7. نبود snapshot همچنان `no_prediction_history` است؛ نبود reference نیز `no_reference` می‌ماند. برچسب ناکافی یا نبود هر دو کلاس، اجازهٔ retraining خودکار نمی‌دهد.

نام/قرارداد gateway و آرگومان‌های worker عوض نشده‌اند؛ لازم نیست DAG یک مسیر فایل محلی Airflow را به training Job منتقل کند. دادهٔ تاریخچه فقط در DB، فضای موقت worker و MLflow خصوصی قرار می‌گیرد؛ ردیف‌های واقعی به Git اضافه نشده‌اند.

آزمون‌های جدید `tests/test_monitor_snapshot_db.py` از `/predict` واقعی روی PostgreSQL آزمایشی snapshot می‌سازند و export خودکار، تقدم فایل صریح، تاریخچه خالی، شکست upload/readback، عدم انتشار تصمیم و اجرای worker بدون متغیر history را می‌سنجند. فیلتر checksum در `tests/test_prediction_history_db.py` نیز بررسی می‌شود.

## مرحلهٔ ۳ — پیش‌نیاز schema و تحویل به یاسین

بررسی فقط‌خواندنیِ پایگاه محلی `promiseops_evaluation` نشان داد جدول `prediction_snapshots` ندارد. این وضعیت **صفر بودن history نیست؛ پیش‌نیاز schema فراهم نیست**. آن پایگاه تغییر نکرد و migration روی داده واقعی اجرا نشد. آزمون‌های integration از پایگاه disposable با schema v4 استفاده کردند. وضعیت schema پایگاه گروه باید جدا بررسی شود.

قبل از فعال‌شدن DAGها، مالک #17/#18/#22/#23 باید:

- migration reviewشده `promiseops db-init` تا schema v4 را روی DB مورد نظر اجرا و دسترسی لازم را تأیید کند؛
- bundle تأییدشده را در image سرویس و worker derivative قرار دهد و worker image با digest مشخص بسازد؛
- `promiseops_worker_image` و `promiseops_worker_commit` را متناسب با همان image در Airflow تنظیم کند؛
- `train_end`، `validation_end` و `as_of` را طبق replay شرکت تنظیم کند؛ تاریخ ثابت قدیمی فعلی و انتقال‌نیافتن cutoff ingestion باید در #17 حل شوند. تاریخ واقعی سیستم را بدون سیاست به جای زمان شرکت نگذارید؛
- دسترسی worker به DB و MLflow، احراز هویت/Host header در صورت نیاز، و ذخیره/بازخوانی artifact را از همان Job بررسی کند؛
- روی Airflow واقعی parse و اجرای DAG را بررسی کند؛ تست‌های `test_dag_behavior.py` از Airflow شبیه‌سازی‌شده استفاده می‌کنند؛
- HTTP 202 را «ارسال job» بداند، سپس تکمیل job، run واقعی MLflow، commit، dataset/cohort و checksumها را به DagRun وصل کند. رد شدن candidate نتیجهٔ معتبر است؛ اجرای train هیچ alias تولیدی را جابه‌جا نمی‌کند.

## اجرا و مشاهدهٔ نتیجه

دستور worker همان قرارداد موجود است، در image پروژه با dependencyهای قفل‌شده و متغیرهای امن:

```bash
python -m promiseops.worker --mode monitor-train \
  --train-end <documented-train-cutoff> \
  --validation-end <documented-validation-cutoff> \
  --as-of <company-replay-cutoff>
```

برای مسیر DB، متغیر `PROMISEOPS_PREDICTION_HISTORY` را تنظیم نکنید. این مثال placeholder است؛ تاریخ‌ها باید پیش از اجرا انتخاب و مستند شوند. اگر با guard زمانی مواجه شدید، آن را خاموش نکنید و به baseline برنگردید؛ مدل و بازهٔ replay را سازگار کنید.

در experiment `promiseops-monitoring`، پارامتر منبع، artifact `monitoring.json` و پوشهٔ `prediction-history/` را ببینید. در صورت توصیهٔ معتبر، run آموزش در `promiseops-late-delivery` با run پایش لینک می‌شود. مقادیر خام snapshot را در گزارش عمومی داوری کپی نکنید.

آزمون‌ها: `tests/test_training_time.py`، `tests/test_monitor_snapshot_db.py`، regressionهای training/monitoring/decision و کل suite. **۵۸۴ تست موفق، یک تست نمونهٔ قدیمی skipped، صفر failure/error**؛ Ruff کامل نیز روی checkout بومی Linux موفق شد. تست‌ها از PostgreSQL disposable و MLflow واقعی محلی استفاده کردند؛ این شاهد اجرای Airflow یا سرور گروه نیست.

کد آزموده‌شده `f4b28bda2387ede8868bb60c79569b0baebaf5a4` است؛ merge بعدی فقط تاریخچه main را هماهنگ کرد و برابری کامل فایل‌های کد با نسخهٔ آزموده‌شده بررسی شد. در اجرای کامل قبلی، شش test double قدیمی به‌جای شیء bundle یک string برمی‌گرداندند و `log_param` نداشتند؛ fixtureها با قرارداد جدید سازگار شدند، بدون حذف assertionهای ترتیب persistence. هر دو اجرای شکست‌خورده و موفق در MLflow محلی ثبت‌اند:

- FAILED قبلی: `1a1c415438f54ba2af86603f695f15d3`؛ ۵۷۸ موفق، شش failure.
- FINISHED نهایی: `2fd02dde48ce439a906ea4296a273e1d`؛ ۵۸۴ موفق، یک skipped.

شواهد کامل در `reports/model/airflow-ml-readiness-2026-11-20.*` و بررسی واقعی bundle در `reports/model/airflow-ml-readiness-real-bundle-2026-11-20.json` قرار دارد. این تغییر پارامتر مدل، feature، recall یا bundle منتشرشده را تغییر نداده است.
