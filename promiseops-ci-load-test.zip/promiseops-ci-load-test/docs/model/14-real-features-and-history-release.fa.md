# اتصال feature واقعی به سرویس و release دارای سابقه

## رفتار جدید

`/predict` از روی order_id سفارش را در PostgreSQL پیدا می‌کند و به همان feature builder آموزش می‌دهد.
خروجی DataFrame با نام و ترتیب ستون‌های manifest به `predict_proba` همان pipeline ذخیره‌شده می‌رود.
هیچ scaler/encoder دوباره fit نمی‌شود. ورودی صفر ساختگی حذف شد.

snapshot شرکت با `PROMISEOPS_AS_OF`، به‌صورت timestamp دارای timezone قابل تنظیم است.
اگر تنظیم نشده باشد، آخرین زمان batch ثبت‌شده در همان دیتابیس استفاده می‌شود؛ از زمان ساعت سیستم
برای جایگزینی تقویم تاریخی شرکت استفاده نمی‌شود. خواندن‌ها در transaction فقط‌خواندنی با snapshot سازگار انجام می‌شوند.

- سفارش ناشناخته یا منتشرنشده: 404.
- مدل خراب/ناموجود، schema پشتیبانی‌نشده یا دیتابیس غیرقابل‌دسترسی: 503.
- schema ۳۲ستونه بدون lineage و سیاست سابقهٔ معتبر قابل سرویس‌دهی نیست.
- پاسخ خطای دیتابیس یا مدل، exception خام یا credential را برنمی‌گرداند.
- `/readyz` اکنون علاوه بر مدل بارگذاری‌شده، اتصال دیتابیس را نیز بررسی می‌کند.

## worker و bundle

`training.run_train` که worker فراخوانی می‌کند، اکنون `include_history=True` دارد.
schema واقعی ۳۲ستونه و SHA آن از DataFrame آموزشی ساخته می‌شوند، نه از ثابت ۱۵ستونه.
در `lineage.json` سیاست `history_policy=frozen-at-train-end-v1` ثبت و در MLflow نیز log می‌شود.
۱۷ feature سابقه در reference پایش هم ثبت می‌شوند.

نحوهٔ بازسازی سابقه در آموزش، API و ارزیابی:

1. مجموعهٔ منبع تاریخچه از سفارش‌ها و outcomeهای منتشرشده تا `lineage.as_of` همان مدل انتخاب می‌شود.
2. هویت receiptهای آن snapshot باید با `lineage.dataset_identity` برابر باشد؛ backfill یا تغییر receipt قبلی رد می‌شود.
3. برای سفارش‌های train، فقط رویدادهای با زمان دانش **پیش از تأیید همان سفارش** مصرف می‌شوند.
4. برای سفارش‌های پس از train، زمان پرس‌وجوی سابقه در `lineage.train_end` ثابت می‌ماند.
5. سفارش تازه فقط هدف پیش‌بینی است؛ اگر عضو منبع frozen نباشد، حتی در شمارندهٔ حجم سفارش وارد نمی‌شود.

بنابراین این release یک snapshot از منبع دیتابیس را با identity و cutoff نسخه‌دار می‌کند؛
فایل مستقلِ کپیِ تاریخچه داخل bundle ذخیره نشده است. برای بازتولید، همان receiptهای immutable دیتابیس باید موجود باشند.
در نبود آن‌ها، سرویس 503 می‌دهد. سیاست‌های rolling و frozen با هم جایگزین نمی‌شوند.

مدل incumbent با builder و snapshot **خودش** روی همان شناسه‌های validation امتیاز می‌گیرد؛
featureهای سابقهٔ candidate به champion تحمیل نمی‌شوند. ارزیابی نهایی نیز schema و lineage مدل را مصرف می‌کند.
خوانندهٔ JSONL پایش، featureهای متناظر manifest هر مدل را می‌پذیرد و رکورد ناقص را رد می‌کند.
مدل‌های قدیمی ۱۵ستونه همچنان پشتیبانی می‌شوند.

## کنترل‌ها و شواهد

`tests/test_api_features_db.py` با PostgreSQL واقعی، pipeline fitشده و bundle ذخیره‌شده بررسی می‌کند:
برابری احتمال API با مدل آموزش، متفاوت‌بودن پاسخ سفارش‌های با feature متفاوت، 404،
رد تغییر receipt و پشتیبانی از bundle قدیمی ۱۵ستونه.
تست‌های worker و registry، schema ۳۲ستونه و مقایسه با champion را پوشش می‌دهند.
دو تست اضافی، استقلال انتخاب سفارش هدف از منبع تاریخچه و برابری محاسبهٔ subset را کنترل می‌کنند.

مجموعهٔ کامل در اجرای ثبت‌شده: **۳۵۸ passed، یک skip**؛ skip مربوط به placeholder عمومی قدیمی است.
دو تست جدید subset/source پس از آن اضافه و در اجرای هدفمند ماژول تاریخچه (۱۲ passed) بررسی شدند.
تست‌های دیتابیس مرتبط نیز با نسخهٔ بهینه‌شده دوباره اجرا شدند: **۳۸ passed، صفر skip**.

`scripts/verify_release_api.py` مسیر کامل را روی train/validation واقعی اجرا می‌کند:
آموزش پیش‌فرض → gate در برابر baseline → bundle و model record → registry آزمایشی مجزا → API واقعی.
هویت source در شروع و پایان اجرا بررسی می‌شود تا وسط آزمایش کد تغییر نکرده باشد.
روی ۲۰ سفارش، احتمال API با احتمال مستقیم مدل مقایسه می‌شود. test امتیازدهی نمی‌شود.
registry این بررسی SQLite مجزاست و candidate/production موجود در tracking server را جابه‌جا نمی‌کند.
خروجی در `reports/model/integration32-real-data-2026-11-16.json` قرار می‌گیرد.

بررسی نهایی روی دادهٔ واقعی موفق بود: schema=32، مدل `logistic_regression-52d3211cb171`،
recall validation برابر ۲۷٫۷۳٪، precision برابر ۲۴٫۱۴٪، AP=0.190338 و Brier=0.079992.
هر ۲۰ پاسخ واقعی API با احتمال مستقیم pipeline برابر بودند؛ سفارش ناموجود 404 شد.
این اعداد به validation مربوط‌اند؛ ارزیابی test جدید انجام نشد.

شواهد MLflow:

- experiment `promiseops-serving-integration`؛ run نهایی `3d8f0dc95ef044ec8de805a3e877ecb7`.
- run آموزش در registry ایزوله: `bc580b52987a41568a62d53584ae810e`.
- لاگ تست کامل: `65552881f08d4e99835d9ce0f14e0853` در `promiseops-verification`.
- لاگ تست نهایی اتصال: `f6dfd26af5354090a3107727d088d1d7` در همان experiment.
- کد هنگام اجرا هنوز commit نشده بود؛ source hashها در گزارش واقعی ثبت‌اند و طی اجرای نهایی ثابت ماندند.

## فایل‌ها

| فایل | مسئولیت |
|---|---|
| `src/promiseops/api.py` | بارگذاری release یک‌بار هنگام startup و دریافت feature واقعی برای درخواست |
| `src/promiseops/inference.py` | builder مشترکِ آگاه از schema، lineage و snapshot همان release |
| `src/promiseops/features.py` | جداسازی snapshot سابقه از snapshot سفارش جدید |
| `src/promiseops/history_features.py` | منبع frozen مستقل از اهداف درخواست و مرز زمانی strict |
| `src/promiseops/training.py` | پیش‌فرض ۳۲ feature و ثبت schema واقعی و سیاست سابقه |
| `src/promiseops/model.py` | مقایسهٔ champion و candidate روی شناسه و برچسب یکسان با ورودی‌های release خودشان |
| `src/promiseops/bundle.py` و `record.py` | ثبت و log سیاست نسخه‌دار تاریخچه |
| `src/promiseops/evaluation.py` | استفاده از builder همان release در ارزیابی |
| `src/promiseops/drift.py` و `monitor_train.py` | reference و snapshot پایش با schema مدل |

## اجرا

در کانتینر `promiseops-dev`، محیط Python همان `/opt/venv/bin/python` و پروژه `/app` است.
متغیرهای `PROMISEOPS_DATABASE_URL`، `MLFLOW_TRACKING_URI` و `CI_COMMIT_SHA` را مطابق محیط و commit واقعی تنظیم کنید.

```bash
cd /app
export PYTHONPATH=/app/src
export OMP_NUM_THREADS=2
export OPENBLAS_NUM_THREADS=2
# بررسی ایزولهٔ مسیر کامل؛ alias موجود را جابه‌جا نمی‌کند:
/opt/venv/bin/python scripts/verify_release_api.py
```

برای اجرای API با bundle تولیدشده، مسیر `bundle` داخل JSON گزارش را استفاده کنید:

```bash
export PROMISEOPS_RELEASE='/app/artifacts/integration32-4dd2536370bc40cf975d17a5c35fe77b/train-bc580b52987a41568a62d53584ae810e/candidate'
export PROMISEOPS_AS_OF='2018-04-30T00:00:00Z'
export PROMISEOPS_API_KEY='your-local-api-key'
/opt/venv/bin/python -m uvicorn promiseops.api:create_app --factory --host 0.0.0.0 --port 8000
```

`PROMISEOPS_RELEASE` را با مسیر واقعی گزارش جایگزین کنید؛ پوشهٔ release قبلی خودکار تعویض نشده است.
پس از تغییر release، API را restart کنید؛ مدل هنگام startup بارگذاری می‌شود.

```bash
curl -X POST http://127.0.0.1:8000/predict \
  -H "X-API-Key: $PROMISEOPS_API_KEY" -H 'Content-Type: application/json' \
  -d '{"order_id":"an-existing-released-order-id"}'
```

این اصلاح اتصال feature و schema است. قراردادهای دیگر API مثل persistence/idempotency شناسهٔ درخواست
و تکمیل metrics هنوز کار جداگانه دارند. بازسازی سابقه از دیتابیس نیز نیازمند آزمون بار و احتمالاً cache/snapshot
کارآمدتر است؛ تست برابری پاسخ، تضمین latency تولید نیست. production deploy انجام نشده است.
