﻿# Worker پایش و تصمیم آموزش مجدد — تسک #21

## مسئولیت و وابستگی

این بخش متعلق به درسا است: ابتدا گزارش پایش در MLflow ذخیره و بازخوانی می‌شود؛ فقط پس از تأیید ثبت گزارش و وجود توصیه، آموزش اجرا می‌شود. ساخت DAG، ارسال Job، تولید تاریخچهٔ replay و استقرار production در این تغییر پیاده‌سازی نشده‌اند.

## ورودی درست پایش

تاریخچه باید شامل پیش‌بینی‌هایی باشد که قبلاً ثبت شده‌اند. امتیازدهی دوبارهٔ سفارش قدیمی و گذاشتن تاریخ انتشار سفارش به‌عنوان زمان پیش‌بینی، شواهد تاریخی معتبر ایجاد نمی‌کند. آمار مبتنی بر آن روش در نسخهٔ قبلی این راهنما، شواهد اجرای واقعی lifecycle محسوب نمی‌شود.

ورودی اختیاری `PROMISEOPS_PREDICTION_HISTORY` مسیر فایل JSONL است. هر خط باید دقیقاً ستون‌های `monitor.PREDICTION_COLUMNS` را داشته باشد:

- `order_id`: شناسهٔ سفارش؛
- `predicted_at`: زمان واقعی ثبت پیش‌بینی در زمان شرکت، دارای timezone؛
- `risk_probability`: احتمال عددی بین صفر و یک؛
- `model_version`: هویت تغییرناپذیر مدل؛
- هر ۱۵ ستون `features.FEATURE_NAMES`: ویژگی‌هایی که هنگام پیش‌بینی مشاهده شده‌اند.

فایل را تولیدکنندهٔ پیش‌بینی/replay صادر می‌کند. worker مقدار احتمال یا زمان را دوباره تولید نمی‌کند و فقط سطرهای مدل incumbent را ارزیابی می‌کند. checksum فایل در گزارش و پارامترهای MLflow ثبت می‌شود. صحت منشأ snapshotها باید در producer حفظ شود؛ این parser اصالت یک فایل دستی را اثبات نمی‌کند.

## رفتارهای قابل مشاهده

| وضعیت | خروجی | آموزش مجدد |
|---|---|---|
| نبود reference در bundle | `no_reference` | اجرا نمی‌شود |
| نبود تاریخچهٔ ثبت‌شده | `no_prediction_history` | اجرا نمی‌شود |
| تاریخچهٔ معتبر | `assessed`، گزارش #26 | فقط با توصیه و label کافی |
| فایل خراب یا خطای ثبت گزارش | خطا، تلاش برای وضعیت `FAILED` | اجرا نمی‌شود |

گزارش در experiment `promiseops-monitoring`، artifact با نام `monitoring.json` و metrics/tags قابل جست‌وجو ذخیره می‌شود. نبود history هم یک گزارش پایدار ایجاد می‌کند؛ نباید با کیفیت واقعی مدل اشتباه گرفته شود.

## ترتیب فایل‌ها

1. `worker.py`: خواندن آرگومان‌ها و مسیر history از محیط؛
2. `monitor_train.load_prediction_history`: خواندن snapshotها بدون بازسازی پیش‌بینی؛
3. `cohorts.load_labels`: دریافت فقط برچسب‌های معلوم تا `as_of`؛
4. `monitor.build_report`: drift و ارزیابی delayed-label، قواعد #26؛
5. `persist_record`: ثبت گزارش و تطبیق نسخهٔ بازخوانی‌شده؛
6. `training.run_train`: فقط در صورت توصیه، با همان gateهای مدل؛
7. ثبت ارتباط run پایش و run آموزش، بدون تغییر production.

## اجرا داخل کانتینر

همان محیط Python 3.12، اتصال دیتابیس و MLflow آموزش را استفاده کنید. `PROMISEOPS_INCUMBENT` باید به bundle مدل مورد پایش اشاره کند، نه لزوماً مدل نمونهٔ `release/`.

```bash
export PROMISEOPS_INCUMBENT=/app/artifacts/train-TRAIN_RUN_ID/candidate
# فقط اگر فایل واقعی snapshot در دسترس است:
export PROMISEOPS_PREDICTION_HISTORY=/app/artifacts/prediction-history.jsonl
python -m promiseops.worker --mode monitor-train \
  --train-end 2017-12-31T23:59:59Z \
  --validation-end 2018-02-28T23:59:59Z \
  --as-of 2018-06-30T00:00:00Z
```

بدون فایل snapshot، متغیر history را تنظیم نکنید: worker از `prediction_snapshots` در PostgreSQL برای نسخه و checksum دقیق incumbent و تا `as_of` خروجی می‌گیرد. اگر snapshot ثبت‌شده‌ای نباشد، گزارش `no_prediction_history` ثبت می‌شود و آموزشی انجام نمی‌شود. فایل صریح همچنان اولویت دارد. خروجی استفاده‌شده با checksum در MLflow ذخیره و بازخوانی می‌شود؛ هیچ پیش‌بینی قدیمی دوباره ساخته یا backdate نمی‌شود. تاریخ‌های train/validation باید با سیاست آموزش مجدد انتخاب شوند؛ این مثال فقط شکل اجرای worker را نشان می‌دهد.

## بررسی

`tests/test_monitor_train.py` ورودی history، حفظ زمان و احتمال، خطای فایل و نبود history را بررسی می‌کند. `tests/test_monitor_train_db.py` با PostgreSQL آزمایشی و MLflow واقعی محلی ثابت می‌کند که گزارش قبل از آموزش ذخیره می‌شود و بدون توصیه، run آموزش جدیدی ایجاد نمی‌شود. snapshotهای این تست‌ها دادهٔ مصنوعی‌اند و مدرک replay گروه نیستند.

اتصال producer واقعی به این ورودی هنوز یک وابستگی integration است؛ برای تکمیل آن، تسک‌های مسئول replay یا API را به نام درسا انجام نمی‌دهیم.
