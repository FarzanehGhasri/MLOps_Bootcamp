# اتصال به MLflow و آماده‌سازی experiment (issue #14)

> کد: `src/promiseops/tracking.py` — تست‌ها: `tests/test_tracking.py` (بدون MLflow) و `tests/test_tracking_mlflow.py` (با MLflow واقعی)

## ۱. این بخش چه کاری می‌کند؟

پایهٔ مشترک همهٔ کارهای MLflow پروژه است:

1. آدرس MLflow را از متغیر محیطی `MLFLOW_TRACKING_URI` می‌خواند و اگر نباشد یا غلط باشد، خطای **روشن** می‌دهد.
2. experiment را اگر نباشد می‌سازد و اگر باشد همان را برمی‌گرداند (اجرای دوباره چیز تکراری نمی‌سازد).
3. به هر run تگ‌های استاندارد می‌زند: نوع run و commit کد.
4. یک دستور بررسی دارد که یک run آزمایشی ثبت می‌کند و **همه‌چیزش را دوباره می‌خواند** تا ثابت شود MLflow واقعاً کار می‌کند.

کارهای بعدی روی همین ساخته می‌شوند: worker آموزش (#15) مدل و معیارها را ثبت می‌کند، شناسنامهٔ مدل (#16) lineage کامل را، و مدیریت alias (#20) نسخه‌ها را.

## ۲. خواسته‌های مستندهای پروژه و جوابشان

| خواسته | منبع | کجا رعایت شده |
|---|---|---|
| Job آموزش آدرس MLflow را از `MLFLOW_TRACKING_URI` می‌گیرد | `docs/CONTRACTS.md` (Queued worker) | آدرس هیچ‌جا در کد نوشته نشده؛ فقط از همین متغیر |
| پارامترها، معیارها، مدل و preprocessing در MLflow؛ نسخهٔ کد و داده، cutoffها، cohort و checksum مدل مشخص باشد | سند پروژه، بخش سوم | این بخش زیرساخت و تگ commit را می‌دهد؛ بقیه در #15 و #16 روی همین ثبت می‌شوند |
| سرویس هنگام قطع MLflow با مدل بارگذاری‌شده ادامه دهد | سند پروژه، بخش ششم؛ `CONTRACTS.md` | MLflow فقط داخل تابع‌ها import می‌شود؛ import کردن این ماژول به MLflow نیاز ندارد (تست دارد) |
| «قطع MLflow» یکی از رخدادهای روز ۹ است | سند پروژه، بخش هشتم؛ `ASSESSMENT.fa.md` | خطاها روشن و سریع‌اند و می‌گویند مشکل کجاست (بخش ۵) |
| secret در Git و log نیاید | README؛ سند پروژه، نکته‌های کلی | آدرس همیشه بدون رمز چاپ می‌شود (`***@host`)، حتی در `repr` |
| وابستگی‌ها از منابع آمادهٔ دوره | سند پروژه، بخش ششم | نسخهٔ MLflow همان `requirements-tracking.lock` است (3.17.2)؛ وابستگی جدیدی اضافه نشده |

## ۳. انتخاب‌ها و دلیلشان

### ۳.۱ MLflow فقط وقتی لازم است import می‌شود
- **چرا:** image سرویس (API) اصلاً MLflow ندارد؛ فقط image مخصوص worker آن را از `requirements-tracking.lock` نصب می‌کند (`Dockerfile.worker`). تست‌های CI هم فقط `requirements.lock` را نصب می‌کنند. اگر بالای فایل `import mlflow` بود، هر کدی که این ماژول را import کند در آن محیط‌ها می‌شکست.
- **ردشده:** اضافه کردن MLflow به وابستگی‌های اصلی. image سرویس را بزرگ می‌کند و سرویس را به چیزی وابسته می‌کند که طبق قرارداد نباید به آن نیاز داشته باشد.

### ۳.۲ `MlflowClient` با آدرس صریح، نه تابع‌های سراسری
- **چرا:** `mlflow.set_tracking_uri` و `mlflow.start_run` وضعیت سراسری نگه می‌دارند (آدرس فعلی، run فعال). با یک client که آدرس را صریح می‌گیرد، هر فراخوانی معلوم است کجا می‌رود و تست‌ها روی هم اثر نمی‌گذارند.
- **ردشده:** API سراسری `mlflow.*`. ساده‌تر است ولی در تست‌ها و وقتی دو تنظیم داریم، خطاهای پنهان می‌سازد.

### ۳.۳ آدرس بدون scheme رد می‌شود
- **چرا:** MLflow آدرسی مثل `mlruns` را به‌عنوان پوشهٔ محلی قبول می‌کند. داخل Job این پوشه در `/tmp` موقت ساخته می‌شود و با تمام شدن pod، **همهٔ runها بی‌صدا از بین می‌روند**. پس فقط `http`، `https`، `file`، `sqlite` و `postgresql` قبول می‌شود.

### ۳.۴ `ensure_experiment`: «اگر هست بده، اگر نیست بساز»
- **اجرای دوباره:** experiment تکراری ساخته نمی‌شود.
- **دو اجرای هم‌زمان:** اگر کس دیگری بین «پیدا کن» و «بساز» آن را ساخته باشد، از همان استفاده می‌شود.
- **محل artifactها را خود سرور تعیین می‌کند:** مسیری که روی کامپیوتر ما یا `/tmp` یک pod انتخاب شود، برای طرف دیگر قابل نوشتن یا ماندگار نیست.
- **experiment حذف‌شده:** MLflow اسم experiment حذف‌شده را رزرو نگه می‌دارد و خطایش گنگ است. ما می‌گوییم «حذف شده؛ در UI بازگردانی کن».

### ۳.۵ دو experiment جدا
- `promiseops-late-delivery`: runهای آموزش واقعی (#15).
- `promiseops-smoke`: فقط runهای آزمایشی اتصال.
- **چرا:** runهای آزمایشی با runهای واقعی قاطی نمی‌شوند و چون ۳۲ GiB فضا مشترک است، پاک کردنشان ساده است.
- این اسم‌ها با یاسین (DAG و Job) هماهنگ شود.

### ۳.۶ تگ‌های استاندارد
- `promiseops.kind`: نوع run (`smoke`، بعداً `train` و `monitor`).
- `promiseops.source_commit` و `mlflow.source.git.commit`: commit کامل از `CI_COMMIT_SHA`. اولی در صفحهٔ run زیر «Tags» دیده می‌شود؛ دومی تگ استاندارد خود MLflow برای نسخهٔ کد است، تا ابزارها و جستجوی MLflow بدون دانستن اسم‌های ما runها را با commit پیدا کنند.
- اگر `CI_COMMIT_SHA` باشد ولی ۴۰ کاراکتر hex نباشد، خطاست: commit غلط در lineage از نبودنش بدتر است.

### ۳.۷ دستور بررسی همه‌چیز را دوباره می‌خواند
- **چرا:** سرور MLflow اطلاعات run را در دیتابیس و فایل‌ها (artifact) را جای دیگری نگه می‌دارد. ممکن است run ثبت شود ولی ذخیرهٔ فایل خراب باشد. پس پارامتر، معیار و محتوای فایل دوباره خوانده و مقایسه می‌شوند.
- run فقط وقتی `FINISHED` می‌شود که همه درست باشد؛ وگرنه `FAILED` و خطا.

### ۳.۸ بررسی سریع `/health` قبل از کار
- برای آدرس‌های `http(s)` اول `/health` بدون دنبال کردن redirect خوانده می‌شود.
- **چرا:** بدون آن، مشکل‌های رایج یا چند دقیقه در حلقهٔ تلاش دوباره می‌مانند یا با خطای گنگ «response is not JSON» از عمق MLflow بیرون می‌آیند.
- برای دستور بررسی، اگر خودت تنظیم نکرده باشی: ۲ تلاش و ۳۰ ثانیه (پیش‌فرض MLflow ۷ تلاش با فاصلهٔ رو به افزایش است).
- telemetry (آمار استفاده) MLflow مثل `Dockerfile.worker` خاموش است.

### ۳.۹ دستور فعلاً در `cli.py` نیست
- `python -m promiseops.tracking check`
- **چرا:** MR !7 (ingestion) کل `cli.py` را عوض می‌کند. تغییر آن در این branch حتماً conflict می‌ساخت. بعد از merge آن MR، این دستور به `promiseops` اضافه می‌شود.

## ۴. MLflow گروه پشت ورود GitLab است

`https://g03-mlflow.mlops.qbootcamp.ir` رابط **آدم‌ها**ست: هر درخواست (حتی `/health`) به صفحهٔ ورود GitLab فرستاده می‌شود (سند پروژه، بخش نهم: «با حساب GitLab گروه وارد می‌شوید»). برنامه مرورگر ندارد، پس:

- **مرورگر:** UI را با حساب GitLab ببین.
- **Job آموزش داخل کلاستر (`g03-jobs`):** آدرس داخلی را خود dispatcher در `MLFLOW_TRACKING_URI` می‌گذارد.
- **کامپیوتر خودت:** MLflow محلی (بخش ۶).
- اگر آدرس UI را به کد بدهی، خطا دقیقاً همین را می‌گوید: «این آدرس به صفحهٔ ورود می‌رود؛ آدرس برنامه‌ها نیست».

متغیرهای CI گروه را دانشجوها نمی‌بینند (همه Developer هستیم). **سؤال باز برای منتور:** آدرس داخلی MLflow چیست و آیا jobهای CI (`g03-ci`) به آن دسترسی دارند؟ اگر بله، یک job دستی در CI می‌تواند همین دستور بررسی را اجرا کند و run در UI گروه دیده شود (هماهنگی با یاسین، چون `.gitlab-ci.yml` حوزهٔ اوست).

## ۵. خطاها و معنی‌شان

خروجی دستور بررسی در stdout همیشه **دقیقاً یک خط JSON** است تا DAG یا CI بتواند آن را بخواند. MLflow خودش لینک‌های «View run at ...» را با `print` در stdout می‌نویسد؛ این‌ها به stderr فرستاده می‌شوند (در log دیده می‌شوند، ولی JSON را خراب نمی‌کنند). کد خروج: `0` موفق، `1` خطای MLflow، `2` استفادهٔ غلط از دستور.

| پیام (خلاصه) | یعنی | چه کنیم |
|---|---|---|
| `MLFLOW_TRACKING_URI is not set` | متغیر تنظیم نشده | محلی: آدرس MLflow محلی؛ داخل Job باید خودکار باشد → به منتور |
| `has scheme ...` | آدرس بدون scheme یا ناشناخته | آدرس کامل با `http://` یا `sqlite:///` |
| `redirects to ... (a sign-in page)` | آدرس UI به جای آدرس برنامه | بخش ۴ |
| `refused the credentials (HTTP 401/403)` | رمز یا token لازم است یا غلط است | `MLFLOW_TRACKING_TOKEN` یا USERNAME/PASSWORD در محیط (هرگز در Git) |
| `cannot reach MLflow` | سرور خاموش یا آدرس غلط | اگر MLflow دوره است: زمان و همین پیام برای منتور |
| `... is deleted` | experiment در UI حذف شده | بازگردانی در UI یا اسم دیگر |
| `not installed` | MLflow در این محیط نیست | بخش ۶ |
| `artifact ... differs` / `logging/reading failed` | run ثبت شد ولی فایل‌ها خراب‌اند | مشکل artifact storage سرور → منتور |

## ۶. اجرای محلی (کامپیوتر خودت)

```powershell
# ۱. نصب MLflow با همان نسخه‌های image سرور (فقط در محیط توسعه، نه در پروژه):
#    فهرست name==version را از requirements-tracking.lock می‌سازیم (hashها مال Linux هستند).
#    (فایل را در TEMP می‌سازیم تا وارد git نشود.)
$constraints = "$env:TEMP\promiseops-tracking-constraints.txt"
(Get-Content requirements-tracking.lock) -match "^[A-Za-z0-9_.-]+==" | ForEach-Object { ($_ -split " ")[0] } | Set-Content -Encoding ascii $constraints
python -m pip install --only-binary=:all: -c $constraints "mlflow==3.17.2"

# ۲. یک MLflow محلی در پوشهٔ موقت (پنجرهٔ جدا؛ تا آخر کار باز بماند):
mlflow server --host 127.0.0.1 --port 5000 --backend-store-uri sqlite:///$env:TEMP/promiseops-mlflow/mlflow.db --artifacts-destination $env:TEMP/promiseops-mlflow/artifacts

# ۳. بررسی:
$env:MLFLOW_TRACKING_URI = "http://127.0.0.1:5000"
$env:PYTHONPATH = "src"
python -m promiseops.tracking check
# UI: http://127.0.0.1:5000 → experiment «promiseops-smoke»
```

تست‌ها:

```powershell
$env:PYTHONPATH = "src"; python -m pytest tests/test_tracking.py tests/test_tracking_mlflow.py -v
```

- `tests/test_tracking.py` بدون MLflow اجرا می‌شود (در CI هم).
- `tests/test_tracking_mlflow.py` با MLflow واقعی و یک SQLite موقت؛ به هیچ سروری چیزی نمی‌فرستد؛ بدون MLflow skip می‌شود.

**محدودیت:** پروژه Python 3.12 است ولی روی این کامپیوتر 3.13 نصب است. برای این کد فرقی ندارد؛ نتیجهٔ نهایی را CI و image سرور (3.12) تأیید می‌کنند.

## ۷. کارهای بعدی و وابستگی‌ها

- **#15 worker train:** `TrackingConfig.from_env()` + `ensure_experiment(..., TRAINING_EXPERIMENT)` + `run_tags("train", commit)`؛ آنجا `CI_COMMIT_SHA` الزامی می‌شود.
- **#16 شناسنامهٔ مدل:** نسخهٔ داده (`dataset_identity`)، cutoffها، cohort hash و checksum مدل به همین run اضافه می‌شوند. الگوی commit همان `bundle.py` (#12) است؛ بعد از merge شدن #12 یکی می‌شوند.
- **#20 alias:** روی همین client.
- **پیشنهاد CI:** یک job که `requirements-tracking.lock` را از wheelhouse داخلی نصب کند و `tests/test_tracking_mlflow.py` را اجرا کند (با یاسین).
