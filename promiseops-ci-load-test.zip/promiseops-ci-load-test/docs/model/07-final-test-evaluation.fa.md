﻿# ارزیابی نهایی مدل ثابت — بخش سوم سند، تسک‌های #24 و #25

## هدف و دامنه

این ارزیابی، گزارش نهایی مدل انتخاب‌شده با validation است؛ هیچ آموزش، تنظیم hyperparameter یا انتخاب مجددی روی test انجام نشده است. گزارش‌های قدیمی همین بازه در repository وجود دارند، بنابراین این اجرا «بازاجرای قابل پیگیری برای مدل ثابت» است و ادعای نخستین مشاهدهٔ این بازه را ندارد.

## برنامهٔ ثابت پیش از اجرا

برنامه در `reports/model/final-evaluation-plan-2026-11-15.json` و commit `63e6b21` ثبت شد.

| ورودی | مقدار |
|---|---|
| مدل | `logistic_regression-bbce02b78c9a` |
| run آموزش | `2a36f281380347fda4d519d514c360a6` |
| commit آموزش | `657f37526b1b84a009d4701d87e4a3d1c3118352` |
| commit کد ارزیابی | `63e6b219e3c3cf69740b5c24411403a5e2278929` |
| train | سفارش و برچسب تا 2017-12-31T23:59:59Z |
| validation | سفارش‌های بعد از train تا 2018-02-28T23:59:59Z؛ برچسب تا 2018-04-30T00:00:00Z |
| test | سفارش‌های تأییدشده در `(2018-02-28T23:59:59Z, 2018-04-30T23:59:59Z]` |
| cutoff برچسب test | `2018-06-30T00:00:00Z` |

## کنترل‌ها در کد

`src/promiseops/evaluation.py` ابتدا checksum bundle و وجود lineage را بررسی می‌کند. بازهٔ test نباید با train/validation هم‌پوشانی داشته باشد. هویت receiptهای دیتابیس در `lineage.as_of` باید دقیقاً برابر هویت ثبت‌شدهٔ آموزش باشد؛ حذف، تغییر یا اضافه‌کردن batch قدیمی موجب رد ارزیابی می‌شود.

برچسب فقط تا cutoff مصرف می‌شود. سفارش بدون برچسب شمرده و از محاسبهٔ معیار کنار گذاشته می‌شود. حداقل ۱۰۰ سفارش و هر دو کلاس لازم است. مدل و baseline روی شناسه‌های یکسان ارزیابی می‌شوند. احتمال baseline از cohort آموزش در snapshot اصلی آموزش بازسازی می‌شود.

گزارش شامل commit مدل، هویت دادهٔ آموزش و ارزیابی، cutoffها، cohort hash، معیارها، پوشش برچسب و میانگین احتمال پیش‌بینی است. گزارش در MLflow ذخیره و بازخوانی می‌شود؛ سپس run، FINISHED می‌شود. خطاها پاک‌سازی و FAILED به‌صورت best effort ثبت می‌شود.

## اجرای تأییدشده در 2026-11-15

داده‌ها در دیتابیس جداگانهٔ `promiseops_evaluation` تا cutoff برچسب بارگذاری شدند. دیتابیس `promiseops_training` تغییر نکرد. اتصال خود ارزیابی با `PGOPTIONS=-c default_transaction_read_only=on` فقط‌خواندنی بود. هویت snapshot آموزش با مدل تطبیق داشت.

در Bash کانتینر، با محیط Python 3.12 و تنظیم اتصال دیتابیس ارزیابی:

```bash
export PYTHONPATH=/tmp/promiseops-mlflow-review/src
export PGOPTIONS='-c default_transaction_read_only=on'
export MLFLOW_TRACKING_URI=http://127.0.0.1:5000
export CI_COMMIT_SHA=63e6b219e3c3cf69740b5c24411403a5e2278929
python -m promiseops.evaluation \
  --bundle /app/artifacts/train-2a36f281380347fda4d519d514c360a6/candidate \
  --test-start 2018-02-28T23:59:59Z \
  --test-end 2018-04-30T23:59:59Z \
  --label-cutoff 2018-06-30T00:00:00Z \
  --output /app/artifacts/final-test-evaluation-2026-11-15.json \
  --log-to-mlflow
```

این commit باید با کد واقعاً در حال اجرا مطابقت داشته باشد؛ برای اجرای کد تغییرکرده نباید شناسهٔ قبلی را به‌عنوان نسخهٔ کد جدید ثبت کرد.

## نتیجهٔ واقعی

13,745 سفارش در بازه قرار گرفتند. 33 سفارش برچسب معلوم نداشتند؛ معیارها روی **13,712 سفارش** با **11.99٪ دیرکرد** محاسبه شدند. ظرفیت ۱۰٪ برابر 1,372 سفارش بود.

| معیار | مدل روی test | baseline روی همان test | مدل روی validation |
|---|---:|---:|---:|
| Recall@10% | 0.246959 | 0.090633 | 0.241202 |
| Precision@10% | 0.295918 | 0.108601 | 0.210015 |
| Average Precision، با نام pr_auc در کد | 0.227850 | 0.119895 | 0.164225 |
| Brier | 0.107782 | 0.112055 | 0.080245 |

میانگین احتمال مدل **4.3314٪** و نرخ واقعی دیرکرد **11.9895٪** است؛ احتمال‌ها در سطح میانگین کمتر از فراوانی واقعی‌اند. این فاصله محدودیت مهم گزارش است. بالاتر بودن AP در test به‌تنهایی بهترشدن مدل را ثابت نمی‌کند، چون prevalence هم بالاتر است. این اجرا به‌تنهایی نبود overfitting یا علت دقیق فاصلهٔ احتمال را اثبات نمی‌کند.

هیچ تغییری بر مبنای نتیجهٔ test در مدل انجام نشد. هر تغییر آتی باید با سیاست ارزیابی و بازهٔ بعدی ازپیش‌تعیین‌شده سنجیده شود.

## مشاهده و شواهد

- experiment محلی: `promiseops-evaluation`، شناسهٔ 2؛
- run ارزیابی: `60508475ae1a4262ac82fc26fc76c8d3`، وضعیت FINISHED؛
- artifact: `runs:/60508475ae1a4262ac82fc26fc76c8d3/test_evaluation.json`؛
- گزارش aggregate: `reports/model/final-test-evaluation-2026-11-15.json`؛
- زمان، فرمان، commitها و بررسی‌ها: `reports/model/final-evaluation-execution-2026-11-15.json`.

فایل دانلودشده از MLflow با گزارش محلی برابر بود. SHA256 مدل قبل و بعد ثابت ماند و candidate alias همچنان نسخهٔ ۱ بود. production تغییر نکرد. این شواهد local هستند و شامل image digest منتشرشده یا اجرای cluster نیستند. index شواهد گروه که به یاسین assign شده، در این تغییر ویرایش نشده است.

## تست‌ها

`tests/test_evaluation.py`، `tests/test_evaluation_db.py` و `tests/test_training_failures.py`: **15 passed** در Python 3.12.16 با PostgreSQL دورریختنی و MLflow محلی موقت. تست تغییر هویت snapshot آموزش، ارزیابی را رد می‌کند. fixture تست طوری اصلاح شده که batch جدید پس از snapshot آموزش منتشر شود؛ batch قدیمی با تاریخ گذشته به snapshot ثابت اضافه نمی‌شود.

Ruff هدفمند با قواعد E4,E7,E9,F,I و `git diff --check` موفق بودند. اتصال MLflow گروه (#14) و ورودی واقعی prediction history برای پایش (#21) مستقل از این ارزیابی باقی مانده‌اند.
