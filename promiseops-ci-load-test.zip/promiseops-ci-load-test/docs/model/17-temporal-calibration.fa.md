# بررسی calibration زمانی روی نسخهٔ push‌شده — ۲۰۲۶/۱۱/۱۶

## نتیجه و تصمیم

آزمایش بر پایهٔ commit `6f0a886171eb60b8d311497899a2dffd0203c6f1`، همان نسخهٔ منتشرشده در MR !33 انجام شد.
هیچ فایل عملیاتی آن نسخه برای این آزمایش تغییر نکرد؛ ماژول و تست مطالعه جدا اضافه شدند.
پارامترهای LR همان C=0.05 باقی ماندند و test برای fit، انتخاب روش یا ارزیابی مدل استفاده نشد.

Sigmoid برای **همان مدل پایهٔ قدیمی‌تر** Brier و log loss را بهتر کرد؛ recall و AP و اعضای top-K آن را تغییر نداد.
اما برای جداکردن زمانی دادهٔ calibration، مدل پایه با دادهٔ کمتر و سابقهٔ قدیمی‌تر آموزش دیده بود.
این pipeline کالیبره در مقایسه با مدل فعلیِ آموزش‌دیده روی کل train، recall و AP پایین‌تری دارد.
هر دو روش sigmoid و isotonic در هر دو پنجره گیت recall در برابر مدل کامل را رد کردند.
بنابراین این روش holdout به worker یا release پیش‌فرض منتقل نشد و alias/production تغییر نکرد.
این نتیجه حکم کلی دربارهٔ بی‌فایده‌بودن calibration یا همهٔ روش‌های دیگر آن نیست.

## جداسازی بدون leakage

سه مجموعهٔ مجزا برای هر پنجره تعریف شد:

1. **base train:** تأیید و زمان دانش برچسب حداکثر cutoff قدیمی‌تر.
2. **calibration train:** تأیید بعد از cutoff پایه تا train_end بیرونی؛ برچسب باید تا train_end بیرونی آماده باشد.
3. **outer validation:** پس از train_end بیرونی تا validation_end؛ برچسب فقط تا as_of ارزیابی.

| پنجره | cutoff مدل پایه | cutoff برچسب calibration | base train | calibration مجاز | validation |
|---|---|---|---:|---:|---:|
| قبلی | 2017-08-31T23:59:59Z | 2017-10-31T23:59:59Z | ۱۹۸۴۵ | ۶۰۴۱ | ۱۲۷۹۷ |
| فعلی | 2017-10-31T23:59:59Z | 2017-12-31T23:59:59Z | ۲۸۲۰۳ | ۹۰۶۶ | ۱۳۳۷۷ |

featureهای دارای سابقه برای مدل پایه در همان cutoff پایه freeze شدند و در calibration و validation
از همان تعریف استفاده شد. قبل و بعد از fit calibrator، hash مدل پایه کنترل شد تا refit نشود.
`FrozenEstimator` کل pipeline برازش‌شده، شامل preprocessing، را نگه می‌دارد؛ calibrator فقط نگاشت احتمال را یاد می‌گیرد.
Sigmoid و isotonic قبل از fit در plan ثبت شدند؛ تعداد bins ارزیابی ECE ثابت و برابر ۱۰ است.

مدل کاملِ مرجع جداگانه با تمام train مجاز و سابقهٔ frozen در train_end بیرونی fit شد.
مقایسهٔ اثر خود calibration باید با **prefix_uncalibrated** باشد؛ مقایسه با full_train_reference،
هم‌زمان تفاوت دادهٔ آموزشی و cutoff سابقه را هم دارد. نباید افت این دو مدل را تماماً به calibration نسبت داد.
در پنجرهٔ فعلی، علاوه بر ۹۰۶۶ ردیف calibration، ۲۵۶۸ سفارش قدیمی‌تر نیز برچسبشان بعد از cutoff پایه
ولی تا train_end بیرونی آماده شده؛ در base train قدیمی‌تر نبوده‌اند، ولی مدل کامل می‌تواند از آن‌ها استفاده کند.

## نتیجهٔ validation فعلی

همان N=۱۳۳۷۷، فراوانی دیرکرد=۸٫۷۱٪ و K=۱۳۳۸:

| روش | recall@10% | precision@10% | AP | Brier ↓ | میانگین ریسک |
|---|---:|---:|---:|---:|---:|
| **مدل فعلی، کل train** | **۲۷٫۷۳٪** | **۲۴٫۱۴٪** | **0.190338** | 0.079992 | ۳٫۱۷٪ |
| مدل پایهٔ قدیمی‌تر، بدون calibration | ۱۸٫۸۰٪ | ۱۶٫۳۷٪ | 0.150090 | 0.082512 | ۲٫۱۸٪ |
| همان مدل پایه + sigmoid | ۱۸٫۸۰٪ | ۱۶٫۳۷٪ | 0.150090 | **0.079719** | ۴٫۴۶٪ |
| همان مدل پایه + isotonic | ۱۹٫۴۸٪ | ۱۶٫۹۷٪ | 0.136700 | 0.079744 | ۴٫۴۰٪ |
| baseline ثابت با فراوانی calibration | ۱۲٫۱۰٪ | ۱۰٫۵۴٪ | 0.087090 | 0.081087 | ۴٫۷۳٪ |

Sigmoid نسبت به همان پایه، Brier را حدود ۰٫۰۰۲۷۹ و log loss را از 0.345665 به 0.301731 کاهش داد؛
ECE با binهای ثابت نیز از 0.065257 به 0.042444 رسید. هنوز میانگین ریسک از نرخ واقعی پایین‌تر است.
مدل کامل log loss=0.313424 و ECE=0.055589 داشت. بهترشدن این معیارها به‌تنهایی افت recall را جبران نمی‌کند.
گیت عمومی اجازهٔ افت recall را نمی‌دهد و AP sigmoid نیز نسبت به مدل کامل بیش از ۰٫۰۲ افت کرده است.

برای sigmoid هیچ شناسه‌ای از اعضای top-K نسبت به همان پایه عوض نشد؛ بنابراین در این آزمایش
calibration رتبه‌بندی را بهتر نکرد. Isotonic تعداد احتمال‌های متمایز را از ۱۳۳۵۳ به ۴۷ کاهش داد و
tie ایجاد کرد؛ شکست تساوی همچنان order_id است. تغییر recall آن را نباید به‌عنوان بهبود قطعی ranking معرفی کرد.

## پنجرهٔ قبلی و هشدار overfit

| روش | recall validation قبلی | Brier | log loss |
|---|---:|---:|---:|
| مدل کامل مرجع | ۱۷٫۵۶٪ | 0.095426 | 0.396290 |
| پایهٔ قدیمی‌تر بدون calibration | ۱۵٫۰۷٪ | 0.097500 | 0.440710 |
| sigmoid | ۱۵٫۰۷٪ | 0.096233 | 0.415734 |
| isotonic | ۱۴٫۹۲٪ | 0.096262 | **0.511811** |

Isotonic روی calibration-fitting cohort، Brier بهتری از sigmoid داشت، اما روی validation پایدارتر نبود؛
در پنجرهٔ قبلی حتی log loss آن از مدل پایه بدتر شد. این هشدار تعمیم است و دلیل انتخاب خودکار روش پیچیده‌تر نیست.
امتیازهای calibration-fitting ظاهری و خوش‌بینانه‌اند؛ دادهٔ آن با validation نرخ دیرکرد و maturity متفاوتی دارد.

از ۱۲۸۳۲ سفارش بالقوهٔ calibration فعلی، ۳۷۶۶ برچسب تا cutoff آموزش آماده نشده بود؛
فراوانی مثبت‌های قابل‌استفاده ۴٫۷۳٪ است، در حالی که validation ۸٫۷۱٪ دیرکرد دارد.
در پنجرهٔ قبلی نیز ۲۵۶۹ سفارش از ۸۶۱۰ مورد حذف شده و نرخ مثبت calibration فقط ۲٫۵۵٪ بود،
در برابر ۱۰٫۰۶٪ در validation. بنابراین این holdout همچنان با محدودیت بلوغ برچسب و تغییر توزیع زمانی روبه‌روست.
تمام اختلاف را نمی‌توان صرفاً به overfit یا صرفاً به drift نسبت داد.

## کنترل‌های صحت، artifact و محدودیت‌ها

- مرزهای زمانی، نرسیدن برچسب، عدم هم‌پوشانی و عدم refit مدل پایه تست شدند.
- pipelineهای مدل کامل، پایه، sigmoid و isotonic در MLflow ذخیره و دانلود شدند؛ احتمال‌ها بعد از دانلود برابر بود.
- SHA256 مدل‌ها، schema، cutoff تاریخچه، cutoff calibration و پارامترها کنار هر artifact ثبت شدند.
- در process تازه نیز pipelineهای sigmoid و isotonic بارگذاری و با ورودی مصنوعی ۳۲ستونه smoke-test شدند؛
  این تست serialization است و ادعای عملکرد واقعی ندارد.
- source hashها در شروع و پایان اجرای واقعی ثابت بودند. کتابخانه‌ها همان نسخه‌های قفل‌شدهٔ پروژه‌اند.
- ۳۷ تست مرتبط passed، صفر skipped؛ بررسی Ruff نیز موفق بود.
- run لاگ تست‌ها: `a0f1860823bc4b5fa0d501ddf85ac2f3` در `promiseops-verification`.
- validationها قبلاً دیده شده‌اند و پنجره‌ها مستقل نیستند. این بررسی اکتشافی است، نه test نهایی مستقل.
- نگاشت‌های calibrated این مطالعه experimental هستند. قبل از انتشار باید cutoff مستقل base fit،
  calibration و freeze تاریخچه در نسخهٔ جدید lineage/policy سرویس پشتیبانی شود؛ قرار دادن مستقیم این joblibها
  در release فعلی با train_end بیرونی، تاریخچهٔ اشتباه می‌سازد.

## مسیرها و بازتولید

- `src/promiseops/calibration_study.py`
- `tests/test_calibration_study.py`
- `reports/model/temporal-calibration-2026-11-16.json`
- `reports/model/temporal-calibration-tests-2026-11-16.log` و `.xml`
- experiment: `promiseops-temporal-calibration`؛ run: `754840a2659b4ba692bf5a824420fa2f`.
- artifactها: `plan-before-fit.json`، `report.json`، `experimental-models/` و `separate-process-load-check.txt`.

در Bash کانتینر دارای کد جدید، با متغیرهای دیتابیس، MLflow و CI_COMMIT_SHA مطابق نسخهٔ واقعی:

```bash
export PYTHONPATH=/app/src
export OMP_NUM_THREADS=2
export OPENBLAS_NUM_THREADS=2
/opt/venv/bin/python -m promiseops.calibration_study --output /app/artifacts/calibration-new.json
```

برنامهٔ مطالعه هنگام اجرای اولیه هنوز commit نشده بود و hash آن در plan ثبت است؛
base_commit=6f0a886 معرف نسخهٔ عملیاتی تحت بررسی است، نه به‌تنهایی کد ماژول آزمایش جدید.

قدم احتمالی بعدی، بررسی cross-fitting زمانی برای calibration با حفظ دادهٔ بیشترِ مدل نهایی است؛
انتقال نگاشت از مدل‌های prefix به مدل نهایی خودش می‌تواند distribution shift بسازد و نیازمند آزمایش جداست.
در این مطالعه پیاده‌سازی یا تأیید نشده و بهبودش تضمین نشده است.
