# worker با حالت train (issue #15)

این راهنما توضیح می‌دهد worker آموزش چه می‌کند، هر قسمت در کدام فایل است، چرا این‌طور ساخته شده، و چطور اجرایش کنیم.

## ۱. خواسته

**از سند پروژه (بخش‌های سوم و چهارم):**
- آموزش از طریق Job صف‌دار و worker گروه انجام می‌شود، نه داخل scheduler.
- candidate و champion روی cohort یکسان مقایسه می‌شوند و gateهای قرارداد اعمال می‌شوند. مدل ضعیف‌تر نباید منتشر شود.
- برای اولین candidate، مقایسه با baseline است.
- پارامترها، معیارها، مدل و preprocessing در MLflow ثبت می‌شوند. ثبت در MLflow به معنی انتشار نیست.

**از `docs/CONTRACTS.md` (بخش Queued worker interface):**
- dispatcher دقیقاً این دستور را اجرا می‌کند:
  `python -m promiseops.worker --mode MODE --train-end ... --validation-end ... --as-of ...`
- نسخهٔ فعلی سرویس (incumbent) داخل image در `/opt/promiseops/release` است. قبل از مقایسه باید در پوشهٔ قابل‌نوشتن کپی شود.
- خود bundle و اطلاعاتش باید در MLflow ذخیره شود، نه فقط در فایل‌های موقت Job.
- هیچ‌کدام از دو حالت production را عوض نمی‌کند.

**معیار قبولی issue #15:**
- اجرای محلی با داده‌های آزمایشی سبز باشد.
- در MLflow این‌ها ثبت شده باشد: params، metrics، و artifact مدل همراه preprocessing.

## ۲. ساختار: هر فایل یک کار

| فایل | کار | چرا جدا |
|---|---|---|
| `src/promiseops/worker.py` | خواندن دستور و متغیرهای محیطی، باز کردن DB و MLflow، و برگرداندن کد خروج (0 یا 1) | فقط «اتصال Job به کد» است. اگر روش اجرا عوض شود، فقط همین فایل عوض می‌شود |
| `src/promiseops/training.py` | ترتیب مراحل یک بار آموزش | DB و MLflow از بیرون به آن داده می‌شود (وارونگی وابستگی، D در SOLID)، پس بدون Job و بدون سرور تست می‌شود |
| ماژول‌های قبلی | خود کارها | worker هیچ منطق مدل یا معیار تکراری ندارد. فقط آن‌ها را به ترتیب صدا می‌زند |

**راه رد شده:** گذاشتن همه چیز در `worker.py`. در آن صورت خواندن env، اتصال، آموزش و ثبت در یک تابع قاطی می‌شد و فقط با یک Job واقعی قابل تست بود.

## ۳. مراحل `training.run_train`

| مرحله | کار | کجای کد | دلیل |
|---|---|---|---|
| 1 | ساختن run در MLflow، قبل از آموزش | `tracking.ensure_experiment` و `client.create_run` | اگر MLflow در دسترس نباشد، در چند ثانیه شکست می‌خورد، نه بعد از چند دقیقه آموزش |
| 2 | کپی incumbent در `PROMISEOPS_ARTIFACTS/train-<run_id>/champion` و بررسی hash | `bundle.copy_bundle` و `training.load_champion` | خواستهٔ قرارداد. بستهٔ خراب هرگز استفاده نمی‌شود |
| 3 | آموزش baseline و دو مدل | `model.train_candidate` (#24، #25) | |
| 4 | مقایسهٔ candidate با champion روی همان سفارش‌های validation | `model.compare_candidate` (#25) | champion هر بار دوباره امتیاز می‌گیرد. قرارداد می‌گوید «A changed champion requires reevaluation» |
| 5 | ساختن reference برای پایش | `drift.build_reference` (#26) | monitor-train (#21) بعداً drift را با همین مقایسه می‌کند |
| 6 | ساختن lineage و نوشتن bundle | `training.build_lineage` و `bundle.write_bundle` (#12) | همهٔ موارد «model record» قرارداد، از جمله `dataset_identity` از رسیدهای ثبت داده (`data.dataset_identity`) |
| 7 | ثبت جزئیات مقایسه در MLflow | `training.comparison_values` | hyperparameterها (`hp.*`)، امتیاز هر روش (`baseline.*`، `logistic_regression.*`، `hist_gradient_boosting.*`) و امتیاز champion (`champion.*`) |
| 8 | ثبت bundle و record در MLflow، و دوباره خواندن و بررسی | `record.log_record` (#16) | ممکن است سرور run را بپذیرد ولی artifact خراب ذخیره شود |
| 9 | اگر accepted بود: نسخهٔ جدید در Model Registry و جابه‌جایی alias `candidate`. به `production` دست نمی‌زند | `training._register_if_accepted` و `registry` (#20) | قرارداد: «`train` fits/evaluates/registers». راهنما: [05-registry-aliases.fa.md](05-registry-aliases.fa.md) |
| 10 | بستن run با وضعیت FINISHED. در صورت خطا FAILED، با دلیل در tag `promiseops.error` | `training.run_train` | خطا هم در MLflow دیده می‌شود، نه فقط در لاگ Job |

**rejected خطا نیست.** اگر candidate از gate رد شود، run با وضعیت FINISHED و `gate_decision=rejected` بسته می‌شود و کد خروج 0 است. قرارداد می‌گوید «Rejection is a valid lifecycle outcome».

## ۴. champion کیست؟ (`training.load_champion`)

| incumbent | champion | دلیل |
|---|---|---|
| `lineage.json` دارد، یعنی با همین pipeline آموزش دیده | خود همان مدل | قرارداد: candidate و champion روی cohort یکسان |
| `lineage.json` ندارد. امروز: مدل ساختگی ثابت پویا (MR !3، `baseline-constant-v1`) | baseline با فراوانی دیرکرد در train | آن مدل record ندارد و قابل بررسی نیست. پس هنوز «champion آموزش‌دیده» نداریم و قاعدهٔ قرارداد برای اولین candidate اجرا می‌شود. نسخهٔ incumbent در tag `promiseops.incumbent_model_version` ثبت می‌شود |
| feature‌هایش با کد فعلی فرق دارد | خطا (`TrainingError`) | مقایسه روی ورودی‌های متفاوت gateها را بی‌معنی می‌کند |

**راه رد شده:** مقایسه با خود مدل ساختگی (عدد ثابت 0.08). ترتیب امتیازهایش مثل baseline است، ولی قرارداد صریحاً «training-prevalence baseline» می‌خواهد و 0.08 از دادهٔ train نیامده است.

## ۵. متغیرهای محیطی

| متغیر | پیش‌فرض | توضیح |
|---|---|---|
| `PROMISEOPS_DATABASE_URL` | الزامی | PostgreSQL گروه |
| `MLFLOW_TRACKING_URI` | الزامی | MLflow گروه. مسیر ساده (بدون scheme) رد می‌شود، چون در Job به `/tmp` می‌رود و از بین می‌رود |
| `CI_COMMIT_SHA` | الزامی، ۴۰ کاراکتر hex | بدون آن record ناقص است، پس worker شروع نمی‌کند |
| `PROMISEOPS_ARTIFACTS` | `/tmp/artifacts` | پوشهٔ قابل‌نوشتن. هر run پوشهٔ `train-<run_id>` خودش را دارد و چیزی بازنویسی نمی‌شود |
| `PROMISEOPS_INCUMBENT` | `/opt/promiseops/release` | فقط برای اجرای محلی عوض می‌شود |

**کد خروج:**
- `0`: مدل آموزش دید و ثبت شد. آخرین خط stdout یک JSON است با `mlflow_run_id`، `model_version`، `gate_decision` و بقیه.
- `1`: شکست. پیام خطا و traceback در stderr چاپ می‌شود.

## ۶. اجرا

**تست‌ها:**
- بدون DB (مثل CI): `tests/test_worker.py`
- با DB و MLflow محلی: `tests/test_training_db.py`

```powershell
$env:PYTHONPATH = "src"
python -m pytest tests/test_worker.py -v
# فقط روی دیتابیس خالی آزمایشی (اسمش با _test تمام شود)، نه دیتابیس دادهٔ واقعی:
$env:PROMISEOPS_TEST_DATABASE_URL = "postgresql://...@127.0.0.1:55432/promiseops_unit_test"
python -m pytest tests/test_training_db.py -v
```

**اجرای کامل با دستور خود dispatcher، با MLflow محلی (SQLite):**

```powershell
$env:PROMISEOPS_DATABASE_URL = "postgresql://...?options=-c%20default_transaction_read_only%3Don"
$env:MLFLOW_TRACKING_URI = "sqlite:///C:/temp/mlflow.db"
$env:CI_COMMIT_SHA = (git rev-parse HEAD)
$env:PROMISEOPS_ARTIFACTS = "C:\temp\artifacts"
$env:PROMISEOPS_INCUMBENT = "release"
python -m promiseops.worker --mode train --train-end 2017-12-31T23:59:59Z --validation-end 2018-02-28T23:59:59Z --as-of 2018-04-30T00:00:00Z
```

`default_transaction_read_only=on` باعث می‌شود خود PostgreSQL هر نوشتنی را رد کند. worker فقط می‌خواند، ولی این قفل خیال را راحت می‌کند.

## ۷. نتیجه روی دادهٔ واقعی (2026-11-13، فقط خواندنی، MLflow محلی)

| مورد | مقدار |
|---|---|
| validation | N = 13,377 و فراوانی دیرکرد 8.71% |
| روش انتخاب‌شده | `logistic_regression` (`logistic_regression-0cd8064a6cc2`) |
| recall@10% | 0.2412 (baseline 0.1210، HGB 0.2146) |
| PR-AUC / Brier | 0.1642 / 0.0802 (baseline 0.0871 / 0.0818) |
| champion | `baseline-training-prevalence`، چون incumbent فعلی مدل ساختگی بدون record است |
| تصمیم gate | accepted، هر سه gate پاس شد |
| در MLflow | run با وضعیت FINISHED، ۵۰ param، ۳۵ metric، و `bundle/` با هر چهار فایل (`model.joblib`، `release.json`، `lineage.json`، `reference.json`) |

این اعداد با نتیجهٔ #25 یکی است. پس worker همان مدل را می‌سازد و فقط ثبتش را اضافه می‌کند.

## ۸. وابستگی‌ها و سؤال‌های باز

- **وابستگی:** این branch روی MR !19 (#26) و شاخهٔ `model/16-model-record` (#16) ساخته شده. #16 هم روی MR !14 (#14) است. MR مربوط به #15 بعد از merge شدن آن‌ها تمیز می‌شود.
- **سؤال باز برای منتور:** قرارداد `PROMISEOPS_RELEASE=/tmp/artifacts/release.json` را هم نام می‌برد، ولی نمی‌گوید worker با آن چه کند. فعلاً worker از آن استفاده نمی‌کند و نتیجه را در stdout و MLflow می‌گذارد.
- **سؤال باز قبلی:** آدرس داخل کلاستر MLflow. آدرس عمومی پشت ورود GitLab است.
- **قدم بعد:**
  - #21 (monitor-train): انجام شد. همین `training.run_train` را فقط وقتی گزارش پایش توصیه کند صدا می‌زند. [06-worker-monitor-train.fa.md](06-worker-monitor-train.fa.md) را ببینید.
  - #20 (alias): انجام شد. [05-registry-aliases.fa.md](05-registry-aliases.fa.md) را ببینید.
