# بستهٔ قابل دریافت برای ارائه — تسک‌های #12 و #19

## وضعیت تحویل

بستهٔ واقعی مدل ۳۲ ویژگی، بدون آموزش مجدد یا تغییر حتی یک بایت از فایل‌های مدل، در GitLab Package Registry منتشر شد:

**[دریافت بسته از GitLab — package 20](https://gitlab.mlops.qbootcamp.ir/qbc13/g03/promiseops/-/packages/20)**

- نام package: `promiseops-model-bundle`
- نسخه: `candidate-52d3211cb171`
- وضعیت: **کاندیدای ارزیابی‌شده، منتظر review مستقل پویا**؛ انتشار package به معنی تأیید نهایی یا استقرار نیست.
- مدل: `logistic_regression-52d3211cb171`
- commit واقعی آموزش: `33087533de58a083c5b6d0888c4523936f0f2e47`
- commit کد بسته‌بندی آزموده‌شده: `2fa5c1a87c1e2304b8b96edfc8471d1d3e311dca`
- SHA256 مدل: `52d3211cb17113b7eeea3c9c27f5e81eee462a8683be77ba3c722b26da033657`
- SHA256 آرشیو: `d0db9e2687166f11565ece2315e32e256a5157569688d12a7b05a445340daac1`

checksum آرشیو با checksum مدل فرق دارد: اولی تمام بستهٔ فشرده را بررسی می‌کند، دومی فقط `model.joblib` را. داور برای دریافت package خصوصی به دسترسی GitLab نیاز دارد؛ هیچ token در فایل‌ها یا لینک قرار نگرفته است.

## داخل package و داخل bundle چیست؟

| فایل package | کاربرد |
|---|---|
| `bundle.tar.gz` | آرشیو قابل دریافت و قابل استفاده در مسیر prepare-release موجود |
| `manifest.json` | نسخه و هویت مدل، SHA256 آرشیو و تک‌تک فایل‌ها، اندازه‌ها، source commit، وضعیت candidate و ارتباط با گزارش ارزیابی |
| `SHA256SUMS` | checksum آرشیو برای بررسی ساده پس از دانلود |

داخل آرشیو دقیقاً پنج فایل در ریشه است:

| فایل bundle | محتوا |
|---|---|
| `model.joblib` | Pipeline fitted شامل preprocessing و Logistic Regression؛ ذخیرهٔ مجدد نشده است |
| `release.json` | چهار فیلد قرارداد سرویس: model_version، feature_names، artifact_sha256، source_commit |
| `lineage.json` | زمان‌های train/validation/دسترسی برچسب، هویت داده، نسخه‌های نرم‌افزار، معیارها، gate و training run |
| `reference.json` | توزیع ویژگی‌های مرجع و معیارهای validation برای پایش |
| `dataset_manifest.json` | receiptهای batchها، checksumها و شواهد هویت داده/cohort؛ دادهٔ خام سفارش‌ها داخل بسته نیست |

سیاست تاریخچه همین مدل `frozen-at-train-end-v1` است؛ ویژگی‌های تاریخچه به منبع مجاز تا train cutoff محدود می‌شوند. برای این تحویل، مدل جدیدی با سیاست دیگری نساختیم.

## چه کاری انجام شد و چرا؟

1. ماژول `src/promiseops/package_bundle.py` اضافه شد تا فقط پنج فایل مجاز را بسته‌بندی کند؛ فایل اضافی مانند `.env` وارد آرشیو نمی‌شود.
2. snapshot همان بایت‌ها پیش از ساخت آرشیو با reader موجود، ModelRecord، checksum مدل و manifest داده و تطبیق reference/lineage بررسی می‌شود. فایل ناقص، symlink، مدل خراب یا ترکیب شناسنامه‌های ناسازگار رد می‌شود.
3. آرشیو با ترتیب و timestamp ثابت ساخته می‌شود تا نام فایل خروجی یا mtime منبع نتیجه را تغییر ندهد. overwrite خروجی موجود مجاز نیست.
4. package جدید به registry خصوصی پروژه رفت. بایت‌ها مجدداً دانلود و SHA256 آرشیو و تک‌تک فایل‌ها بررسی شدند.
5. استخراج و verification همان `ci/prepare_release.py` در پوشهٔ موقت اجرا شد؛ پوشهٔ واقعی `release/` جایگزین نشد.
6. روی ۱۰ سفارش واقعی، feature builder مشترک با اتصال read-only به PostgreSQL اجرا شد؛ احتمال‌های مدل دانلودشده دقیقاً با bundle اصلی برابر بود. این smoke پیش‌بینی است، نه ارزیابی کیفیت جدید.

۴۸ تست مربوط به بسته‌بندی، bundle و model record و Ruff کامل در checkout بومی Linux موفق بودند. شواهد در `reports/model/candidate-bundle-delivery-2026-11-20.*`، `reports/model/candidate-bundle-verification-2026-11-20.json` و `reports/model/candidate-bundle-publication-2026-11-20.json` است. دادهٔ خام، شناسهٔ سفارش‌های smoke و credential منتشر نشده‌اند.

شاهد تحویل در MLflow **محلی** نیز در experiment `promiseops-bundle-delivery` و run `89e060485e354bdebfcd4151c1db675b` ثبت شده است. این run آزمون نرم‌افزار/بسته و پیش‌بینی است؛ آموزش جدید یا شاهد اجرای گروه نیست.

## نمایش به داور: دریافت، بررسی و بارگذاری

### ۱. دریافت

صفحهٔ package بالا را در GitLab باز کنید و `bundle.tar.gz` و `manifest.json` را دانلود کنید. فایل‌ها را در پوشهٔ جدید `artifacts/bundle-demo/` پروژه قرار دهید. دستورات بعدی را در **ترمینال Linux کانتینر پروژه، داخل `/app`، با Python 3.12 و dependencyهای قفل‌شده پروژه** اجرا کنید؛ مسیر `/app` دستور PowerShell ویندوز نیست.

### ۲. بررسی و استخراج

فقط package این پروژه با منبع مورد اعتماد را باز کنید؛ hash به‌تنهایی منبع ناشناختهٔ pickle را قابل اعتماد نمی‌کند. در این دستور SHA آرشیو مستقیماً با مقدار ثابت و قابل review این سند مقایسه می‌شود:

```bash
python - <<'PY'
import hashlib
import json
import tarfile
from pathlib import Path

folder = Path('artifacts/bundle-demo')
archive = folder / 'bundle.tar.gz'
expected = 'd0db9e2687166f11565ece2315e32e256a5157569688d12a7b05a445340daac1'
assert hashlib.sha256(archive.read_bytes()).hexdigest() == expected
manifest = json.loads((folder / 'manifest.json').read_text())
assert manifest['archive_sha256'] == expected
destination = folder / 'candidate'
destination.mkdir()  # پوشه باید جدید باشد؛ اجرای تکراری فایل قبلی را overwrite نمی‌کند
with tarfile.open(archive) as package:
    assert sorted(package.getnames()) == sorted(manifest['files'])
    package.extractall(destination, filter='data')
for name, details in manifest['files'].items():
    assert hashlib.sha256((destination / name).read_bytes()).hexdigest() == details['sha256']
print('Archive and all five files verified')
PY
```

### ۳. نشان‌دادن خود مدل بدون نیاز به دیتابیس

```bash
PYTHONPATH=src python - <<'PY'
from promiseops.bundle import read_bundle
from promiseops.record import ModelRecord

loaded = read_bundle('artifacts/bundle-demo/candidate')
record = ModelRecord(manifest=loaded.manifest, lineage=loaded.lineage)
print('Model:', record.model_version)
print('Features:', len(loaded.manifest.feature_names))
print('Pipeline:', loaded.model)
print('Training commit:', loaded.manifest.source_commit)
print('Validation:', loaded.lineage.validation_metrics.model_dump())
PY
```

باید نام مدل `logistic_regression-52d3211cb171`، تعداد feature برابر ۳۲ و Pipeline fitted دیده شود. این مرحله به MLflow زنده یا PostgreSQL نیاز ندارد. خود artifact مدل را هرگز با `git add` وارد source repository نکنید؛ registry محل دریافت آن است.

### ۴. پیش‌بینی سفارش واقعی، در صورت آماده بودن دیتابیس

`PROMISEOPS_DATABASE_URL` باید به پایگاهی دارای feed واقعی و schema سازگار اشاره کند. مقدار credential را در ارائه یا Git قرار ندهید. برای محدودکردن اتصال به خواندن:

```bash
export PGOPTIONS='-c default_transaction_read_only=on'
PYTHONPATH=src python -m promiseops.cli score \
  --bundle artifacts/bundle-demo/candidate \
  --since 2018-05-01T00:00:00Z \
  --as-of 2018-06-01T00:00:00Z \
  --output artifacts/bundle-demo/priority-orders.json
```

این دستور cohort را بر اساس **زمان انتشار سفارش** در `(since, as_of]` انتخاب می‌کند، نه لزوماً ماه تأیید سفارش؛ بنابراین نتیجه آن را با cohort ارزیابی ماه مه یکی معرفی نکنید. فایل خروجی شمار سفارش‌ها، نسخه مدل و فهرست اولویت top 10% را نشان می‌دهد. این فهرست اطلاعات سفارش دارد؛ محلی نگه دارید و وارد Git نکنید.

همین دستور با bundle دانلودشده و پایگاه واقعی محلی در اتصال read-only اجرا شد: **۷٬۵۳۶ سفارش امتیازدهی و ۷۵۴ سفارش اولویت‌بندی شدند**. این تعداد شاهد اجرای scoring است و به معنی محاسبه recall یا تغییر معیارهای ارزیابی نیست.

## نتیجه کیفیت مدل و محدودیت ارائه

گزارش ارزیابی ثابت در !61 است: از ۶٬۳۵۳ سفارش دارای برچسب، recall@10% برابر ۲۸٫۰۹٪، precision@10% برابر ۱۱٫۷۹٪، AP برابر ۰٫۰۹۵۰۸ و Brier برابر ۰٫۰۳۹۳۹ بود؛ ۵۶۶ سفارش فاقد برچسب کنار گذاشته شدند. نمونه‌هایی از ماه مه قبلاً predict شده‌اند؛ این بازه را pristine unseen test نمی‌نامیم. این انتشار هیچ metric جدید یا افزایش recall ایجاد نکرده است.

## تحویل به مالک استقرار، پس از review

این metadata برای هماهنگی در !57 است، **هنوز دستور تغییر CI یا استقرار نیست**:

```text
RELEASE_BUNDLE_URL=https://gitlab.mlops.qbootcamp.ir/api/v4/projects/4/packages/generic/promiseops-model-bundle/candidate-52d3211cb171/bundle.tar.gz
RELEASE_BUNDLE_SHA256=d0db9e2687166f11565ece2315e32e256a5157569688d12a7b05a445340daac1
```

پس از تأیید پویا، مالک deploy دسترسی خصوصی registry را با CI variable امن و masked تنظیم و مسیر prepare-release → app image → worker image را اجرا می‌کند. source آموزش داخل bundle با commit کد سرویس/worker یکی فرض نمی‌شود؛ هر دو باید جدا ثبت شوند. migration schema v4 و اجرای gateway نیز پیش‌نیاز تحویل گروه هستند. هیچ alias، سرویس، CI variable یا release تولیدی با این کار تغییر نکرد.
