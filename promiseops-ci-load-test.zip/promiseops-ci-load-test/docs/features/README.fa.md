# راهنمای بخش ML: از داده تا مدل و پایش

این پوشه راهنمای سه issue پشت سر هم است. هر کدام روی قبلی ساخته شده. به همین ترتیب بخوانید:

| ترتیب | issue | branch | راهنما | ورودی‌های قرارداد |
|---|---|---|---|---|
| ۱ | #24 features، برچسب و تقسیم زمانی | `data/24-features-labels-split` | [01-features-labels-split.fa.md](01-features-labels-split.fa.md) | `data.build_features` |
| ۲ | #25 معیارها، baseline، دو مدل و gateها | `model/25-models-and-gates` | [02-models-and-gates.fa.md](02-models-and-gates.fa.md) | `model.train_candidate`، `model.compare_candidate` |
| ۳ | #26 پایش و توصیهٔ retraining | `monitor/26-drift-retraining` | [03-monitoring.fa.md](03-monitoring.fa.md) | `monitor.build_report` |

## جریان داده

```
PostgreSQL (MR !7)
  └─ cohorts.load_labels ──► برچسب‌های معلوم تا as_of
  └─ features.load_features ─► ۱۵ feature در لحظهٔ تأیید
         │
         ▼
model.train_candidate ──► baseline + LR + HGB روی train ─► امتیاز روی همان validation ─► بهترین
         │
         ▼
model.compare_candidate ─► gateها در برابر champion (یا baseline) ─► accepted / rejected + دلیل‌ها
         │
         ▼  (worker #15: bundle #12 + MLflow #16 — راهنما: ../model/04-worker-train.fa.md)
         │   (accepted → نسخهٔ registry و alias «candidate»، #20 — راهنما: ../model/05-registry-aliases.fa.md)
drift.build_reference ──► reference.json داخل bundle
         │
         ▼  (worker #21 monitor-train: incumbent دوباره امتیاز می‌دهد — راهنما: ../model/06-worker-monitor-train.fa.md)
monitor.build_report ──► drift، کیفیت داده، کیفیت مدل، توصیهٔ retraining + دلیل و تعداد


یک بار، بعد از انتخاب مدل نهایی:
evaluation.evaluate_bundle ──► test دست‌نخورده (مارس و آوریل 2018) — راهنما: ../model/07-final-test-evaluation.fa.md
```

## ماژول‌ها و تنها مسئولیت هرکدام (SOLID)

| ماژول | مسئولیت |
|---|---|
| `features.py` | featureها: یک مسیر برای آموزش و سرویس |
| `cohorts.py` | برچسب، cutoffها، تقسیم زمانی، hash مجموعه |
| `metrics.py` | معیارهای قرارداد |
| `approaches.py` | ساختن و برازش هر روش (یک sklearn Pipeline) |
| `gates.py` | قانون‌های gate (تابع خالص) |
| `model.py` | چیدن موارد بالا برای دو تابع قرارداد |
| `drift.py` | ریاضی توزیع‌ها: PSI، TVD، reference، کیفیت داده |
| `monitor.py` | سیاست پایش: پنجره‌ها، آستانه‌ها، تصمیم |

- هر ماژول یک لایهٔ **خالص** دارد که بدون دیتابیس در CI تست می‌شود، و در صورت نیاز یک لایهٔ کوچک **دیتابیس** که فقط داده را می‌خواند.
- هیچ‌کدام MLflow را import نمی‌کنند. ثبت در MLflow کار worker است، با `record.py`.

## اجرای همهٔ تست‌ها

```powershell
$env:PYTHONPATH = "src"
python -m pytest tests -q            # تست‌های دیتابیس بدون PROMISEOPS_TEST_DATABASE_URL رد می‌شوند
```

تست‌های دیتابیس schema را پاک می‌کنند. همیشه یک دیتابیس **خالی** با نامی که به `_test` ختم شود بدهید، نه دیتابیسی که دادهٔ واقعی دارد.
