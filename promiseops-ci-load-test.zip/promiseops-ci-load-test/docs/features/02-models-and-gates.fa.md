# معیارها، baseline، دو مدل و gateها (issue #25)

> کد: `metrics.py` (معیارها)، `approaches.py` (baseline و دو روش)، `gates.py` (قانون‌های gate)، `model.py` (`train_candidate` و `compare_candidate`، ورودی‌های قرارداد)
> تست‌ها: `tests/test_metrics_gates.py` و `tests/test_model.py` (بدون دیتابیس، در CI)، `tests/test_model_db.py` (با PostgreSQL، محلی)
> پیش‌نیاز: features و تقسیم زمانی (#24) و قالب bundle (#12). این branch روی هر دو ساخته شده است.

## ۱. خواسته (`docs/CONTRACTS.md`، بخش Evaluation and release)

- **K** = max(1, ceil(0.1·N)). در تساوی، order ID کوچک‌تر جلوتر است.
- **recall@10%** = سفارش‌های دیررس در K بالا / همهٔ دیررس‌ها. **precision@10%** = سفارش‌های دیررس در K بالا / K.
- **PR-AUC** همان average precision است. **Brier** میانگین مربع خطای احتمال است. N و نرخ دیرکرد همیشه کنار این‌ها گزارش می‌شوند.
- candidate و champion روی **همان سفارش‌های validation** سنجیده می‌شوند و این با hash مجموعه ثبت می‌شود.
- **gateها:** recall نباید کم شود؛ PR-AUC حداکثر ۰٫۰۲ کم شود؛ Brier حداکثر ۰٫۰۰۵ بدتر شود.
- اولین candidate با **baseline ثابت (نرخ دیرکرد train)** مقایسه می‌شود.
- رد شدن هم نتیجهٔ معتبر است و gateها را نباید شل کرد.
- دست‌کم دو روش، و یک pipeline برازش‌شده برای آموزش و سرویس.

## ۲. ساختار: هر فایل یک کار

| فایل | کار | چرا جدا |
|---|---|---|
| `metrics.py` | معیارهای قرارداد روی یک مجموعه | پایش (#26) هم همین را لازم دارد. خروجی همان `EvaluationMetrics` در bundle (#12) است، پس عددی که حساب می‌شود دقیقاً همان است که ثبت می‌شود |
| `approaches.py` | ساختن و برازش هر روش به شکل یک sklearn Pipeline | اضافه کردن روش جدید = اضافه کردن یک تابع (open/closed) |
| `gates.py` | قانون‌های gate، تابع خالص | بدون مدل و دیتابیس تست می‌شود. آستانه‌ها ثابت‌اند تا کسی برای قبول کردن مدل شلشان نکند |
| `model.py` | چیدن این‌ها کنار هم برای دو تابع قرارداد | تنها جایی که دیتابیس خوانده می‌شود |

- **ردشده:** چارچوب کامل «model registry» داخلی یا کلاس‌های انتزاعی بیشتر. سه روش ثابت این پیچیدگی را نمی‌خواهند.
- `model.py` هیچ اثر جانبی ندارد: نه MLflow، نه فایل. ثبت در MLflow و ساختن bundle کار worker (#15) است، با `record.py` (#16) و `bundle.py` (#12). این‌طوری آموزش بدون سرور MLflow هم تست می‌شود.

## ۳. معیارها: نکته‌های دقیق

- **K با حساب اعداد صحیح** (`bundle.top_k_size`). در float، `0.1*30` برابر `3.0000000000000004` می‌شود و `ceil` آن ۴ است، نه ۳. تست `test_k_uses_integer_ceiling` این را چک می‌کند.
- **تساوی با order ID صعودی** (`np.lexsort`). این ترتیب ثابت است و به ترتیب ورودی بستگی ندارد. همان قانون برای خروجی batch priority هم لازم است، برای همین `top_k` عمومی است.
- **ورودی نامعتبر رد می‌شود:** مجموعهٔ تک‌کلاسه، order ID تکراری (هر سفارش یک بار شمرده شود)، و احتمال بیرون از [0,1] یا NaN. عدد ساختگی ساخته نمی‌شود.

## ۴. سه روش و دلیل هر انتخاب

| روش | ساختار | چرا |
|---|---|---|
| `baseline` | `DummyClassifier(strategy="prior")` | قرارداد: احتمال ثابت برابر نرخ دیرکرد train. کلاس آمادهٔ sklearn است، پس کلاس جدیدی نمی‌نویسیم |
| `logistic_regression` | StandardScaler برای عددی‌ها و OneHotEncoder برای دسته‌ای‌ها، بعد LogisticRegression | ساده و قابل توضیح است و احتمال‌هایش معمولاً کالیبره است (برای Brier مهم است) |
| `hist_gradient_boosting` | OrdinalEncoder و HistGradientBoosting با پشتیبانی مستقیم از دسته‌ای‌ها | رابطه‌های غیرخطی و ترکیبی را می‌گیرد |

**تصمیم‌های ریزتر:**
1. **کل pipeline یک شیء است.** همین شیء در `model.joblib` ذخیره می‌شود. API فقط `predict_proba(build_features(...))` را صدا می‌زند و هیچ پیش‌پردازشی بیرون از pipeline نیست، همان «یک preprocessing» که قرارداد می‌خواهد.
2. **دستهٔ جدید در سرویس خطا نمی‌دهد.**
   - در LR: `handle_unknown="infrequent_if_exist"`.
   - در HGB: مقدار ۱- که مدل آن را «missing» می‌گیرد.
   - تست `test_every_approach_handles_unknown_categories` هر سه روش را چک می‌کند.
3. **دسته‌های کم (کمتر از ۲۰ سفارش در train) در LR یک ستون مشترک دارند.** وزنی که از چند سفارش یاد گرفته شود قابل اعتماد نیست.
4. **`class_weight="balanced"` نه.** این گزینه احتمال همهٔ سفارش‌ها را بالا می‌برد و calibration و Brier را خراب می‌کند، ولی ترتیب سفارش‌ها (recall و PR-AUC) تقریباً عوض نمی‌شود.
5. **تصادف ثابت است** (`random_state=0`) و early stopping در HGB خاموش است، چون داده را تصادفی جدا می‌کند. تست `test_training_is_reproducible` و اجرای دوباره روی دادهٔ واقعی عدد کاملاً یکسان دادند.
6. **فقط scikit-learn.** LightGBM و XGBoost در lock فایل‌های image نیستند.

## ۵. انتخاب بهترین روش

- **ترتیب انتخاب:** اول بیشترین recall@10%، بعد بیشترین PR-AUC، بعد کمترین Brier، و آخر نام روش (تا نتیجه همیشه یکی باشد).
- **چرا recall@10% اول:** مسئلهٔ کسب‌وکار این است که تیم پشتیبانی فقط ۱۰٪ سفارش‌ها را می‌تواند بررسی کند. اولین gate هم همین معیار است.
- **انتخاب فقط روی validation انجام می‌شود.** دورهٔ test (مارس و آوریل ۲۰۱۸) دست نخورده است.

## ۶. `compare_candidate` و gateها

- `cohort` باید همان cohort خود candidate باشد (hash برابر)، وگرنه خطا می‌دهد. دو مدل روی سفارش‌های متفاوت قابل مقایسه نیستند.
- **هر دو مدل همین‌جا دوباره امتیاز می‌گیرند.** عدد قدیمی champion استفاده نمی‌شود («champion عوض‌شده باید دوباره ارزیابی شود»).
- اگر `champion=None` باشد، یعنی هنوز مدل آموزش‌دیده‌ای نداریم و مقایسه با baseline ثابت انجام می‌شود.
- `champion` هر مدلی با `predict_proba` می‌تواند باشد، از جمله مدل ساختگی فعلی سرویس. worker (#15) آن را از bundle فعلی می‌سازد.
- **هر سه بررسی با هر دو عدد** در `reasons` نوشته می‌شوند، چه pass چه FAIL. این متن در `lineage.gate_reasons` (#12) ثبت می‌شود و مشخص می‌کند تصمیم دقیقاً چرا گرفته شده.
- مرزها شامل خود آستانه است: کاهش PR-AUC دقیقاً به اندازهٔ ۰٫۰۲ قبول است و ۰٫۰۲۰۱ رد. فقط یک حاشیهٔ خیلی کوچک (`1e-12`) برای خطای اعشاری وجود دارد.

## ۷. نتیجه روی دادهٔ واقعی (اتصال فقط‌خواندنی)

تقسیم: train تا `2017-12-31`، validation تا `2018-02-28`، `as_of=2018-04-30` (دلیلش در `01-features-labels-split.fa.md`).

| روش | recall@10% | precision@10% | PR-AUC | Brier |
|---|---:|---:|---:|---:|
| baseline (نرخ ثابت ۳٫۹٪) | 0.121 | 0.105 | 0.087 | 0.0818 |
| **logistic_regression (انتخاب‌شده)** | **0.241** | **0.210** | **0.164** | **0.0802** |
| hist_gradient_boosting | 0.215 | 0.187 | 0.146 | 0.0812 |

- N = 13,377، نرخ دیرکرد ۸٫۷٪، K = 1,338. train: ۳۹٬۸۳۷ سفارش. hash مجموعهٔ validation با `56fff773…` شروع می‌شود.
- **تصمیم gate در برابر baseline: accepted.** recall دو برابر شد و PR-AUC تقریباً دو برابر.
- کل آموزش (خواندن داده و سه مدل) ۵٫۳ ثانیه طول کشید و اجرای دوباره عدد کاملاً یکسان داد.

**تفسیر صادقانه:**
- **recall baseline صفر نیست (۱۲٪).** احتمال ثابت یعنی همه با هم برابرند، پس K بالا فقط با ترتیب order ID انتخاب می‌شود. این عملاً یک نمونهٔ تصادفی است که حدود ۱۰٪ دیررس‌ها را می‌گیرد.
- **Brier فقط کمی بهتر شده.** نرخ دیرکرد train ۳٫۹٪ است و validation ۸٫۷٪، پس احتمال‌ها کمتر از واقعیت برآورد می‌شوند (همان محدودیت بخش ۵ سند #24). calibration را می‌شود بعداً بهتر کرد. ولی gate Brier را **شل نمی‌کنیم**.
- **HGB ضعیف‌تر از LR شد.** احتمالاً تغییر توزیع بین دو دوره به مدل پیچیده‌تر بیشتر آسیب می‌زند. هر دو روش ثبت می‌شوند، پس مقایسه قابل حسابرسی است.
- **عدد test هنوز گرفته نشده** و فقط یک بار، در ارزیابی نهایی، گرفته می‌شود.

## ۸. اجرا و تست

```powershell
$env:PYTHONPATH = "src"
python -m pytest tests/test_metrics_gates.py tests/test_model.py -v      # بدون دیتابیس (۲۸ تست)
$env:PROMISEOPS_TEST_DATABASE_URL = "postgresql://promiseops:<password>@127.0.0.1:55432/promiseops_unit_test"
python -m pytest tests/test_model_db.py -v                              # ۳ تست، از ingestion تا gate
```

## ۹. چه چیزی به MLflow می‌رود

سند پروژه، بخش سوم: «پارامترها، معیارها، مدل و preprocessing را در MLflow ثبت کنید». و: «حداقل دو مدل … را در کنار baseline مقایسه کنید».

| داده | از کجا | چه چیزی دارد |
|---|---|---|
| params | `candidate.run_params()` | روش انتخاب‌شده، فهرست روش‌های مقایسه‌شده، اندازه، نرخ دیرکرد و hash مجموعهٔ train، و **همهٔ تنظیمات pipeline** با پیشوند `hp.` (هم `hp.model.*`، مثل `C` و `learning_rate`، هم `hp.preprocess.*`، مثل `min_frequency` و `handle_unknown`) |
| metrics | `candidate.comparison_metrics()` | معیارهای **هر سه روش** روی همان مجموعهٔ validation، مثل `baseline.recall_at_10` و `logistic_regression.pr_auc` |
| مدل و preprocessing | خود `candidate.model` (یک Pipeline) | داخل bundle و `model.joblib` (#12)، که `record.log_record` (#16) آن را ثبت می‌کند |
| cutoffها، hash مجموعه، commit، تصمیم gate | `lineage.json` (#12) | `record.mlflow_params/metrics/tags` (#16) |

- **چرا `model.py` خودش در MLflow ثبت نمی‌کند:** این دو متد فقط dict ساده می‌سازند و ثبت کار worker (#15) است.
  - اصل وارونگی وابستگی (D در SOLID): منطق مدل به MLflow وابسته نیست، پس بدون سرور MLflow تست می‌شود. image سرویس هم MLflow ندارد.
- **`approaches.hyperparameters`** تنظیمات را از خود pipeline برازش‌شده می‌خواند (`get_params`)، نه از یک فهرست دستی. پس اگر تنظیمی در کد عوض شود، همان چیزی ثبت می‌شود که واقعاً اجرا شده.

## ۱۰. قدم بعد و وابستگی‌ها

- **worker train (#15)** این‌ها را به هم وصل می‌کند:
  1. `train_candidate`
  2. champion از bundle فعلی (`/opt/promiseops/release`)
  3. `compare_candidate`
  4. `write_bundle` (#12)
  5. `log_record` در MLflow (#16)
- **reference پایش (#26)** از `candidate.training_features` ساخته می‌شود (هیستوگرام عددی‌ها و سهم دسته‌ای‌ها).
- **هماهنگی با API پویا:** API فعلی (develop) مدل را با یک لیست صفر (`dummy_features`) صدا می‌زند. مدل واقعی ما یک Pipeline است و باید یک pandas DataFrame با ستون‌های `release.json["feature_names"]` بگیرد، که از `data.build_features` می‌آید. این تغییر در `api.py` با پویاست.
- این branch روی MR !7 (ثبت داده)، #24 و MR !15 (#12) ساخته شده است. MR آن بعد از merge شدن آن‌ها باز می‌شود.

## ۱۱. به‌روزرسانی با develop (2026-11-13، بعد از merge شدن MR !3 پویا)

MR !3 پویا (API، loader و مدل ساختگی) وارد develop شد. فایل `src/promiseops/model.py` را هم پویا و هم ما تغییر داده بودیم، پس git تداخل (conflict) نشان داد.

| مرحله | چه کردیم | چرا |
|---|---|---|
| 1 | develop را اول در شاخهٔ پایه (`data/13`) merge کردیم و بعد بالا آوردیم (`data/24` و بعد `model/25` و بعد `monitor/26`) | اگر فقط در این شاخه merge می‌کردیم، diff این MR (نسبت به `data/24`) پر از کد API پویا می‌شد و review سخت می‌شد |
| 2 | در `model.py` هر دو طرف ماند: توابع ما بالا، کلاس `ConstantProbabilityEstimator` پویا بدون تغییر در بخش آخر | فایل `release/model.joblib` با نام دقیق `promiseops.model.ConstantProbabilityEstimator` pickle شده است. اگر کلاس جابه‌جا یا حذف شود، API و worker مدل فعلی را نمی‌توانند باز کنند |
| 3 | فقط `class X():` به `class X:` تغییر کرد (قاعدهٔ ruff) | برای pickle فقط نام ماژول و نام کلاس مهم است، پس این تغییر بی‌خطر است |
| 4 | تست `test_incumbent_release_of_the_repo_can_be_a_champion` (در `tests/test_bundle.py`) | ثابت می‌کند `release/` فعلی هنوز باز می‌شود و می‌تواند champion باشد |

**راه رد شده:** انتقال کلاس پویا به یک فایل جدا (مثلاً `mock.py`). این کار تمیزتر بود، اما مدل pickle‌شده را خراب می‌کرد، مگر این‌که `release/model.joblib` دوباره ساخته شود. آن فایل مال پویاست.
