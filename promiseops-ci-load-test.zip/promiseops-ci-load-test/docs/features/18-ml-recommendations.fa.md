# بررسی پیشنهادهای ML و محدودهٔ این تغییر

منبع: `G03_ML_RECOMMENDATIONS.fa (1).md`؛ SHA256:
`32cbab2867c586a3658fa66d3aa1a301bf2e6dd40f3719c88e7f4123e0f83b83`.
این فایل پیشنهاد فنی است؛ وضعیت شاخهٔ فعلی و قرارداد پروژه ملاک اجرای پیشنهادها بوده‌اند. شرح stub بودن worker/API در ابتدای سند، دربارهٔ شاخهٔ فعلی صدق نمی‌کند.

## موارد اجراشده در محدودهٔ داده و ML درسا

| پیشنهاد | پیاده‌سازی | محل مشاهدهٔ نتیجه |
|---|---|---|
| نسخهٔ دقیق داده، فراتر از SQL | `training_evidence.dataset_manifest`: receiptها، checksum فایل‌ها، watermark، cutoff، اندازه/شیوع هر split، hash شناسه‌ها و محتوای feature/label، schema و نسخهٔ کد | `dataset_manifest.json` داخل bundle و artifacts همان run |
| اتصال manifest به مدل | SHA256 در `lineage.json` و model record؛ کنترل checksum پیش از بازکردن مدل؛ سازگاری bundleهای قدیمی حفظ شده | `bundle.py`، `record.py` و تست دستکاری manifest |
| signature و input example | flavor استاندارد sklearn با خروجی `predict_proba`، signature و نمونهٔ ورودی؛ ذخیره/بارگذاری مجدد و مقایسهٔ احتمال | `sklearn-model/`، `model_signature.json`، `input_example.json` |
| بررسی calibration | O/E، ECE، Brier و reliability curve روی validation ثابت | `validation_diagnostics.json` و `validation_reliability.png` |
| بلوغ برچسب | توزیع `label_available_at-approved_at` و منحنی بلوغ؛ gamma فقط در cohort کامل تعریف می‌شود | `label_maturity.json`؛ cutoff و embargo بدون تغییر خودکار |
| عملکرد زیرگروه‌ها | ایالت مشتری، روش پرداخت، مهلت تحویل و مسیر بین‌ایالتی؛ حداقل ۱۰۰ سفارش و ۲۰ late برای گزارش محلی | `validation_diagnostics.json`؛ تفکیک بودجهٔ سراسری از top-10% داخل هر slice |
| model card واقعی | نسخهٔ مدل/کد/داده، cutoff، معیارها، زیرگروه ضعیف، gate و محدودیت‌ها | `model-card.md` همان run |
| آزمون راه تازه برای recall | میانگین و انحراف معیار مدت تحویل سفارش‌های قبلی، در سطح global/seller/state/route؛ مقایسهٔ مهلت سفارش با این سابقه | `duration_features.py` و `presentation_study --family duration` |

`release.json` طبق قرارداد همچنان چهار فیلد دارد؛ اطلاعات اضافی در lineage و record قرار می‌گیرد. دادهٔ خام و نمونه‌های سفارش واقعی به Git اضافه نمی‌شوند.

## روش آزمایش recall

دو پنجرهٔ زمانی داخل train برای انتخاب بین مدل مرجع و دو مقدار ازپیش‌تعریف‌شدهٔ C استفاده می‌شود. مدل انتخاب‌شده پیش از ارزیابی validation قفل و در MLflow ثبت می‌شود. test برای انتخاب، آموزش یا ارزیابی این تغییر خوانده نمی‌شود. validation قبلاً دیده شده و آزمون نهایی دست‌نخورده محسوب نمی‌شود.

در featureهای مدت تحویل، outcome فقط وقتی وارد سابقه می‌شود که `label_available_at < min(approved_at, train_end)` باشد. outcome خود سفارش ورودی مدل نیست. cold-start prior برابر میانگین ۱۵ روز و انحراف معیار ۱۰ روز و smoothing برابر ۲۰ است؛ این ثابت‌ها روی validation تنظیم نشده‌اند. طرح ۴۴ستونی فعلاً آزمایشی است و release سرویس همچنان ۳۲ستونی است. ارتقای مدل ۴۴ستونی به worker/API به policy نسخه‌دار و تست برابری جداگانه نیاز دارد.

## مواردی که به این تغییر اضافه نشد

- Active learning و IPS: طبق پیوست C همین سند، برای feed با برچسب‌های نهایتاً قابل‌دسترسی لازم نیستند.
- تغییر embargo: مقدار p95 روی cohort ناقص برآورد مطمئنی نیست؛ ابتدا گزارش بلوغ و سانسورشدگی دیده می‌شود. هیچ برچسب نامعلوم به negative تبدیل نشده است.
- کاهش gate یا تغییر بودجهٔ top-10%: قرارداد حفظ می‌شود.
- DAG، Helm، worker image، CI و استقرار: به مسئولیت هم‌تیمی‌ها و review جداگانه مربوط‌اند؛ این MR آن‌ها را تغییر نمی‌دهد.
- KS/chi-square/bootstrap و alertهای جدید: پیشنهادهای تکمیلی‌اند؛ آستانهٔ قراردادی drift با این آزمایش تغییر نکرده است.
- merge به develop/main و جابه‌جایی production: جزو این درخواست نیست. اجرای واقعی در registry ایزوله انجام می‌شود.

## اجرای دوباره

داخل محیط پروژه با dependencyهای tracking نصب‌شده:

```bash
export PYTHONPATH=/app/src
export CI_COMMIT_SHA=$(git rev-parse HEAD)
export MLFLOW_TRACKING_URI=http://127.0.0.1:5000
# PROMISEOPS_DATABASE_URL باید به snapshot ارزیابی شما اشاره کند.
python -m promiseops.presentation_study --family duration --output /app/artifacts/duration-study.json
PROMISEOPS_VERIFICATION_REPORT=/app/artifacts/evidence-integration.json python scripts/verify_release_api.py
```

فرمان اول پژوهشی است؛ فرمان دوم مدل ۳۲ستونی را در registry جداگانه آموزش می‌دهد، evidence را بررسی و احتمال API را با pipeline مقایسه می‌کند. artifactهای آموزش در MLflow اصلی زیر `training-evidence/` در run گزارش integration نیز کپی می‌شوند. برای تست‌های DB فقط از دیتابیس disposable با نام انتهایی `_test` استفاده کنید.

برای ثبت لاگ و JUnit تست‌هایی که روی همین commit اجرا کرده‌اید:

```bash
python scripts/log_test_evidence.py --junit /app/artifacts/recommendations-tests-2026-11-16.xml --log /app/artifacts/recommendations-tests-2026-11-16.log --output /app/artifacts/test-evidence.json
```

`CI_COMMIT_SHA` باید نسخهٔ کدِ زمان اجرای تست‌ها باشد. این فرمان تست را اجرا نمی‌کند؛ نتیجهٔ موجود را با hash فایل و کد ثبت می‌کند. خروجی این بررسی و اعداد واقعی در `reports/model/duration-recommendations-summary.fa.md` آمده است.
