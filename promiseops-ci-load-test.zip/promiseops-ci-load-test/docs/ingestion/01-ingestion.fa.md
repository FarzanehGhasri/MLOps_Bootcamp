# بخش داده: ورود batchها به PostgreSQL (Issue #13)

> این سند برای **بازبین (reviewer)** و هم‌تیمی‌ها نوشته شده است: چه چیزی از قبل بود، چه کار کردیم،
> **چرا**، چه راه‌های دیگری بود و **چرا آن‌ها را انتخاب نکردیم**، و چطور اجرا و تست می‌شود.
> شاخه: `data/13-batch-ingestion` — مرجع قرارداد: `docs/CONTRACTS.md`.

---

## ۱. این بخش از پروژه چه می‌خواهد؟

از سند پروژه (بخش اول و دوم + بندهای PostgreSQL):

| خواستهٔ سند | کجا انجام شده |
|---|---|
| داده‌ها batch به batch از «مسیر شرکت» می‌آیند (orders، items، payments، customers، sellers، products، outcomes) | `feed.py` (خواندن فهرست feed) + `data.py` (`ingest_batch`) |
| روابط جدول‌ها حفظ شود | `schema.sql` (کلید اصلی/خارجی) + `validation.py` (بررسی FK قبل از نوشتن) |
| schema، checksum و کیفیت ورودی بررسی شود | `validation.parse_payload` و `validation.check_file_sha256` |
| batch خراب **کامل** رد شود و **علت ثبت شود** | یک تراکنش برای کل batch + جدول‌های `ingest_attempts` و `ingest_quarantine` |
| ثبت تراکنشی و قابل اجرای مجدد؛ اجرای دوباره ردیف تکراری نسازد | جدول رسید `ingest_batches` + بررسی `payload_sha256` (replay = بدون تغییر) |
| شناسهٔ یکسان با محتوای متفاوت خطا بدهد | دلیل `batch_id_conflict` |
| در join اقلام و پرداخت‌ها مبلغ چندبرابر نشود | جدول‌های جدا برای items و payments، مبلغ‌ها با `numeric` دقیق؛ (ساخت feature در بخش بعد باید جدا جمع بزند — بخش ۸) |
| زمان دسترسی به داده و برچسب رعایت شود (هدف پروژه: پیش‌بینی هنگام تأیید سفارش) | `as_of` در هر اجرا، `available_at` در رسید و outcomes، view `order_releases` |

---

## ۲. چه چیزی از قبل وجود داشت (starter پروژه)

| فایل | وضعیت قبلی | کاری که کردیم |
|---|---|---|
| `src/promiseops/contracts.py` | مدل‌های pydantic برای `Batch` و ردیف‌ها، `digest()` برای checksum | **تغییر ندادیم**؛ از آن استفاده کردیم (منبع واحد قرارداد) |
| `contracts/Batch.schema.json`، `docs/CONTRACTS.md` | قرارداد ورودی و قوانین رد | فقط خواندیم |
| `fixtures/synthetic-*.json` | دو batch نمونه (۳۰۰ سفارش، ۳۰۰ نتیجه) | در تست‌ها استفاده کردیم |
| `src/promiseops/data.py` | فقط امضای `ingest_batch` با `NotImplementedError` | پیاده‌سازی کامل |
| `src/promiseops/cli.py` | فقط `NotImplementedError` | فرمان‌های داده اضافه شد |
| `requirements.lock` | `psycopg[binary]==3.3.4` از قبل pin شده بود | وابستگی جدیدی اضافه **نکردیم** |

فایل‌های جدید: `schema.sql`، `db.py`، `validation.py`، `feed.py`، و تست‌های
`tests/factories.py`، `tests/test_validation.py`، `tests/test_feed.py`، `tests/test_ingestion_db.py`.

---

## ۳. مسیر یک batch، قدم به قدم (و دلیل هر قدم)

```
فایل batch (بایت‌ها)
   │ 1. file_sha256 روی بایت‌ها           ← فایل خراب/ناقص دانلود شده؟
   │ 2. UTF-8 + JSON سخت‌گیر               ← NaN، کلید تکراری، متن خراب
   │ 3. payload_sha256 روی JSON استاندارد  ← محتوا همان است که شرکت منتشر کرده؟
   │ 4. schema با pydantic (strict)        ← ستون ناشناخته، نوع غلط، مبلغ منفی، بدون منطقهٔ زمانی
   │ 4b. kind/available_at/batch_id فهرست = خود فایل؟  ← feed_metadata_mismatch (اگر از فهرست آمده)
   │ 4c. available_at <= as_of ؟                       ← future_publication — قبل از replay (بازبینی MR !7)
   ▼
┌──────────── یک تراکنش PostgreSQL ────────────┐
│ 5. قفل سراسری ingestion (advisory lock)      │
│ 6. این batch_id قبلاً ثبت شده؟                │
│      همان محتوا   → replay: هیچ کاری نکن      │
│      محتوای دیگر  → رد: batch_id_conflict      │
│ 7. ردیف‌های موجود مرتبط را بخوان               │
│ 8. قوانین بین‌ردیفی/بین‌batch (validate_batch) │
│ 9. رسید + همهٔ ردیف‌ها + ثبت attempt           │
└──────────── COMMIT (یا هیچ چیز) ─────────────┘
   اگر رد شد: ROLLBACK → در تراکنش جدا: quarantine + attempt «rejected» → خطای BatchRejected
   اگر خطای غیرمنتظره (مثلاً قطع DB): ROLLBACK → attempt «failed» → خطا دوباره بالا می‌رود
```

**چرا قدم‌های ۱ تا ۴ قبل از دیتابیس؟** هر کدام بدون قبلی بی‌معناست: تا JSON سالم نباشد checksum
معنی ندارد و تا checksum درست نباشد بررسی schema روی داده‌ای است که شاید اصلاً داده‌ی شرکت نیست.
این قدم‌ها به دیتابیس نیاز ندارند، پس **همیشه در CI تست می‌شوند**.

**چرا دو checksum؟** قرارداد دو چیز متفاوت تعریف کرده است: `file_sha256` روی بایت‌های فایل (خرابی
در انتقال) و `payload_sha256` روی JSON استاندارد (کلیدهای مرتب، بدون فاصله). دومی به قالب‌بندی
فایل حساس نیست؛ پس اگر همان داده با فاصله‌گذاری دیگری دوباره بیاید، همان batch شناخته می‌شود
(تست `test_replay_of_same_payload_is_a_no_op`).

**چرا قفل (قدم ۵)؟** بین «خواندن ردیف‌های موجود» (قدم ۷) و «نوشتن» (قدم ۹) نباید اجرای دیگری
چیزی بنویسد؛ وگرنه ممکن است دو اجرا هر دو فکر کنند سفارش جدید است. مثال واقعی: retry در Airflow
وقتی اجرای اول هنوز تمام نشده. تست `test_concurrent_ingestion_of_same_batch_commits_once` چهار
اجرای هم‌زمان را امتحان می‌کند: دقیقاً یکی commit و سه‌تا replay می‌شوند.

**چرا رسید قبل از ردیف‌ها و در همان تراکنش؟** رسید (`ingest_batches`) یعنی «این batch کامل در
دیتابیس است». چون در همان تراکنش است، حالت «ردیف‌ها هستند ولی رسید نیست» (یا برعکس) هرگز رخ
نمی‌دهد. ردیف‌ها با کلید خارجی به رسید اشاره می‌کنند، پس رسید باید اول نوشته شود.

**چرا quarantine در تراکنش جدا؟** تراکنش اصلی rollback می‌شود تا هیچ ردیفی از batch خراب نماند؛
ولی مدرک رد شدن باید بماند. پس بعد از rollback، در تراکنش مستقل، بایت‌های دقیق و علت ذخیره می‌شوند.

---

## ۴. جدول‌ها (`src/promiseops/schema.sql`)

همه در schema جدای `promiseops` (چون دیتابیس پلتفرم ممکن است جدول‌های Airflow/MLflow هم داشته باشد).

| جدول | نقش |
|---|---|
| `ingest_batches` | **رسید**: یک ردیف برای هر batch ثبت‌شده؛ checksumها، `available_at`، `as_of`، تعداد ردیف‌ها، نسخهٔ کد (`source_commit`) |
| `customers`، `sellers`، `products` | ابعاد (dimension)؛ ردیف یکسان در چند batch مجاز است و فقط یک بار ذخیره می‌شود؛ `first_batch_id` = اولین batch |
| `orders`، `order_items`، `order_payments` | واقعیت‌ها (fact)؛ هر سفارش یک بار و کامل می‌آید |
| `outcomes` | منبع برچسب؛ `available_at` = زمانی که نتیجه **دانسته** شد (با تأخیر ۷ روزه) |
| view `order_releases` | هر سفارش از چه زمانی منتشر شده (برای 404 در API و انتخاب cohort) |
| `ingest_attempts` | **لاگ ممیزی**: هر تلاش (committed / replayed / rejected / failed) با علت |
| `ingest_quarantine` | قرنطینهٔ خصوصی: بایت‌های دقیق batch رد شده + علت؛ تکرار همان بایت‌ها فقط شمارنده را زیاد می‌کند |

قیدهای دیتابیس (PK، FK، CHECK) **تور ایمنی** هستند، نه اعتبارسنجی اصلی؛ اعتبارسنجی اصلی در Python
و قبل از نوشتن انجام می‌شود.

---

## ۵. قوانین رد (`validation.Reason`)

| کد | یعنی | مثال تست |
|---|---|---|
| `invalid_json` | UTF-8 نیست، JSON نیست، NaN/Infinity، کلید تکراری | `test_unreadable_json_is_rejected` |
| `checksum_mismatch` | `payload_sha256` یا `file_sha256` نمی‌خواند | `test_payload_checksum_mismatch_keeps_batch_id` |
| `schema_invalid` | ستون ناشناخته، مبلغ منفی، رشته به‌جای عدد، بدون منطقهٔ زمانی، نسخهٔ schema دیگر، ID ناامن | `test_schema_violations_are_rejected` |
| `future_publication` | batch بعد از `as_of` منتشر شده | `test_future_publication` |
| `batch_id_conflict` | همان `batch_id` با محتوای دیگر | `test_same_batch_id_with_other_payload_...` |
| `duplicate_key` | کلید تکراری داخل یک batch | `test_duplicate_keys_inside_batch` |
| `missing_foreign_key` | اشاره به مشتری/محصول/فروشنده/سفارشی که هیچ‌جا نیست | `test_missing_foreign_keys` |
| `incomplete_order` | سفارش بدون حداقل یک item و یک payment | `test_incomplete_order` |
| `append_to_committed_order` | item/payment جدید برای سفارشی که قبلاً ثبت شده | `test_items_cannot_be_appended_...` |
| `changed_immutable_row` | مشتری/فروشنده/محصول شناخته‌شده با مقدار متفاوت | `test_identical_dimension_rows_...` |
| `already_committed` | سفارش یا نتیجه‌ای که batch دیگری قبلاً ثبت کرده | `test_order_already_committed_...` |
| `delivery_before_approval` | تحویل قبل از تأیید سفارش | `test_outcome_rules` |
| `feed_metadata_mismatch` | `kind`/`available_at`/`batch_id` فهرست feed با خود فایل یکی نیست | `test_metadata_mismatch_is_reported`، `test_index_payload_mismatch_is_detected` |

یک batch رد شده **همهٔ** مشکلاتش را گزارش می‌کند (حداکثر ۵۰ مورد در لاگ)، به ترتیب ثابت (مرتب‌شده)،
تا پیام خطا قابل تکرار باشد.

---

## ۶. تصمیم‌ها و راه‌های جایگزین

### ۶.۱ اعتبارسنجی در Python به‌جای جدول staging دائمی
- **انتخاب:** batch کامل در حافظه به اشیای pydantic تبدیل و بررسی می‌شود؛ فقط داده‌ی معتبر وارد جدول‌ها می‌شود. نقش «staging» را همین اشیا بازی می‌کنند.
- **جایگزین:** جدول‌های staging در PostgreSQL (`COPY` به staging، بعد بررسی با SQL، بعد `INSERT ... SELECT`).
- **چرا نه:** batchها کوچک‌اند (صدها تا چند هزار ردیف)؛ staging یعنی دو برابر جدول، پاک‌سازی بعد از هر اجرا، و قوانین نوشته‌شده در SQL که پیام خطای خوانا نمی‌دهند و بدون دیتابیس تست نمی‌شوند. اگر حجم batch بزرگ شود (میلیون‌ها ردیف)، staging با `COPY` راه درست است.

### ۶.۲ یک تراکنش برای کل batch
- **جایگزین:** تراکنش برای هر جدول، یا commit تکه‌تکه.
- **چرا نه:** سند می‌گوید batch خراب «کامل» رد شود؛ با چند تراکنش، خطا در جدول پنجم چهار جدول نیمه‌کاره باقی می‌گذارد. تست `test_failure_in_the_middle_rolls_back_everything` این را ثابت می‌کند.

### ۶.۳ قفل سراسری `pg_advisory_xact_lock`
- **جایگزین‌ها:** سطح ایزولاسیون `SERIALIZABLE` (و تکرار در صورت خطا)، یا قفل ردیف با `SELECT ... FOR UPDATE`.
- **چرا نه:** batchها باید به ترتیب انتشار ثبت شوند، پس اجرای موازی سودی ندارد. `SERIALIZABLE` کد retry لازم دارد؛ `FOR UPDATE` روی ردیفی که **هنوز وجود ندارد** قفل نمی‌گیرد. قفل advisory ساده است و با پایان تراکنش خودکار آزاد می‌شود.

### ۶.۴ `numeric` برای مبلغ و وزن
- **جایگزین‌ها:** `double precision` (float) یا `numeric(12,2)`.
- **چرا نه:** float خطای گرد کردن دارد (0.1+0.2≠0.3) و جمع مبلغ‌ها را کمی غلط می‌کند. `numeric(12,2)` اعشار اضافهٔ غیرمنتظره را **بی‌صدا** گرد می‌کند. تبدیل از JSON با `Decimal(repr(x))` است تا 19.9 دقیقاً 19.9 ذخیره شود (`test_amounts_are_stored_exactly`).

### ۶.۵ SQL ساده و psycopg به‌جای ORM و Alembic
- **جایگزین‌ها:** SQLAlchemy ORM، Alembic برای migration.
- **چرا نه:** Alembic در `requirements.lock` ایمیج نیست (افزودن وابستگی = تغییر lock و wheelhouse). یک فایل SQL قابل اجرای مکرر (`IF NOT EXISTS`) برای نسخهٔ ۱ کافی است و بازبینی‌اش راحت‌تر است. جدول `schema_version` آماده است تا اگر بعداً تغییر schema لازم شد، migration اضافه شود.

### ۶.۶ سه جدول جدا: رسید، تلاش، قرنطینه
- **جایگزین:** یک جدول با ستون status.
- **چرا نه:** معنی‌ها فرق دارند: رسید = «این داده در دیتابیس است» (کلید خارجی ردیف‌ها به آن)، تلاش = «چه اتفاقی افتاد» (ممکن است چند بار برای یک batch)، قرنطینه = «مدرک خصوصی» (بایت‌ها). اگر قاطی شوند، کلید خارجی به batch رد شده هم ممکن می‌شد.

### ۶.۷ قرنطینه به صورت `bytea` در دیتابیس
- **جایگزین:** ذخیرهٔ فایل روی دیسک pod یا object storage.
- **چرا نه:** دیسک pod با حذف pod از بین می‌رود؛ object storage برای این پروژه آماده نیست. دیتابیس از قبل خصوصی و پشتیبان‌دار است. `bytea` (نه `text`) چون batch خراب ممکن است UTF-8 معتبر نباشد و بایت‌ها باید دقیق بمانند تا checksum دوباره قابل بررسی باشد.

### ۶.۸ سفارش/نتیجهٔ تکراری از batch دیگر = رد (`already_committed`)
- **تفسیر ما:** قرارداد می‌گوید ردیف‌های تغییرناپذیر نباید عوض شوند و item/payment به سفارش ثبت‌شده اضافه نشود. ما سفارش یا نتیجه‌ای را که **دوباره** در batch دیگری بیاید هم رد می‌کنیم (حتی اگر یکسان باشد)، چون هر واقعیت باید فقط یک منبع (یک batch) داشته باشد تا «چه زمانی دانسته شد» یکتا باشد.
- **جایگزین:** پذیرفتن بی‌صدای ردیف یکسان (مثل ابعاد).
- **ریسک:** اگر feed واقعی عمداً سفارش‌ها را تکرار کند، این قانون باید بازبینی شود. **بازبین لطفاً این تفسیر را تأیید کند.**

### ۶.۹ `ingest-feed` در اولین batch رد شده متوقف می‌شود
- **جایگزین:** رد کردن و ادامه دادن.
- **چرا نه:** batchهای بعدی اغلب به قبلی وابسته‌اند (outcomes به orders)؛ ادامه دادن فقط رد‌های زنجیره‌ای می‌سازد و ترتیب انتشار را می‌شکند. بعد از رفع مشکل، اجرای دوباره امن است چون batchهای ثبت‌شده replay می‌شوند.

### ۶.۱۰ pydantic در حالت strict
- **چرا:** در حالت عادی `"19.9"` (رشته) بی‌صدا به عدد تبدیل می‌شد؛ قرارداد نوع داده را مشخص کرده و ورودی با نوع غلط باید رد شود.

### ۶.۱۱ اتصال باید autocommit و بیرون از هر تراکنشی باشد
- **چرا:** اگر فراخواننده خودش تراکنش باز کرده باشد، `connection.transaction()` ما به savepoint تبدیل می‌شود: رسید فقط وقتی commit می‌شود که فراخواننده commit کند و قرنطینه ممکن است همراه کار او rollback شود. پس صریحاً خطا می‌دهیم.
- دو حالت رد می‌شود: `autocommit=False` (`test_connection_inside_a_transaction_is_refused`)، و `autocommit=True` ولی داخل `with connection.transaction():` — تنظیم autocommit این را نشان نمی‌دهد، فقط وضعیت واقعی تراکنش (`transaction_status` باید `IDLE` باشد) نشان می‌دهد (`test_autocommit_connection_inside_explicit_transaction_is_refused`).

### ۶.۱۲ کنترل زمان انتشار قبل از replay
- **چرا:** batchی که قبلاً با `as_of` دیرتری ثبت شده، برای `as_of` زودتر از زمان انتشارش «وجود نداشته». اگر اول replay بررسی شود، جواب «replayed» می‌گیرد و دادهٔ تاریخی اشتباه ساخته می‌شود. پس `available_at <= as_of` **قبل از** تراکنش و replay بررسی می‌شود (`test_replay_with_as_of_before_publication_is_rejected_not_replayed`).

### ۶.۱۳ فهرست feed باید با فایل‌ها یکی باشد (pre-flight)
- **چرا:** ترتیب ثبت و فیلتر `as_of` از روی **فهرست** (`manifest.json`) انجام می‌شود، قبل از خواندن فایل‌ها. اگر فهرست بگوید batchی «دیرتر» منتشر شده، بی‌صدا کنار گذاشته می‌شود؛ اگر `kind` اشتباه باشد، ترتیب orders/outcomes به هم می‌خورد.
- **انتخاب:** `ingest-feed` اول **همهٔ** ورودی‌های فهرست (حتی آن‌هایی که بعد از `as_of` هستند) را با فایلشان مقایسه می‌کند: `file_sha256`، `payload_sha256` (اثر انگشت JSON استاندارد)، `kind`، `available_at` و `batch_id` اگر باشد. ورودی‌هایی که بعد از `as_of` هستند در این اجرا به `ingest_batch` نمی‌رسند؛ بدون این کنترل، checksum آن‌ها هیچ‌وقت بررسی نمی‌شد (بازبینی دوم MR !7، `test_cli_ingest_feed_checks_payload_sha256_of_entries_not_yet_due`). فایل با همان قواعد سخت‌گیرانهٔ ثبت خوانده می‌شود (`validation.decode_document`: بدون کلید تکراری و NaN)، تا pre-flight و ثبت هرگز دربارهٔ یک فایل نظر متفاوت نداشته باشند. اگر یکی نخواند، **هیچ batchی ثبت نمی‌شود** و همان ورودی از مسیر عادی `ingest_batch` رد، ثبت و قرنطینه می‌شود (کد خروج ۳). خود `ingest_batch` هم پارامتر `expected` دارد تا هر فراخواننده‌ای (مثلاً DAG) همین کنترل را داشته باشد.
- **جایگزین ردشده:** فقط کنترل هر ورودی هنگام ثبت. حالت «بی‌صدا کنار گذاشته شدن» را نمی‌گیرد، چون آن ورودی هیچ‌وقت خوانده نمی‌شود.
- **هزینه:** هر فایل یک بار اضافه خوانده و hash می‌شود؛ روی کل دادهٔ دوره (۴۲ batch) حدود ۳ ثانیه.

---

## ۷. ویژگی‌های کیفیتی خواسته‌شده

| ویژگی | چطور رعایت شده |
|---|---|
| **Correctness** | قرارداد در یک جا (`contracts.py`)؛ ۱۲ قانون رد، هر کدام با تست؛ اعداد دقیق (`numeric`) |
| **Idempotency** | رسید + `payload_sha256`: اجرای دوباره = replay بدون ردیف جدید؛ `db-init` هم چندبار قابل اجراست |
| **Integrity** | یک تراکنش برای هر batch، قفل سراسری، کلیدهای اصلی/خارجی و CHECK به عنوان تور ایمنی |
| **ثبت وضعیت batch و لاگ** | `ingest_attempts` برای هر تلاش؛ یک خط JSON در لاگ برای هر رویداد (`batch_committed`، `batch_replayed`، `batch_rejected`، `batch_failed`) بدون رمز یا URL دیتابیس |
| **Reproducibility** | `as_of` صریح در هر اجرا (نه ساعت سرور)؛ ترتیب ثابت انتشار؛ `dataset_identity(as_of)` = اثر انگشت داده‌ی شناخته‌شده تا آن لحظه |
| **Auditability** | هر ردیف → batch آورنده؛ رسید → checksumها و `source_commit` (نسخهٔ کد)؛ قرنطینه → بایت‌های دقیق |

---

## ۸. آنچه بخش‌های بعدی از این بخش لازم دارند

| بخش بعدی | چه چیزی آماده است | نکته |
|---|---|---|
| ساخت feature و آموزش (MLflow) | `orders.approved_at`، جدول‌های جدای items/payments، `outcomes.available_at` | **items و payments را جدا جمع بزنید و بعد join کنید** (وگرنه مبلغ چند برابر می‌شود). برچسب فقط اگر `outcomes.available_at <= cutoff`. تابع `build_features` عمداً هنوز پیاده نشده |
| lineage مدل در MLflow و bundle | `dataset_identity(conn, as_of=...)` و فرمان `promiseops dataset-identity` | مقدار را در `lineage.dataset_identity` بگذارید |
| API (404 برای سفارش منتشرنشده) | view `order_releases` | `released_at <= as_of` شرکت |
| Airflow DAG | `promiseops ingest-feed DIR --as-of ...` با کد خروج ۰/۱/۳ | retry امن است (idempotent)؛ کد ۳ = داده خراب، retry نکنید |
| پایش و تمرین حادثه («batch خراب») | `ingest_attempts` و `ingest_quarantine` | مدرک تشخیص و علت آماده است |

---

## ۹. اجرا

### ۹.۱ فرمان‌ها (متغیر `PROMISEOPS_DATABASE_URL` باید تنظیم باشد)

```bash
promiseops db-init
promiseops payload-sha256 fixtures/synthetic-orders.json
promiseops ingest-file fixtures/synthetic-orders.json --as-of 2017-06-01T00:00:00Z --expected-sha256 <خروجی فرمان قبل>
promiseops ingest-feed <پوشهٔ feed> --as-of 2017-06-01T00:00:00Z
promiseops dataset-identity --as-of 2017-06-01T00:00:00Z
```

کدهای خروج: `0` موفق، `1` خطای غیرمنتظره، `2` استفادهٔ غلط از فرمان، `3` batch رد شد.
نتیجه روی stdout (JSON)، لاگ روی stderr (هر خط یک JSON).

### ۹.۲ تست‌ها

تست‌های بدون دیتابیس (همیشه، مثل CI):

```bash
pytest -q
```

تست‌های دیتابیس به PostgreSQL واقعی نیاز دارند. فایل `compose.test.yaml` در ریشهٔ پروژه یک PostgreSQL
موقت فقط روی کامپیوتر خودتان (`127.0.0.1:55432`) می‌سازد؛ این دیتابیس اصلی پروژه نیست (آن را مسئولان دوره روی
کلاستر داده‌اند).

```powershell
docker compose -f compose.test.yaml up -d --wait
$env:PROMISEOPS_TEST_DATABASE_URL = "postgresql://promiseops:promiseops-test@127.0.0.1:55432/promiseops_test"
pytest -q
```

- توقف با نگه داشتن داده: `docker compose -f compose.test.yaml down` — توقف و پاک کردن داده: همان فرمان با `-v`.
- رمز پیش‌فرض ساده است چون پورت فقط از خود کامپیوتر در دسترس است؛ با متغیر `PROMISEOPS_TEST_DB_PASSWORD`
  قابل تغییر است (اگر عوض شد، در URL بالا هم عوض کنید). پورت با `PROMISEOPS_TEST_DB_PORT` عوض می‌شود.
- دیدن داده‌ها: `docker compose -f compose.test.yaml exec postgres psql -U promiseops -d promiseops_test`
  و بعد `SET search_path TO promiseops;` و `\dt`.

**جایگزین‌هایی که انتخاب نشد:** فقط یک فرمان `docker run` در سند (هر کس باید پارامترها را درست کپی کند و
تکرارپذیر نیست)، یا سرویس PostgreSQL در Helm chart (آن برای کلاستر است و دیتابیس آنجا را staff می‌دهد).

⚠️ تست‌ها schema `promiseops` را پاک و دوباره می‌سازند؛ به همین دلیل نام دیتابیس **باید** به `_test`
ختم شود وگرنه تست‌ها اجرا نمی‌شوند.

نتیجهٔ اجرای محلی (بعد از بازبینی): **۹۵ تست موفق** (با دیتابیس)، **۷۰ موفق و ۲۵ رد شده (skip)** بدون دیتابیس؛ `ruff` بدون خطا.

⚠️ تست‌ها را روی دیتابیسی که دادهٔ واقعی دارد اجرا نکنید (schema پاک می‌شود). اگر `promiseops-pg-test` دادهٔ واقعی
دارد، برای تست یک دیتابیس جدا با پورت دیگر بسازید: `$env:PROMISEOPS_TEST_DB_PORT = "55433"` و بعد `docker compose ...`.
(تست `test_real_course_manifest_is_readable_and_ordered` فقط وقتی اجرا می‌شود که دادهٔ واقعی در `data/` باشد.)

### ۹.۳ اجرا روی دادهٔ واقعی دوره

بستهٔ داده: GitLab → پروژه → **Deploy → Package registry** → `olist-course-data` نسخهٔ `2026.11.06` →
فایل `student-company-feed.zip` (۲۰٬۵۰۵٬۷۶۵ بایت، sha256 `698c6d30…a9ffb`). آن را در `data/student-company-feed/`
باز کنید؛ پوشهٔ `data/` در `.gitignore` است، پس داده هرگز commit نمی‌شود (مجوز داده CC BY-NC-SA است).

```bash
promiseops db-init
promiseops ingest-feed data/student-company-feed --as-of 2018-09-10T00:00:00Z
```

**قالب واقعی بسته:** فهرست در `manifest.json` است و ورودی‌ها زیر کلید `releases`؛ هر ورودی
`file`، `kind`، `available_at`، `payload_sha256`، `file_sha256` و تعداد ردیف دارد. ۴۲ batch (۲۱ orders + ۲۱ outcomes)
هر دو هفته از 2018-01-01؛ اولی snapshot تاریخی است (۴۳٬۶۰۹ سفارش). `feed.py` هر دو قالب `releases` (بسته) و
`entries` (پاسخ `GET /feed` گیت‌وی طبق CONTRACTS.md) را می‌پذیرد.

نتیجهٔ اجرای ما (PostgreSQL 16 در Docker محلی، ۱۱ نوامبر ۲۰۲۶):

| اجرا | نتیجه |
|---|---|
| `--as-of 2018-09-10` | ۳۸ batch ثبت شد، **هیچ batchی رد نشد**، حدود ۳۰ ثانیه؛ ۴ batch outcomes بعد از as_of (۵۳ نتیجه) درست کنار گذاشته شدند |
| دوباره با `--as-of 2018-11-05` | ۳۸ batch **replay** (بدون ردیف جدید) + ۴ batch جدید ثبت شد؛ حدود ۴ ثانیه |
| جمع نهایی | ۹۶٬۳۹۳ سفارش، ۹۶٬۳۹۳ نتیجه، ۱۱۰٬۱۰۱ قلم، ۱۰۰٬۶۶۸ پرداخت، ۲٬۹۷۰ فروشنده، ۳۲٬۱۹۹ محصول؛ قرنطینه خالی |
| `dataset-identity` دو بار پشت سر هم | مقدار یکسان (قابل تکرار) |
| نرخ دیرکرد کل داده (`تاریخ محلی تحویل > تاریخ وعده`) | حدود **۶.۸٪** — برای بخش مدل: داده نامتوازن است، پس accuracy معیار مناسبی نیست |

---

## ۱۰. موارد باز و ریسک‌ها (برای بازبین)

1. **قالب فهرست feed:** با بستهٔ واقعی بررسی و اصلاح شد (`manifest.json` / `releases`؛ بخش ۹.۳).
   قالب دقیق پاسخ `GET /feed` گیت‌وی هنوز دیده نشده؛ طبق متن قرارداد کلید `entries` فرض شده و هنگام ساخت
   DAG در Airflow باید بررسی شود.
2. **اختلاف قرارداد و کد در شناسه‌ها:** متن `CONTRACTS.md` الگوی `[A-Za-z0-9][A-Za-z0-9_.-]*` را می‌گوید
   ولی `contracts.py` و `Batch.schema.json` کاراکتر `:` را هم مجاز می‌دانند. ما از کد/schema پیروی کردیم.
3. **CI دیتابیس ندارد:** تست‌های دیتابیس در CI skip می‌شوند. پیشنهاد بعدی: یک job با سرویس `postgres` در `.gitlab-ci.yml`.
4. **نسخهٔ Python:** پروژه 3.12 می‌خواهد؛ اجرای محلی با 3.13 بود (کد با هر دو سازگار است).
5. **`schema.sql` داخل wheel:** بررسی شد — wheel ساخته‌شده با hatchling 1.33 فایل `promiseops/schema.sql` را دارد
   و `.dockerignore` هم `src/**` را به Docker می‌فرستد؛ پس `db-init` داخل ایمیج هم کار می‌کند.
6. تفسیر بند ۶.۸ (تکرار سفارش از batch دیگر) نیاز به تأیید دارد.
7. قانون `data/` در `.gitignore` هر پوشه‌ای به نام `data` را (حتی `docs/data/`) نادیده می‌گیرد؛ به همین دلیل
   این سند در `docs/ingestion/` است. اگر تیم بخواهد فقط پوشهٔ دادهٔ ریشه نادیده گرفته شود، باید `/data/` نوشته شود
   (تغییری که روی همه اثر دارد؛ تصمیمش با تیم است).
