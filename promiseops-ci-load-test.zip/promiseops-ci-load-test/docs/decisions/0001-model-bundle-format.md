# ADR 0001 — Model bundle format

- **Status:** proposed (owner: qbc13-g03-05, model/MLflow) — issue #12
- **Date:** 2026-11-11
- **Affects:** model training (worker), API loader (MR !3, g03-01), CI image build (deploy, g03-04),
  monitoring
- **Code:** `src/promiseops/bundle.py`, tests in `tests/test_bundle.py`
- **Walkthrough, step-by-step reasons and how to run (Persian):** `docs/model/01-bundle-format.fa.md`

## Context

A trained model travels from the training worker to the API inside a *bundle*: one folder that is
stored in MLflow, copied into the app image at `/opt/promiseops/release`, and loaded once at API
startup. Three requirements pull in different directions:

1. **The API loader in MR !3** accepts exactly two files, `model.joblib` and `release.json`, and
   validates `release.json` with `ReleaseManifest`, which has **exactly four fields**
   (`model_version`, `feature_names`, `artifact_sha256`, `source_commit`) and `extra="forbid"`.
   Any additional field makes validation fail, and the API then reports "no model" (503).
2. **`docs/CONTRACTS.md`** requires that every model record contains much more: model SHA256,
   immutable identity, source commit, software versions, dataset/schema identity,
   train/evaluation cutoffs, label cutoff, cohort hash, metrics and gate decision.
3. **Monitoring** needs a validation reference (recall@10%, AP and Brier on validation, and feature
   distributions) to decide about drift and retraining.

The API image does **not** contain MLflow (`requirements.lock`), and production must never load
a model by a mutable MLflow alias. So the bundle must be self-contained.

## Decision

Keep `release.json` exactly as the API loader expects, and put the additional information in
**separate files in the same folder**:

| File | Purpose | Read by | Required |
|---|---|---|---|
| `model.joblib` | fitted scikit-learn `Pipeline` (preprocessing + classifier) | API, worker, batch scoring | yes |
| `release.json` | serving manifest, exactly the four `ReleaseManifest` fields | API loader | yes |
| `lineage.json` | audit record: cutoffs, cohort hash, metrics, versions, gate decision | humans, CI, evidence | for new candidates |
| `reference.json` | validation reference metrics + feature distributions | monitoring | for new candidates |

Additional rules:

- **`model_version` is content-addressed:** `<approach>-<first 12 hex chars of model SHA256>`,
  for example `hist_gradient_boosting-8dbbcf93af92`. It is known as soon as the model file is
  written, does not depend on the MLflow registry, and can never point to a different model.
  The MLflow registry version is linked to it through tags instead.
- **Verify before unpickling:** the SHA256 of `model.joblib` is checked against `release.json`
  *before* `joblib.load`, because unpickling runs code.
- **Atomic and immutable:** a bundle is written in a temporary folder and renamed into place only
  when complete. An existing bundle folder is never overwritten.
- **Only scikit-learn objects are pickled.** A pickle stores the import path of every class, so a
  custom class would tie the bundle to that exact module path forever. `scikit-learn==1.9.0` is
  pinned identically in the API and worker images.
- **Older bundles stay readable:** `lineage.json` and `reference.json` are optional when *reading*,
  so the current incumbent (the mock baseline from MR !3, which has only the two files) can still be
  loaded as a champion.

## Alternatives considered

**Ask g03-01 to extend `ReleaseManifest` with the extra fields.** Rejected for now:

- It changes another member's open MR and makes both MRs wait for each other.
- The serving file would grow with fields the API never uses. Every new audit field would need an
  API change and redeploy (violates the open/closed principle).
- A mistake in an audit field could stop the API from loading a perfectly good model.

**Store lineage only in MLflow.** Rejected: the contract requires that serving does not need live
MLflow, and evidence must survive an MLflow outage (one of the announced incidents). The same
information is still logged to MLflow as well.

## Consequences

- No change is needed in MR !3.
- `release.json` is written with `contracts.ReleaseManifest` itself (since MR !3 was merged on
  2026-11-13; the temporary copy `ServingManifest` was removed). A test opens a written bundle with
  the real `promiseops.api.load_bundle`.
- The API must call the model with a pandas DataFrame whose columns follow
  `release.json["feature_names"]` (the real pipeline selects columns by name). To be raised as a
  review note on MR !3.
- Monitoring reads `reference.json`. Its format is defined in `promiseops.bundle.ValidationReference`.
- `lineage.json["dataset_identity"]` depends on the ingestion receipts from the data part (pending).

## Design notes (SOLID)

- **Single responsibility:** each file has one reader and one reason to change; in code, each
  document has its own schema class, and hashing, writing and reading are separate functions.
- **Open/closed:** new audit information goes into `lineage.json` or a new file, without touching
  the serving manifest or the API loader.
- **Liskov substitution / interface segregation:** the bundle only requires a model that has
  `predict_proba` (`ProbabilisticModel` protocol). Any scikit-learn classifier or pipeline can be
  stored, and readers depend on nothing else.
- **Dependency inversion:** `promiseops.bundle` does not import MLflow. MLflow code will live in a
  separate tracking module that depends on the bundle, not the other way round, so the API and
  batch scoring can use the bundle without MLflow installed.
