#!/usr/bin/env python3
"""Download the verified release bundle from MLflow and package it for the release pipeline.

The training run logs its exact bundle under ``bundle/`` and verifies it on read-back
(promiseops.record.log_record). This script downloads that bundle again, re-verifies it
against the run's ``promiseops.artifact_sha256`` tag (before any code is unpickled) and
against model.joblib (promiseops.bundle.read_bundle), then writes a .tar.gz suitable for
the GitLab generic package registry that ci/prepare_release.py downloads.

Usage (env: MLFLOW_TRACKING_URI plus MLFLOW_TRACKING_TOKEN or
MLFLOW_TRACKING_USERNAME/MLFLOW_TRACKING_PASSWORD — the same values the training Job got):

    PYTHONPATH=src python ci/fetch_release.py RUN_ID [--out DIR]

Prints the archive path, its SHA256 (use as RELEASE_BUNDLE_SHA256) and the next steps.
Exit codes: 0 success, 1 error.
"""

import argparse
import gzip
import hashlib
import io
import sys
import tarfile
from pathlib import Path

from promiseops import record, tracking
from promiseops.bundle import read_bundle


def fetch_verified_bundle(client, run_id: str, out: Path) -> Path:
    """Download the run's bundle into ``out`` after verifying it (record.load_logged_record's trust order)."""
    expected = client.get_run(run_id).data.tags.get(record.TAG_ARTIFACT_SHA256)
    if expected is None:
        raise SystemExit(f"run {run_id} has no {record.TAG_ARTIFACT_SHA256} tag: no model record was logged")
    bundle = Path(client.download_artifacts(run_id, record.BUNDLE_ARTIFACT_DIR, out))
    manifest = read_bundle(bundle).manifest
    if manifest.artifact_sha256 != expected:
        raise SystemExit(f"downloaded bundle artifact_sha256 {manifest.artifact_sha256} "
                         f"does not match the run's tag {expected}")
    return bundle


def archive_bundle(bundle: Path, dest: Path) -> Path:
    """Tar the bundle dir with the dir at archive root (what ci/prepare_release.py extracts).

    mtimes are zeroed (like package_bundle) so re-fetching the same run yields the
    same archive sha256 instead of a new one per invocation.
    """
    with open(dest, "wb") as raw, \
            gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as compressed, \
            tarfile.open(fileobj=compressed, mode="w") as tf:
        for path in sorted(p for p in bundle.iterdir() if p.is_file()):
            info = tarfile.TarInfo(name=f"{bundle.name}/{path.name}")
            content = path.read_bytes()
            info.size, info.mode, info.mtime = len(content), 0o644, 0
            tf.addfile(info, io.BytesIO(content))
    return dest


def main() -> int:
    parser = argparse.ArgumentParser(prog="python ci/fetch_release.py")
    parser.add_argument("run_id", help="MLflow run id of the accepted training run")
    parser.add_argument("--out", default="release-package", help="work dir (default: release-package/)")
    args = parser.parse_args()

    for name, value in tracking._CHECK_HTTP_DEFAULTS.items():
        import os
        os.environ.setdefault(name, value)
    client = tracking.create_client(tracking.TrackingConfig.from_env(experiment_name="release-fetch"))
    bundle = fetch_verified_bundle(client, args.run_id, Path(args.out))
    manifest = read_bundle(bundle).manifest
    archive = archive_bundle(bundle, Path(args.out) / "promiseops-release.tar.gz")
    sha256 = hashlib.sha256(archive.read_bytes()).hexdigest()
    print(f"verified bundle: model_version={manifest.model_version} artifact_sha256={manifest.artifact_sha256}")
    print(f"archive: {archive} sha256={sha256}")
    print("next: upload this archive to the GitLab generic package registry, then run the")
    print("release pipeline with RELEASE_BUNDLE_URL, RELEASE_BUNDLE_SHA256 and RELEASE_BUNDLE_TOKEN.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
