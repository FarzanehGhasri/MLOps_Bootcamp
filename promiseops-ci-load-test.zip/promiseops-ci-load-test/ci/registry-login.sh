#!/usr/bin/env bash
# Shared registry login for the image-build jobs.
set -euo pipefail

mkdir -p "$HOME/.docker"
python ci/registry_login.py
