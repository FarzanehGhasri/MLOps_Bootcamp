#!/usr/bin/env bash
# Shared venv setup for CI jobs: offline wheelhouse sync + editable project install.
# Pass --tracking to also install the MLflow tracking dependencies.
set -euo pipefail

cp -a /opt/promiseops/wheelhouse ./wheelhouse
uv venv --python /usr/local/bin/python .venv
uv pip sync --python .venv/bin/python --no-index --find-links wheelhouse --require-hashes requirements.lock
uv pip install --python .venv/bin/python --no-index --no-deps --no-build-isolation .

if [ "${1:-}" = "--tracking" ]; then
  cp -a /opt/promiseops/tracking-wheelhouse ./tracking-wheelhouse
  uv pip install --python .venv/bin/python --no-index --find-links tracking-wheelhouse --require-hashes -r requirements-tracking.lock
fi
