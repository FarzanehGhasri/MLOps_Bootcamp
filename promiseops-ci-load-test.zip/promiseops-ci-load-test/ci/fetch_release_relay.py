#!/usr/bin/env python3
"""Fetch the accepted training run's bundle from MLflow, verify it, and stream it out.

Runs INSIDE a one-off Job in the team staging namespace (created by the fetch-release CI
job): that namespace can reach the in-cluster MLflow (MLFLOW_TRACKING_URI from the
runtime-config secret) but has no egress to the GitLab host — so the verified archive
leaves the pod through THIS pod log: base64 between BUNDLE_BASE64_BEGIN/END sentinels on
stdout, diagnostics on stderr. The CI job extracts it with kubectl logs, re-checks the
digest, and uploads to the package registry from the runner. The pod is read-only and
nothing is unpickled here — digest checks only; the full read_bundle verification
(manifest schema + unpickle) happens in ci/prepare_release.py.

Trust order (promiseops.record.load_logged_record): the run's promiseops.artifact_sha256
tag must equal release.json's artifact_sha256, which must equal the model.joblib digest.

Environment: MLFLOW_TRACKING_URI (+ optional MLFLOW_TRACKING_TOKEN, MLFLOW_HOST_HEADER)
via the runtime-config secret; the MLflow run id (or models:/<name>@<alias>) as argv[1].
"""

import base64
import gzip
import hashlib
import io
import json
import os
import sys
import tarfile
import urllib.parse
import urllib.request

TAG = "promiseops.artifact_sha256"
BUNDLE = "bundle"


class ApiError(RuntimeError):
    pass


def api(uri: str, headers: dict, endpoint: str, params: dict):
    url = f"{uri}/api/2.0/mlflow/{endpoint}?{urllib.parse.urlencode(params)}"
    host = urllib.parse.urlsplit(uri).hostname
    request = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(request, timeout=60) as response:
            return json.load(response)
    except urllib.error.HTTPError as error:
        # Distinguish MLflow's own "not found" JSON from an ingress/nginx 404 for the path.
        body = error.read(300).decode(errors="replace")
        raise ApiError(f"GET {endpoint} on {host} -> HTTP {error.code}: {body!r}") from None
    except urllib.error.URLError as error:
        raise ApiError(f"GET {endpoint} on {host} unreachable: {error.reason}") from None


def fail(message: str) -> "int":
    print(f"ERROR: {message}", file=sys.stderr)
    return 1


def resolve_model_ref(uri: str, headers: dict, model_ref: str) -> tuple:
    """Resolve "models:/<name>@<alias>" or "models:/<name>/<version>" to a (run_id, version).

    The REST equivalent of MlflowClient.get_model_version_by_alias/get_model_version_download_uri:
    both map a registry reference to the ModelVersion record whose run_id anchors the verified
    bundle fetch. The resolved values are logged, so the release record stays pinned even
    though the alias itself is mutable.
    """
    ref = model_ref[len("models:/"):]
    if "@" in ref:
        params = {"name": ref.split("@", 1)[0], "alias": ref.split("@", 1)[1]}
        document = api(uri, headers, "registered-models/alias", params)
    else:
        name, _, version = ref.partition("/")
        if not version:
            raise ApiError(f"unsupported model ref {model_ref!r}: use models:/name@alias or models:/name/version")
        document = api(uri, headers, "model-versions/get", {"name": name, "version": version})
    model_version = document["model_version"]
    print(f"resolved {model_ref} -> registry version {model_version.get('version')} "
          f"run {model_version.get('run_id')}", file=sys.stderr)
    return model_version["run_id"], model_version.get("version")


def http_get_bytes(url: str, headers: dict) -> bytes:
    """Proxied artifact download: the response body IS the file bytes (no JSON wrapper)."""
    with urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=120) as response:
        return response.read()


def pack_archive(blobs: dict) -> bytes:
    """Deterministic tar.gz of the bundle (zeroed mtimes, like package_bundle): re-fetching
    the same run yields byte-identical archives, so RELEASE_BUNDLE_SHA256 is stable per run
    id and a changed sha means the bundle content actually changed."""
    buffer = io.BytesIO()
    with gzip.GzipFile(filename="", mode="wb", fileobj=buffer, mtime=0) as compressed, \
            tarfile.open(fileobj=compressed, mode="w") as archive:
        for path, data in sorted(blobs.items()):
            info = tarfile.TarInfo(name=path)
            info.size, info.mode, info.mtime = len(data), 0o644, 0
            archive.addfile(info, io.BytesIO(data))
    return buffer.getvalue()


def main() -> int:
    model_ref = sys.argv[1] if len(sys.argv) == 2 else ""
    # The MLflow URI comes from the runtime-config secret via the pod's environment.
    uri = os.environ.get("MLFLOW_TRACKING_URI", "").rstrip("/")
    if not model_ref:
        return fail("argv[1] (run id or models:/<name>@<alias>) must be set")
    if not uri:
        return fail("MLFLOW_TRACKING_URI is not set in this pod (runtime-config secret)")
    print(f"mlflow host: {urllib.parse.urlsplit(uri).hostname}", file=sys.stderr)
    print(f"host header override: {os.environ.get('MLFLOW_HOST_HEADER') or 'none'}", file=sys.stderr)

    headers = {}
    if os.environ.get("MLFLOW_TRACKING_TOKEN"):
        headers["Authorization"] = f"Bearer {os.environ['MLFLOW_TRACKING_TOKEN']}"
    if os.environ.get("MLFLOW_HOST_HEADER"):
        headers["Host"] = os.environ["MLFLOW_HOST_HEADER"]

    resolved_version = None
    if model_ref.startswith("models:/"):
        # The reference is resolved once here and the release is pinned to the resolved
        # run: a moved alias between approval and fetch changes nothing mid-flow.
        run_id, resolved_version = resolve_model_ref(uri, headers, model_ref)
    else:
        run_id = model_ref

    run = api(uri, headers, "runs/get", {"run_id": run_id})["run"]
    tags = {t["key"]: t["value"] for t in run["data"]["tags"]}
    expected = tags.get(TAG)
    if not expected:
        return fail(f"run {run_id} has no {TAG} tag: no model record was logged")

    # The platform serves artifacts through the tracking server's proxy: the run's
    # artifact_uri is "http://<host>/api/2.0/mlflow-artifacts/artifacts/<exp>/<run>/artifacts"
    # (or "mlflow-artifacts:/<exp>/<run>/artifacts"). List and download go to the same
    # mlflow-artifacts endpoint; anything else (s3:, server-local paths) is not fetchable
    # from a pod and fails here with the observed location.
    artifact_uri = run["info"].get("artifact_uri") or ""
    if "/mlflow-artifacts/artifacts" in artifact_uri:
        base, _, root = artifact_uri.partition("/mlflow-artifacts/artifacts")
        endpoint_base = base.rstrip("/") + "/api/2.0/mlflow-artifacts/artifacts"
        root = root.strip("/")
    elif artifact_uri.startswith("mlflow-artifacts:"):
        endpoint_base = uri.rstrip("/") + "/api/2.0/mlflow-artifacts/artifacts"
        root = artifact_uri.split(":", 1)[1].strip("/")
    else:
        return fail(f"unsupported artifact location {artifact_uri!r}: the relay can only "
                    "download proxied (mlflow-artifacts) artifacts")

    # List is GET <endpoint_base>?path=<root>/<bundle> (raw JSON, same host as artifacts).
    url = f"{endpoint_base}?{urllib.parse.urlencode({'path': f'{root}/{BUNDLE}'})}"
    with urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=60) as response:
        listing = json.load(response)
    blobs = {}
    prefix = f"{root}/{BUNDLE}/"
    for entry in listing["files"]:
        if entry.get("is_dir"):
            continue
        rel = entry["path"].removeprefix(prefix)
        data = http_get_bytes(f"{endpoint_base}/{root}/{BUNDLE}/{rel}", headers)
        blobs[f"{BUNDLE}/{rel}"] = data
        print(f"downloaded {BUNDLE}/{rel} ({len(data)} bytes)", file=sys.stderr)
    if f"{BUNDLE}/release.json" not in blobs or f"{BUNDLE}/model.joblib" not in blobs:
        return fail("bundle artifacts missing release.json or model.joblib")

    manifest = json.loads(blobs[f"{BUNDLE}/release.json"])
    if manifest.get("artifact_sha256") != expected:
        return fail(f"release.json artifact_sha256 {manifest.get('artifact_sha256')!r} "
                    f"does not match the run tag {expected!r}")
    model_sha = hashlib.sha256(blobs[f"{BUNDLE}/model.joblib"]).hexdigest()
    if model_sha != expected:
        return fail(f"model.joblib digest {model_sha} does not match release.json {expected!r}")

    archive = pack_archive(blobs)
    archive_sha = hashlib.sha256(archive).hexdigest()

    # The staging namespace has no egress to the GitLab host, so the archive leaves the
    # pod through THIS pod log: base64 between sentinels on stdout (diagnostics go to
    # stderr). The CI job extracts it with kubectl logs, checks the digest below, and
    # uploads to the package registry from the runner.
    print("BUNDLE_BASE64_BEGIN")
    for chunk in base64.encodebytes(archive).decode().splitlines():
        print(chunk, flush=True)
    print("BUNDLE_BASE64_END")
    print(f"bundle verified: model_version={manifest.get('model_version')} model_sha256={model_sha} "
          + (f"registry_version={resolved_version}" if resolved_version else ""), file=sys.stderr)
    print(f"RELEASE_BUNDLE_SHA256={archive_sha}")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except ApiError as error:
        print(f"ERROR: {error}", file=sys.stderr)
        sys.exit(1)
