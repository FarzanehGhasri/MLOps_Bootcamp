#!/usr/bin/env python3
"""Fetch the human-approved release bundle, verify it, and replace ``release/`` with it.

CI's ``prepare-release`` job runs this before the image build so the Dockerfile
``COPY release`` bakes in the reviewed incumbent bundle, not the repo placeholder.
The bundle source is a package artifact (e.g. GitLab generic package registry)
configured with:

* ``RELEASE_BUNDLE_URL``  -- URL of the bundle archive (``.tar.gz``, ``.tgz`` or ``.zip``)
* ``RELEASE_BUNDLE_TOKEN`` -- optional bearer token for private registries OUTSIDE this
  project; in CI the own project's registry is fetched with the job token (no secret).
* ``RELEASE_BUNDLE_SHA256`` -- optional pin; the archive digest must match it

The bundle directory must contain ``release.json`` + the model file (``model.joblib``).
Verification is ``promiseops.bundle.read_bundle``: manifest schema, model SHA256 vs
manifest, and unpickling. Anything failing verification never reaches the image.

Exit codes: 0 success, 1 error.
"""

import hashlib
import os
import shutil
import sys
import tarfile
import tempfile
import urllib.error
import urllib.request
import zipfile
from pathlib import Path

from promiseops.bundle import read_bundle

SERVING_FILES = ("release.json", "model.joblib")


def download_archive(url: str, token: str | None, expected_sha256: str | None, dest: Path) -> None:
    request = urllib.request.Request(url)
    if token:
        request.add_header("Authorization", f"Bearer {token}")
    elif os.environ.get("CI_JOB_TOKEN"):
        # No token given and running in CI: this job's token can fetch the own project's
        # package registry, so the release pipeline needs no secret at all.
        request.add_header("JOB-TOKEN", os.environ["CI_JOB_TOKEN"])
    with urllib.request.urlopen(request) as response:
        data = response.read()
    if expected_sha256:
        actual = hashlib.sha256(data).hexdigest()
        if actual != expected_sha256:
            raise SystemExit(f"bundle archive SHA256 mismatch: got {actual}, expected {expected_sha256}")
    dest.write_bytes(data)


def extract_archive(archive: Path, dest: Path) -> Path:
    dest.mkdir(parents=True, exist_ok=True)
    if zipfile.is_zipfile(archive):
        with zipfile.ZipFile(archive) as zf:
            zf.extractall(dest)
    elif tarfile.is_tarfile(archive):
        # python 3.14 defaults to filter="data": refuses paths outside dest; keep explicit.
        with tarfile.open(archive) as tf:
            try:
                tf.extractall(dest, filter="data")
            except TypeError:  # python < 3.11.4 has no filter= kwarg
                tf.extractall(dest)
    else:
        raise SystemExit(f"unsupported bundle archive format: {archive.name}")
    entries = [p for p in dest.iterdir()]
    if len(entries) == 1 and entries[0].is_dir():
        return entries[0]
    return dest


def verify(bundle: Path) -> None:
    for name in SERVING_FILES:
        if not (bundle / name).is_file():
            raise SystemExit(f"bundle is missing {name}")
    read_bundle(bundle)


def replace_release(bundle: Path, dest: Path) -> None:
    staging = dest.parent / f".{dest.name}.new"
    backup = dest.parent / f".{dest.name}.old"
    shutil.rmtree(staging, ignore_errors=True)
    shutil.rmtree(backup, ignore_errors=True)
    shutil.copytree(bundle, staging)
    dest.rename(backup)
    staging.rename(dest)
    shutil.rmtree(backup)


def main() -> int:
    url = os.environ.get("RELEASE_BUNDLE_URL", "").strip()
    if not url:
        raise SystemExit("RELEASE_BUNDLE_URL is not set; point it at the approved bundle archive")
    with tempfile.TemporaryDirectory(prefix="prepare-release.") as tmp:
        work = Path(tmp)
        download_archive(url, os.environ.get("RELEASE_BUNDLE_TOKEN") or None,
                         os.environ.get("RELEASE_BUNDLE_SHA256") or None, work / "bundle.bin")
        bundle = extract_archive(work / "bundle.bin", work / "extracted")
        verify(bundle)
        manifest = read_bundle(bundle).manifest
        print(f"verified bundle: model_version={manifest.model_version} "
              f"artifact_sha256={manifest.artifact_sha256[:12]}...")
        release_dir = Path(__file__).resolve().parent.parent / "release"
        replace_release(bundle, release_dir)
    print(f"replaced {release_dir} with the verified bundle")
    return 0


if __name__ == "__main__":
    sys.exit(main())
