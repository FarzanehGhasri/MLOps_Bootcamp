"""Record an executed pytest/JUnit report in MLflow without presenting it as real-data evaluation.

python -m promiseops.verification --junit results.xml --log pytest.log
Requires MLFLOW_TRACKING_URI and CI_COMMIT_SHA. Does not run, fabricate or retry tests.
"""

import argparse
import hashlib
import json
import os
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

from promiseops import bundle, experiment_log, tracking

EXPERIMENT = "promiseops-verification"


def summarize_junit(text: str) -> dict:
    root = ET.fromstring(text)
    cases = [root] if root.tag == "testcase" else list(root.iter("testcase"))
    if not cases:
        raise ValueError("JUnit report contains no test cases")
    tests = []
    for case in cases:
        status = next((name for name in ("error", "failure", "skipped") if case.find(name) is not None), "passed")
        tests.append({"name": f"{case.get('classname', '')}::{case.get('name', '')}",
                      "status": status, "duration_seconds": float(case.get("time", "0"))})
    return {"report_schema_version": "1.0", "dataset_kind": "synthetic_software_tests",
            "total": len(tests), **{name: sum(t["status"] == name for t in tests)
                                   for name in ("passed", "failure", "error", "skipped")}, "tests": tests}


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--junit", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    args = parser.parse_args(argv)
    try:
        commit = tracking.source_commit_from_env(os.environ)
        if commit is None:
            raise ValueError("CI_COMMIT_SHA is required to identify the tested code")
        xml = args.junit.read_text(encoding="utf-8")
        report = summarize_junit(xml)
        report.update({"source_commit": commit, "software_versions": bundle.collect_software_versions(),
                       "junit_sha256": hashlib.sha256(args.junit.read_bytes()).hexdigest(),
                       "log_sha256": hashlib.sha256(args.log.read_bytes()).hexdigest()})
        client = tracking.create_client(tracking.TrackingConfig.from_env(os.environ))
        success = report["failure"] + report["error"] == 0
        run_id = experiment_log.log_report(
            client, experiment=EXPERIMENT, kind="verification", source_commit=commit, report=report,
            params={"dataset_kind": report["dataset_kind"], "phase": "software_verification"},
            metrics={key: report[key] for key in ("total", "passed", "failure", "error", "skipped")},
            artifacts={"junit.xml": xml, "pytest.log": args.log.read_text(encoding="utf-8")}, successful=success)
        print(json.dumps({"status": "ok" if success else "tests_failed", "mlflow_run_id": run_id,
                          "passed": report["passed"], "skipped": report["skipped"]}))
        return 0 if success else 1
    # CLI boundary must sanitize third-party failures and return a nonzero exit code.
    except Exception as error:  # noqa: BLE001
        print(json.dumps({"status": "failed", "error": tracking.redact_error(error)}), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
