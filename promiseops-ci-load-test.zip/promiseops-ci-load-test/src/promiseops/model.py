"""Train a reproducible candidate and decide whether it may replace the champion (contract entry points).

    train_candidate(connection, *, train_end, validation_end, as_of) -> Candidate
    compare_candidate(candidate, champion, cohort)                   -> GateDecision

Steps of train_candidate:
  1. cutoffs checked (train_end < validation_end <= as_of)             promiseops.cohorts.Cutoffs
  2. labels known at as_of; train/validation cohorts                   promiseops.cohorts
  3. too small / one-class cohort -> InsufficientCohort (no metrics)   promiseops.cohorts
  4. features of both cohorts, the same code as serving                promiseops.features
  5. baseline + every candidate approach fitted on train               promiseops.approaches
  6. all scored on the SAME validation orders                          promiseops.metrics
  7. best approach chosen on validation only (the test period stays untouched)

MLflow logging and the bundle are done by the worker (#15) with promiseops.record (#16) and
promiseops.bundle (#12): this module has no side effects besides reading the database.
Walkthrough and reasons (Persian): docs/features/02-models-and-gates.fa.md

The last section keeps ``ConstantProbabilityEstimator`` from MR !3 (g03-01) unchanged: the
committed incumbent ``release/model.joblib`` was pickled as
``promiseops.model.ConstantProbabilityEstimator``, so moving or renaming it would make the API and
the worker unable to load the current release.
"""

import hashlib
import json
from collections.abc import Sequence
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import psycopg

from promiseops import approaches, cohorts, features, gates, metrics
from promiseops.bundle import EvaluationMetrics, ProbabilisticModel
from promiseops.contracts import ReleaseManifest

BASELINE_MODEL_VERSION = "baseline-training-prevalence"


@dataclass(frozen=True)
class ValidationCohort:
    """The validation orders every model is scored on, with their features and labels."""

    features: pd.DataFrame   # index order_id (sorted), columns FEATURE_NAMES
    late: pd.Series          # bool, same index
    sha256: str              # cohorts.cohort_sha256 of the index

    @classmethod
    def build(cls, table: pd.DataFrame, late: pd.Series) -> "ValidationCohort":
        table = table.sort_index()
        labels = late.reindex(table.index)
        if labels.isna().any():
            raise ValueError("every validation order needs a known label")
        return cls(features=table, late=labels.astype(bool), sha256=cohorts.cohort_sha256(table.index))

    @property
    def order_ids(self) -> list[str]:
        return [str(order_id) for order_id in self.features.index]


@dataclass(frozen=True)
class Champion:
    """The model currently serving (from the incumbent bundle) or, for the first candidate, the baseline."""

    model_version: str
    model: ProbabilisticModel


@dataclass(frozen=True)
class Candidate:
    approach: str
    model: ProbabilisticModel                    # fitted Pipeline: preprocessing + estimator
    cutoffs: cohorts.Cutoffs
    train_summary: dict                          # cohorts.describe of the training cohort
    validation_metrics: EvaluationMetrics
    cohort: ValidationCohort
    approach_metrics: dict[str, EvaluationMetrics]   # every approach incl. baseline, same cohort
    approach_parameters: dict[str, dict[str, str]]   # settings of every fitted approach, not only the winner
    baseline: ProbabilisticModel                 # fitted constant-prevalence model
    training_features: pd.DataFrame              # reference distributions for monitoring (#26)

    # The two methods below only SHAPE values for MLflow; logging them is the worker's job (#15),
    # so this module never imports MLflow (dependency inversion: plain dicts in, any logger out).
    def run_params(self) -> dict[str, str]:
        """Chosen approach, its hyperparameters (incl. preprocessing) and the cohort sizes."""
        params = {f"hp.{key}": value for key, value in approaches.hyperparameters(self.model).items()}
        params.update({f"approaches.{name}.{key}": value
                       for name, settings in self.approach_parameters.items() for key, value in settings.items()})
        params.update({
            "approach": self.approach,
            "candidate_approaches": ",".join(name for name in self.approach_metrics if name != approaches.BASELINE),
            "train_n": str(self.train_summary["n"]),
            "train_prevalence": str(self.train_summary["prevalence"]),
            "train_cohort_sha256": str(self.train_summary["cohort_sha256"]),
        })
        return params

    def comparison_metrics(self) -> dict[str, float]:
        """Every approach (baseline included) on the same validation cohort: ``<approach>.<metric>``."""
        return {f"{name}.{metric}": float(value)
                for name, scored in self.approach_metrics.items()
                for metric, value in scored.model_dump().items()}


@dataclass(frozen=True)
class GateDecision:
    decision: str                                # "accepted" | "rejected"
    reasons: tuple[str, ...]
    candidate_metrics: EvaluationMetrics
    champion_metrics: EvaluationMetrics
    champion_model_version: str
    cohort_sha256: str


def train_candidate(connection: psycopg.Connection, *, train_end: datetime | str,
                    validation_end: datetime | str, as_of: datetime | str,
                    include_history: bool = False) -> Candidate:
    """At least two approaches; mature labels at the correct cutoffs; MLflow lineage (by the worker)."""
    cutoffs = cohorts.Cutoffs(train_end=train_end, validation_end=validation_end, as_of=as_of)
    labels = cohorts.load_labels(connection, as_of=cutoffs.as_of)
    split = cohorts.split(labels, cutoffs)
    cohorts.require_sufficient("train", labels, split.train)
    cohorts.require_sufficient("validation", labels, split.validation)
    if include_history:
        table = features.load_features_with_history(
            connection, split.train + split.validation, as_of=cutoffs.as_of, freeze_at=cutoffs.train_end
        )
    else:
        table = features.load_features(connection, split.train + split.validation, as_of=cutoffs.as_of)
    return fit_candidate(table, labels, split)


def fit_candidate(table: pd.DataFrame, labels: pd.DataFrame, split: cohorts.Split,
                  candidates: Sequence[str] = approaches.CANDIDATE_APPROACHES) -> Candidate:
    """Pure part of train_candidate (no database): fit, score on one cohort, choose."""
    late = labels.set_index("order_id")["late"]
    missing = set(split.train + split.validation) - set(table.index)
    if missing:
        raise ValueError(f"{len(missing)} cohort order(s) have no features, e.g. {min(missing)!r}")
    train_x = table.loc[list(split.train)]
    train_y = late.reindex(train_x.index).astype(bool)
    cohort = ValidationCohort.build(table.loc[list(split.validation)], late)

    fitted = {name: approaches.fit(name, train_x, train_y) for name in (approaches.BASELINE, *candidates)}
    scored = {name: score(model, cohort) for name, model in fitted.items()}
    best = select_best({name: scored[name] for name in candidates})
    return Candidate(
        approach=best,
        model=fitted[best],
        cutoffs=split.cutoffs,
        train_summary=cohorts.describe(labels, split.train),
        validation_metrics=scored[best],
        cohort=cohort,
        approach_metrics=scored,
        approach_parameters={name: approaches.hyperparameters(pipeline) for name, pipeline in fitted.items()},
        baseline=fitted[approaches.BASELINE],
        training_features=train_x,
    )


def select_best(scored: dict[str, EvaluationMetrics]) -> str:
    """Highest recall@10% (the business budget: 10% of orders can be reviewed); then PR-AUC; then
    lower Brier; then name — so the choice is deterministic and matches the first gate."""
    return min(scored, key=lambda name: (-scored[name].recall_at_10, -scored[name].pr_auc,
                                         scored[name].brier, name))


def score(model: ProbabilisticModel, cohort: ValidationCohort) -> EvaluationMetrics:
    """Contract metrics of ``model`` on ``cohort`` (always recomputed: a changed champion is re-evaluated)."""
    return metrics.evaluate(cohort.order_ids, cohort.late.to_numpy(), approaches.risk(model, cohort.features))


def compare_candidate(candidate: Candidate, champion: Champion | None, cohort: ValidationCohort, *,
                      champion_cohort: ValidationCohort | None = None) -> GateDecision:
    """Both models must use exactly the same validation orders and public gates.

    ``champion=None`` means there is no trained champion yet: the contract compares the first
    candidate with the constant training-prevalence baseline. Both models are scored here, on
    ``cohort``, which must be the candidate's own validation cohort (same hash).
    """
    if cohort.sha256 != candidate.cohort.sha256:
        raise ValueError("cohort differs from the candidate's validation cohort: scores would not be comparable")
    if champion is None:
        champion = Champion(model_version=BASELINE_MODEL_VERSION, model=candidate.baseline)
    candidate_metrics = score(candidate.model, cohort)
    champion_cohort = champion_cohort if champion_cohort is not None else cohort
    if champion_cohort.sha256 != cohort.sha256 or champion_cohort.order_ids != cohort.order_ids:
        raise ValueError("champion must be scored on identical validation IDs")
    if not champion_cohort.late.equals(cohort.late):
        raise ValueError("champion must be scored with identical validation labels")
    champion_metrics = score(champion.model, champion_cohort)
    result = gates.apply_gates(candidate_metrics, champion_metrics)
    return GateDecision(
        decision=result.decision,
        reasons=result.reasons,
        candidate_metrics=candidate_metrics,
        champion_metrics=champion_metrics,
        champion_model_version=champion.model_version,
        cohort_sha256=cohort.sha256,
    )


# --------------------------------------------------------------------------------------------
# Mock incumbent from MR !3 (g03-01). Do not move or rename: release/model.joblib unpickles it.
# --------------------------------------------------------------------------------------------
class ConstantProbabilityEstimator:
    """A simple estimator that returns a constant probability for all inputs."""

    def __init__(self, probability: float = 0.08):
        self.probability = probability

    def predict_proba(self, X):
        """Return a constant probability for all inputs."""
        return np.full((len(X), 2), [1 - self.probability, self.probability])

    def build_mock_bundle(
        self,
        output_dir: Path | str,
        *,
        model_version: str = "baseline-constant-v1",
        features_path: Path | str = "contracts/features.json",
        source_commit: str = "0000000000000000000000000000000000000000",
    ) -> ReleaseManifest:
        """Build and validate a mock model bundle matching project contracts."""
        out_path = Path(output_dir)
        out_path.mkdir(parents=True, exist_ok=True)

        model_file = out_path / "model.joblib"
        joblib.dump(self, model_file)

        model_bytes = model_file.read_bytes()
        artifact_sha256 = hashlib.sha256(model_bytes).hexdigest()

        feature_names = json.loads(Path(features_path).read_text(encoding="utf-8"))

        manifest = ReleaseManifest(
            model_version=model_version,
            feature_names=feature_names,
            artifact_sha256=artifact_sha256,
            source_commit=source_commit,
        )

        manifest_file = out_path / "release.json"
        manifest_file.write_text(
            json.dumps(manifest.model_dump(), indent=2), encoding="utf-8"
        )

        return manifest
