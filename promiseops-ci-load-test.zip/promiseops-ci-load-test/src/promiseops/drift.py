"""Distribution math for monitoring: reference histograms, PSI, total variation distance, data quality.

One job: measure how a set of feature values differs from the training reference. No windows, no
thresholds, no decisions — those are policy and live in promiseops.monitor (single responsibility:
the math can be tested and reused without the retraining rules).

* numeric features    -> PSI against quantile bins of the TRAINING cohort (open-ended outer bins)
* categorical features-> total variation distance against training category shares
* data quality        -> missing values, values outside the training range, unseen categories

The reference document is the bundle's ``reference.json`` (promiseops.bundle.ValidationReference),
built once at training time by ``build_reference``.
Walkthrough and reasons (Persian): docs/features/03-monitoring.fa.md
"""

from collections.abc import Iterable

import numpy as np
import pandas as pd

from promiseops.bundle import (
    CategoricalDistribution,
    EvaluationMetrics,
    NumericDistribution,
    ValidationReference,
)
from promiseops.features import CATEGORICAL_FEATURES

REFERENCE_BINS = 10
# PSI divides by bin shares: an empty bin would give log(0). A small floor is the usual fix; it only
# matters for empty bins, and 1e-4 keeps one empty bin from dominating the sum.
_PSI_FLOOR = 1e-4


# ---------------------------------------------------------------------------------------------
# Reference (training time)
# ---------------------------------------------------------------------------------------------
def build_reference(training_features: pd.DataFrame, validation_metrics: EvaluationMetrics,
                    validation_cohort_sha256: str, *, bins: int = REFERENCE_BINS) -> ValidationReference:
    """Training distributions + validation metrics -> ``reference.json`` (promiseops.bundle)."""
    numeric = {name: numeric_distribution(training_features[name], bins=bins)
               for name in training_features.columns if name not in CATEGORICAL_FEATURES}
    categorical = {name: categorical_distribution(training_features[name]) for name in CATEGORICAL_FEATURES}
    return ValidationReference(validation_cohort_sha256=validation_cohort_sha256,
                               validation_metrics=validation_metrics, numeric=numeric, categorical=categorical)


def numeric_distribution(values: Iterable[float], *, bins: int = REFERENCE_BINS) -> NumericDistribution:
    """Quantile (equal-frequency) bins of the training values: suits skewed money amounts.

    Discrete features (item_count is mostly 1) give repeated quantiles; repeated edges are merged,
    so such a feature simply has fewer bins. A constant feature gets one bin around its value.
    """
    data = np.asarray(list(values), dtype=float)
    edges = np.unique(np.quantile(data, np.linspace(0, 1, bins + 1)))
    if len(edges) < 2:
        edges = np.array([edges[0] - 0.5, edges[0] + 0.5])
    return NumericDistribution(edges=edges.tolist(), proportions=bin_shares(edges, data).tolist())


def categorical_distribution(values: Iterable[str]) -> CategoricalDistribution:
    shares = pd.Series(list(values), dtype=object).astype(str).value_counts(normalize=True).sort_index()
    return CategoricalDistribution(proportions={str(k): float(v) for k, v in shares.items()})


# ---------------------------------------------------------------------------------------------
# Scores (monitoring time)
# ---------------------------------------------------------------------------------------------
def psi(reference: NumericDistribution, values: Iterable[float]) -> float:
    """Population stability index of ``values`` against the reference histogram."""
    expected = np.maximum(np.asarray(reference.proportions, dtype=float), _PSI_FLOOR)
    actual = np.maximum(bin_shares(np.asarray(reference.edges), np.asarray(list(values), dtype=float)),
                        _PSI_FLOOR)
    return float(np.sum((actual - expected) * np.log(actual / expected)))


def tvd(reference: CategoricalDistribution, values: Iterable[str]) -> float:
    """Total variation distance: half the summed share differences. New categories count fully."""
    current = pd.Series(list(values), dtype=object).astype(str).value_counts(normalize=True)
    categories = set(reference.proportions) | set(current.index)
    return 0.5 * sum(abs(reference.proportions.get(c, 0.0) - float(current.get(c, 0.0))) for c in categories)


def feature_scores(reference: ValidationReference, rows: pd.DataFrame) -> dict[str, float]:
    """PSI for every numeric and TVD for every categorical feature of the reference (empty rows -> {})."""
    if rows.empty:
        return {}
    scores = {name: psi(dist, rows[name]) for name, dist in reference.numeric.items()}
    scores.update({name: tvd(dist, rows[name]) for name, dist in reference.categorical.items()})
    return {name: round(score, 6) for name, score in scores.items()}


def data_quality(reference: ValidationReference, rows: pd.DataFrame) -> dict[str, dict[str, float]]:
    """Input checks next to drift (project doc part 7: data quality, drift and model quality).

    Per feature, as shares of the rows: ``missing`` (null), and ``outside_training_range``
    (numeric) or ``unseen_category`` (categorical). Only nonzero findings are listed.
    """
    findings: dict[str, dict[str, float]] = {}
    total = len(rows)
    if total == 0:
        return findings
    for name, dist in reference.numeric.items():
        values = pd.to_numeric(rows[name], errors="coerce")
        outside = ((values < dist.edges[0]) | (values > dist.edges[-1])).sum()
        _add(findings, name, missing=values.isna().sum() / total, outside_training_range=outside / total)
    for name, dist in reference.categorical.items():
        values = rows[name]
        unseen = (~values.isna() & ~values.astype(str).isin(set(dist.proportions))).sum()
        _add(findings, name, missing=values.isna().sum() / total, unseen_category=unseen / total)
    return findings


def bin_shares(edges: np.ndarray, values: np.ndarray) -> np.ndarray:
    """Share of values per bin; below edges[0] -> first bin, above edges[-1] -> last bin."""
    if len(values) == 0:
        return np.zeros(len(edges) - 1)
    # Only the inner edges are searched: everything left of edges[1] lands in bin 0 and everything
    # at/after edges[-2] in the last bin, which makes the outer bins open-ended.
    index = np.searchsorted(edges[1:-1], values, side="right")
    return np.bincount(index, minlength=len(edges) - 1) / len(values)


def _add(findings: dict[str, dict[str, float]], name: str, **shares: float) -> None:
    nonzero = {key: round(float(value), 4) for key, value in shares.items() if value > 0}
    if nonzero:
        findings[name] = nonzero
