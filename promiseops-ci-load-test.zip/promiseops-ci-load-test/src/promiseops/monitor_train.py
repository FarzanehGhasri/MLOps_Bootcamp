"""One monitoring run of the queued worker, ``--mode monitor-train`` (issue #21).

What the contract asks (docs/CONTRACTS.md, "Queued worker interface", "Monitoring and retraining")
---------------------------------------------------------------------------------------------------
* "`monitor-train` first persists a report and fits only if retraining is recommended."
* The report follows the public monitoring reference (promiseops.monitor, issue #26): unique orders,
  two 7-day drift windows, 60-day delayed-label window, exact reasons and counts.
* "Neither mode promotes/deploys production." Training, if any, is exactly ``training.run_train``.
* Issue #21 acceptance: with a "no recommendation" report no training runs, and the report is recorded.

Where the predictions come from (the main design decision)
----------------------------------------------------------
The worker consumes a JSONL export of recorded prediction snapshots. An explicit
``PROMISEOPS_PREDICTION_HISTORY`` file takes precedence; otherwise the worker exports PostgreSQL snapshots
for the incumbent's exact model version and artifact checksum. Each row preserves company prediction time, score, immutable model
identity and the features actually observed. Only snapshots of the incumbent model are assessed.
The prediction/replay producer owns the original observed snapshots. Missing history produces a persisted
``no_prediction_history`` record without automatic retraining. Re-scoring old orders and backdating
their timestamps is not a substitute for recorded predictions.

Steps of :func:`run_monitor_train`
---------------------------------
  1. monitoring run created FIRST (own experiment)   MLflow down -> fail before any work
  2. incumbent copied and verified                    bundle.copy_bundle (contract: copy before use)
  3. no reference.json (e.g. the mock from MR !3)     nothing can be measured: recorded, no training
  4. recorded prediction snapshots + known outcomes   load_prediction_history, cohorts.load_labels
  5. report built                                     monitor.build_report (#26)
  6. report PERSISTED: monitoring.json + metrics/tags, read back and compared; run FINISHED
     and read back; only then the decision is published to promiseops.monitoring_decisions
     (promiseops.decisions), which the API exports as promiseops_retraining_required
  7. only if recommended: training.run_train (#15, #20), linked to this run by tags both ways
"""

import json
import tempfile
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Literal

import pandas as pd
import psycopg
from pydantic import BaseModel, ConfigDict, Field

from promiseops import bundle, cohorts, decisions, monitor, tracking, training
from promiseops import prediction_history as snapshots
from promiseops.contracts import instant
from promiseops.features import EXTENDED_FEATURE_NAMES, FEATURE_NAMES

MONITORING_EXPERIMENT = "promiseops-monitoring"  # reports apart from training runs: easy to list and compare
MONITORING_FILE = "monitoring.json"

TAG_RETRAIN = "promiseops.retrain_recommended"
TAG_STATUS = "promiseops.monitoring_status"
TAG_REASONS = "promiseops.monitoring_reasons"
TAG_TRAINING_RUN = "promiseops.training_run_id"       # on the monitoring run
TAG_MONITORING_RUN = "promiseops.monitoring_run_id"   # on the training run it triggered
_MAX_REASONS_TAG = 5000  # the full list is in monitoring.json; the tag is for the MLflow UI


class MonitoringRecord(BaseModel):
    """What one monitor-train run decided and why: the document persisted BEFORE any training."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    record_schema_version: Literal["1.0"] = "1.0"
    as_of: datetime
    incumbent_model_version: str
    status: Literal["assessed", "no_reference", "no_prediction_history"]
    retrain_recommended: bool
    prediction_history_sha256: str | None = None
    reasons: list[str] = Field(default_factory=list)
    report: monitor.MonitoringReport | None = None   # None when reference or recorded history is absent


@dataclass(frozen=True)
class MonitorTrainResult:
    monitoring_run_id: str
    record: MonitoringRecord
    training: training.TrainingResult | None   # None when retraining was not recommended

    def summary(self) -> dict[str, Any]:
        """One JSON-friendly line for the Job log."""
        out = {"mode": "monitor-train", "monitoring_run_id": self.monitoring_run_id,
               "monitoring_status": self.record.status, "retrain_recommended": self.record.retrain_recommended,
               "incumbent_model_version": self.record.incumbent_model_version, "trained": self.training is not None}
        if self.training is not None:
            out["training"] = self.training.summary()
        return out


# ---------------------------------------------------------------------------------------------
# Inputs of the report
# ---------------------------------------------------------------------------------------------
def load_prediction_history(path: Path, incumbent: bundle.LoadedBundle) -> pd.DataFrame:
    """Read recorded JSONL predictions; never reconstruct or backdate historical scores.

    Each line contains PREDICTION_COLUMNS, including the original company prediction time and
    feature values. Exporting these snapshots belongs to the prediction/replay producer.
    """
    if tuple(incumbent.manifest.feature_names) not in (FEATURE_NAMES, EXTENDED_FEATURE_NAMES):
        raise training.TrainingError(f"incumbent {incumbent.manifest.model_version} uses other features than "
                                     "the current code; its prediction snapshots cannot be assessed")
    columns = (*monitor.PREDICTION_COLUMNS[:4], *incumbent.manifest.feature_names)
    rows = []
    with path.open(encoding="utf-8") as stream:
        for number, line in enumerate(stream, 1):
            if not line.strip():
                continue
            try:
                row = json.loads(line)
                if not isinstance(row, dict) or set(row) != set(columns):
                    raise ValueError("expected exactly PREDICTION_COLUMNS")
                row["predicted_at"] = instant(row["predicted_at"])
                if not isinstance(row["order_id"], str) or not row["order_id"]:
                    raise ValueError("order_id must be a nonempty string")
                if not isinstance(row["model_version"], str) or not row["model_version"]:
                    raise ValueError("model_version must be a nonempty string")
                probability = row["risk_probability"]
                if isinstance(probability, bool) or not isinstance(probability, (int, float)) or not 0 <= probability <= 1:
                    raise ValueError("risk_probability must be finite and in [0, 1]")
            except (ValueError, TypeError) as error:
                raise training.TrainingError(f"prediction history line {number}: invalid snapshot") from error
            if row["model_version"] == incumbent.manifest.model_version:
                rows.append(row)
    return pd.DataFrame(rows, columns=columns)


def released_outcomes(connection: psycopg.Connection, order_ids: list[str], *, as_of: datetime | str) -> pd.DataFrame:
    """Labels of these orders as known at ``as_of`` (<NA> if not yet known): monitor.OUTCOME_COLUMNS."""
    labels = cohorts.load_labels(connection, as_of=as_of, order_ids=order_ids)
    return labels[list(monitor.OUTCOME_COLUMNS)]


def assess(connection: psycopg.Connection, incumbent: bundle.LoadedBundle, *, as_of: datetime | str,
           prediction_history: Path | None = None) -> MonitoringRecord:
    """Steps 3-5: the monitoring decision for this incumbent at ``as_of`` (no MLflow here)."""
    version = incumbent.manifest.model_version
    if incumbent.reference is None:
        return MonitoringRecord(
            as_of=instant(as_of), incumbent_model_version=version, status="no_reference", retrain_recommended=False,
            reasons=[(f"incumbent {version} has no reference.json (not trained by this pipeline): drift and "
                      "quality cannot be measured, so no automatic retraining; use --mode train for a first model")])
    if prediction_history is None:
        return MonitoringRecord(
            as_of=instant(as_of), incumbent_model_version=version, status="no_prediction_history",
            retrain_recommended=False,
            reasons=[("No recorded prediction history supplied; set PROMISEOPS_PREDICTION_HISTORY to a JSONL "
                      "snapshot export. Retrospective scores are not historical predictions; retraining suppressed.")])
    predictions = load_prediction_history(prediction_history, incumbent)
    outcomes = released_outcomes(connection, predictions["order_id"].tolist(), as_of=as_of)
    report = monitor.build_report(predictions, outcomes, incumbent.reference, as_of=as_of)
    return MonitoringRecord(as_of=report.as_of, incumbent_model_version=version, status="assessed",
                            prediction_history_sha256=bundle.sha256_file(prediction_history),
                            retrain_recommended=report.retrain_recommended, reasons=list(report.reasons),
                            report=report)


# ---------------------------------------------------------------------------------------------
# The run
# ---------------------------------------------------------------------------------------------
def run_monitor_train(connection: psycopg.Connection, client: Any, settings: training.TrainingSettings, *,
                      cutoffs: cohorts.Cutoffs, experiment: str = MONITORING_EXPERIMENT,
                      prediction_history: Path | None = None) -> MonitorTrainResult:
    """Steps 1-7 of the module docstring. Raises on failure, after marking the failed MLflow run FAILED."""
    experiment_id = tracking.ensure_experiment(client, experiment)
    run_id = client.create_run(experiment_id, tags=tracking.run_tags("monitor", settings.source_commit),
                               run_name=f"monitor-as-of-{cutoffs.as_of:%Y%m%d}").info.run_id
    try:
        workdir = settings.artifacts / f"monitor-{run_id}"
        incumbent = bundle.copy_bundle(settings.incumbent, workdir / "incumbent")
        source = "provided_file" if prediction_history is not None else "none"
        if prediction_history is None and incumbent.reference is not None:
            rows = snapshots.export_history(connection, model_version=incumbent.manifest.model_version,
                                            artifact_sha256=incumbent.manifest.artifact_sha256,
                                            as_of=cutoffs.as_of)
            source = "database"
            if rows:
                prediction_history = workdir / "prediction-history.jsonl"
                snapshots.write_export(rows, prediction_history)
        client.log_param(run_id, "prediction_history_source", source)
        record = assess(connection, incumbent, as_of=cutoffs.as_of, prediction_history=prediction_history)
        persist_record(client, run_id, record)
        if record.prediction_history_sha256 is not None:
            persist_history(client, run_id, prediction_history, record.prediction_history_sha256)
        client.set_terminated(run_id, "FINISHED")   # report is final BEFORE any training starts
        if client.get_run(run_id).info.status != "FINISHED":
            raise training.TrainingError(f"run {run_id}: monitoring FINISHED status did not read back")
        # Published only now, so a run that fails finalization can neither raise nor clear the
        # RetrainingRecommended alert. If this write fails the run is marked FAILED and nothing trains.
        decisions.record_decision(connection, run_id, record)
    except BaseException as error:
        training.close_failed(client, run_id, error)
        raise

    if not record.retrain_recommended:
        return MonitorTrainResult(monitoring_run_id=run_id, record=record, training=None)
    trained = training.run_train(connection, client, settings, cutoffs=cutoffs)
    client.set_tag(trained.run_id, TAG_MONITORING_RUN, run_id)
    client.set_tag(run_id, TAG_TRAINING_RUN, trained.run_id)
    return MonitorTrainResult(monitoring_run_id=run_id, record=record, training=trained)


def persist_history(client: Any, run_id: str, path: Path, expected_sha256: str) -> None:
    """Persist the exact assessed snapshots before finalizing or publishing a decision."""
    client.log_artifact(run_id, str(path), "prediction-history")
    with tempfile.TemporaryDirectory() as folder:
        saved = Path(client.download_artifacts(run_id, f"prediction-history/{path.name}", folder))
        if bundle.sha256_file(saved) != expected_sha256:
            raise training.TrainingError("prediction history read back differs from the assessed export")


def persist_record(client: Any, run_id: str, record: MonitoringRecord) -> None:
    """Store the record in the run (JSON artifact + searchable values), then read it back and compare."""
    from mlflow.entities import Metric, Param, RunTag  # lazy, like promiseops.record

    now_ms = int(time.time() * 1000)
    params = {"as_of": record.as_of.isoformat().replace("+00:00", "Z"),
              "incumbent_model_version": record.incumbent_model_version}
    if record.prediction_history_sha256 is not None:
        params["prediction_history_sha256"] = record.prediction_history_sha256
    tags = {TAG_STATUS: record.status, TAG_RETRAIN: str(record.retrain_recommended).lower(),
            training.TAG_INCUMBENT: record.incumbent_model_version,
            TAG_REASONS: "; ".join(record.reasons)[:_MAX_REASONS_TAG]}
    client.log_batch(run_id, metrics=[Metric(key, value, now_ms, 0) for key, value in report_metrics(record).items()],
                     params=[Param(key, value) for key, value in params.items()],
                     tags=[RunTag(key, value) for key, value in tags.items() if value])
    client.log_text(run_id, record.model_dump_json(indent=2), MONITORING_FILE)
    with tempfile.TemporaryDirectory() as folder:
        stored = Path(client.download_artifacts(run_id, MONITORING_FILE, folder)).read_text(encoding="utf-8")
    if MonitoringRecord.model_validate(json.loads(stored)) != record:
        raise training.TrainingError(f"run {run_id}: the monitoring record read back differs from the one logged")


def report_metrics(record: MonitoringRecord) -> dict[str, float]:
    """Numbers worth sorting/plotting in MLflow. The full report (all reasons, data quality) is the JSON."""
    values = {"retrain_recommended": float(record.retrain_recommended)}
    report = record.report
    if report is None:
        return values
    values.update({f"counts.{name}": float(count) for name, count in report.counts.items()})
    for name, window in zip(("previous", "current"), report.windows, strict=True):
        values[f"drift.{name}.unique_orders"] = float(window.unique_orders)
        values.update({f"drift.{name}.{feature}": float(score) for feature, score in window.scores.items()})
    labels = report.labels
    values.update({"labels.predicted_orders": float(labels.predicted_orders),
                   "labels.mature_orders": float(labels.mature_orders),
                   "labels.label_coverage": float(labels.label_coverage), "labels.late": float(labels.late)})
    if labels.metrics is not None:
        values.update({f"live.{name}": float(value) for name, value in labels.metrics.model_dump().items()})
    return values
