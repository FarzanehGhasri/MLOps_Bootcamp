"""Point-in-time historical aggregates. Outcome events are usable strictly before prediction."""

import numpy as np
import pandas as pd

GROUPS = ("global", "seller", "customer_state", "route")
HISTORY_PRIOR = 0.05
HISTORY_SMOOTHING = 20.0
RECENT_DAYS = 30
WORKLOAD_DAYS = 7


def policy_parameters():
    """Frozen policy v1 constants; changing these requires a new history_policy version."""
    return {"cold_start_prior": str(HISTORY_PRIOR), "smoothing": str(HISTORY_SMOOTHING),
            "recent_days": str(RECENT_DAYS), "workload_days": str(WORKLOAD_DAYS),
            "knowledge_boundary": "strictly_before_approval"}


HISTORY_NAMES = tuple(f"history_{group}_{metric}" for group in GROUPS
                      for metric in ("count", "rate", "recent_count", "recent_rate")) + ("seller_orders_7d",)


def _window(events, queries, time_column, window_days):
    """Cumulative and trailing sums, excluding events at or after each query time."""
    events = events.sort_values(time_column)
    times = events[time_column].dt.as_unit("ns").astype("int64").to_numpy()
    query = queries.dt.as_unit("ns").astype("int64").to_numpy()
    sums = np.r_[0.0, events["late"].astype(float).to_numpy().cumsum()]
    upper = np.searchsorted(times, query, side="left")
    lower = np.searchsorted(times, query - pd.Timedelta(days=window_days).value, side="left")
    return upper, sums[upper], upper - lower, sums[upper] - sums[lower]


def build_history(orders, labels, *, freeze_at=None, source_order_ids=None, query_order_ids=None):
    """One row per supplied order. Groups are immutable approval-time attributes.

    Training labels are NOT used as an encoding fit target: each historical event is looked up
    by its actual knowledge time. ``freeze_at`` caps queries for a frozen-state validation control.
    Unknown groups shrink toward the contemporaneous global rate; no full-dataset target means.
    """
    if orders.order_id.duplicated().any() or labels.order_id.duplicated().any():
        raise ValueError("duplicate order IDs")
    rows = orders.set_index("order_id").sort_index().copy()
    rows["approved_at"] = pd.to_datetime(rows.approved_at, utc=True)
    known = labels[labels.late.notna() & labels.label_available_at.notna()].copy()
    known["label_available_at"] = pd.to_datetime(known.label_available_at, utc=True)
    source = rows if source_order_ids is None else rows.loc[rows.index.isin(set(source_order_ids))]
    events = source.join(known.set_index("order_id")[["late", "label_available_at"]], how="inner")
    if (events.label_available_at <= events.approved_at).any():
        raise ValueError("historical outcome must become known after its own approval")
    if query_order_ids is not None:
        rows = rows.loc[rows.index.isin(set(query_order_ids))].copy()
    queries = rows.approved_at.copy()
    if freeze_at is not None:
        cutoff = pd.Timestamp(freeze_at)
        if cutoff.tzinfo is None:
            raise ValueError("freeze cutoff must be timezone-aware")
        queries = queries.clip(upper=cutoff)
    out = pd.DataFrame(index=rows.index)
    rows["global"] = "all"
    events["global"] = "all"
    for group in GROUPS:
        counts = np.zeros(len(rows))
        positives = counts.copy()
        recent_counts, recent_positives = counts.copy(), counts.copy()
        for key, positions in rows.groupby(group).indices.items():
            selected = events[events[group] == key]
            values = _window(selected, queries.iloc[positions], "label_available_at", RECENT_DAYS)
            for target, value in zip((counts, positives, recent_counts, recent_positives), values, strict=True):
                target[positions] = value
        prior = HISTORY_PRIOR if group == "global" else out["history_global_rate"].to_numpy()
        recent_prior = HISTORY_PRIOR if group == "global" else out["history_global_recent_rate"].to_numpy()
        out[f"history_{group}_count"] = np.log1p(counts)
        out[f"history_{group}_rate"] = (positives + HISTORY_SMOOTHING * prior) / (counts + HISTORY_SMOOTHING)
        out[f"history_{group}_recent_count"] = np.log1p(recent_counts)
        out[f"history_{group}_recent_rate"] = (recent_positives + HISTORY_SMOOTHING * recent_prior) / (recent_counts + HISTORY_SMOOTHING)
    workload = np.zeros(len(rows))
    for seller, positions in rows.groupby("seller").indices.items():
        past = source[source.seller == seller].assign(late=0.0)
        workload[positions] = _window(past, queries.iloc[positions], "approved_at", WORKLOAD_DAYS)[2]
    out["seller_orders_7d"] = np.log1p(workload)
    return out.loc[:, list(HISTORY_NAMES)]


def load_order_groups(connection, order_ids):
    """Primary seller by summed item price, deterministic ID tie-break; ID is not a predictor."""
    result = connection.execute("""
        WITH ranked AS (
            SELECT order_id, seller_id,
                   row_number() OVER (PARTITION BY order_id ORDER BY sum(price) DESC, seller_id) AS rank
            FROM promiseops.order_items WHERE order_id = ANY(%s) GROUP BY order_id, seller_id
        )
        SELECT o.order_id, o.approved_at, r.seller_id, c.customer_state,
               s.seller_state || '>' || c.customer_state AS route
        FROM promiseops.orders o JOIN ranked r ON r.order_id=o.order_id AND r.rank=1
        JOIN promiseops.customers c USING(customer_id)
        JOIN promiseops.sellers s ON s.seller_id=r.seller_id
        ORDER BY o.order_id
    """, (list(order_ids),)).fetchall()
    return pd.DataFrame(result, columns=["order_id", "approved_at", "seller", "customer_state", "route"])
