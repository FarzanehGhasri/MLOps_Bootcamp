"""Read-only independent label, cohort, feature coverage and ingestion completeness audit."""

import argparse
import hashlib
import json
import os
import sys
from pathlib import Path

import pandas as pd

from promiseops import bundle, cohorts, contracts, data, db, experiment_log, features, feed, tracking

AS_OF = "2018-06-30T00:00:00Z"
WINDOWS = (
    ("train", None, "2017-12-31T23:59:59Z", "2017-12-31T23:59:59Z", "2018-04-30T00:00:00Z"),
    ("validation", "2017-12-31T23:59:59Z", "2018-02-28T23:59:59Z", "2018-04-30T00:00:00Z", "2018-04-30T00:00:00Z"),
    ("test_integrity_only", "2018-02-28T23:59:59Z", "2018-04-30T23:59:59Z", AS_OF, AS_OF),
)
EXPERIMENT = "promiseops-data-audit"


def reconcile_source(connection, directory):
    """Reconcile exact prepared-source values; never import later batches into the database."""
    manifest_path = directory / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    entries = feed.load_index(manifest_path)
    corrupted = feed.first_inconsistent_entry(directory, entries)
    if corrupted is not None:
        raise ValueError(f"source checksum/metadata mismatch: {corrupted.file}")
    published = feed.published_until(entries, AS_OF)
    layouts = {
        "customers": ("customers", contracts.Customer, ("customer_id",)),
        "sellers": ("sellers", contracts.Seller, ("seller_id",)),
        "products": ("products", contracts.Product, ("product_id",)),
        "orders": ("orders", contracts.Order, ("order_id",)),
        "items": ("order_items", contracts.Item, ("order_id", "item_id")),
        "payments": ("order_payments", contracts.Payment, ("order_id", "sequence")),
        "outcomes": ("outcomes", contracts.Outcome, ("order_id",)),
    }
    expected = {name: {} for name in layouts}
    source_batches = {}
    for entry in published:
        parsed = contracts.Batch.model_validate_json(feed.read_entry(directory, entry))
        source_batches[parsed.batch_id] = (entry.payload_sha256, entry.file_sha256)
        for name, (_, _, keys) in layouts.items():
            for row in getattr(parsed, name):
                value = row.model_dump()
                key = tuple(value[k] for k in keys)
                if key in expected[name] and expected[name][key] != value:
                    raise ValueError("prepared source contains conflicting immutable rows")
                expected[name][key] = value
    comparisons = {}
    for name, (table, row_type, keys) in layouts.items():
        columns = list(row_type.model_fields)
        rows = connection.execute(f"SELECT {', '.join(columns)} FROM promiseops.{table}").fetchall()
        actual = {}
        for row in rows:
            value = row_type.model_validate(dict(zip(columns, row, strict=True))).model_dump()
            actual[tuple(value[k] for k in keys)] = value
        shared = expected[name].keys() & actual.keys()
        comparisons[table] = {"source_unique_rows": len(expected[name]), "database_rows": len(actual),
                              "missing": len(expected[name].keys() - actual.keys()),
                              "extra": len(actual.keys() - expected[name].keys()),
                              "different_values": sum(expected[name][key] != actual[key] for key in shared)}
    receipts = {bid: (payload, raw) for bid, payload, raw in connection.execute(
        "SELECT batch_id,payload_sha256,file_sha256 FROM promiseops.ingest_batches").fetchall()}
    return {"manifest_sha256": hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
            "manifest_original_orders": manifest.get("original_orders"),
            "manifest_included_orders": manifest.get("included_orders"), "upstream_exclusions": manifest.get("exclusions"),
            "upstream_missing_value_policy": manifest.get("missing_product_weight"), "upstream_scope": manifest.get("scope"),
            "all_file_checksums_verified": len(entries), "expected_batches_by_snapshot": len(published),
            "later_batches_not_loaded": len(entries) - len(published),
            "missing_batches": sorted(source_batches.keys() - receipts.keys()),
            "extra_batches": sorted(receipts.keys() - source_batches.keys()),
            "receipt_checksum_mismatches": sum(receipts[k] != source_batches[k] for k in receipts.keys() & source_batches.keys()),
            "row_reconciliation": comparisons,
            "raw_original_csv_revalidated": False}


def scalar(connection, sql, params=None):
    return connection.execute(sql, params).fetchone()[0]


def audit(connection):
    rows = connection.execute("""
        SELECT o.order_id, o.approved_at, o.promised_date, ob.available_at AS order_batch_at,
               y.delivered_at, y.available_at AS label_at, yb.available_at AS label_batch_at,
               (y.delivered_at AT TIME ZONE 'America/Sao_Paulo')::date > o.promised_date AS sql_late,
               (y.delivered_at AT TIME ZONE 'UTC')::date > o.promised_date AS utc_late
        FROM promiseops.orders o JOIN promiseops.ingest_batches ob ON ob.batch_id=o.batch_id
        LEFT JOIN promiseops.outcomes y USING(order_id)
        LEFT JOIN promiseops.ingest_batches yb ON yb.batch_id=y.batch_id
        ORDER BY o.order_id
    """).fetchall()
    frame = pd.DataFrame(rows, columns=["order_id", "approved_at", "promised_date", "order_batch_at",
                                        "delivered_at", "label_at", "label_batch_at", "sql_late", "utc_late"])
    known = frame[frame.sql_late.notna()]
    # Independent stdlib conversion, not the pandas implementation used in production labels.
    from zoneinfo import ZoneInfo

    independent = known.apply(lambda row: row.delivered_at.astimezone(ZoneInfo("America/Sao_Paulo")).date()
                              > row.promised_date, axis=1)
    loaded = cohorts.load_labels(connection, as_of=AS_OF).set_index("order_id")
    visible = frame[(frame.order_batch_at <= pd.Timestamp(AS_OF)) & frame.sql_late.notna()
                    & (frame.label_at <= pd.Timestamp(AS_OF)) & (frame.label_batch_at <= pd.Timestamp(AS_OF))]
    python_labels = loaded.loc[visible.order_id, "late"].astype(bool).to_numpy()
    label_checks = {
        "orders": len(frame), "outcomes": len(known), "orders_without_outcome_row": len(frame) - len(known),
        "sql_vs_independent_stdlib_mismatches": int((known.sql_late.to_numpy() != independent.to_numpy()).sum()),
        "sql_vs_production_labels_mismatches": int((visible.sql_late.to_numpy() != python_labels).sum()),
        "utc_instead_of_brazil_would_change_labels": int((known.sql_late != known.utc_late).sum()),
        "delivery_before_approval": int((known.delivered_at < known.approved_at).sum()),
        "label_before_delivery": int((known.label_at < known.delivered_at).sum()),
        "order_published_before_approval": int((frame.order_batch_at < frame.approved_at).sum()),
        "outcome_published_before_knowledge": int((known.label_batch_at < known.label_at).sum()),
        "promise_before_local_approval": int(frame.apply(
            lambda row: row.promised_date < row.approved_at.astimezone(ZoneInfo("America/Sao_Paulo")).date(), axis=1).sum()),
        "same_local_delivery_and_promise_date": int(known.apply(
            lambda row: row.delivered_at.astimezone(ZoneInfo("America/Sao_Paulo")).date() == row.promised_date, axis=1).sum()),
    }
    lag = (known.label_at - known.delivered_at).dt.total_seconds() / 86400
    label_checks["reporting_delay_days"] = {"min": float(lag.min()), "median": float(lag.median()),
                                             "max": float(lag.max()), "not_exactly_seven_days": int((lag != 7).sum())}
    windows, selected_sets = [], {}
    for name, start, end, label_cutoff, snapshot in WINDOWS:
        approved = frame[(frame.approved_at <= pd.Timestamp(end))]
        if start is not None:
            approved = approved[approved.approved_at > pd.Timestamp(start)]
        released = approved[approved.order_batch_at <= pd.Timestamp(snapshot)]
        eligible = released[released.sql_late.notna() & (released.label_at <= pd.Timestamp(label_cutoff))
                            & (released.label_batch_at <= pd.Timestamp(snapshot))]
        production = cohorts.load_labels(connection, as_of=snapshot)
        ids = cohorts.select_window(production, start=start, end=end, label_cutoff=label_cutoff)
        expected = set(eligible.order_id)
        selected_sets[name] = expected
        known_later = released[released.sql_late.notna() & (released.label_at <= pd.Timestamp(AS_OF))
                               & (released.label_batch_at <= pd.Timestamp(AS_OF))]
        windows.append({"name": name, "approval_start_exclusive": start, "approval_end_inclusive": end,
                        "label_cutoff_inclusive": label_cutoff, "source_snapshot": snapshot,
                        "approved_in_database": len(approved), "published_by_snapshot": len(released),
                        "missing_outcome_row": int(released.sql_late.isna().sum()),
                        "label_after_cutoff": int((released.label_at > pd.Timestamp(label_cutoff)).sum()),
                        "label_known_but_batch_after_snapshot": int(((released.label_at <= pd.Timestamp(label_cutoff))
                                                                     & (released.label_batch_at > pd.Timestamp(snapshot))).sum()),
                        "selected": len(eligible), "late": int(eligible.sql_late.sum()),
                        "prevalence": float(eligible.sql_late.mean()),
                        "production_vs_independent_ids_differ": len(expected.symmetric_difference(ids)),
                        "cohort_sha256": cohorts.cohort_sha256(ids),
                        "same_approval_pool_known_by_june30": len(known_later),
                        "same_approval_pool_later_prevalence": float(known_later.sql_late.mean()),
                        "later_labels_used_for_training": False})
    # Integrity of the loaded snapshot, not a claim that the full remote feed has been loaded.
    fact_tables = ("orders", "order_items", "order_payments", "outcomes")
    receipts = connection.execute("SELECT batch_id, kind, available_at, row_counts FROM promiseops.ingest_batches ORDER BY available_at, batch_id").fetchall()
    counts = {table: int(scalar(connection, f"SELECT count(*) FROM promiseops.{table}")) for table in fact_tables}
    manifest_counts = {}
    mapping = {"orders": "orders", "order_items": "items", "order_payments": "payments", "outcomes": "outcomes"}
    for table, key in mapping.items():
        manifest_counts[table] = sum(int(row[3].get(key, 0)) for row in receipts)
    # Aggregate each side separately; never multiply items by payments.
    shape = connection.execute("""
        WITH i AS (SELECT order_id, count(*) n, count(DISTINCT seller_id) sellers,
                          count(DISTINCT p.category) categories, sum(price) price, sum(freight) freight
                   FROM promiseops.order_items JOIN promiseops.products p USING(product_id) GROUP BY order_id),
             pay AS (SELECT order_id, count(*) n, count(DISTINCT payment_type) kinds, sum(value) total
                     FROM promiseops.order_payments GROUP BY order_id)
        SELECT count(*) FILTER (WHERE i.order_id IS NULL), count(*) FILTER (WHERE pay.order_id IS NULL),
               count(*) FILTER (WHERE i.n>1), count(*) FILTER (WHERE i.sellers>1),
               count(*) FILTER (WHERE i.categories>1), count(*) FILTER (WHERE pay.n>1),
               count(*) FILTER (WHERE pay.kinds>1),
               count(*) FILTER (WHERE abs(pay.total - i.price - i.freight)>0.01)
        FROM promiseops.orders o LEFT JOIN i USING(order_id) LEFT JOIN pay USING(order_id)
    """).fetchone()
    shape = dict(zip(("orders_without_items", "orders_without_payments", "multi_item_orders", "multi_seller_orders",
                      "multi_category_orders", "multi_payment_orders", "mixed_payment_type_orders",
                      "payment_vs_price_plus_freight_diff_over_cent"), shape, strict=True))
    shape["zero_weight_products"] = scalar(connection, "SELECT count(*) FROM promiseops.products WHERE weight_g=0")
    shape["orders_with_zero_weight_product"] = scalar(connection, "SELECT count(DISTINCT order_id) FROM promiseops.order_items JOIN promiseops.products USING(product_id) WHERE weight_g=0")
    shape["unknown_category_products"] = scalar(connection, "SELECT count(*) FROM promiseops.products WHERE category='unknown'")
    # Inspect train/validation feature materialization only; test is not scored or used for selection.
    feature_ids = sorted(selected_sets["train"] | selected_sets["validation"])
    table = features.load_features(connection, feature_ids, as_of=WINDOWS[0][4])
    feature_audit = {"requested": len(feature_ids), "materialized": len(table),
                     "missing_ids": len(set(feature_ids) - set(table.index)),
                     "null_cells": int(table.isna().sum().sum()), "columns": list(table.columns),
                     "constant_columns": [col for col in table if table[col].nunique(dropna=False) <= 1]}
    month = frame.assign(month=frame.approved_at.dt.strftime("%Y-%m")).groupby("month").size().to_dict()
    boundary = {}
    for cutoff in (WINDOWS[0][2], WINDOWS[1][2], WINDOWS[2][2]):
        instant = pd.Timestamp(cutoff)
        boundary[cutoff] = {"exactly_equal": int((frame.approved_at == instant).sum()),
                            "fractional_second_after_until_midnight": int(((frame.approved_at > instant)
                                                                           & (frame.approved_at < instant + pd.Timedelta(seconds=1))).sum())}
    inventory = connection.execute("SELECT table_name, column_name FROM information_schema.columns WHERE table_schema='promiseops' AND table_name IN ('orders','outcomes','customers','sellers','products','order_items','order_payments') ORDER BY table_name, ordinal_position").fetchall()
    return {"scope": "Loaded evaluation snapshot; labels and membership only, no training or scoring",
            "dataset_identity": data.dataset_identity(connection, as_of=AS_OF),
            "software_versions": bundle.collect_software_versions(), "labels": label_checks, "windows": windows,
            "pairwise_overlap": {f"{a}:{b}": len(selected_sets[a] & selected_sets[b])
                                 for a, b in (("train", "validation"), ("train", "test_integrity_only"),
                                              ("validation", "test_integrity_only"))},
            "approval_month_counts": month, "boundary_seconds": boundary,
            "source_fields": [list(row) for row in inventory], "feature_audit": feature_audit, "order_shape": shape,
            "fact_counts": counts, "receipt_fact_counts": manifest_counts,
            "receipt_counts_match": counts == manifest_counts,
            "batch_count": len(receipts), "batch_publication_min": min(row[2] for row in receipts).isoformat(),
            "batch_publication_max": max(row[2] for row in receipts).isoformat(),
            "receipt_row_count_keys": sorted({key for row in receipts for key in row[3]}),
            "ingestion_status_counts": dict(connection.execute("SELECT status,count(*) FROM promiseops.ingest_attempts GROUP BY status").fetchall()),
            "test_predictions_computed": False, "test_used_for_model_selection": False}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--feed-dir", type=Path, help="Prepared local feed for checksum and exact row reconciliation")
    args = parser.parse_args(argv)
    client, run_id = None, None
    try:
        commit = tracking.source_commit_from_env(os.environ)
        if commit is None:
            raise ValueError("CI_COMMIT_SHA required")
        client = tracking.create_client(tracking.TrackingConfig.from_env(os.environ))
        exp = tracking.ensure_experiment(client, EXPERIMENT)
        run_id = client.create_run(exp, tags=tracking.run_tags("data-audit", commit)).info.run_id
        with db.connect() as connection:
            connection.execute("SET default_transaction_read_only=on")
            report = audit(connection)
            if args.feed_dir is not None:
                report["source_reconciliation"] = reconcile_source(connection, args.feed_dir)
        report.update({"base_commit": commit, "audit_source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                       "mlflow_run_id": run_id})
        report = json.loads(json.dumps(report))
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
        experiment_log.log_report(client, experiment=EXPERIMENT, kind="data-audit", source_commit=commit,
                                 report=report, params={"model_scoring": "false"}, metrics={}, run_id=run_id)
        print(json.dumps(report, indent=2))
        return 0
    # CLI boundary must sanitize third-party failures and return a nonzero exit code.
    except Exception as error:  # noqa: BLE001
        if client is not None and run_id is not None:
            tracking.close_failed_run(client, run_id, error)
        print(tracking.redact_error(error), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
