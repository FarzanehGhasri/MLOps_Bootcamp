"""Own-team transactional ingestion and a single leakage-safe feature builder.

``ingest_batch`` implements the ingestion contract of docs/CONTRACTS.md:

1. verify ``file_sha256`` and ``payload_sha256``, parse and schema-check (``promiseops.validation``),
   then check the index metadata (when given) and that the batch is published by ``as_of`` —
   both before step 2, so a replay can never bypass them;
2. in ONE transaction, holding a global ingestion lock:
   a. same batch ID already committed? same payload -> no-op (replay), other payload -> reject;
   b. load the existing rows this batch refers to and run every cross-row/cross-batch rule;
   c. write the receipt and all rows (or nothing, on any error);
3. on rejection: roll back, then record the attempt and quarantine the exact bytes in a separate
   transaction, and raise :class:`~promiseops.validation.BatchRejected`.

Every attempt (committed, replayed, rejected, failed) is written to ``ingest_attempts`` and logged
as one JSON line. Walkthrough with reasons and rejected alternatives: docs/ingestion/01-ingestion.fa.md
"""

import json
import logging
import os
import time
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any, Literal

import psycopg
from psycopg.types.json import Jsonb

from promiseops import cohorts, features
from promiseops.contracts import Batch, digest, instant
from promiseops.db import require_autocommit
from promiseops.validation import (
    BatchRejected,
    ExistingState,
    ExpectedMetadata,
    Problem,
    Reason,
    check_file_sha256,
    metadata_problems,
    parse_payload,
    publication_problems,
    raw_sha256,
    referenced_keys,
    to_decimal,
    validate_batch,
)

logger = logging.getLogger("promiseops.ingest")

# One lock for ALL ingestion: batches must be applied in publication order anyway, so running two
# at once gains nothing, and the lock guarantees the "existing rows" we validated against cannot
# change before our insert (e.g. an Airflow retry overlapping a slow first try).
INGEST_LOCK_KEY = 0x50524F4D_49534521  # "PROMISE!" — arbitrary fixed advisory-lock key


@dataclass(frozen=True)
class IngestReceipt:
    """What ``ingest_batch`` returns for an accepted batch (a fresh commit or a no-op replay)."""

    batch_id: str
    kind: Literal["orders", "outcomes"]
    status: Literal["committed", "replayed"]
    payload_sha256: str
    available_at: datetime
    as_of: datetime
    row_counts: Mapping[str, int]


def ingest_batch(
    connection: psycopg.Connection,
    payload: bytes | str,
    *,
    as_of: datetime | str,
    expected_sha256: str,
    expected_file_sha256: str | None = None,
    expected: ExpectedMetadata | None = None,
    source_commit: str | None = None,
) -> IngestReceipt:
    """Validate, commit once, handle retry; quarantine invalid input. See module docstring.

    ``payload`` is the exact file content. ``expected_sha256`` is the feed's ``payload_sha256``;
    ``expected_file_sha256`` the feed's ``file_sha256`` (optional for payloads not read from a file);
    ``expected`` the index entry's kind/available_at/batch_id (optional, same reason).
    """
    require_autocommit(connection)
    raw = payload.encode("utf-8") if isinstance(payload, str) else bytes(payload)
    context = _Attempt(
        raw=raw,
        raw_sha256=raw_sha256(raw),
        as_of=instant(as_of),
        source_commit=source_commit or os.environ.get("CI_COMMIT_SHA"),
        started_at=datetime.now(UTC),
        started_clock=time.monotonic(),
    )
    batch: Batch | None = None
    try:
        check_file_sha256(raw, expected_file_sha256)
        batch = parse_payload(raw, expected_sha256=expected_sha256)
        # Checked BEFORE the transaction and therefore before the replay short-circuit: a batch
        # already committed must still be rejected for an as_of earlier than its publication, and
        # a payload that disagrees with its index entry must not count as a replay either.
        problems = [] if expected is None else metadata_problems(
            batch_id=batch.batch_id, kind=batch.kind, available_at=batch.available_at, expected=expected)
        problems += publication_problems(batch, as_of=context.as_of)
        if problems:
            raise BatchRejected(problems, batch_id=batch.batch_id)
        with connection.transaction():
            receipt = _apply(connection, batch, expected_sha256, expected_file_sha256, context)
    except BatchRejected as rejection:
        batch_id = batch.batch_id if batch is not None else rejection.batch_id
        _record_rejection(connection, rejection, batch_id, _payload_sha(batch, expected_sha256), context)
        raise
    except Exception as error:
        # Not the data's fault (database down, bug, ...): nothing was committed; record and re-raise.
        _record_failure(connection, error, batch, context)
        raise
    _log("batch_" + receipt.status, context, batch_id=receipt.batch_id, kind=receipt.kind,
         rows=dict(receipt.row_counts))
    return receipt


# ---------------------------------------------------------------------------------------------
# Inside the transaction
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class _Attempt:
    raw: bytes
    raw_sha256: str
    as_of: datetime
    source_commit: str | None
    started_at: datetime
    started_clock: float


def _apply(conn: psycopg.Connection, batch: Batch, payload_sha256: str, file_sha256: str | None,
           ctx: _Attempt) -> IngestReceipt:
    conn.execute("SELECT pg_advisory_xact_lock(%s)", (INGEST_LOCK_KEY,))

    previous = conn.execute(
        "SELECT payload_sha256, row_counts FROM promiseops.ingest_batches WHERE batch_id = %s",
        (batch.batch_id,),
    ).fetchone()
    if previous is not None:
        if previous[0] != payload_sha256:
            raise BatchRejected([Problem(
                Reason.BATCH_ID_CONFLICT,
                f"batch {batch.batch_id} was committed with payload_sha256 {previous[0]}, "
                f"got {payload_sha256}",
            )], batch_id=batch.batch_id)
        _insert_attempt(conn, ctx, batch_id=batch.batch_id, payload_sha256=payload_sha256, status="replayed")
        return _receipt(batch, payload_sha256, "replayed", ctx, previous[1])

    problems = validate_batch(batch, _load_existing(conn, batch), as_of=ctx.as_of)
    if problems:
        raise BatchRejected(problems, batch_id=batch.batch_id)

    counts = _row_counts(batch)
    conn.execute(
        """INSERT INTO promiseops.ingest_batches
               (batch_id, kind, schema_version, available_at, payload_sha256, file_sha256, as_of,
                row_counts, source_commit)
           VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)""",
        (batch.batch_id, batch.kind, batch.schema_version, batch.available_at, payload_sha256,
         file_sha256, ctx.as_of, Jsonb(counts), ctx.source_commit),
    )
    _insert_rows(conn, batch)
    _insert_attempt(conn, ctx, batch_id=batch.batch_id, payload_sha256=payload_sha256, status="committed")
    return _receipt(batch, payload_sha256, "committed", ctx, counts)


def _load_existing(conn: psycopg.Connection, batch: Batch) -> ExistingState:
    """Fetch only the existing rows this batch refers to (never whole tables)."""
    keys = referenced_keys(batch)

    def rows(sql: str, ids: frozenset[str]) -> list[tuple[Any, ...]]:
        return conn.execute(sql, (sorted(ids),)).fetchall() if ids else []

    return ExistingState(
        customers=dict(rows("SELECT customer_id, customer_state FROM promiseops.customers "
                            "WHERE customer_id = ANY(%s)", keys.customers)),
        sellers=dict(rows("SELECT seller_id, seller_state FROM promiseops.sellers "
                          "WHERE seller_id = ANY(%s)", keys.sellers)),
        products={pid: (category, weight) for pid, category, weight in rows(
            "SELECT product_id, category, weight_g FROM promiseops.products WHERE product_id = ANY(%s)",
            keys.products)},
        orders=dict(rows("SELECT order_id, approved_at FROM promiseops.orders "
                         "WHERE order_id = ANY(%s)", keys.orders)),
        outcomes=frozenset(r[0] for r in rows("SELECT order_id FROM promiseops.outcomes "
                                              "WHERE order_id = ANY(%s)", keys.orders)),
    )


def _insert_rows(conn: psycopg.Connection, batch: Batch) -> None:
    """Insert every row of an already validated batch. executemany uses psycopg's pipeline mode."""
    bid = batch.batch_id
    with conn.cursor() as cur:
        # Identical dimension rows already in the database are reused (validated equal above).
        cur.executemany(
            "INSERT INTO promiseops.customers (customer_id, customer_state, first_batch_id) "
            "VALUES (%s, %s, %s) ON CONFLICT (customer_id) DO NOTHING",
            [(c.customer_id, c.customer_state, bid) for c in batch.customers])
        cur.executemany(
            "INSERT INTO promiseops.sellers (seller_id, seller_state, first_batch_id) "
            "VALUES (%s, %s, %s) ON CONFLICT (seller_id) DO NOTHING",
            [(s.seller_id, s.seller_state, bid) for s in batch.sellers])
        cur.executemany(
            "INSERT INTO promiseops.products (product_id, category, weight_g, first_batch_id) "
            "VALUES (%s, %s, %s, %s) ON CONFLICT (product_id) DO NOTHING",
            [(p.product_id, p.category, to_decimal(p.weight_g), bid) for p in batch.products])
        # Facts: no ON CONFLICT — a duplicate here would be a validation bug and must fail loudly.
        cur.executemany(
            "INSERT INTO promiseops.orders (order_id, customer_id, approved_at, promised_date, batch_id) "
            "VALUES (%s, %s, %s, %s, %s)",
            [(o.order_id, o.customer_id, o.approved_at, o.promised_date, bid) for o in batch.orders])
        cur.executemany(
            "INSERT INTO promiseops.order_items (order_id, item_id, product_id, seller_id, price, freight) "
            "VALUES (%s, %s, %s, %s, %s, %s)",
            [(i.order_id, i.item_id, i.product_id, i.seller_id, to_decimal(i.price), to_decimal(i.freight))
             for i in batch.items])
        cur.executemany(
            "INSERT INTO promiseops.order_payments (order_id, sequence, payment_type, installments, value) "
            "VALUES (%s, %s, %s, %s, %s)",
            [(p.order_id, p.sequence, p.payment_type, p.installments, to_decimal(p.value))
             for p in batch.payments])
        cur.executemany(
            "INSERT INTO promiseops.outcomes (order_id, delivered_at, available_at, batch_id) "
            "VALUES (%s, %s, %s, %s)",
            [(o.order_id, o.delivered_at, o.available_at, bid) for o in batch.outcomes])


def _row_counts(batch: Batch) -> dict[str, int]:
    tables = ("customers", "sellers", "products", "orders", "items", "payments", "outcomes")
    return {table: len(getattr(batch, table)) for table in tables}


def _receipt(batch: Batch, payload_sha256: str, status: Literal["committed", "replayed"], ctx: _Attempt,
             counts: Mapping[str, int]) -> IngestReceipt:
    return IngestReceipt(batch_id=batch.batch_id, kind=batch.kind, status=status,
                         payload_sha256=payload_sha256, available_at=batch.available_at,
                         as_of=ctx.as_of, row_counts=dict(counts))


# ---------------------------------------------------------------------------------------------
# Audit records (attempts, quarantine) and logs
# ---------------------------------------------------------------------------------------------
def _insert_attempt(conn: psycopg.Connection, ctx: _Attempt, *, batch_id: str | None,
                    payload_sha256: str | None, status: str, reason: str | None = None,
                    detail: Any = None) -> None:
    conn.execute(
        """INSERT INTO promiseops.ingest_attempts
               (batch_id, payload_sha256, raw_sha256, status, reason_code, reason_detail, as_of,
                source_commit, started_at)
           VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)""",
        (batch_id, payload_sha256, ctx.raw_sha256, status, reason,
         Jsonb(detail) if detail is not None else None, ctx.as_of, ctx.source_commit, ctx.started_at),
    )


def _record_rejection(conn: psycopg.Connection, rejection: BatchRejected, batch_id: str | None,
                      payload_sha256: str | None, ctx: _Attempt) -> None:
    """Quarantine the exact bytes and log the attempt, in a transaction of its own.

    Runs AFTER the ingestion transaction rolled back, so the rejected rows are gone but the evidence
    of the rejection survives. Same bytes again -> same quarantine row, attempts counter + 1.
    """
    detail = rejection.detail_records()
    _log("batch_rejected", ctx, batch_id=batch_id, reason=rejection.reason.value,
         problems=len(rejection.problems), first_problem=rejection.problems[0].detail)
    with conn.transaction():
        conn.execute(
            """INSERT INTO promiseops.ingest_quarantine
                   (raw_sha256, batch_id, reason_code, reason_detail, payload, as_of)
               VALUES (%s, %s, %s, %s, %s, %s)
               ON CONFLICT (raw_sha256) DO UPDATE
                   SET last_seen_at = now(), attempts = promiseops.ingest_quarantine.attempts + 1""",
            (ctx.raw_sha256, batch_id, rejection.reason.value, Jsonb(detail), ctx.raw, ctx.as_of),
        )
        _insert_attempt(conn, ctx, batch_id=batch_id, payload_sha256=payload_sha256, status="rejected",
                        reason=rejection.reason.value, detail=detail)


def _record_failure(conn: psycopg.Connection, error: Exception, batch: Batch | None, ctx: _Attempt) -> None:
    """Best effort: log an unexpected failure; never hide the original error if this also fails."""
    _log("batch_failed", ctx, batch_id=batch.batch_id if batch else None, error=type(error).__name__)
    try:
        with conn.transaction():
            _insert_attempt(conn, ctx, batch_id=batch.batch_id if batch else None, payload_sha256=None,
                            status="failed", reason=type(error).__name__,
                            detail=[{"reason": "failed", "detail": str(error)[:500]}])
    except Exception:  # database unreachable etc. — the log line above is the evidence
        logger.exception("could not record failed attempt")


def _payload_sha(batch: Batch | None, expected: str) -> str | None:
    # Only claim a payload digest once parsing proved the payload matches it.
    return expected if batch is not None else None


def _log(event: str, ctx: _Attempt, **fields: Any) -> None:
    """One JSON object per line: easy to grep in Airflow/Kubernetes logs. Never includes secrets."""
    record = {"event": event, "raw_sha256": ctx.raw_sha256, "as_of": ctx.as_of.isoformat(),
              "duration_ms": round((time.monotonic() - ctx.started_clock) * 1000), **fields}
    logger.info(json.dumps(record, sort_keys=True, default=str))


# ---------------------------------------------------------------------------------------------
# Read helpers used by later parts
# ---------------------------------------------------------------------------------------------
def dataset_identity(connection: psycopg.Connection, *, as_of: datetime | str) -> str:
    """Identity of the data known at ``as_of``: SHA256 over the committed receipts published by then.

    Used as ``lineage.dataset_identity`` of a trained model (promiseops.bundle). The same receipts
    always give the same identity; any added, missing or changed batch gives a different one.
    """
    rows = connection.execute(
        """SELECT batch_id, kind, payload_sha256, available_at
           FROM promiseops.ingest_batches
           WHERE available_at <= %s
           ORDER BY available_at, CASE kind WHEN 'orders' THEN 0 ELSE 1 END, batch_id""",
        (instant(as_of),),
    ).fetchall()
    receipts = [[batch_id, kind, sha, available_at.astimezone(UTC).isoformat()]
                for batch_id, kind, sha, available_at in rows]
    return f"receipts-sha256:{digest(receipts)}"


def build_features(connection, order_ids, *, as_of, labeled=False):
    """Aggregate one-to-many relations independently; never use outcome fields as features.

    Contract entry point; the work is in promiseops.features (and promiseops.cohorts for labels),
    kept out of this file so ingestion and features can change independently.

    Returns one row per requested order released by ``as_of`` (index ``order_id``, sorted), columns
    ``features.FEATURE_NAMES``. Unknown/unreleased orders are absent. With ``labeled=True`` a
    ``late`` column is added (nullable boolean): the label only if its outcome was known by
    ``as_of``, otherwise <NA> — the caller (training) decides which orders it may use.
    """
    table = features.load_features(connection, order_ids, as_of=as_of)
    if labeled:
        labels = cohorts.load_labels(connection, as_of=as_of, order_ids=table.index).set_index("order_id")["late"]
        table["late"] = labels.reindex(table.index).astype("boolean")
    return table
