"""Descriptive model evidence. These reports do not select a model or alter promotion gates."""

import numpy as np
import pandas as pd

from promiseops import metrics
from promiseops.contracts import instant


def reliability_report(y, risk):
    y, risk = np.asarray(y, dtype=bool), np.asarray(risk, dtype=float)
    assignment = np.minimum((risk * 10).astype(int), 9)
    rows, ece = [], 0.0
    for index in range(10):
        selected = assignment == index
        n = int(selected.sum())
        if not n:
            continue
        predicted, observed = float(risk[selected].mean()), float(y[selected].mean())
        ece += n / len(y) * abs(predicted - observed)
        rows.append({"lower": index / 10, "upper": (index + 1) / 10, "n": n,
                     "mean_risk": predicted, "observed_prevalence": observed})
    return {"ece_fixed_10_bins": ece, "reliability": rows}


def quality_report(table, late, risk, *, minimum=100, min_positives=20):
    values = metrics.evaluate(list(table.index), list(late), list(risk))
    y, p = np.asarray(late, dtype=bool), np.asarray(risk, dtype=float)
    selected = set(metrics.top_k(table.index, p, values.k))
    global_mask = np.array([oid in selected for oid in table.index])
    axes = {
        "customer_state": table.customer_state.astype(str),
        "primary_payment_type": table.primary_payment_type.astype(str),
        "promise_days": pd.cut(table.promise_days, [-np.inf, 7, 14, 30, np.inf],
                               labels=["<=7", "8-14", "15-30", ">30"]).astype(str),
        "interstate_fraction": pd.Series(np.where(table.interstate_fraction == 0, "same_state",
                                                   np.where(table.interstate_fraction == 1, "all_interstate", "mixed")),
                                           index=table.index),
    }
    slices = []
    for axis, groups in axes.items():
        for group in sorted(groups.unique()):
            mask = (groups == group).to_numpy()
            n, positives = int(mask.sum()), int(y[mask].sum())
            hits = int(y[mask & global_mask].sum())
            sufficient = n >= minimum and min_positives <= positives < n
            local = metrics.evaluate(table.index[mask].tolist(), y[mask].tolist(), p[mask].tolist()) if sufficient else None
            slices.append({"axis": axis, "group": group, "n": n, "late": positives,
                           "prevalence": positives / n, "sufficient": sufficient,
                           "global_budget_selected": int(global_mask[mask].sum()), "global_budget_late_found": hits,
                           "global_budget_recall_in_slice": hits / positives if positives else None,
                           "within_slice_top10_metrics": local.model_dump() if local else None})
    eligible = [row for row in slices if row["sufficient"]]
    worst = min(eligible, key=lambda row: (row["global_budget_recall_in_slice"], row["axis"], row["group"])) if eligible else None
    mean = float(p.mean())
    return {"global_metrics": values.model_dump(), "mean_risk": mean,
            "observed_expected_ratio": float(y.mean()) / mean if mean > 0 else None,
            "lift_at_actual_budget": values.recall_at_10 / (values.k / values.n),
            "maximum_recall_at_budget": min(1., values.k / int(y.sum())),
            **reliability_report(y, p), "slices": slices, "worst_supported_slice": worst,
            "slice_policy": {"minimum_orders": minimum, "minimum_late": min_positives,
                             "note": "Global-budget recall differs from re-ranking the top 10% inside each slice; slices overlap."}}


def maturity_report(labels, *, approved_end, as_of, ages=(1, 3, 7, 14, 30, 60, 90)):
    """Availability lag, not delivery lag; never impute unknown outcomes as training negatives."""
    pool = labels[labels.approved_at <= instant(approved_end)].copy()
    known = pool.late.notna() & (pool.label_available_at <= instant(as_of))
    mature = pool[known]
    complete = bool(len(pool) and known.all())
    positives = int(mature.late.sum())
    lag = (mature.label_available_at - mature.approved_at).dt.total_seconds() / 86400
    curve = []
    for age in ages:
        available = known & (pool.label_available_at <= pool.approved_at + pd.Timedelta(days=age))
        observed_late = int(pool.loc[available, "late"].sum())
        gamma = observed_late / positives if complete and positives else None
        curve.append({"age_days": age, "labels_available": int(available.sum()), "late_observed": observed_late,
                      "label_coverage": float(available.mean()) if len(pool) else None,
                      "late_prevalence_among_available": observed_late / int(available.sum()) if available.any() else None,
                      "late_incidence_per_approved": observed_late / len(pool) if len(pool) else None,
                      "gamma_late_label_coverage": gamma, "under_reporting_bias": 1 - gamma if gamma is not None else None})
    return {"approved_end": instant(approved_end).isoformat(), "as_of": instant(as_of).isoformat(),
            "approved_orders": len(pool), "known_outcomes": len(mature), "missing_outcomes": int((~known).sum()),
            "complete_for_loaded_cohort": complete, "final_late": positives,
            "availability_lag_days_quantiles": {str(q): float(lag.quantile(q)) for q in (.5, .95, .99)} if len(lag) else {},
            "quantile_scope": "complete loaded cohort" if complete else "observed outcomes only; censored",
            "maturation_curve": curve,
            "denominator_note": "Gamma is observed late count / final late count for the same complete cohort, not the prevalence among available labels.",
            "training_cutoffs_changed": False}
