"""Labels and chronological cohorts (train / validation / test) without leakage.

Label (docs/CONTRACTS.md "Prediction and labels"):
    late = local_date(delivered_at, America/Sao_Paulo) > promised_date
A label may be used only by a computation whose cutoff is at or after ``outcomes.available_at``
(the label KNOWLEDGE time, which includes the prepared data's seven-day reporting delay).

Cohorts (same section):
* train      — approved on/before train_end AND label available on/before train_end;
* validation — approved after train_end and on/before validation_end, label available by as_of;
* test       — a later window chosen by the team, used only for the final evaluation
               (``select_window`` with the team's test dates; never used to choose a model).
Require train_end < validation_end <= as_of. A cohort that is too small or has one class is a
reported failure (``InsufficientCohort``), never fabricated metrics.

Like promiseops.features: pure functions (tested in CI) + one small database loader.
Walkthrough and reasons (Persian): docs/features/01-features-labels-split.fa.md
"""

from collections.abc import Iterable
from dataclasses import dataclass
from datetime import datetime

import pandas as pd
import psycopg
from pydantic import BaseModel, ConfigDict, field_validator, model_validator

from promiseops.contracts import LOCAL_TZ, digest, instant
from promiseops.features import query_frame

# Public reference minimum for monitoring windows (docs/CONTRACTS.md "Monitoring"); used here too so
# that metrics are never reported on a handful of orders. Callers may pass a stricter value.
MIN_COHORT_SIZE = 100

LABEL_COLUMNS = ("order_id", "approved_at", "promised_date", "delivered_at", "label_available_at")


class Cutoffs(BaseModel):
    """The three cutoffs of one training run (the worker's --train-end/--validation-end/--as-of)."""

    model_config = ConfigDict(frozen=True)

    train_end: datetime
    validation_end: datetime
    as_of: datetime

    @field_validator("train_end", "validation_end", "as_of", mode="before")
    @classmethod
    def _aware_utc(cls, value: str | datetime) -> datetime:
        return instant(value)  # offset required, stored in UTC; never the server time zone

    @model_validator(mode="after")
    def _ordered(self) -> "Cutoffs":
        if not self.train_end < self.validation_end <= self.as_of:
            raise ValueError("cutoffs must satisfy train_end < validation_end <= as_of")
        return self

    # Stored explicitly in the model record (promiseops.bundle.Lineage), so they are named here.
    @property
    def training_label_cutoff(self) -> datetime:
        return self.train_end

    @property
    def validation_label_cutoff(self) -> datetime:
        return self.as_of


class InsufficientCohort(ValueError):
    """A cohort too small or with only one class: report it, do not compute metrics on it."""

    def __init__(self, name: str, size: int, late: int, minimum: int):
        self.name, self.size, self.late, self.minimum = name, size, late, minimum
        super().__init__(f"{name} cohort is insufficient: N={size}, late={late}, on-time={size - late} "
                         f"(need N >= {minimum} and both classes)")


@dataclass(frozen=True)
class Split:
    """Order IDs (sorted) of the training and validation cohorts for one set of cutoffs."""

    cutoffs: Cutoffs
    train: tuple[str, ...]
    validation: tuple[str, ...]


# ---------------------------------------------------------------------------------------------
# Pure layer
# ---------------------------------------------------------------------------------------------
def add_labels(rows: pd.DataFrame) -> pd.DataFrame:
    """Add ``late`` (nullable boolean) to LABEL_COLUMNS rows; <NA> where the outcome is not known.

    delivered_at / label_available_at may be missing (outcome not yet known at the loader's as_of).
    """
    missing = [column for column in LABEL_COLUMNS if column not in rows.columns]
    if missing:
        raise ValueError(f"label rows are missing columns {missing}")
    out = rows.copy()
    out["approved_at"] = pd.to_datetime([instant(v) for v in out["approved_at"]], utc=True)
    out["label_available_at"] = _optional_instants(out["label_available_at"])
    delivered = _optional_instants(out["delivered_at"])
    out["delivered_at"] = delivered
    # Local DATE of delivery vs the promised Brazilian date (not UTC: 23:30 in Sao Paulo is already
    # the next day in UTC, which would wrongly turn an on-time order late).
    delivered_local = pd.Series(delivered, index=out.index).dt.tz_convert(LOCAL_TZ).dt.tz_localize(None).dt.normalize()
    promised = pd.to_datetime(pd.Series(list(out["promised_date"]), index=out.index, dtype="object").astype(str))
    late = (delivered_local > promised).astype("boolean")
    late[delivered_local.isna()] = pd.NA
    out["late"] = late
    return out


def select_window(labels: pd.DataFrame, *, start: datetime | str | None, end: datetime | str,
                  label_cutoff: datetime | str) -> tuple[str, ...]:
    """Sorted IDs of orders approved in (start, end] whose label was known by ``label_cutoff``.

    ``start=None`` means "from the beginning". Bounds: start exclusive, end and cutoff inclusive,
    exactly as the contract words them ("after train_end", "on/before validation_end").
    """
    approved = labels["approved_at"]
    chosen = (approved <= instant(end)) & labels["late"].notna()
    chosen &= labels["label_available_at"] <= instant(label_cutoff)
    if start is not None:
        chosen &= approved > instant(start)
    return tuple(sorted(labels.loc[chosen, "order_id"].astype(str)))


def split(labels: pd.DataFrame, cutoffs: Cutoffs) -> Split:
    """Contract training and validation cohorts for ``cutoffs`` (see module docstring)."""
    return Split(
        cutoffs=cutoffs,
        train=select_window(labels, start=None, end=cutoffs.train_end, label_cutoff=cutoffs.training_label_cutoff),
        validation=select_window(labels, start=cutoffs.train_end, end=cutoffs.validation_end,
                                 label_cutoff=cutoffs.validation_label_cutoff),
    )


def cohort_sha256(order_ids: Iterable[str]) -> str:
    """Identity of a cohort: SHA256 of its sorted, unique order IDs (canonical JSON, as contracts.digest).

    Candidate and champion must be scored on the same IDs; equal hashes prove it
    (stored as ``validation_cohort_sha256`` in the model record).
    """
    return digest(sorted({str(order_id) for order_id in order_ids}))


def require_sufficient(name: str, labels: pd.DataFrame, order_ids: Iterable[str], *,
                       minimum: int = MIN_COHORT_SIZE) -> None:
    """Raise InsufficientCohort unless the cohort has >= ``minimum`` orders and both classes."""
    ids = set(order_ids)
    late = labels.loc[labels["order_id"].isin(ids), "late"]
    size, positives = int(late.count()), int(late.sum())
    if size < minimum or positives == 0 or positives == size:
        raise InsufficientCohort(name, size, positives, minimum)


def describe(labels: pd.DataFrame, order_ids: Iterable[str]) -> dict:
    """Size, prevalence, cohort hash and approval range — what the split report and docs show."""
    rows = labels[labels["order_id"].isin(set(order_ids))]
    ids = tuple(rows["order_id"])
    late = rows["late"]
    return {
        "n": len(rows),
        "late": int(late.sum()),
        "prevalence": round(float(late.mean()), 4) if len(ids) else None,
        "cohort_sha256": cohort_sha256(ids),
        "approved_from": rows["approved_at"].min().isoformat() if len(ids) else None,
        "approved_to": rows["approved_at"].max().isoformat() if len(ids) else None,
    }


def _optional_instants(values: pd.Series) -> pd.Series:
    converted = [pd.NaT if v is None or v is pd.NaT or (isinstance(v, float) and pd.isna(v)) else instant(v)
                 for v in values]
    return pd.Series(pd.to_datetime(converted, utc=True), index=values.index)


# ---------------------------------------------------------------------------------------------
# Database layer
# ---------------------------------------------------------------------------------------------
# Every order released by as_of, with its outcome only if that outcome is known by as_of: the
# outcome row's knowledge time (available_at) AND its batch publication must both be <= as_of.
_LABELS_SQL = """
SELECT o.order_id, o.approved_at, o.promised_date,
       k.delivered_at, k.available_at AS label_available_at
FROM promiseops.orders AS o
JOIN promiseops.ingest_batches AS ob ON ob.batch_id = o.batch_id
LEFT JOIN (
    SELECT y.order_id, y.delivered_at, y.available_at
    FROM promiseops.outcomes AS y
    JOIN promiseops.ingest_batches AS yb ON yb.batch_id = y.batch_id
    WHERE y.available_at <= %(as_of)s AND yb.available_at <= %(as_of)s
) AS k ON k.order_id = o.order_id
WHERE ob.available_at <= %(as_of)s
  AND (%(ids)s::text[] IS NULL OR o.order_id = ANY(%(ids)s::text[]))
"""


def load_labels(connection: psycopg.Connection, *, as_of: datetime | str,
                order_ids: Iterable[str] | None = None) -> pd.DataFrame:
    """Labels known at ``as_of`` for every order released by then (``late`` is <NA> if unknown).

    ``order_ids`` limits the result to those orders (None = all released orders).
    """
    ids = None if order_ids is None else sorted({str(order_id) for order_id in order_ids})
    rows = query_frame(connection, _LABELS_SQL, {"as_of": instant(as_of), "ids": ids}, LABEL_COLUMNS)
    return add_labels(rows).sort_values("order_id", kind="mergesort").reset_index(drop=True)
