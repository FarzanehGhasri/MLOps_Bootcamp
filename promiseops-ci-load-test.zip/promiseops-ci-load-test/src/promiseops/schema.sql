-- PromiseOps relational store — schema version 1.
--
-- Applied by `promiseops db-init` (promiseops.db.apply_schema). Every statement is idempotent
-- (IF NOT EXISTS / ON CONFLICT), so running it twice is safe.
-- Walkthrough and reasons (Persian): docs/ingestion/01-ingestion.fa.md
--
-- Design notes
-- * Own schema `promiseops`: the platform database may be shared with Airflow/MLflow tables.
-- * Validation happens in Python BEFORE rows are written (promiseops.validation). The constraints
--   below (PK, FK, NOT NULL, CHECK) are a cheap last safety net, not the main validation.
-- * Money and weight use `numeric` (exact decimal): no float rounding when summing amounts, and
--   no silent rounding of unexpected extra decimals (which numeric(12,2) would do).
-- * Every source row points to the batch (receipt) that brought it, so "what was known at time T"
--   is answerable later (features, labels, API 404 for not-yet-released orders).

CREATE SCHEMA IF NOT EXISTS promiseops;

CREATE TABLE IF NOT EXISTS promiseops.schema_version (
    version     integer     PRIMARY KEY,
    applied_at  timestamptz NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------------------------------
-- Receipts: exactly one row per COMMITTED batch, written in the same transaction as its rows.
-- ---------------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS promiseops.ingest_batches (
    batch_id        text        PRIMARY KEY,
    kind            text        NOT NULL CHECK (kind IN ('orders', 'outcomes')),
    schema_version  text        NOT NULL,
    available_at    timestamptz NOT NULL,          -- company publication time of the batch
    payload_sha256  text        NOT NULL CHECK (payload_sha256 ~ '^[a-f0-9]{64}$'),
    file_sha256     text                 CHECK (file_sha256 ~ '^[a-f0-9]{64}$'),
    as_of           timestamptz NOT NULL,          -- team-chosen replay cutoff used for this run
    row_counts      jsonb       NOT NULL,          -- rows received per table
    source_commit   text,                          -- code version that ingested it (CI_COMMIT_SHA)
    committed_at    timestamptz NOT NULL DEFAULT now()  -- wall clock, infrastructure only
);
CREATE INDEX IF NOT EXISTS ingest_batches_available_at_idx ON promiseops.ingest_batches (available_at);

-- ---------------------------------------------------------------------------------------------
-- Dimensions. Identical rows may appear in many batches and are reused; a changed row is rejected.
-- first_batch_id records which batch introduced the row (audit).
-- ---------------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS promiseops.customers (
    customer_id     text PRIMARY KEY,
    customer_state  text NOT NULL CHECK (customer_state ~ '^[A-Z]{2}$'),
    first_batch_id  text NOT NULL REFERENCES promiseops.ingest_batches (batch_id)
);

CREATE TABLE IF NOT EXISTS promiseops.sellers (
    seller_id       text PRIMARY KEY,
    seller_state    text NOT NULL CHECK (seller_state ~ '^[A-Z]{2}$'),
    first_batch_id  text NOT NULL REFERENCES promiseops.ingest_batches (batch_id)
);

CREATE TABLE IF NOT EXISTS promiseops.products (
    product_id      text    PRIMARY KEY,
    category        text    NOT NULL,
    weight_g        numeric NOT NULL CHECK (weight_g >= 0),
    first_batch_id  text    NOT NULL REFERENCES promiseops.ingest_batches (batch_id)
);

-- ---------------------------------------------------------------------------------------------
-- Facts. An order arrives exactly once, complete with its items and payments.
-- ---------------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS promiseops.orders (
    order_id        text        PRIMARY KEY,
    customer_id     text        NOT NULL REFERENCES promiseops.customers (customer_id),
    approved_at     timestamptz NOT NULL,          -- prediction time
    promised_date   date        NOT NULL,          -- Brazilian local date (America/Sao_Paulo)
    batch_id        text        NOT NULL REFERENCES promiseops.ingest_batches (batch_id)
);
CREATE INDEX IF NOT EXISTS orders_approved_at_idx ON promiseops.orders (approved_at);
CREATE INDEX IF NOT EXISTS orders_batch_id_idx ON promiseops.orders (batch_id);

CREATE TABLE IF NOT EXISTS promiseops.order_items (
    order_id    text    NOT NULL REFERENCES promiseops.orders (order_id),
    item_id     integer NOT NULL CHECK (item_id >= 1),
    product_id  text    NOT NULL REFERENCES promiseops.products (product_id),
    seller_id   text    NOT NULL REFERENCES promiseops.sellers (seller_id),
    price       numeric NOT NULL CHECK (price >= 0),
    freight     numeric NOT NULL CHECK (freight >= 0),
    PRIMARY KEY (order_id, item_id)
);

CREATE TABLE IF NOT EXISTS promiseops.order_payments (
    order_id      text    NOT NULL REFERENCES promiseops.orders (order_id),
    sequence      integer NOT NULL CHECK (sequence >= 1),
    payment_type  text    NOT NULL,
    installments  integer NOT NULL CHECK (installments BETWEEN 0 AND 100),
    value         numeric NOT NULL CHECK (value >= 0),
    PRIMARY KEY (order_id, sequence)
);

-- Labels source. available_at is the label KNOWLEDGE time (includes the 7-day reporting delay):
-- a label may be used only by computations whose cutoff is at or after it.
CREATE TABLE IF NOT EXISTS promiseops.outcomes (
    order_id      text        PRIMARY KEY REFERENCES promiseops.orders (order_id),
    delivered_at  timestamptz NOT NULL,
    available_at  timestamptz NOT NULL,
    batch_id      text        NOT NULL REFERENCES promiseops.ingest_batches (batch_id),
    CHECK (available_at >= delivered_at)
);
CREATE INDEX IF NOT EXISTS outcomes_available_at_idx ON promiseops.outcomes (available_at);

-- When did each order become known to the company? Used by the API (404 for an order that is
-- not yet released at the company as_of) and by cohort selection.
CREATE OR REPLACE VIEW promiseops.order_releases AS
SELECT o.order_id, b.available_at AS released_at, o.batch_id
FROM promiseops.orders AS o
JOIN promiseops.ingest_batches AS b ON b.batch_id = o.batch_id;

-- ---------------------------------------------------------------------------------------------
-- Audit log: one row per ingestion ATTEMPT (committed, replayed no-op, rejected, failed).
-- Separate from receipts: a receipt means "these rows are in the database"; an attempt means
-- "this is what happened when we tried".
-- ---------------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS promiseops.ingest_attempts (
    attempt_id      bigint      GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    batch_id        text,                          -- NULL when the payload could not be parsed
    payload_sha256  text,                          -- canonical payload digest, when computable
    raw_sha256      text        NOT NULL,          -- digest of the exact bytes received
    status          text        NOT NULL CHECK (status IN ('committed', 'replayed', 'rejected', 'failed')),
    reason_code     text,
    reason_detail   jsonb,
    as_of           timestamptz NOT NULL,
    source_commit   text,
    started_at      timestamptz NOT NULL,
    -- clock_timestamp(), not now(): now() is the START of the transaction, not the end of the attempt.
    finished_at     timestamptz NOT NULL DEFAULT clock_timestamp()
);
CREATE INDEX IF NOT EXISTS ingest_attempts_batch_id_idx ON promiseops.ingest_attempts (batch_id);

-- ---------------------------------------------------------------------------------------------
-- Private quarantine: the exact rejected bytes and why. One row per distinct payload; repeated
-- attempts with the same bytes only bump the counter (the attempts table keeps every attempt).
-- bytea, not text: the payload may be invalid UTF-8/JSON, and the bytes must stay exact so their
-- SHA256 can be re-checked during an investigation.
-- ---------------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS promiseops.ingest_quarantine (
    quarantine_id   bigint      GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    raw_sha256      text        NOT NULL UNIQUE,
    batch_id        text,
    reason_code     text        NOT NULL,
    reason_detail   jsonb       NOT NULL,
    payload         bytea       NOT NULL,
    as_of           timestamptz NOT NULL,
    first_seen_at   timestamptz NOT NULL DEFAULT now(),
    last_seen_at    timestamptz NOT NULL DEFAULT now(),
    attempts        integer     NOT NULL DEFAULT 1
);

INSERT INTO promiseops.schema_version (version) VALUES (1) ON CONFLICT (version) DO NOTHING;

CREATE TABLE IF NOT EXISTS promiseops.predictions (
    request_id        text             PRIMARY KEY,
    order_id          text             NOT NULL,
    risk_probability  double precision NOT NULL CHECK (risk_probability >= 0 AND risk_probability <= 1),
    model_version     text             NOT NULL,
    created_at        timestamptz      NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS predictions_request_id_idx ON promiseops.predictions (request_id);
CREATE INDEX IF NOT EXISTS predictions_order_id_idx ON promiseops.predictions (order_id);
CREATE INDEX IF NOT EXISTS predictions_created_at_idx ON promiseops.predictions (created_at);

INSERT INTO promiseops.schema_version (version) VALUES (2) ON CONFLICT (version) DO NOTHING;

-- Original observed inputs, not a later reconstruction from mutable history.
-- Legacy predictions have no snapshot and must not be silently backfilled.
CREATE TABLE IF NOT EXISTS promiseops.prediction_snapshots (
    request_id       text PRIMARY KEY REFERENCES promiseops.predictions(request_id),
    predicted_at     timestamptz NOT NULL,
    features         jsonb NOT NULL CHECK (jsonb_typeof(features) = 'object'),
    artifact_sha256  text NOT NULL CHECK (artifact_sha256 ~ '^[0-9a-f]{64}$')
);
CREATE INDEX IF NOT EXISTS prediction_snapshots_time_idx ON promiseops.prediction_snapshots (predicted_at);
INSERT INTO promiseops.schema_version (version) VALUES (3) ON CONFLICT (version) DO NOTHING;

-- ---------------------------------------------------------------------------------------------
-- Monitoring decisions: one row per FINISHED monitor-train run (promiseops.decisions). The full
-- report is in MLflow; this copy lets the API export the latest decision about the model it serves
-- as promiseops_retraining_required (staff alert RetrainingRecommended).
-- ---------------------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS promiseops.monitoring_decisions (
    monitoring_run_id        text        PRIMARY KEY,   -- MLflow run id of the monitoring run
    as_of                    timestamptz NOT NULL,      -- evaluation cutoff of the report
    incumbent_model_version  text        NOT NULL,
    status                   text        NOT NULL,
    retrain_recommended      boolean     NOT NULL,
    labels_sufficient        boolean     NOT NULL,      -- enough mature labels to judge quality
    reasons_count            integer     NOT NULL CHECK (reasons_count >= 0),  -- reasons are in MLflow
    recorded_at              timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS monitoring_decisions_model_as_of_idx
    ON promiseops.monitoring_decisions (incumbent_model_version, as_of DESC, recorded_at DESC);

INSERT INTO promiseops.schema_version (version) VALUES (4) ON CONFLICT (version) DO NOTHING;
