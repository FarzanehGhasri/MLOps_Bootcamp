"""Persist observed prediction inputs and export them for monitor-train; never backfill features."""

import argparse
import json
from pathlib import Path

import pandas as pd
from psycopg.types.json import Jsonb

from promiseops import db
from promiseops.contracts import instant


def record_snapshot(connection, *, request_id, predicted_at, feature_row, artifact_sha256):
    """Called inside the same transaction as the immutable prediction response."""
    if len(feature_row) != 1:
        raise ValueError("A prediction snapshot requires exactly one feature row")
    # Preserve Python float precision; normalize missing values to JSON null.
    features = {name: None if pd.isna(value) else value
                for name, value in feature_row.to_dict(orient="records")[0].items()}
    json.dumps(features, allow_nan=False)
    connection.execute(
        "INSERT INTO promiseops.prediction_snapshots "
        "(request_id, predicted_at, features, artifact_sha256) VALUES (%s, %s, %s, %s)",
        (request_id, instant(predicted_at), Jsonb(features), artifact_sha256),
    )


def export_history(connection, *, model_version, as_of, artifact_sha256=None):
    """Export only genuinely recorded snapshots for one immutable model, in deterministic order."""
    rows = connection.execute(
        """SELECT p.order_id, s.predicted_at, p.risk_probability, p.model_version, s.features
           FROM promiseops.prediction_snapshots s
           JOIN promiseops.predictions p USING (request_id)
           WHERE p.model_version = %s AND s.predicted_at <= %s
             AND (%s::text IS NULL OR s.artifact_sha256 = %s)
           ORDER BY s.predicted_at, p.order_id, p.request_id""",
        (model_version, instant(as_of), artifact_sha256, artifact_sha256),
    ).fetchall()
    return [{"order_id": oid, "predicted_at": at.isoformat(), "risk_probability": probability,
             "model_version": version, **features} for oid, at, probability, version, features in rows]


def write_export(rows, output: Path) -> None:
    """Freeze observed rows without overwriting earlier evidence or inventing predictions."""
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("x", encoding="utf-8") as stream:
        for row in rows:
            stream.write(json.dumps(row, sort_keys=True, allow_nan=False) + "\n")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model-version", required=True)
    parser.add_argument("--as-of", required=True, type=instant)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args(argv)
    with db.connect() as connection:
        rows = export_history(connection, model_version=args.model_version, as_of=args.as_of)
    if not rows:
        raise ValueError("No recorded snapshots for this model/cutoff; do not reconstruct past predictions")
    write_export(rows, args.output)
    print(json.dumps({"output": str(args.output), "snapshots": len(rows), "model_version": args.model_version}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
