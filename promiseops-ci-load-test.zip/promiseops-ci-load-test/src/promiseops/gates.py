"""Public reference gates: may a candidate replace the champion? (docs/CONTRACTS.md "Evaluation and release")

    recall@10%  must not decrease
    PR-AUC      may decrease by at most 0.02
    Brier       may worsen (increase) by at most 0.005

Both metric sets must come from the SAME validation orders (promiseops.model checks the cohort
hash before calling this). Rejection is a valid lifecycle outcome; the thresholds are constants
on purpose — "do not lower gates just to force a promotion".

Pure: no model, no database. Every check is written into ``reasons`` (passed or failed), so the
model record shows exactly why a decision was taken.
"""

from dataclasses import dataclass
from typing import Literal

from promiseops.bundle import EvaluationMetrics

RECALL_MAX_DECREASE = 0.0
PR_AUC_MAX_DECREASE = 0.02
BRIER_MAX_INCREASE = 0.005
# Floating-point slack only (sums of many probabilities): far below any meaningful difference.
_TOLERANCE = 1e-12


@dataclass(frozen=True)
class GateResult:
    decision: Literal["accepted", "rejected"]
    reasons: tuple[str, ...]


def apply_gates(candidate: EvaluationMetrics, champion: EvaluationMetrics) -> GateResult:
    """Accept only if every gate passes. ``reasons`` lists each check with both values."""
    if (candidate.n, candidate.prevalence) != (champion.n, champion.prevalence):
        raise ValueError("candidate and champion metrics come from different cohorts")
    checks = [
        _check("recall@10%", candidate.recall_at_10, champion.recall_at_10,
               ok=candidate.recall_at_10 >= champion.recall_at_10 - RECALL_MAX_DECREASE - _TOLERANCE,
               rule="must not decrease"),
        _check("PR-AUC", candidate.pr_auc, champion.pr_auc,
               ok=candidate.pr_auc >= champion.pr_auc - PR_AUC_MAX_DECREASE - _TOLERANCE,
               rule=f"may decrease by at most {PR_AUC_MAX_DECREASE}"),
        _check("Brier", candidate.brier, champion.brier,
               ok=candidate.brier <= champion.brier + BRIER_MAX_INCREASE + _TOLERANCE,
               rule=f"may increase by at most {BRIER_MAX_INCREASE}"),
    ]
    accepted = all(ok for ok, _ in checks)
    return GateResult(decision="accepted" if accepted else "rejected", reasons=tuple(text for _, text in checks))


def _check(name: str, candidate: float, champion: float, *, ok: bool, rule: str) -> tuple[bool, str]:
    verdict = "pass" if ok else "FAIL"
    return ok, f"{verdict}: {name} candidate {candidate:.4f} vs champion {champion:.4f} ({rule})"
