"""Evaluation of a frozen model on a later, explicitly declared test period.

What is asked
-------------
* docs/CONTRACTS.md: "Choose and document your own chronological split and untouched test period."
* Our split (docs/features/01-features-labels-split.fa.md, section 5): train up to 2017-12-31, validation
  2018-01..02 (model choice and gates), TEST = orders approved 2018-03-01..2018-04-30 with labels known by
  2018-06-30. The test period is used once, for the final report, never to choose or tune a model.

Rules this module enforces (chronological nonoverlap, not proof of an unseen test)
-------------------------------------------------------------------------
* The model must have a record (lineage.json): we must know which cutoffs it was trained and chosen with.
* The test window starts at or after the model's ``validation_end``: no order the model was chosen on is
  in the test cohort. A test window inside the training/validation period is refused.
* Only labels known by ``label_cutoff`` (as everywhere: no future facts); unknown labels are left out
  and COUNTED, because late orders get their label later (the count shows how far to trust the numbers).
* The cohort must be sufficient (cohorts.require_sufficient: >= 100 orders, both classes).

What is reported (:class:`HoldoutEvaluation`)
------------------------------------------
the contract metrics of the model AND of the constant training-prevalence baseline on the same orders,
the model's recorded validation metrics next to them (how much of the validation result holds), and
calibration (mean predicted risk vs observed late rate). Optionally the report is logged to MLflow in its
own experiment, linked to the model's training run.

Command (read-only on the database):
    python -m promiseops.evaluation --bundle PATH --test-start ... --test-end ... --label-cutoff ...
Walkthrough (Persian): docs/model/07-final-test-evaluation.fa.md
"""

import argparse
import json
import os
import sys
import tempfile
import time
from collections.abc import Mapping, Sequence
from datetime import datetime
from pathlib import Path
from typing import Any, Literal

import numpy as np
import psycopg
from pydantic import BaseModel, ConfigDict, model_validator

from promiseops import approaches, bundle, cohorts, data, db, inference, metrics, record, tracking, training
from promiseops.contracts import instant

EVALUATION_EXPERIMENT = "promiseops-evaluation"
EVALUATION_FILE = "test_evaluation.json"
TAG_TRAINING_RUN = "promiseops.training_run_id"


class EvaluationError(ValueError):
    """The evaluation would not be a fair test (e.g. it overlaps the period the model was chosen on)."""


class HoldoutWindow(BaseModel):
    """Orders approved in (start, end] whose label was known by ``label_cutoff``."""

    model_config = ConfigDict(frozen=True)

    start: datetime
    end: datetime
    label_cutoff: datetime

    @model_validator(mode="after")
    def _ordered(self) -> "HoldoutWindow":
        if not self.start < self.end <= self.label_cutoff:
            raise ValueError("test window must satisfy start < end <= label_cutoff")
        return self


class HoldoutEvaluation(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    report_schema_version: Literal["1.0"] = "1.0"
    model_version: str
    artifact_sha256: str
    model_source_commit: str
    training_dataset_identity: str
    evaluation_dataset_identity: str
    training_run_id: str | None
    trained_with: dict[str, datetime]           # the model's own cutoffs, from its record
    window: HoldoutWindow
    cohort_sha256: str
    approved_orders: int                         # approved in the window and released by label_cutoff
    unlabeled_orders: int                        # left out: outcome not known by label_cutoff
    model: bundle.EvaluationMetrics
    baseline: bundle.EvaluationMetrics                  # constant training prevalence, same orders
    validation: bundle.EvaluationMetrics                # what the model scored when it was chosen
    training_prevalence: float
    mean_predicted_risk: float                   # calibration: compare with model.prevalence

    def summary(self) -> dict[str, Any]:
        return {"model_version": self.model_version, "n": self.model.n, "prevalence": self.model.prevalence,
                "recall_at_10": self.model.recall_at_10, "baseline_recall_at_10": self.baseline.recall_at_10,
                "validation_recall_at_10": self.validation.recall_at_10, "pr_auc": self.model.pr_auc,
                "brier": self.model.brier, "unlabeled_orders": self.unlabeled_orders}


# ---------------------------------------------------------------------------------------------
def check_untouched(lineage_validation_end: datetime, window: HoldoutWindow) -> None:
    """Refuse chronological overlap. Prior inspection or external tuning cannot be inferred here."""
    if window.start < lineage_validation_end:
        raise EvaluationError(f"test window starts {window.start:%Y-%m-%d %H:%M} before the model's validation_end "
                              f"{lineage_validation_end:%Y-%m-%d %H:%M}: it would reuse orders the model was chosen on")


def evaluate_bundle(connection: psycopg.Connection, bundle_path: str | Path,
                    window: HoldoutWindow) -> HoldoutEvaluation:
    """Score the bundle and the training-prevalence baseline on the test cohort (database is only read)."""
    loaded = bundle.read_bundle(bundle_path)                 # SHA256 checked before unpickling
    if loaded.lineage is None:
        raise EvaluationError(f"{bundle_path} has no lineage.json: its cutoffs are unknown, so 'untouched' "
                              "cannot be checked")
    model_record = record.ModelRecord(manifest=loaded.manifest, lineage=loaded.lineage)   # consistency checks
    lineage = model_record.lineage
    check_untouched(lineage.validation_end, window)
    training_identity = data.dataset_identity(connection, as_of=lineage.as_of)
    if training_identity != lineage.dataset_identity:
        raise EvaluationError("training-time dataset identity differs from the model record; "
                              "restore the recorded source batches before evaluating")

    labels = cohorts.load_labels(connection, as_of=window.label_cutoff)
    in_window = labels[(labels["approved_at"] > window.start) & (labels["approved_at"] <= window.end)]
    test_ids = cohorts.select_window(labels, start=window.start, end=window.end, label_cutoff=window.label_cutoff)
    cohorts.require_sufficient("test", labels, test_ids)
    # Training prevalence exactly as the model saw it: train cohort at the model's own cutoffs.
    train_labels = cohorts.load_labels(connection, as_of=lineage.as_of)
    train_ids = cohorts.select_window(train_labels, start=None, end=lineage.train_end,
                                      label_cutoff=lineage.training_label_cutoff)
    cohorts.require_sufficient("train", train_labels, train_ids)
    late_by_id = labels.set_index("order_id")["late"]
    prevalence = float(train_labels.set_index("order_id")["late"].reindex(list(train_ids)).astype(bool).mean())

    table = inference.release_features(connection, test_ids, as_of=window.label_cutoff,
                                       manifest=loaded.manifest, lineage=loaded.lineage)
    missing = set(test_ids) - set(table.index)
    if missing:
        raise EvaluationError(f"{len(missing)} test order(s) have no features, e.g. {min(missing)!r}")
    ids = [str(order_id) for order_id in table.index]
    late = late_by_id.reindex(ids).astype(bool).to_numpy()
    risk = approaches.risk(loaded.model, table[loaded.manifest.feature_names]).reindex(ids).to_numpy()   # paired by ID
    return HoldoutEvaluation(
        model_version=model_record.model_version, artifact_sha256=model_record.artifact_sha256,
        model_source_commit=model_record.manifest.source_commit,
        training_dataset_identity=training_identity,
        evaluation_dataset_identity=data.dataset_identity(connection, as_of=window.label_cutoff),
        training_run_id=lineage.mlflow_run_id,
        trained_with={"train_end": lineage.train_end, "validation_end": lineage.validation_end, "as_of": lineage.as_of},
        window=window, cohort_sha256=cohorts.cohort_sha256(ids),
        approved_orders=len(in_window), unlabeled_orders=len(in_window) - len(ids),
        model=metrics.evaluate(ids, late, risk),
        baseline=metrics.evaluate(ids, late, np.full(len(ids), prevalence)),
        validation=lineage.validation_metrics,
        training_prevalence=round(prevalence, 6), mean_predicted_risk=round(float(np.mean(risk)), 6),
    )


def log_evaluation(client: Any, evaluation: HoldoutEvaluation, *, source_commit: str | None) -> str:
    """Own MLflow run (experiment promiseops-evaluation), linked to the model's training run; returns its id."""
    from mlflow.entities import Metric, Param  # lazy, like promiseops.record

    experiment_id = tracking.ensure_experiment(client, EVALUATION_EXPERIMENT)
    tags = tracking.run_tags("evaluation", source_commit) | {record.TAG_MODEL_VERSION: evaluation.model_version,
                                                            record.TAG_ARTIFACT_SHA256: evaluation.artifact_sha256}
    if evaluation.training_run_id:
        tags[TAG_TRAINING_RUN] = evaluation.training_run_id
    run_id = client.create_run(experiment_id, tags=tags, run_name=f"test-{evaluation.model_version}").info.run_id
    now_ms = int(time.time() * 1000)
    values = {f"test_{k}": float(v) for k, v in evaluation.model.model_dump().items()}
    values |= {f"baseline_{k}": float(v) for k, v in evaluation.baseline.model_dump().items()}
    values |= {"unlabeled_orders": float(evaluation.unlabeled_orders),
               "mean_predicted_risk": evaluation.mean_predicted_risk}
    params = {"test_start": _iso(evaluation.window.start), "test_end": _iso(evaluation.window.end),
              "label_cutoff": _iso(evaluation.window.label_cutoff), "cohort_sha256": evaluation.cohort_sha256,
              "model_source_commit": evaluation.model_source_commit,
              "training_dataset_identity": evaluation.training_dataset_identity,
              "evaluation_dataset_identity": evaluation.evaluation_dataset_identity}
    params.update({f"evaluation_software.{name}": version
                   for name, version in bundle.collect_software_versions().items()})
    try:
        client.log_batch(run_id, metrics=[Metric(k, v, now_ms, 0) for k, v in values.items()],
                         params=[Param(k, v) for k, v in params.items()])
        client.log_text(run_id, evaluation.model_dump_json(indent=2), EVALUATION_FILE)
        with tempfile.TemporaryDirectory() as folder:
            saved = Path(client.download_artifacts(run_id, EVALUATION_FILE, folder))
            if HoldoutEvaluation.model_validate_json(saved.read_text(encoding="utf-8")) != evaluation:
                raise EvaluationError("evaluation report read back from MLflow differs from the one logged")
        client.set_terminated(run_id, "FINISHED")
    except BaseException as error:
        training.close_failed(client, run_id, error)
        raise
    return run_id


def _iso(value: datetime) -> str:
    return value.isoformat().replace("+00:00", "Z")


# ---------------------------------------------------------------------------------------------
def main(argv: Sequence[str] | None = None, environ: Mapping[str, str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="python -m promiseops.evaluation", description=__doc__.splitlines()[0])
    parser.add_argument("--bundle", required=True, type=Path, help="model bundle folder (with lineage.json)")
    parser.add_argument("--test-start", required=True, help="exclusive; at/after the model's validation_end")
    parser.add_argument("--test-end", required=True, help="inclusive approval bound")
    parser.add_argument("--label-cutoff", required=True, help="only outcomes known by then are used")
    parser.add_argument("--output", type=Path, help="also write the JSON report to this file")
    parser.add_argument("--log-to-mlflow", action="store_true", help="log to MLFLOW_TRACKING_URI as well")
    args = parser.parse_args(argv)
    environ = os.environ if environ is None else environ
    try:
        window = HoldoutWindow(start=instant(args.test_start), end=instant(args.test_end),
                            label_cutoff=instant(args.label_cutoff))
        with db.connect(environ.get(db.DATABASE_URL_ENV)) as connection:
            evaluation = evaluate_bundle(connection, args.bundle, window)
        if args.output:
            args.output.write_text(evaluation.model_dump_json(indent=2) + "\n", encoding="utf-8")
        run_id = None
        if args.log_to_mlflow:
            client = tracking.create_client(tracking.TrackingConfig.from_env(environ))
            run_id = log_evaluation(client, evaluation, source_commit=tracking.source_commit_from_env(environ))
    except Exception as error:  # noqa: BLE001  (one place that turns any failure into exit code 1)
        print(json.dumps({"status": "failed", "error": f"{type(error).__name__}: {tracking.redact_error(error)}"}),
              file=sys.stderr)
        return 1
    print(json.dumps({"status": "ok", "mlflow_run_id": run_id, **evaluation.summary()}, sort_keys=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())
