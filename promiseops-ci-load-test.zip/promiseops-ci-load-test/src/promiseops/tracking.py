"""MLflow tracking client for PromiseOps (issue #14): connect, prepare the experiment, prove it works.

What the project documents ask (and where it is handled here)
-------------------------------------------------------------
* docs/CONTRACTS.md (queued worker): the training Job receives ``MLFLOW_TRACKING_URI`` from the course
  dispatcher. So the address is NEVER written in code; it is read from that variable (:class:`TrackingConfig`).
* Course doc, section 3: parameters, metrics, model and preprocessing go to MLflow, together with code
  version, data version, cutoffs, evaluation cohort and model checksum. This module gives the shared
  building blocks (client, experiment, standard tags); the worker (#15) and model record (#16) log the
  model, the metrics and the full lineage through it.
* Course doc, sections 6 and 8 ("MLflow outage" incident): the API must keep serving when MLflow is down.
  Therefore this module imports MLflow lazily (only inside functions). The API image has no MLflow at all
  (it is installed only in the worker image from ``requirements-tracking.lock``), and importing
  ``promiseops.tracking`` never needs it.
* README / course doc: no secret in Git or logs. A URI such as ``https://user:pass@host`` is always
  printed redacted (:func:`redact_uri`), also by ``repr()``.

Why the human UI address does not work from a laptop
----------------------------------------------------
``https://g03-mlflow.mlops.qbootcamp.ir`` is the web UI for people: every request (even ``/health``) is
redirected to the GitLab sign-in page. A program has no browser, so the training Job uses the in-cluster
address injected by the dispatcher. :func:`probe_server` recognises the sign-in redirect and says so,
instead of failing later with an unreadable "response is not JSON" error.

Command (kept out of ``promiseops.cli`` until MR !7 is merged, to avoid a merge conflict in that file)::

    python -m promiseops.tracking check [--experiment promiseops-smoke]

Exit codes: 0 success, 1 MLflow not configured / not reachable / not working, 2 wrong usage (argparse).
Full explanation (Persian): docs/model/02-mlflow-client.fa.md
"""

import argparse
import base64
import contextlib
import ipaddress
import json
import os
import re
import sys
import tempfile
import urllib.error
import urllib.request
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Protocol
from urllib.parse import urlsplit, urlunsplit

# --- Names shared with the team (agree with the DAG/Job owner before changing them) ------------------
TRACKING_URI_ENV = "MLFLOW_TRACKING_URI"  # set by the course dispatcher inside the training Job
COMMIT_ENV = "CI_COMMIT_SHA"  # set by GitLab CI and passed to the Job (docs/CONTRACTS.md)
# Optional: MLflow's DNS-rebinding protection rejects Host headers outside its --allowed-hosts
# allowlist. When the server allowlist has the public name but not the in-cluster name, the client
# must send the public name as Host. Only a server-side allowlist change can do it for everyone.
HOST_HEADER_ENV = "MLFLOW_HOST_HEADER"
TRAINING_EXPERIMENT = "promiseops-late-delivery"  # real training runs (#15)
SMOKE_EXPERIMENT = "promiseops-smoke"  # connectivity checks only: never mixed with real runs, easy to clean

# Tag names: "promiseops.*" for our own lineage (shown under "Tags" in the run page);
# "mlflow.source.git.commit" is MLflow's own standard tag for the code version, so MLflow tools and
# searches (e.g. tags.`mlflow.source.git.commit` = '...') find runs by commit without knowing our names.
TAG_KIND = "promiseops.kind"
TAG_SOURCE_COMMIT = "promiseops.source_commit"
TAG_MLFLOW_GIT_COMMIT = "mlflow.source.git.commit"

_COMMIT_RE = re.compile(r"^[a-f0-9]{40}$")  # same rule as the training gateway and bundle.py (#12)
# Explicit schemes only. A bare path ("mlruns") is accepted by MLflow but inside the Job it would write to
# the temporary /tmp and the runs would silently disappear with the pod, so we refuse it.
_ALLOWED_SCHEMES = frozenset({"http", "https", "file", "sqlite", "postgresql"})
_HTTP_SCHEMES = frozenset({"http", "https"})

# The check command should fail in seconds, not minutes. MLflow's defaults (7 retries with exponential
# backoff, 120 s timeout) can take several minutes before the first error. Only used if the caller did
# not choose its own values.
_CHECK_HTTP_DEFAULTS = {"MLFLOW_HTTP_REQUEST_MAX_RETRIES": "2", "MLFLOW_HTTP_REQUEST_TIMEOUT": "30"}


# --- Errors -------------------------------------------------------------------------------------------
class TrackingError(RuntimeError):
    """MLflow cannot be used. The message says what is wrong and what to do; it never contains secrets."""


class TrackingConfigError(TrackingError):
    """The environment is not configured (missing or invalid MLFLOW_TRACKING_URI / CI_COMMIT_SHA)."""


class TrackingUnavailable(TrackingError):
    """MLflow is configured but cannot be reached or used (not installed, down, sign-in, credentials)."""


# --- Configuration ------------------------------------------------------------------------------------
def redact_uri(uri: str) -> str:
    """Hide credentials before a URI is printed or logged.

    ``https://user:pass@host/x`` -> ``https://***@host/x``; a query string (it may carry a password, e.g.
    ``postgresql://h/db?password=...``) is replaced by ``?***``.
    """
    parts = urlsplit(uri)
    netloc = parts.netloc
    if "@" in netloc:
        netloc = "***@" + netloc.rsplit("@", 1)[1]
    query = "***" if parts.query else ""
    return urlunsplit((parts.scheme, netloc, parts.path, query, ""))


def redact_error(error: Exception) -> str:
    """Redact each URI embedded in exception prose, preserving useful failure context."""
    def replace(match: re.Match[str]) -> str:
        try:
            return redact_uri(match.group())
        except ValueError:
            # Even a malformed URI must not leak credentials or mask the original failure.
            return "[redacted URI]"

    return re.sub(r"[A-Za-z][A-Za-z0-9+.-]*://[^\s<>\"']+", replace, str(error))


@dataclass(frozen=True)
class TrackingConfig:
    """Where to log and in which experiment. Built from the environment by :meth:`from_env`."""

    tracking_uri: str = field(repr=False)  # repr=False: a dataclass repr would print the password
    experiment_name: str = TRAINING_EXPERIMENT

    @property
    def scheme(self) -> str:
        return urlsplit(self.tracking_uri).scheme

    @property
    def safe_uri(self) -> str:
        return redact_uri(self.tracking_uri)

    def __repr__(self) -> str:
        return f"TrackingConfig(tracking_uri={self.safe_uri!r}, experiment_name={self.experiment_name!r})"

    @classmethod
    def from_env(cls, environ: Mapping[str, str] | None = None, *,
                 experiment_name: str = TRAINING_EXPERIMENT) -> "TrackingConfig":
        environ = os.environ if environ is None else environ
        uri = environ.get(TRACKING_URI_ENV, "").strip()
        if not uri:
            raise TrackingConfigError(
                f"{TRACKING_URI_ENV} is not set. Inside the training Job the course dispatcher sets it; "
                f"locally use a local MLflow, e.g. {TRACKING_URI_ENV}=http://127.0.0.1:5000 "
                f"(see docs/model/02-mlflow-client.fa.md).")
        scheme = urlsplit(uri).scheme
        if scheme not in _ALLOWED_SCHEMES:
            raise TrackingConfigError(
                f"{TRACKING_URI_ENV}={redact_uri(uri)!r} has scheme {scheme!r}; expected one of "
                f"{sorted(_ALLOWED_SCHEMES)}. A bare folder path is refused on purpose: inside the Job it "
                f"would write to the temporary /tmp and the runs would be lost.")
        if not experiment_name.strip():
            raise TrackingConfigError("experiment name must not be empty")
        return cls(tracking_uri=uri, experiment_name=experiment_name)


def source_commit_from_env(environ: Mapping[str, str] | None = None) -> str | None:
    """The full git commit of the running code (``CI_COMMIT_SHA``), or ``None`` outside CI/Job.

    A value that is present but malformed is an error: a wrong commit in the lineage is worse than none.
    The worker (#15) will require it; the local check command does not.
    """
    environ = os.environ if environ is None else environ
    value = environ.get(COMMIT_ENV, "").strip()
    if not value:
        return None
    if not _COMMIT_RE.fullmatch(value):
        raise TrackingConfigError(f"{COMMIT_ENV} must be 40 lowercase hex characters (a full git commit)")
    return value


def run_tags(kind: str, source_commit: str | None) -> dict[str, str]:
    """Standard tags for every PromiseOps run: what kind of run, and from which code."""
    tags = {TAG_KIND: kind}
    if source_commit is not None:
        tags[TAG_SOURCE_COMMIT] = source_commit
        tags[TAG_MLFLOW_GIT_COMMIT] = source_commit
    return tags


def close_failed_run(client: Any, run_id: str, error: BaseException) -> None:
    """Independent best-effort failure records; cleanup never replaces the original error."""
    with contextlib.suppress(Exception):
        client.set_tag(run_id, "promiseops.error", f"{type(error).__name__}: {redact_error(error)}"[:500])
    with contextlib.suppress(Exception):
        client.set_terminated(run_id, "FAILED")


# --- Reaching the server --------------------------------------------------------------------------------
def _host_header(environ: Mapping[str, str]) -> dict[str, str]:
    """The Host header the server's allowlist expects, when it differs from the URI's host."""
    host = environ.get(HOST_HEADER_ENV, "").strip()
    return {"Host": host} if host else {}


class _HostHeaderProvider:
    """MLflow request-header provider (its extension point for per-request headers).

    MLflow 3.17.2 resolves extra headers ONLY through this registry (mlflow/utils/rest_utils.py),
    so there is no env-var shortcut; the provider covers every MlflowClient and artifact HTTP call.
    """

    def in_context(self) -> bool:
        return bool(os.environ.get(HOST_HEADER_ENV))

    def request_headers(self) -> dict[str, str]:
        return _host_header(os.environ)


_host_provider_registered = False


def _register_host_header_provider() -> None:
    global _host_provider_registered
    if not _host_provider_registered:
        from mlflow.tracking.request_header.registry import _request_header_provider_registry
        _request_header_provider_registry.register(_HostHeaderProvider)
        _host_provider_registered = True


def _auth_header(environ: Mapping[str, str]) -> dict[str, str]:
    """The same credentials MLflow itself would send (its standard environment variables)."""
    token = environ.get("MLFLOW_TRACKING_TOKEN")
    if token:
        return {"Authorization": f"Bearer {token}"}
    user, password = environ.get("MLFLOW_TRACKING_USERNAME"), environ.get("MLFLOW_TRACKING_PASSWORD")
    if user and password:
        encoded = base64.b64encode(f"{user}:{password}".encode()).decode()
        return {"Authorization": f"Basic {encoded}"}
    return {}


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    """Keep a redirect visible: following it would hide the "you are being sent to sign-in" signal."""

    def redirect_request(self, *args: Any, **kwargs: Any) -> None:
        return None


def probe_server(config: TrackingConfig, *, timeout: float = 10.0,
                 environ: Mapping[str, str] | None = None) -> None:
    """Fast, readable pre-check of an HTTP(S) MLflow server via its ``/health`` endpoint.

    Without it, the common problems surface as long retry loops or as "response is not JSON" errors
    from deep inside MLflow. Non-HTTP URIs (sqlite, file, postgresql) are local and are not probed.
    """
    if config.scheme not in _HTTP_SCHEMES:
        return
    environ = os.environ if environ is None else environ
    url = config.tracking_uri.rstrip("/") + "/health"
    request = urllib.request.Request(url, headers={**_host_header(environ), **_auth_header(environ)})
    opener = urllib.request.build_opener(_NoRedirect)
    where = config.safe_uri
    try:
        with opener.open(request, timeout=timeout) as response:
            status = response.status
    except urllib.error.HTTPError as error:
        status = error.code
        if 300 <= status < 400:
            target = urlsplit(error.headers.get("Location", "")).netloc or "another page"
            raise TrackingUnavailable(
                f"{where} redirects to {target} (a sign-in page). This is the web UI for people, not the "
                f"address for programs. Inside the cluster the Job gets its own {TRACKING_URI_ENV}; "
                f"locally use a local MLflow. Ask the mentor for the in-cluster address if needed.") from None
        if status in (401, 403):
            raise TrackingUnavailable(
                f"{where} refused the credentials (HTTP {status}). Set MLFLOW_TRACKING_TOKEN or "
                f"MLFLOW_TRACKING_USERNAME/MLFLOW_TRACKING_PASSWORD in the environment "
                f"(never in Git).") from None
    except (urllib.error.URLError, TimeoutError, OSError) as error:
        reason = getattr(error, "reason", error)
        raise TrackingUnavailable(
            f"cannot reach MLflow at {where}: {reason}. Is the server running and is the address "
            f"right? Report outages of the course MLflow to the mentor with time and this message.") from None
    if status != 200:
        raise TrackingUnavailable(f"MLflow at {where} answered /health with HTTP {status}, expected 200")


# --- Client and experiment ------------------------------------------------------------------------------
class ExperimentClient(Protocol):
    """The two MlflowClient methods :func:`ensure_experiment` needs (lets tests use a fake client)."""

    def get_experiment_by_name(self, name: str) -> Any: ...

    def create_experiment(self, name: str, artifact_location: str | None = None,
                          tags: dict[str, str] | None = None) -> str: ...


def create_client(config: TrackingConfig) -> Any:
    """An ``MlflowClient`` bound to this URI.

    Why a client object and not ``mlflow.set_tracking_uri`` + ``mlflow.start_run``: the global functions keep
    process-wide state (current URI, active run). With an explicit client every call says where it goes,
    and tests or two configurations cannot leak into each other.
    """
    try:
        from mlflow import MlflowClient  # lazy: see module docstring (API image has no MLflow)
    except ImportError as error:
        raise TrackingUnavailable(
            "MLflow is not installed in this environment. It belongs to the worker image "
            "(requirements-tracking.lock), not to the API image; for local work install it in the "
            "development venv (docs/model/02-mlflow-client.fa.md).") from error
    _register_host_header_provider()
    return MlflowClient(tracking_uri=config.tracking_uri)


def ensure_experiment(client: ExperimentClient, name: str) -> str:
    """Return the experiment ID for ``name``, creating the experiment if it does not exist.

    * Idempotent: running the worker or the check again does not create duplicates.
    * Concurrent-safe: if another process creates it between our "get" and "create", we use theirs.
    * No ``artifact_location`` is passed: the server decides where artifacts live. A location chosen on a
      laptop (or in a pod's /tmp) would not be writable or durable for the other side.
    * A *deleted* experiment keeps its name reserved in MLflow; we stop with instructions instead of
      MLflow's unclear "already exists" error.
    """
    experiment = client.get_experiment_by_name(name)
    if experiment is None:
        try:
            return client.create_experiment(name, tags={"promiseops.project": "late-delivery-risk"})
        except Exception:  # the only accepted case is "created meanwhile", checked below; else re-raised
            experiment = client.get_experiment_by_name(name)
            if experiment is None:
                raise
    if getattr(experiment, "lifecycle_stage", "active") == "deleted":
        raise TrackingError(
            f"MLflow experiment {name!r} exists but is deleted. Restore it in the MLflow UI (or "
            f"'mlflow experiments restore --experiment-id {experiment.experiment_id}'), or choose another "
            f"name. MLflow does not allow creating a new experiment with a deleted one's name.")
    return experiment.experiment_id


# --- Smoke check ----------------------------------------------------------------------------------------
SMOKE_ARTIFACT = "smoke.txt"


@dataclass(frozen=True)
class SmokeResult:
    tracking_uri: str  # already redacted
    experiment_name: str
    experiment_id: str
    run_id: str
    source_commit: str | None

    def as_dict(self) -> dict[str, Any]:
        return {"status": "ok", "tracking_uri": self.tracking_uri, "experiment": self.experiment_name,
                "experiment_id": self.experiment_id, "run_id": self.run_id,
                "source_commit": self.source_commit}


def smoke_check(config: TrackingConfig, *, source_commit: str | None = None, client: Any = None,
                now: datetime | None = None) -> SmokeResult:
    """Prove the whole path works: experiment, run, param, metric, artifact — and READ THEM BACK.

    Reading back matters: run metadata (database) and artifacts (file/object storage) are stored in two
    different places on an MLflow server; a server can accept runs while its artifact store is broken.
    The run ends as FINISHED only if everything was verified, otherwise FAILED (and the error is raised).
    """
    probe_server(config)
    client = client if client is not None else create_client(config)
    try:
        experiment_id = ensure_experiment(client, config.experiment_name)
        stamp = (now or datetime.now(UTC)).strftime("%Y%m%dT%H%M%SZ")
        run = client.create_run(experiment_id, run_name=f"smoke-{stamp}",
                                tags=run_tags("smoke", source_commit))
    except TrackingError:
        raise
    # Normalize arbitrary third-party MLflow failures to the sanitized tracking error contract. any MLflow/network failure -> one readable message
    except Exception as error:  # noqa: BLE001
        raise TrackingUnavailable(
            f"MLflow at {config.safe_uri} did not work: {redact_error(error)}") from None

    run_id = run.info.run_id
    payload = f"promiseops tracking smoke check {stamp}\n"
    try:
        client.log_param(run_id, "check", "tracking-smoke")
        client.log_metric(run_id, "smoke_value", 1.0)
        with tempfile.TemporaryDirectory() as folder:
            source = Path(folder) / SMOKE_ARTIFACT
            source.write_text(payload, encoding="utf-8")
            client.log_artifact(run_id, str(source))
            back = Path(client.download_artifacts(run_id, SMOKE_ARTIFACT, str(Path(folder) / "back")))
            artifact_ok = back.read_text(encoding="utf-8") == payload
        stored = client.get_run(run_id).data
        if stored.params.get("check") != "tracking-smoke" or stored.metrics.get("smoke_value") != 1.0:
            raise TrackingUnavailable(f"run {run_id} was created but its param/metric did not read back")
        if not artifact_ok:
            raise TrackingUnavailable(
                f"run {run_id}: the artifact read back differs from what was written (artifact store)")
        client.set_terminated(run_id, "FINISHED")
        if client.get_run(run_id).info.status != "FINISHED":
            raise TrackingUnavailable(f"run {run_id}: FINISHED status did not read back")
    except Exception as error:
        # Cleanup is best effort: an outage can also prevent updating the run's status.
        # Its exception must not replace the primary failure or bypass the CLI JSON contract.
        with contextlib.suppress(Exception):
            client.set_terminated(run_id, "FAILED")
        if isinstance(error, TrackingError):
            raise
        raise TrackingUnavailable(
            f"run {run_id} was created but logging/reading failed at {config.safe_uri}: {redact_error(error)}. "
            f"If only artifacts fail, the server's artifact storage is the problem.") from None
    return SmokeResult(config.safe_uri, config.experiment_name, experiment_id, run_id, source_commit)


# --- Command line -----------------------------------------------------------------------------------------
def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="python -m promiseops.tracking",
                                     description="MLflow connectivity for PromiseOps")
    commands = parser.add_subparsers(dest="command", required=True)
    check = commands.add_parser("check", help="log and read back a small smoke run")
    check.add_argument("--experiment", default=SMOKE_EXPERIMENT,
                       help=f"experiment for the smoke run (default: {SMOKE_EXPERIMENT})")
    check.add_argument("--require-server", action="store_true",
                       help="require a non-loopback HTTP(S) server; reject local-store acceptance evidence")
    args = parser.parse_args(argv)

    for name, value in _CHECK_HTTP_DEFAULTS.items():
        os.environ.setdefault(name, value)
    # Same as Dockerfile.worker: no usage telemetry leaves the machine.
    os.environ.setdefault("MLFLOW_DISABLE_TELEMETRY", "true")
    try:
        config = TrackingConfig.from_env(experiment_name=args.experiment)
        if args.require_server:
            host = urlsplit(config.tracking_uri).hostname
            loopback = host is None or host.lower().rstrip(".") == "localhost"
            with contextlib.suppress(ValueError):
                loopback = loopback or ipaddress.ip_address(host or "").is_loopback
            if config.scheme not in _HTTP_SCHEMES or loopback:
                raise TrackingConfigError(
                    "Group acceptance requires a non-loopback HTTP(S) MLFLOW_TRACKING_URI. "
                    "Use the mentor-provided machine endpoint; a local store is not group-server evidence.")
        # MLflow prints "View run at ..." links with print() to stdout. stdout must stay ONE JSON line so a
        # DAG/CI step can parse it, so everything MLflow prints goes to stderr (still visible in the log).
        with contextlib.redirect_stdout(sys.stderr):
            result = smoke_check(config, source_commit=source_commit_from_env())
    except TrackingError as error:
        print(json.dumps({"status": "error", "error_type": type(error).__name__, "error": str(error)},
                         ensure_ascii=False), flush=True)
        return 1
    print(json.dumps(result.as_dict(), ensure_ascii=False), flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
