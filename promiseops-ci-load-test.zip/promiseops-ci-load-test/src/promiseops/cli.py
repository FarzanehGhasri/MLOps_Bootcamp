"""Command line entry point: ``promiseops <command>`` (installed by pyproject ``[project.scripts]``).

Commands of part 1-2 (data ingestion). Later parts add their own subcommands here
(``train``, ``score`` — the Helm CronJob already runs ``promiseops score`` —, ``serve`` ...).

  promiseops db-init
      Create/complete the ``promiseops`` schema (idempotent).
  promiseops payload-sha256 FILE
      Print the contract payload_sha256 of a batch file (canonical JSON digest). Useful for the
      fixtures, which are not listed in a feed index.
  promiseops ingest-file FILE --as-of T --expected-sha256 SHA [--expected-file-sha256 SHA]
      Ingest one batch file.
  promiseops ingest-feed DIR --as-of T [--index manifest.json]
      First checks that EVERY index entry agrees with its file (checksum, kind, available_at,
      batch_id); then ingests the entries published at or before T, in publication order. Stops at the
      first rejected batch (later batches may depend on it; continuing would only produce more rejections).
  promiseops dataset-identity --as-of T
      Print the identity of the data known at T (goes into the model lineage).

The database URL is read from the environment variable PROMISEOPS_DATABASE_URL.
Results go to stdout as JSON; logs (one JSON object per line) go to stderr.

Exit codes: 0 success, 1 unexpected error, 2 wrong command-line usage (argparse), 3 batch rejected.
"""

import argparse
import json
import logging
import os
import sys
from collections.abc import Sequence
from dataclasses import asdict
from datetime import datetime
from pathlib import Path
from typing import Any

import numpy as np
import psycopg

from promiseops import db, inference
from promiseops.bundle import BundleError, LoadedBundle, read_bundle, top_k_size
from promiseops.contracts import digest, instant
from promiseops.data import IngestReceipt, dataset_identity, ingest_batch
from promiseops.feed import (
    DEFAULT_INDEX_NAME,
    FeedEntry,
    first_inconsistent_entry,
    load_index,
    publication_order,
    published_until,
    read_entry,
)
from promiseops.validation import BatchRejected

EXIT_OK, EXIT_ERROR, EXIT_REJECTED = 0, 1, 3
logger = logging.getLogger(__name__)


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(message)s", stream=sys.stderr)
    try:
        return args.handler(args)
    except BatchRejected as rejection:
        _print({"status": "rejected", "batch_id": rejection.batch_id, "reason": rejection.reason.value,
                "problems": rejection.detail_records()})
        return EXIT_REJECTED
    except (BundleError, ValueError, RuntimeError) as error:
        logger.error(json.dumps({"event": "cli_error", "error": str(error)}, sort_keys=True))
        return EXIT_ERROR


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="promiseops", description=__doc__.splitlines()[0])
    commands = parser.add_subparsers(dest="command", required=True)

    init = commands.add_parser("db-init", help="create or complete the database schema")
    init.set_defaults(handler=_db_init)

    sha = commands.add_parser("payload-sha256", help="print the canonical payload SHA256 of a batch file")
    sha.add_argument("file", type=Path)
    sha.set_defaults(handler=_payload_sha256)

    one = commands.add_parser("ingest-file", help="ingest one batch file")
    one.add_argument("file", type=Path)
    one.add_argument("--as-of", required=True, type=instant, help="replay cutoff, e.g. 2017-06-01T00:00:00Z")
    one.add_argument("--expected-sha256", required=True, help="payload_sha256 from the feed")
    one.add_argument("--expected-file-sha256", help="file_sha256 from the feed (optional)")
    one.set_defaults(handler=_ingest_file)

    feed = commands.add_parser("ingest-feed", help="ingest all feed entries published by --as-of")
    feed.add_argument("directory", type=Path)
    feed.add_argument("--as-of", required=True, type=instant)
    feed.add_argument("--index", default=DEFAULT_INDEX_NAME, help="index file name inside the directory")
    feed.set_defaults(handler=_ingest_feed)

    ident = commands.add_parser("dataset-identity", help="print the identity of the data known at --as-of")
    ident.add_argument("--as-of", required=True, type=instant)
    ident.set_defaults(handler=_dataset_identity)

    score = commands.add_parser("score", help="score daily cohort and output top 10% priority orders")
    score.add_argument("--as-of", required=True, type=instant, help="company cutoff timestamp")
    score.add_argument("--since", type=instant, help="exclusive lower bound on released_at for daily cohorts")
    score.add_argument(
        "--bundle",
        type=Path,
        default=None,
        help="path to bundle directory or release.json (defaults to PROMISEOPS_RELEASE)",
    )
    score.add_argument("--output", type=Path, default=None, help="optional file path to write JSON output")
    score.set_defaults(handler=_score)

    return parser


def _db_init(args: argparse.Namespace) -> int:
    with db.connect() as connection:
        db.apply_schema(connection)
    _print({"status": "ok", "schema_version": db.SCHEMA_VERSION})
    return EXIT_OK


def _payload_sha256(args: argparse.Namespace) -> int:
    print(digest(json.loads(args.file.read_text(encoding="utf-8"))))
    return EXIT_OK


def _ingest_file(args: argparse.Namespace) -> int:
    with db.connect() as connection:
        receipt = ingest_batch(connection, args.file.read_bytes(), as_of=args.as_of,
                               expected_sha256=args.expected_sha256,
                               expected_file_sha256=args.expected_file_sha256)
    _print(_receipt_json(receipt))
    return EXIT_OK


def _ingest_feed(args: argparse.Namespace) -> int:
    index = load_index(args.directory / args.index)
    with db.connect() as connection:
        # 1. Pre-flight on the WHOLE index: the index metadata drives ordering and as_of filtering,
        #    so it must agree with every payload before we rely on it. Nothing is ingested otherwise;
        #    the bad entry goes through ingest_batch so its rejection is recorded and quarantined.
        bad = first_inconsistent_entry(args.directory, index)
        if bad is not None:
            _ingest_entry(connection, args, bad)  # raises BatchRejected -> exit code 3
            raise RuntimeError(f"pre-flight flagged {bad.file} but ingestion accepted it")
        # 2. Publication order, only entries published by as_of; stop at the first rejection.
        for entry in published_until(publication_order(index), args.as_of):
            _print(_receipt_json(_ingest_entry(connection, args, entry)))
    return EXIT_OK


def _ingest_entry(connection: psycopg.Connection, args: argparse.Namespace,
                  entry: FeedEntry) -> IngestReceipt:
    return ingest_batch(connection, read_entry(args.directory, entry), as_of=args.as_of,
                        expected_sha256=entry.payload_sha256, expected_file_sha256=entry.file_sha256,
                        expected=entry.expected())


def _dataset_identity(args: argparse.Namespace) -> int:
    with db.connect() as connection:
        identity = dataset_identity(connection, as_of=args.as_of)
    _print({"as_of": args.as_of.isoformat(), "dataset_identity": identity})
    return EXIT_OK

def _resolve_bundle_dir(bundle_arg: Path | None) -> Path:
    raw = str(bundle_arg) if bundle_arg is not None else os.getenv("PROMISEOPS_RELEASE", "release/release.json")
    target = Path(raw)
    return target.parent if target.is_file() or target.name == "release.json" else target


def _select_cohort_order_ids(
    connection: psycopg.Connection,
    *,
    as_of: datetime,
    since: datetime | None = None,
) -> list[str]:
    """Select newly released orders in (since, as_of] (or <= as_of when since is omitted)."""
    if since is not None:
        if since >= as_of:
            raise ValueError("--since must be strictly earlier than --as-of")
        rows = connection.execute(
            """SELECT order_id
               FROM promiseops.order_releases
               WHERE released_at > %s AND released_at <= %s
               ORDER BY order_id""",
            (since, as_of),
        ).fetchall()
    else:
        rows = connection.execute(
            """SELECT order_id
               FROM promiseops.order_releases
               WHERE released_at <= %s
               ORDER BY order_id""",
            (as_of,),
        ).fetchall()
    return [row[0] for row in rows]


def _prepare_feature_matrix(
    connection: psycopg.Connection,
    order_ids: list[str],
    *,
    as_of: datetime,
    bundle: LoadedBundle,
) -> Any:
    """Use the same versioned, cutoff-bound features as the prediction API."""
    features = inference.release_features(connection, order_ids, as_of=as_of,
                                           manifest=bundle.manifest, lineage=bundle.lineage)
    if not features.index.is_unique or set(features.index) != set(order_ids):
        raise ValueError("Feature cohort does not match released orders")
    return features.loc[order_ids, bundle.manifest.feature_names]


def score_cohort(
    connection: psycopg.Connection,
    bundle: LoadedBundle,
    *,
    as_of: datetime,
    since: datetime | None = None,
) -> dict[str, Any]:
    """Score cohort orders and select top K = max(1, ceil(0.1 * N)) priority orders."""
    order_ids = _select_cohort_order_ids(connection, as_of=as_of, since=since)
    if not order_ids:
        raise ValueError("cohort has 0 orders; nothing to score")

    feature_matrix = _prepare_feature_matrix(
        connection,
        order_ids,
        as_of=as_of,
        bundle=bundle,
    )
    probas = np.asarray(bundle.model.predict_proba(feature_matrix), dtype=float)
    if probas.ndim != 2 or probas.shape != (len(order_ids), 2):
        raise ValueError(f"expected predict_proba shape ({len(order_ids)}, 2), got {probas.shape}")
    if not np.isfinite(probas).all() or (probas < 0).any() or (probas > 1).any():
        raise ValueError("Invalid model probabilities")

    scored = [
        {"order_id": oid, "risk_probability": float(prob)}
        for oid, prob in zip(order_ids, probas[:, 1], strict=True)
    ]
    scored.sort(key=lambda item: (-item["risk_probability"], item["order_id"]))

    total_scored = len(scored)
    top_k = top_k_size(total_scored)
    priority_orders = [
        {
            "rank": idx + 1,
            "order_id": item["order_id"],
            "risk_probability": item["risk_probability"],
        }
        for idx, item in enumerate(scored[:top_k])
    ]

    cohort_rule = (
        f"released_at > {since.isoformat()} AND released_at <= {as_of.isoformat()}"
        if since is not None
        else f"released_at <= {as_of.isoformat()}"
    )

    return {
        "schema_version": "1.0",
        "as_of": as_of.isoformat(),
        "cohort_identity": f"cohort-sha256:{digest(order_ids)}",
        "cohort_selection_rule": cohort_rule,
        "model_version": bundle.manifest.model_version,
        "scored_count": total_scored,
        "priority_count": top_k,
        "priority_orders": priority_orders,
    }


def _score(args: argparse.Namespace) -> int:
    bundle = read_bundle(_resolve_bundle_dir(args.bundle))
    with db.connect() as connection:
        report = score_cohort(connection, bundle, as_of=args.as_of, since=args.since)

    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, sort_keys=True, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    _print(report)
    return EXIT_OK


def _receipt_json(receipt: IngestReceipt) -> dict:
    return asdict(receipt) | {"available_at": receipt.available_at.isoformat(),
                              "as_of": receipt.as_of.isoformat(), "row_counts": dict(receipt.row_counts)}


def _print(document: dict) -> None:
    print(json.dumps(document, sort_keys=True, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    sys.exit(main())
