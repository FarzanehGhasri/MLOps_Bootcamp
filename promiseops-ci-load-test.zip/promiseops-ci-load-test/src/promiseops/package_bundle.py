"""Package a trusted, complete local candidate without changing its model bytes.

python -m promiseops.package_bundle --bundle PATH --output candidate.tar.gz
Prints a checksum manifest. Packaging does not approve, register or deploy a model.
"""

import argparse
import gzip
import hashlib
import io
import json
import tarfile
import tempfile
from pathlib import Path

from promiseops import bundle, record

FILES = tuple(sorted(("model.joblib", "release.json", "lineage.json", "reference.json", "dataset_manifest.json")))


def package_candidate(source: Path, output: Path) -> dict:
    """Validate an exact snapshot of five trusted files, then create a deterministic archive.

    Only use a trusted source: validating a checksum does not make joblib safe to unpickle.
    Extra files are excluded; missing files, symlinks and overwrites are refused.
    """
    payloads = {}
    for name in FILES:
        path = source / name
        if path.is_symlink() or not path.is_file():
            raise ValueError(f"candidate needs a regular file: {name}")
        payloads[name] = path.read_bytes()
    # Validate exactly the bytes being distributed, even if source files change meanwhile.
    with tempfile.TemporaryDirectory(prefix="candidate-check.") as folder:
        snapshot = Path(folder)
        for name, content in payloads.items():
            (snapshot / name).write_bytes(content)
        loaded = bundle.read_bundle(snapshot)
        if loaded.lineage is None or loaded.reference is None or loaded.lineage.dataset_manifest_sha256 is None:
            raise ValueError("candidate needs lineage, monitoring reference and a pinned dataset manifest")
        record.ModelRecord(manifest=loaded.manifest, lineage=loaded.lineage)
        if (loaded.reference.validation_cohort_sha256 != loaded.lineage.validation_cohort_sha256
                or loaded.reference.validation_metrics != loaded.lineage.validation_metrics):
            raise ValueError("reference and lineage describe different validation results")

    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("xb") as raw:
        try:
            with (gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as compressed,
                  tarfile.open(fileobj=compressed, mode="w", format=tarfile.USTAR_FORMAT) as archive):
                for name, content in payloads.items():
                    info = tarfile.TarInfo(name)
                    info.size, info.mode, info.mtime = len(content), 0o644, 0
                    archive.addfile(info, io.BytesIO(content))
        except BaseException:
            raw.close()
            output.unlink()
            raise
    return {
        "schema_version": "1.0", "status": "candidate_pending_independent_review",
        "model_version": loaded.manifest.model_version,
        "artifact_sha256": loaded.manifest.artifact_sha256,
        "model_source_commit": loaded.manifest.source_commit,
        "feature_count": len(loaded.manifest.feature_names),
        "training_run_id": loaded.lineage.mlflow_run_id,
        "training_gate_decision": loaded.lineage.gate_decision,
        "history_policy": loaded.lineage.history_policy,
        "archive_sha256": bundle.sha256_file(output),
        "files": {name: {"bytes": len(content), "sha256": hashlib.sha256(content).hexdigest()}
                  for name, content in payloads.items()},
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--bundle", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(package_candidate(args.bundle, args.output), indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
