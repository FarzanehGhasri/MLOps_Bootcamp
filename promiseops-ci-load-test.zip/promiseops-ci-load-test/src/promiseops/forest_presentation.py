"""Bounded regularized forest alternatives, using only the existing 32-column approval-time schema."""

import numpy as np
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import ExtraTreesClassifier, RandomForestClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer, OneHotEncoder

from promiseops import approaches

FORESTS = {
    "reference": {"family": "LR", "C": .05},
    "rf_depth8": {"family": "RF", "n_estimators": 120, "max_depth": 8, "min_samples_leaf": 50, "max_features": .5},
    "rf_regular": {"family": "RF", "n_estimators": 120, "max_depth": None, "min_samples_leaf": 30, "max_features": .5},
    "extra_regular": {"family": "ET", "n_estimators": 180, "max_depth": None, "min_samples_leaf": 30, "max_features": .7},
    "extra_flexible": {"family": "ET", "n_estimators": 180, "max_depth": None, "min_samples_leaf": 10, "max_features": .7},
}
CYCLIC = tuple(f"{name}_{component}" for name in ("hour", "weekday", "promise_weekday") for component in ("sin", "cos"))


def forest_features(table):
    out = approaches.engineer_features(table)
    promised = (out.approval_weekday + out.promise_days) % 7
    for name, value, period in (("hour", out.approval_hour, 24), ("weekday", out.approval_weekday, 7),
                                ("promise_weekday", promised, 7)):
        out[f"{name}_sin"] = np.sin(2 * np.pi * value / period)
        out[f"{name}_cos"] = np.cos(2 * np.pi * value / period)
    out["promise_weekday_category"] = promised.astype(int).astype(str)
    out["approval_weekday_category"] = out.approval_weekday.astype(int).astype(str)
    return out


def build_forest(name):
    from promiseops.forest_presentation import forest_features as transform

    if name == "reference":
        return approaches.build("logistic_regression", with_history=True)
    config = dict(FORESTS[name])
    family = config.pop("family")
    estimator = (RandomForestClassifier if family == "RF" else ExtraTreesClassifier)(
        **config, random_state=0, n_jobs=2, class_weight=None)
    # Remove two global counters that primarily encode elapsed historical time.
    numeric = [name for name in approaches.ALL_NUMERIC_WITH_HISTORY
               if name not in ("history_global_count", "history_global_recent_count")] + list(CYCLIC)
    categorical = list(approaches.ALL_CATEGORICAL) + ["promise_weekday_category", "approval_weekday_category"]
    preprocess = ColumnTransformer([
        ("numeric", "passthrough", numeric),
        ("categorical", OneHotEncoder(handle_unknown="infrequent_if_exist", min_frequency=20,
                                       sparse_output=False), categorical),
    ])
    return Pipeline([("engineer", FunctionTransformer(transform, validate=False)),
                     ("preprocess", preprocess), ("model", estimator)])
