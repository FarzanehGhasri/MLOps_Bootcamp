"""One training run of the queued worker, ``--mode train`` (issue #15).

What the contract asks (docs/CONTRACTS.md, "Queued worker interface" and "Evaluation and release")
--------------------------------------------------------------------------------------------------
* "`train` fits/evaluates/registers" a candidate at the given cutoffs, in the team's MLflow;
* "Copy that trusted bundle [the incumbent at /opt/promiseops/release] into writable artifacts before
  comparing a candidate"; candidate and champion on identical validation IDs, public gates;
  "Compare the first candidate with a constant training-prevalence baseline";
* "Persist the exact bundle and metadata to your own MLflow, not only ephemeral Job files";
* "Neither mode promotes/deploys production": nothing here touches a release, an alias or a deployment.

Steps of :func:`run_train` (each step is a function of an existing module; this module only orders them)
--------------------------------------------------------------------------------------------------------
  1. MLflow run created FIRST            tracking.ensure_experiment   (MLflow down -> fail before training)
  2. incumbent copied and verified       bundle.copy_bundle           -> champion, or None (see load_champion)
  3. candidate trained                   model.train_candidate        (#24 features/labels, #25 approaches)
  4. candidate vs champion, same cohort  model.compare_candidate      (#25 gates)
  5. monitoring reference                drift.build_reference        (#26)
  6. lineage + bundle written            bundle.write_bundle          (#12)
  7. comparison details logged           this module                  (every approach, champion scores)
  8. bundle + record logged, read back   record.log_record            (#16)
  9. accepted -> registry version + alias registry.register_candidate (#20; never moves "production")
 10. run closed FINISHED; on any error FAILED with the reason as a tag, and the error is raised again

A rejected candidate is a normal result (run FINISHED, gate_decision=rejected), not an error. It is
logged but not registered: the registry lists only models a human may release.

Dependencies are passed in (database connection, MLflow client), so this module never reads environment
variables and is tested with a test database and a local SQLite MLflow (tests/test_training_db.py).
Reading the environment and the command line is the worker's job (promiseops.worker).
Walkthrough and reasons (Persian): docs/model/04-worker-train.fa.md
"""

import time
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import psycopg

from promiseops import (
    bundle,
    cohorts,
    data,
    drift,
    inference,
    model,
    record,
    registry,
    tracking,
    training_evidence,
)
from promiseops.features import EXTENDED_FEATURE_NAMES, FEATURE_NAMES

DEFAULT_INCUMBENT = Path("/opt/promiseops/release")  # where the worker image carries the serving bundle
DEFAULT_ARTIFACTS = Path("/tmp/artifacts")  # the contract's writable PROMISEOPS_ARTIFACTS

TAG_INCUMBENT = "promiseops.incumbent_model_version"
TAG_CHAMPION_SOURCE = "promiseops.champion_source"
TAG_ERROR = "promiseops.error"
TAG_REGISTRY_VERSION = "promiseops.registry_version"


class TrainingError(RuntimeError):
    """The run cannot be done as asked (e.g. an incumbent the current features cannot score)."""


@dataclass(frozen=True)
class TrainingSettings:
    source_commit: str          # CI_COMMIT_SHA of the running image, 40 lowercase hex
    artifacts: Path             # writable folder (PROMISEOPS_ARTIFACTS)
    incumbent: Path             # trusted serving bundle (read-only in the image)
    experiment: str = tracking.TRAINING_EXPERIMENT


@dataclass(frozen=True)
class TrainingResult:
    run_id: str
    bundle_path: Path
    record: record.ModelRecord
    decision: model.GateDecision
    registry_version: str | None = None   # None when the candidate was rejected (not registered)

    def summary(self) -> dict[str, Any]:
        """One JSON-friendly line for the Job log: enough to find everything else."""
        return {"mode": "train", "mlflow_run_id": self.run_id, "model_version": self.record.model_version,
                "artifact_sha256": self.record.artifact_sha256, "gate_decision": self.decision.decision,
                "champion_model_version": self.decision.champion_model_version,
                "validation_cohort_sha256": self.decision.cohort_sha256, "bundle": str(self.bundle_path),
                "registry_version": self.registry_version}


@dataclass(frozen=True)
class IncumbentChampion:
    champion: model.Champion | None   # None -> compare with the training-prevalence baseline
    incumbent_model_version: str
    source: str                       # why this champion: written to MLflow as a tag
    loaded: bundle.LoadedBundle | None = None


def load_champion(incumbent: Path, workdir: Path) -> IncumbentChampion:
    """Copy the incumbent bundle into ``workdir/champion`` (verified) and decide what the champion is.

    * Incumbent WITH ``lineage.json``: a model trained by this pipeline -> it is the champion. It is always
      re-scored on the candidate's cohort ("A changed champion requires reevaluation").
    * Incumbent WITHOUT ``lineage.json`` (today: the constant mock from MR !3): not trained by this pipeline,
      no record, not auditable -> no trained champion yet, so the contract's rule for the first candidate
      applies: compare with the constant training-prevalence baseline.
    * A champion whose feature list differs from the current one cannot be scored on the same rows: refused,
      because a comparison on different inputs would make the gates meaningless.
    """
    copied = bundle.copy_bundle(incumbent, workdir / "champion")
    version = copied.manifest.model_version
    if copied.lineage is None:
        return IncumbentChampion(None, version, f"baseline: incumbent {version} has no model record")
    record.ModelRecord(manifest=copied.manifest, lineage=copied.lineage)
    if tuple(copied.manifest.feature_names) not in (FEATURE_NAMES, EXTENDED_FEATURE_NAMES):
        raise TrainingError(f"incumbent {version} was trained on other features than the current code; "
                            f"it cannot be scored on the same validation rows")
    return IncumbentChampion(model.Champion(model_version=version, model=copied.model), version,
                             f"incumbent: {version}", copied)


def validate_champion_cutoffs(incumbent: IncumbentChampion, cutoffs: cohorts.Cutoffs) -> None:
    """Reject backdated comparisons before fitting; an auditable baseline needs no dates.

    The validation window is (train_end, validation_end]. A champion trained past
    its start has already trained on the comparison period. A later selection
    window or source snapshot also must not be imported into an earlier replay.
    Equal cutoffs remain valid for a repeat comparison on the documented cohort.
    """
    if incumbent.loaded is None:
        return
    lineage = incumbent.loaded.lineage
    for name in ("train_end", "validation_end", "as_of"):
        if getattr(lineage, name) > getattr(cutoffs, name):
            raise TrainingError(
                f"incumbent {incumbent.incumbent_model_version} {name}="
                f"{getattr(lineage, name).isoformat()} is later than requested "
                f"{name}={getattr(cutoffs, name).isoformat()}; backdated champion comparison refused. "
                "Choose and document compatible replay cutoffs; do not discard the champion or lower gates.")


def build_lineage(candidate: model.Candidate, decision: model.GateDecision, *, source_commit: str,
                  dataset_identity: str, run_id: str, dataset_manifest_sha256: str | None = None) -> bundle.Lineage:
    """The model record's lineage: every item of the contract's list, from the objects of this run."""
    cutoffs = candidate.cutoffs
    return bundle.Lineage(
        approach=candidate.approach,
        source_commit=source_commit,
        created_at=datetime.now(UTC),
        software_versions=bundle.collect_software_versions(),
        dataset_identity=dataset_identity,
        feature_schema_sha256=bundle.feature_schema_sha256(list(candidate.training_features.columns)),
        train_end=cutoffs.train_end,
        validation_end=cutoffs.validation_end,
        as_of=cutoffs.as_of,
        training_label_cutoff=cutoffs.training_label_cutoff,
        validation_label_cutoff=cutoffs.validation_label_cutoff,
        validation_cohort_sha256=candidate.cohort.sha256,
        validation_metrics=candidate.validation_metrics,
        gate_decision=decision.decision,
        gate_reasons=list(decision.reasons),
        champion_model_version=decision.champion_model_version,
        mlflow_run_id=run_id,
        history_policy=("frozen-at-train-end-v1"
                        if tuple(candidate.training_features.columns) == EXTENDED_FEATURE_NAMES else None),
        dataset_manifest_sha256=dataset_manifest_sha256,
    )


def comparison_values(candidate: model.Candidate, decision: model.GateDecision,
                      already_logged: dict[str, str]) -> tuple[dict[str, str], dict[str, float]]:
    """Params and metrics the record does not carry: hyperparameters, every approach, the champion's scores.

    Keys the record already logs (e.g. ``approach``) are left out: MLflow refuses a param logged twice
    with another value, and one source per fact is easier to audit.
    """
    params = {key: value for key, value in candidate.run_params().items() if key not in already_logged}
    metrics = candidate.comparison_metrics()
    metrics.update({f"champion.{name}": float(value)
                    for name, value in decision.champion_metrics.model_dump().items()})
    return params, metrics


def run_train(connection: psycopg.Connection, client: Any, settings: TrainingSettings, *,
              cutoffs: cohorts.Cutoffs) -> TrainingResult:
    """Steps 1-10 of the module docstring. Raises on failure, after marking the MLflow run FAILED."""
    experiment_id = tracking.ensure_experiment(client, settings.experiment)
    run_id = client.create_run(experiment_id, tags=tracking.run_tags("train", settings.source_commit),
                               run_name=f"train-as-of-{cutoffs.as_of:%Y%m%d}").info.run_id
    try:
        result = _train_in_run(connection, client, settings, cutoffs, run_id)
        client.set_terminated(run_id, "FINISHED")
    except BaseException as error:
        close_failed(client, run_id, error)
        raise
    return result


def _train_in_run(connection: psycopg.Connection, client: Any, settings: TrainingSettings,
                  cutoffs: cohorts.Cutoffs, run_id: str) -> TrainingResult:
    workdir = settings.artifacts / f"train-{run_id}"   # unique per run: bundles are never overwritten
    incumbent = load_champion(settings.incumbent, workdir)
    client.set_tag(run_id, TAG_INCUMBENT, incumbent.incumbent_model_version)
    client.set_tag(run_id, TAG_CHAMPION_SOURCE, incumbent.source)
    for name in ("train_end", "validation_end", "as_of"):
        client.log_param(run_id, f"requested.{name}", getattr(cutoffs, name).isoformat())
        if incumbent.loaded is not None:
            client.log_param(run_id, f"champion.{name}", getattr(incumbent.loaded.lineage, name).isoformat())
    validate_champion_cutoffs(incumbent, cutoffs)

    candidate = model.train_candidate(connection, train_end=cutoffs.train_end,
                                      validation_end=cutoffs.validation_end, as_of=cutoffs.as_of, include_history=True)
    champion_cohort = None
    if incumbent.loaded is not None:
        table = inference.release_features(connection, candidate.cohort.order_ids, as_of=cutoffs.as_of,
                                           manifest=incumbent.loaded.manifest, lineage=incumbent.loaded.lineage)
        champion_cohort = model.ValidationCohort.build(table, candidate.cohort.late)
    decision = model.compare_candidate(candidate, incumbent.champion, candidate.cohort,
                                       champion_cohort=champion_cohort)
    reference = drift.build_reference(candidate.training_features, candidate.validation_metrics,
                                      candidate.cohort.sha256)
    identity = data.dataset_identity(connection, as_of=cutoffs.as_of)
    manifest = training_evidence.dataset_manifest(connection, candidate, dataset_identity=identity,
                                                   source_commit=settings.source_commit)
    lineage = build_lineage(candidate, decision, source_commit=settings.source_commit,
                            dataset_identity=identity, run_id=run_id, dataset_manifest_sha256=bundle.digest(manifest))
    bundle_path = workdir / "candidate"
    bundle.write_bundle(bundle_path, candidate.model, approach=candidate.approach,
                        feature_names=list(candidate.training_features.columns),
                        source_commit=settings.source_commit, lineage=lineage, reference=reference,
                        dataset_manifest=manifest)

    expected = record.load_record(bundle_path)
    params, metrics = comparison_values(candidate, decision, expected.mlflow_params())
    _log_values(client, run_id, params, metrics)
    logged = record.log_record(client, run_id, bundle_path)   # also downloads and verifies the bundle
    training_evidence.log_evidence(connection, client, run_id, candidate, logged)
    return TrainingResult(run_id=run_id, bundle_path=bundle_path, record=logged, decision=decision,
                          registry_version=_register_if_accepted(client, run_id, logged))


def _register_if_accepted(client: Any, run_id: str, logged: record.ModelRecord) -> str | None:
    """Accepted -> new registry version, alias ``candidate`` moved to it. Production is never touched."""
    if logged.lineage.gate_decision != "accepted":
        return None
    registered = registry.register_candidate(client, run_id, logged)
    registry.move_alias(client, registry.ALIAS_CANDIDATE, registered.version)
    client.set_tag(run_id, TAG_REGISTRY_VERSION, f"{registered.name}/{registered.version}")
    return registered.version


def _log_values(client: Any, run_id: str, params: dict[str, str], metrics: dict[str, float]) -> None:
    from mlflow.entities import Metric, Param  # lazy, like promiseops.record: the API image has no MLflow

    now_ms = int(time.time() * 1000)
    client.log_batch(run_id, metrics=[Metric(key, value, now_ms, 0) for key, value in metrics.items()],
                     params=[Param(key, value) for key, value in params.items()])


def close_failed(client: Any, run_id: str, error: BaseException) -> None:
    """Best effort: the original error matters more than a second failure while reporting it."""
    tracking.close_failed_run(client, run_id, error)
