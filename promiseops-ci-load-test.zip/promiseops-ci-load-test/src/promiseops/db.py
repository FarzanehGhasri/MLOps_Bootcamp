"""PostgreSQL connection and schema setup (small on purpose: no ORM, no migration framework).

* psycopg 3 directly (already pinned in requirements.lock): explicit SQL and explicit
  transactions are easier to review than ORM magic. SQLAlchemy stays available to others.
* Plain idempotent SQL (``schema.sql``) instead of Alembic: Alembic is not in the app image's
  locked dependencies, and one versioned, re-runnable file is enough for one schema version.
* The database URL comes only from ``PROMISEOPS_DATABASE_URL`` (staff runtime secret in the
  cluster) and is never logged, because it contains the password.
"""

import os
from importlib import resources

import psycopg
from psycopg import pq

DATABASE_URL_ENV = "PROMISEOPS_DATABASE_URL"
SCHEMA_VERSION = 4
# Serialises concurrent `db-init` runs (e.g. two pods starting at once). Arbitrary fixed number.
_SCHEMA_LOCK_KEY = 0x50524F4D_53434845  # "PROMSCHE"


class SchemaNotReady(RuntimeError):
    """The worker image and database migration are not ready to run together."""


def require_schema(connection: psycopg.Connection) -> None:
    """Read-only preflight; a worker must never apply a production migration implicitly."""
    required = ("schema_version", "ingest_batches", "customers", "sellers", "products", "orders",
                "order_items", "order_payments", "outcomes", "predictions", "prediction_snapshots",
                "monitoring_decisions")
    missing = [name for name, relation in connection.execute(
        "SELECT name, to_regclass('promiseops.' || name) FROM unnest(%s::text[]) AS name", (list(required),))
        if relation is None]
    if missing:
        raise SchemaNotReady(f"Missing promiseops tables: {', '.join(missing)}; deploy owner must run "
                             "the reviewed promiseops db-init migration before enabling workers")
    version = connection.execute("SELECT max(version) FROM promiseops.schema_version").fetchone()[0]
    if version != SCHEMA_VERSION:
        raise SchemaNotReady(f"Database schema version {version} does not match worker {SCHEMA_VERSION}; "
                             "coordinate the reviewed migration/image; no migration was attempted")


def connect(url: str | None = None, *, connect_timeout: int | None = None,
            statement_timeout_ms: int | None = None) -> psycopg.Connection:
    """Open an autocommit connection; transactions are opened explicitly with ``conn.transaction()``.

    ``connect_timeout`` (seconds) and ``statement_timeout_ms`` (also used as the lock timeout) bound
    callers that must not hang on an unreachable, slow or locked database, such as the API's /metrics.
    """
    url = url or os.environ.get(DATABASE_URL_ENV)
    if not url:
        raise RuntimeError(f"{DATABASE_URL_ENV} is not set")
    scheme, _, rest = url.partition("://")
    if scheme.startswith("postgresql+"):
        # Platform DB secrets arrive in SQLAlchemy dialect form ("postgresql+psycopg://…");
        # libpq's conninfo parser only understands the plain "postgresql://" scheme.
        url = f"postgresql://{rest}"
    options: dict[str, object] = {} if connect_timeout is None else {"connect_timeout": connect_timeout}
    if statement_timeout_ms is not None:
        limit = f"{statement_timeout_ms}"
        options["options"] = f"-c statement_timeout={limit} -c lock_timeout={limit}"
    return psycopg.connect(url, autocommit=True, application_name="promiseops", **options)


def require_autocommit(connection: psycopg.Connection) -> None:
    """Refuse a connection unless our next ``connection.transaction()`` will be a real top-level one.

    Otherwise that block becomes a *savepoint* inside the caller's transaction: the receipt would
    only commit if the caller commits, and a quarantine record could be rolled back together with
    the caller's work. Both break the contract. Two ways this can happen, both refused:

    * ``autocommit`` is off (psycopg then opens a transaction implicitly);
    * ``autocommit`` is on, but the caller is inside ``with connection.transaction():`` — the
      setting alone does not show this, the server-side transaction status does (review of MR !7).
    """
    if not connection.autocommit:
        raise ValueError("ingestion needs an autocommit connection (use promiseops.db.connect)")
    status = connection.info.transaction_status
    if status != pq.TransactionStatus.IDLE:
        raise ValueError(f"ingestion needs a connection outside any transaction (status: {status.name})")


def schema_sql() -> str:
    return resources.files("promiseops").joinpath("schema.sql").read_text(encoding="utf-8")


def apply_schema(connection: psycopg.Connection) -> None:
    """Create or complete the ``promiseops`` schema. Safe to run any number of times."""
    require_autocommit(connection)
    with connection.transaction():
        connection.execute("SELECT pg_advisory_xact_lock(%s)", (_SCHEMA_LOCK_KEY,))
        connection.execute(schema_sql())
