"""Controlled chronological label-maturity study; no final test or registry writes."""

import argparse
import hashlib
import json
import os
import sys
from datetime import timedelta
from pathlib import Path

from promiseops import approaches, bundle, cohorts, data, db, experiment_log, features, metrics, tracking

EXPERIMENT = "promiseops-label-maturity"
GAPS = (0, 30, 60)
FOLDS = (
    ("earlier", "2017-10-31T23:59:59Z", "2017-12-31T23:59:59Z", "2018-02-28T23:59:59Z"),
    ("current", "2017-12-31T23:59:59Z", "2018-02-28T23:59:59Z", "2018-04-30T00:00:00Z"),
)


def mature_train_ids(labels, cutoffs, gap_days):
    """Exclude recent approvals, not delayed outcomes; keep the original knowledge cutoff."""
    if isinstance(gap_days, bool) or not isinstance(gap_days, int) or gap_days < 0:
        raise ValueError("gap_days must be a nonnegative integer")
    return cohorts.select_window(labels, start=None, end=cutoffs.train_end - timedelta(days=gap_days),
                                 label_cutoff=cutoffs.training_label_cutoff)


def maturity_summary(labels, cutoffs, gap_days):
    end = cutoffs.train_end - timedelta(days=gap_days)
    pool = labels[labels.approved_at <= end]
    ids = mature_train_ids(labels, cutoffs, gap_days)
    return {"approval_end": end.isoformat(), "label_cutoff": cutoffs.train_end.isoformat(),
            "approved": len(pool), "missing_labels_at_training": len(pool) - len(ids),
            "label_coverage": len(ids) / len(pool) if len(pool) else None,
            **cohorts.describe(labels, ids)}


def study(connection, progress):
    results = []
    for name, train_end, validation_end, as_of in FOLDS:
        cutoffs = cohorts.Cutoffs(train_end=train_end, validation_end=validation_end, as_of=as_of)
        labels = cohorts.load_labels(connection, as_of=cutoffs.as_of)
        # Test-period approvals never enter this study, including descriptive statistics.
        labels = labels[labels.approved_at <= cutoffs.validation_end].copy()
        split = cohorts.split(labels, cutoffs)
        cohorts.require_sufficient("validation", labels, split.validation)
        table = features.load_features(connection, split.train + split.validation, as_of=cutoffs.as_of)
        y = labels.set_index("order_id").late
        validation_x = table.loc[list(split.validation)]
        validation_y = y.loc[validation_x.index].astype(bool)
        fold = {"name": name, "cutoffs": cutoffs.model_dump(mode="json"),
                "dataset_identity": data.dataset_identity(connection, as_of=cutoffs.as_of),
                "validation": cohorts.describe(labels, split.validation), "variants": []}
        for gap in GAPS:
            ids = mature_train_ids(labels, cutoffs, gap)
            cohorts.require_sufficient("train", labels, ids)
            train_x, train_y = table.loc[list(ids)], y.loc[list(ids)].astype(bool)
            variant = {"gap_days": gap, "train": maturity_summary(labels, cutoffs, gap), "models": []}
            for approach in (approaches.BASELINE, *approaches.CANDIDATE_APPROACHES):
                key = f"{name}.gap_{gap}.{approach}"
                progress(key, {"status": "started"})
                fitted = approaches.fit(approach, train_x, train_y)
                risk = approaches.risk(fitted, validation_x)
                values = metrics.evaluate(list(validation_x.index), validation_y.tolist(), risk.tolist())
                result = {"approach": approach, "validation": values.model_dump(),
                          "hyperparameters": approaches.hyperparameters(fitted)}
                variant["models"].append(result)
                progress(key, result)
            fold["variants"].append(variant)
        results.append(fold)
    return {"schema_version": "1.0", "dataset_kind": "real_olist", "folds": results,
            "test_used": False, "registry_changed": False,
            "software_versions": bundle.collect_software_versions(),
            "limitations": ["Fixed gaps reduce recent-label selection but do not eliminate censoring.",
                            "Earlier validation overlaps later training; folds are not independent.",
                            "Existing final test has already been inspected; no untouched-test claim."]}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    client, run_id = None, None
    try:
        commit = tracking.source_commit_from_env(os.environ)
        if commit is None:
            raise ValueError("CI_COMMIT_SHA is required")
        # Hash actual source too: a study run may precede its Git commit.
        hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                  for p in sorted(Path(__file__).parent.glob("*.py"))}
        plan = {"gaps_days": GAPS, "folds": FOLDS, "seed": approaches.RANDOM_STATE,
                "base_commit": commit, "source_sha256": hashes, "test_used": False,
                "policy": "Report every variant; no automatic promotion or cutoff movement."}
        client = tracking.create_client(tracking.TrackingConfig.from_env(os.environ))
        exp = tracking.ensure_experiment(client, EXPERIMENT)
        run_id = client.create_run(exp, tags=tracking.run_tags("maturity", commit)).info.run_id
        client.log_text(run_id, json.dumps(plan, indent=2), "plan-before-fit.json")

        def progress(key, result):
            client.log_text(run_id, json.dumps(result, indent=2),
                            f"checks/{key}-{'started' if 'status' in result else 'finished'}.json")
            print(json.dumps({"check": key, **result}), flush=True)

        with db.connect() as connection:
            connection.execute("SET TRANSACTION READ ONLY")
            report = study(connection, progress)
        report["plan"] = json.loads(json.dumps(plan))
        report["mlflow_run_id"] = run_id
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
        values = {f"{f['name']}.gap_{v['gap_days']}.{m['approach']}.{k}": value
                  for f in report["folds"] for v in f["variants"] for m in v["models"]
                  for k, value in m["validation"].items()}
        experiment_log.log_report(client, experiment=EXPERIMENT, kind="maturity", source_commit=commit,
                                 report=report, params={"test_used": "false", "gaps_days": "0,30,60"},
                                 metrics=values, run_id=run_id)
        print(json.dumps({"status": "ok", "mlflow_run_id": run_id}))
        return 0
    # CLI boundary must sanitize third-party failures and return a nonzero exit code.
    except Exception as error:  # noqa: BLE001
        if client is not None and run_id is not None:
            tracking.close_failed_run(client, run_id, error)
        print(tracking.redact_error(error), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
