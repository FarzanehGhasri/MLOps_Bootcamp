"""Model bundle: the folder that carries one trained model from training to serving.

Why this module exists
----------------------
The training worker, the API, batch scoring, CI and monitoring must all agree on *one* on-disk
format for a trained model. This module is that agreement. The reasons for the layout are written
down in ``docs/decisions/0001-model-bundle-format.md`` (ADR 0001).

Bundle layout::

    <bundle>/
        model.joblib     fitted scikit-learn Pipeline (preprocessing + classifier)
        release.json     serving manifest: EXACTLY the 4 fields the API loader accepts
        lineage.json     audit record: cutoffs, cohort hash, metrics, versions, gate decision
        reference.json   validation reference used by monitoring (drift + quality baseline)

Design rules (see ADR 0001):

* This module does NOT import MLflow. The API image has no MLflow, and serving must keep working
  while MLflow is down. MLflow logging lives in a separate module that *uses* this one.
* A bundle is written atomically and is never overwritten (immutable).
* The model file's SHA256 is verified *before* unpickling, because unpickling executes code.

Where to read more
------------------
* Decision and rejected alternatives: ``docs/decisions/0001-model-bundle-format.md``
* Step-by-step walkthrough (Persian): ``docs/model/01-bundle-format.fa.md``

How to run the tests for this module
------------------------------------
Linux/WSL (official, Python 3.12)::

    PYTHONPATH=src .venv/bin/pytest -q tests/test_bundle.py

Windows PowerShell (local check)::

    $env:PYTHONPATH = "src"; .\\.venv\\Scripts\\python.exe -m pytest -q tests/test_bundle.py

Typical use::

    manifest = write_bundle("artifacts/candidate", fitted_pipeline, approach="logistic_regression",
                            feature_names=features, source_commit=commit, lineage=lineage)
    loaded = read_bundle("artifacts/candidate")      # verified: manifest, model, lineage, reference
    champion = copy_bundle("/opt/promiseops/release", "/tmp/artifacts/champion")
"""

import hashlib
import json
import math
import os
import platform
import re
import shutil
import tempfile
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from datetime import datetime
from importlib import metadata
from pathlib import Path
from typing import Any, Literal, Protocol, runtime_checkable

import joblib
from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator, model_validator

from promiseops.contracts import ReleaseManifest, digest, instant

# --------------------------------------------------------------------------------------------
# Constants: file names and value patterns shared by every reader and writer of a bundle.
# --------------------------------------------------------------------------------------------
MODEL_FILE = "model.joblib"
RELEASE_FILE = "release.json"
LINEAGE_FILE = "lineage.json"
REFERENCE_FILE = "reference.json"

SHA256_PATTERN = r"^[a-f0-9]{64}$"
COMMIT_PATTERN = r"^[a-f0-9]{40}$"  # full git commit, same rule as the training gateway
# Approach names become part of model_version, so they are restricted to safe characters.
APPROACH_PATTERN = r"^[a-z][a-z0-9_]{0,63}$"

# Proportions in a distribution must sum to 1; this tolerance absorbs float rounding only.
_SUM_TOLERANCE = 1e-6

# Packages whose versions decide whether a pickled model loads and behaves the same way.
DEFAULT_SOFTWARE_PACKAGES = ("scikit-learn", "pandas", "numpy", "joblib", "pydantic", "mlflow")


class BundleError(ValueError):
    """A bundle is missing, incomplete, or does not match its own manifest."""


@runtime_checkable
class ProbabilisticModel(Protocol):
    """The only capability the bundle needs from a model (interface segregation).

    Any fitted scikit-learn classifier or ``Pipeline`` satisfies it, so models are freely
    interchangeable (Liskov substitution): the bundle code never checks the concrete class.
    """

    def predict_proba(self, X: Any) -> Any: ...


# --------------------------------------------------------------------------------------------
# Small pure helpers
# --------------------------------------------------------------------------------------------
def top_k_size(n: int) -> int:
    """K = max(1, ceil(0.1 * N)) from docs/CONTRACTS.md, computed with integers.

    ``math.ceil(0.1 * 30)`` is 4, not 3, because ``0.1 * 30 == 3.0000000000000004`` in floating
    point. Integer ceiling division (``-(-n // 10)``) avoids that silent off-by-one.
    """
    if n < 1:
        raise ValueError("cohort size N must be at least 1")
    return max(1, -(-n // 10))


def sha256_file(path: str | Path) -> str:
    """SHA256 of a file's bytes, read in chunks so large models do not fill memory."""
    hasher = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


def make_model_version(approach: str, artifact_sha256: str) -> str:
    """Immutable, content-addressed model version: ``<approach>-<first 12 hex of SHA256>``.

    It depends only on the model bytes, so it is known before MLflow registration and can never
    point to a different model (the API contract requires an immutable ``model_version``).
    """
    if not _matches(APPROACH_PATTERN, approach):
        raise ValueError(f"approach must match {APPROACH_PATTERN!r}")
    if not _matches(SHA256_PATTERN, artifact_sha256):
        raise ValueError("artifact_sha256 must be 64 lowercase hex characters")
    return f"{approach}-{artifact_sha256[:12]}"


def feature_schema_sha256(feature_names: Iterable[str]) -> str:
    """Identity of the ordered feature list, using the contract's canonical JSON digest."""
    return digest(list(feature_names))


def collect_software_versions(packages: Iterable[str] = DEFAULT_SOFTWARE_PACKAGES) -> dict[str, str]:
    """Python and package versions of the running environment, for lineage."""
    versions = {"python": platform.python_version()}
    for package in packages:
        try:
            versions[package] = metadata.version(package)
        except metadata.PackageNotFoundError:
            versions[package] = "not-installed"
    return versions


def _matches(pattern: str, value: str) -> bool:
    """True if the whole value matches the pattern (not just a prefix)."""
    return re.fullmatch(pattern, value) is not None


# --------------------------------------------------------------------------------------------
# Document schemas: one class per JSON file (single responsibility).
# --------------------------------------------------------------------------------------------
class _Document(BaseModel):
    """Base for every JSON document in a bundle.

    ``extra="forbid"``: a typo or an unexpected field is an error, not silently ignored.
    ``frozen=True``: a loaded document cannot be modified by accident.
    ``allow_inf_nan=False``: JSON has no NaN/inf, and metrics must be real numbers.
    """

    model_config = ConfigDict(extra="forbid", frozen=True, allow_inf_nan=False)


# release.json is NOT defined here: it is ``contracts.ReleaseManifest``, the exact class the API
# loader validates with (MR !3). One definition => the writer (this module) and the reader (the
# API) can never drift apart. Do NOT add fields to it; put audit data in ``Lineage`` (ADR 0001).


class EvaluationMetrics(_Document):
    """Metrics of one model on one cohort, exactly as defined in docs/CONTRACTS.md.

    Reported together with N and prevalence, because recall@10% alone is not interpretable.
    """

    n: int = Field(ge=1, description="cohort size N")
    prevalence: float = Field(ge=0, le=1, description="share of late orders in the cohort")
    k: int = Field(ge=1, description="review budget K = max(1, ceil(0.1*N))")
    recall_at_10: float = Field(ge=0, le=1, description="late orders in top K / all late orders")
    precision_at_10: float = Field(ge=0, le=1, description="late orders in top K / K")
    pr_auc: float = Field(ge=0, le=1, description="average precision")
    brier: float = Field(ge=0, le=1, description="mean squared probability error")

    @model_validator(mode="after")
    def _k_matches_n(self) -> "EvaluationMetrics":
        if self.k != top_k_size(self.n):
            raise ValueError(f"k must be max(1, ceil(0.1*N)) = {top_k_size(self.n)} for N={self.n}")
        return self


GateOutcome = Literal["accepted", "rejected", "not_evaluated"]


class Lineage(_Document):
    """``lineage.json``: the model record required by docs/CONTRACTS.md "Evaluation and release".

    Together with ``release.json`` (model SHA256, model_version, source commit) this answers:
    which code, which data, which time cutoffs, which cohort, which results, which decision.
    """

    lineage_schema_version: Literal["1.0"] = "1.0"
    approach: str = Field(pattern=APPROACH_PATTERN)
    source_commit: str = Field(pattern=COMMIT_PATTERN)
    created_at: datetime
    software_versions: dict[str, str]

    # Identity of the data the model saw. Supplied by the data/ingestion part (e.g. a hash over
    # the ingestion receipts committed up to as_of) — pending from the data teammate.
    dataset_identity: str = Field(min_length=1, max_length=200)
    feature_schema_sha256: str = Field(pattern=SHA256_PATTERN)

    # Time cutoffs (contract: train_end < validation_end <= as_of).
    train_end: datetime
    validation_end: datetime
    as_of: datetime
    # Label cutoffs: a training label counts only if available by train_end; a validation label
    # only if available by as_of. Stored explicitly so an auditor does not have to infer them.
    training_label_cutoff: datetime
    validation_label_cutoff: datetime

    # Which validation orders were scored (hash of the sorted order IDs) and the result.
    validation_cohort_sha256: str = Field(pattern=SHA256_PATTERN)
    validation_metrics: EvaluationMetrics

    # Candidate-vs-champion decision. "not_evaluated" until the gate step has run.
    gate_decision: GateOutcome
    gate_reasons: list[str] = Field(default_factory=list)
    champion_model_version: str | None = None

    # Link to the MLflow run that produced this bundle (None when trained without MLflow).
    mlflow_run_id: str | None = None
    history_policy: Literal["frozen-at-train-end-v1"] | None = None
    dataset_manifest_sha256: str | None = Field(default=None, pattern=SHA256_PATTERN)

    @field_validator(
        "created_at", "train_end", "validation_end", "as_of", "training_label_cutoff",
        "validation_label_cutoff",
    )
    @classmethod
    def _aware_utc(cls, value: datetime) -> datetime:
        # Same rule as the input contract: timestamps need an offset and are stored in UTC.
        return instant(value)

    @model_validator(mode="after")
    def _cutoffs_are_ordered(self) -> "Lineage":
        if not self.train_end < self.validation_end <= self.as_of:
            raise ValueError("cutoffs must satisfy train_end < validation_end <= as_of")
        if self.training_label_cutoff > self.train_end:
            raise ValueError("training labels must be available on/before train_end")
        if self.validation_label_cutoff > self.as_of:
            raise ValueError("validation labels must be available on/before as_of")
        return self


class NumericDistribution(_Document):
    """Histogram of one numeric feature, the baseline for PSI drift checks.

    ``edges`` are the bin boundaries (len = bins + 1). The first and last bins are open-ended:
    monitoring counts values below ``edges[0]`` in the first bin and above ``edges[-1]`` in
    the last bin, so no new value can fall outside the histogram.
    """

    edges: list[float] = Field(min_length=2)
    proportions: list[float]

    @model_validator(mode="after")
    def _valid_histogram(self) -> "NumericDistribution":
        if any(right <= left for left, right in zip(self.edges, self.edges[1:])):
            raise ValueError("edges must be strictly increasing")
        if len(self.proportions) != len(self.edges) - 1:
            raise ValueError("proportions must have one value per bin (len(edges) - 1)")
        _check_proportions(self.proportions)
        return self


class CategoricalDistribution(_Document):
    """Category shares of one categorical feature, the baseline for total-variation drift."""

    proportions: dict[str, float] = Field(min_length=1)

    @model_validator(mode="after")
    def _valid_shares(self) -> "CategoricalDistribution":
        _check_proportions(self.proportions.values())
        return self


class ValidationReference(_Document):
    """``reference.json``: what monitoring compares new data and new labels against.

    * ``validation_metrics``: retraining triggers compare live quality with these
      (recall < 80% of reference, AP down > 0.05, Brier up > 0.02 — docs/CONTRACTS.md).
    * ``numeric`` / ``categorical``: feature distributions of the TRAINING cohort, the baseline
      for PSI / total variation distance.
    """

    reference_schema_version: Literal["1.0"] = "1.0"
    validation_cohort_sha256: str = Field(pattern=SHA256_PATTERN)
    validation_metrics: EvaluationMetrics
    numeric: dict[str, NumericDistribution] = Field(default_factory=dict)
    categorical: dict[str, CategoricalDistribution] = Field(default_factory=dict)


def _check_proportions(values: Iterable[float]) -> None:
    values = list(values)
    if any(value < 0 for value in values):
        raise ValueError("proportions must be nonnegative")
    if not math.isclose(sum(values), 1.0, abs_tol=_SUM_TOLERANCE):
        raise ValueError("proportions must sum to 1")


# --------------------------------------------------------------------------------------------
# Writing a bundle
# --------------------------------------------------------------------------------------------
def write_bundle(
    target: str | Path,
    model: ProbabilisticModel,
    *,
    approach: str,
    feature_names: Iterable[str],
    source_commit: str,
    lineage: Lineage,
    reference: ValidationReference | None = None,
    dataset_manifest: dict | None = None,
) -> ReleaseManifest:
    """Write a new, complete bundle to ``target`` and return its serving manifest.

    ``lineage`` is required: every new model must be auditable. ``reference`` is optional until
    feature distributions are computed (monitoring step), but should be present for candidates.

    The bundle is assembled in a hidden sibling folder and renamed into place only at the end,
    so a crash never leaves a half-written bundle that looks valid.
    """
    target = Path(target)
    feature_names = list(feature_names)
    if target.exists():
        # Bundles are immutable: a new model always gets a new folder.
        raise FileExistsError(f"bundle already exists, refusing to overwrite: {target}")
    if not isinstance(model, ProbabilisticModel):
        raise TypeError("model must provide predict_proba (a fitted probabilistic classifier)")
    _check_documents_agree(approach, feature_names, source_commit, lineage, reference)
    if (digest(dataset_manifest) if dataset_manifest is not None else None) != lineage.dataset_manifest_sha256:
        raise BundleError("dataset manifest does not match lineage checksum")

    target.parent.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix=f".{target.name}.", suffix=".partial", dir=target.parent))
    try:
        model_path = staging / MODEL_FILE
        joblib.dump(model, model_path)
        artifact_sha256 = sha256_file(model_path)
        manifest = ReleaseManifest(
            model_version=make_model_version(approach, artifact_sha256),
            feature_names=feature_names,
            artifact_sha256=artifact_sha256,
            source_commit=source_commit,
        )
        _write_json(staging / RELEASE_FILE, manifest)
        _write_json(staging / LINEAGE_FILE, lineage)
        if dataset_manifest is not None:
            (staging / "dataset_manifest.json").write_text(
                json.dumps(dataset_manifest, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False),
                encoding="utf-8")
        if reference is not None:
            _write_json(staging / REFERENCE_FILE, reference)
        # Same parent folder => same filesystem => the rename is a single atomic step.
        os.rename(staging, target)
    except BaseException:
        shutil.rmtree(staging, ignore_errors=True)
        raise
    return manifest


def _check_documents_agree(
    approach: str,
    feature_names: list[str],
    source_commit: str,
    lineage: Lineage,
    reference: ValidationReference | None,
) -> None:
    """The files of one bundle must describe the same model; catch mix-ups before writing."""
    if lineage.approach != approach:
        raise ValueError("lineage.approach does not match the bundle approach")
    if lineage.source_commit != source_commit:
        raise ValueError("lineage.source_commit does not match the bundle source commit")
    if lineage.feature_schema_sha256 != feature_schema_sha256(feature_names):
        raise ValueError("lineage.feature_schema_sha256 does not match feature_names")
    if reference is not None and reference.validation_cohort_sha256 != lineage.validation_cohort_sha256:
        raise ValueError("reference and lineage were computed on different validation cohorts")


def _write_json(path: Path, document: BaseModel) -> None:
    # sort_keys + fixed indent => the same document always produces the same bytes (diffable).
    text = json.dumps(document.model_dump(mode="json"), indent=2, sort_keys=True, ensure_ascii=False)
    path.write_text(text + "\n", encoding="utf-8")


# --------------------------------------------------------------------------------------------
# Reading and copying a bundle
# --------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class LoadedBundle:
    """A bundle that passed verification. ``lineage``/``reference`` are None for older bundles."""

    path: Path
    manifest: ReleaseManifest
    model: ProbabilisticModel
    lineage: Lineage | None
    reference: ValidationReference | None


def read_bundle(path: str | Path) -> LoadedBundle:
    """Read and verify a bundle. Raises ``BundleError`` with the exact reason on any problem.

    Order matters: validate ``release.json`` -> check the model's SHA256 -> only then unpickle.
    ``lineage.json`` and ``reference.json`` are optional here so that the current incumbent
    (e.g. the mock baseline, which has only the two serving files) can still be a champion.
    """
    path = Path(path)
    manifest = _read_document(path / RELEASE_FILE, ReleaseManifest)
    if manifest is None:
        raise BundleError(f"{RELEASE_FILE} is missing in {path}")

    model_path = path / MODEL_FILE
    if not model_path.is_file():
        raise BundleError(f"{MODEL_FILE} is missing in {path}")
    actual_sha256 = sha256_file(model_path)
    if actual_sha256 != manifest.artifact_sha256:
        raise BundleError(
            f"{MODEL_FILE} SHA256 {actual_sha256[:12]}... does not match {RELEASE_FILE} "
            f"{manifest.artifact_sha256[:12]}...; refusing to unpickle an unverified model"
        )

    lineage = _read_document(path / LINEAGE_FILE, Lineage)
    if lineage is not None and lineage.dataset_manifest_sha256 is not None:
        dataset_path = path / "dataset_manifest.json"
        if not dataset_path.is_file() or sha256_file(dataset_path) != lineage.dataset_manifest_sha256:
            raise BundleError("dataset manifest checksum mismatch; refusing to unpickle")
    try:
        model = joblib.load(model_path)
    except Exception as error:  # e.g. a class that no longer exists at its pickled import path
        raise BundleError(f"cannot unpickle {MODEL_FILE}: {error}") from error
    if not isinstance(model, ProbabilisticModel):
        raise BundleError(f"{MODEL_FILE} does not contain a model with predict_proba")

    return LoadedBundle(
        path=path,
        manifest=manifest,
        model=model,
        lineage=lineage,
        reference=_read_document(path / REFERENCE_FILE, ValidationReference),
    )


def copy_bundle(source: str | Path, target: str | Path) -> LoadedBundle:
    """Copy a trusted bundle (e.g. the incumbent at /opt/promiseops/release) and verify the copy.

    The worker compares candidates against this *copy* in its writable artifacts folder, as the
    contract asks, and the verification proves the copy is byte-identical in the parts that count.
    """
    source, target = Path(source), Path(target)
    read_bundle(source)  # never copy something that is already broken
    if target.exists():
        raise FileExistsError(f"refusing to overwrite existing folder: {target}")
    target.parent.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix=f".{target.name}.", suffix=".partial", dir=target.parent))
    try:
        # copytree needs a non-existing destination, so copy into a child and move that.
        shutil.copytree(source, staging / "bundle")
        os.rename(staging / "bundle", target)
    finally:
        shutil.rmtree(staging, ignore_errors=True)
    return read_bundle(target)


def _read_document[DocumentT: BaseModel](path: Path, schema: type[DocumentT]) -> DocumentT | None:
    """Parse one JSON document; None if the file does not exist; BundleError if it is invalid."""
    if not path.is_file():
        return None
    try:
        raw: Mapping[str, Any] = json.loads(path.read_text(encoding="utf-8"))
        return schema.model_validate(raw)
    except (json.JSONDecodeError, ValidationError) as error:
        raise BundleError(f"{path.name} is invalid: {error}") from error
