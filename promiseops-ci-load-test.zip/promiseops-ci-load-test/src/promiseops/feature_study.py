"""Audit and compare approval-only feature engineering on chronological validation."""

import argparse
import hashlib
import json
import os
import sys
import tempfile
from pathlib import Path

import joblib
import numpy as np
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer, OneHotEncoder, SplineTransformer, StandardScaler

from promiseops import (
    approaches,
    bundle,
    cohorts,
    data,
    db,
    experiment_log,
    features,
    gates,
    metrics,
    tracking,
)
from promiseops.maturity import FOLDS

EXPERIMENT = "promiseops-feature-audit"
EXTRA_NUMERIC = ("log_price", "log_freight", "log_weight", "price_per_item", "weight_per_item",
                 "freight_to_price", "promise_x_interstate")
EXTRA_CATEGORICAL = ("shipping_route",)


def engineer(table):
    """Stateless, per-order transformation; never consumes IDs, outcomes or other orders."""
    if list(table.columns) != list(features.FEATURE_NAMES):
        raise ValueError("expected the exact approval-only feature schema")
    out = table.copy()
    for source, target in (("total_price", "log_price"), ("total_freight", "log_freight"),
                           ("total_weight_g", "log_weight")):
        out[target] = np.log1p(out[source])
    out["price_per_item"] = out.total_price / out.item_count.clip(lower=1)
    out["weight_per_item"] = out.total_weight_g / out.item_count.clip(lower=1)
    out["freight_to_price"] = out.total_freight / (1 + out.total_price)
    out["promise_x_interstate"] = out.promise_days * out.interstate_fraction
    out["shipping_route"] = out.primary_seller_state + ">" + out.customer_state
    return out


def build_engineered(name):
    """Keep raw input contract unchanged; save transformation and estimator as ONE pipeline."""
    # Canonical import makes artifacts loadable outside a CLI's __main__ process.
    from promiseops.feature_study import engineer as transform

    if name not in approaches.CANDIDATE_APPROACHES:
        raise ValueError("unsupported engineered approach")
    original = approaches.build(name)
    numeric = list(features.NUMERIC_FEATURES) + list(EXTRA_NUMERIC)
    categorical = list(features.CATEGORICAL_FEATURES) + list(EXTRA_CATEGORICAL)
    if name == "logistic_regression":
        preprocess = ColumnTransformer([
            ("numeric", StandardScaler(), numeric),
            ("categorical", OneHotEncoder(handle_unknown="infrequent_if_exist", min_frequency=20,
                                           sparse_output=False), categorical),
            # Knots are learned from TRAIN only, with constant extrapolation outside training range.
            ("promise_spline", SplineTransformer(n_knots=5, degree=3, extrapolation="constant"),
             ["promise_days"]),
        ])
    else:
        # Retain native-categorical HGB and its established estimator parameters.
        from sklearn.preprocessing import OrdinalEncoder

        preprocess = ColumnTransformer([
            ("numeric", "passthrough", numeric),
            ("categorical", OrdinalEncoder(handle_unknown="use_encoded_value", unknown_value=-1,
                                            encoded_missing_value=-1), categorical),
        ])
        original.named_steps["model"].set_params(
            categorical_features=[False] * len(numeric) + [True] * len(categorical))
        # Route has up to 27x27 values, exceeding HGB's 255-bin categorical limit.
        preprocess.transformers[1][1].set_params(max_categories=200)
    return Pipeline([("engineer", FunctionTransformer(transform, validate=False)),
                     ("preprocess", preprocess), ("model", original.named_steps["model"])])


def evaluate(fitted, x, y):
    return metrics.evaluate(list(x.index), y.tolist(), approaches.risk(fitted, x).tolist())


def study(connection, progress, save_model):
    folds = []
    for name, train_end, validation_end, as_of in FOLDS:
        cutoffs = cohorts.Cutoffs(train_end=train_end, validation_end=validation_end, as_of=as_of)
        labels = cohorts.load_labels(connection, as_of=cutoffs.as_of)
        labels = labels[labels.approved_at <= cutoffs.validation_end].copy()
        split = cohorts.split(labels, cutoffs)
        for kind, ids in (("train", split.train), ("validation", split.validation)):
            cohorts.require_sufficient(kind, labels, ids)
        table = features.load_features(connection, split.train + split.validation, as_of=cutoffs.as_of)
        y = labels.set_index("order_id").late
        tx, vx = table.loc[list(split.train)], table.loc[list(split.validation)]
        ty, vy = y.loc[tx.index].astype(bool), y.loc[vx.index].astype(bool)
        early_features = features.load_features(connection, split.train, as_of=cutoffs.train_end)
        # CONTRACTS: historical label knowledge time differs from optional batch replay publication.
        # Prepared orders are published in January 2018, including earlier historical approvals.
        common = early_features.index.intersection(tx.index)
        same_common = early_features.loc[common].equals(tx.loc[common])
        if not same_common:
            raise ValueError("published training feature values changed across snapshots")
        sample = features.load_features(connection, [split.train[0]], as_of=cutoffs.as_of)
        if not sample.equals(tx.loc[[split.train[0]]]):
            raise ValueError("single-order and batch feature values differ")
        audit = {"train_orders_published_by_historical_train_end": len(early_features),
                 "published_feature_values_unchanged": same_common if len(common) else None,
                 "publication_note": "Batch replay time is distinct from historical label knowledge time (CONTRACTS).",
                 "single_vs_batch_equal": True,
                 "disjoint_order_ids": not bool(set(tx.index) & set(vx.index)),
                 "no_missing_values": not bool(table.isna().any().any()),
                 "finite_numeric": bool(np.isfinite(table[list(features.NUMERIC_FEATURES)]).all().all()),
                 "feature_columns": list(table.columns),
                 "unseen_validation_categories": {
                     col: float((~vx[col].isin(set(tx[col]))).mean()) for col in features.CATEGORICAL_FEATURES},
                 "numeric_quantiles": {
                     col: {"train": tx[col].quantile([0, .5, .99, 1]).to_dict(),
                           "validation": vx[col].quantile([0, .5, .99, 1]).to_dict()}
                     for col in features.NUMERIC_FEATURES}}
        results, reference = [], None
        for variant in ("baseline", "original_lr", "original_hgb", "engineered_lr", "engineered_hgb",
                        "shuffled_labels_lr"):
            progress(f"{name}.{variant}", {"status": "started"})
            approach = "hist_gradient_boosting" if variant.endswith("hgb") else "logistic_regression"
            fitted = (approaches.build("baseline") if variant == "baseline" else
                      build_engineered(approach) if variant.startswith("engineered") else approaches.build(approach))
            fit_y = np.random.default_rng(42).permutation(ty.to_numpy()) if variant == "shuffled_labels_lr" else ty.to_numpy()
            fitted.fit(tx, fit_y)
            scores = evaluate(fitted, vx, vy)
            if variant == "original_lr":
                reference = scores
            result = {"variant": variant, "validation": scores.model_dump(),
                      "hyperparameters": approaches.hyperparameters(fitted)}
            if variant.startswith("engineered"):
                gate = gates.apply_gates(scores, reference)
                result["gate_vs_original_lr"] = {"decision": gate.decision, "reasons": gate.reasons}
                save_model(f"{name}.{variant}", fitted, vx.iloc[:10])
            results.append(result)
            progress(f"{name}.{variant}", result)
        folds.append({"name": name, "cutoffs": cutoffs.model_dump(mode="json"),
                      "dataset_identity": data.dataset_identity(connection, as_of=cutoffs.as_of),
                      "train": cohorts.describe(labels, split.train),
                      "validation": cohorts.describe(labels, split.validation), "audit": audit, "results": results})
    return {"dataset_kind": "real_olist", "folds": folds, "test_used": False, "registry_changed": False,
            "software_versions": bundle.collect_software_versions(),
            "limitations": ["Leakage checks cannot prove absence of all upstream leakage.",
                            "Label permutation is a negative control, not a proof of no leakage.",
                            "Folds overlap in time; repeated validation use introduces selection optimism."]}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    client, run_id = None, None
    try:
        commit = tracking.source_commit_from_env(os.environ)
        if commit is None:
            raise ValueError("CI_COMMIT_SHA required")
        plan = {"base_commit": commit, "source_sha256": {
            p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(Path(__file__).parent.glob("*.py"))},
            "folds": FOLDS, "seed": 0, "shuffle_seed": 42, "test_used": False,
            "extra_numeric": EXTRA_NUMERIC, "extra_categorical": EXTRA_CATEGORICAL,
            "lr_spline": {"feature": "promise_days", "knots": 5, "degree": 3},
            "selection_policy": "report all variants; no production changes"}
        client = tracking.create_client(tracking.TrackingConfig.from_env(os.environ))
        exp = tracking.ensure_experiment(client, EXPERIMENT)
        run_id = client.create_run(exp, tags=tracking.run_tags("feature-audit", commit)).info.run_id
        client.log_text(run_id, json.dumps(plan, indent=2), "plan-before-fit.json")

        def progress(key, value):
            client.log_text(run_id, json.dumps(value), f"checks/{key}-{'started' if 'status' in value else 'finished'}.json")
            print(json.dumps({"check": key, "validation": value.get("validation", "started")}), flush=True)

        def save_model(key, fitted, sample):
            with tempfile.TemporaryDirectory() as folder:
                path = Path(folder) / f"{key}.joblib"
                joblib.dump(fitted, path)
                client.log_artifact(run_id, str(path), "experimental-pipelines")
                restored = joblib.load(client.download_artifacts(run_id, f"experimental-pipelines/{path.name}"))
                np.testing.assert_allclose(fitted.predict_proba(sample), restored.predict_proba(sample), rtol=0, atol=0)

        with db.connect() as connection:
            connection.execute("SET default_transaction_read_only = on")
            report = study(connection, progress, save_model)
        # Normalize JSON keys/tuples before report read-back comparison.
        report = json.loads(json.dumps({**report, "plan": plan, "mlflow_run_id": run_id}))
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
        values = {f"{fold['name']}.{r['variant']}.{k}": v for fold in report["folds"]
                  for r in fold["results"] for k, v in r["validation"].items()}
        experiment_log.log_report(client, experiment=EXPERIMENT, kind="feature-audit", source_commit=commit,
                                 report=report, params={"test_used": "false"}, metrics=values, run_id=run_id)
        print(json.dumps({"status": "ok", "mlflow_run_id": run_id}))
        return 0
    # CLI boundary must sanitize third-party failures and return a nonzero exit code.
    except Exception as error:  # noqa: BLE001
        if client is not None and run_id is not None:
            tracking.close_failed_run(client, run_id, error)
        print(tracking.redact_error(error), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
