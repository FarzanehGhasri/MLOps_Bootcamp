"""Model versions and aliases in the MLflow Model Registry (issue #20).

What the contract asks (docs/CONTRACTS.md "Evaluation and release", README item 6)
-------------------------------------------------------------------------------------
* "MLflow candidate registration does not promote production."
* "Production startup never resolves a mutable alias."
* README: "changing an alias in MLflow must not silently change the running service".
* Issue #20 acceptance: moving an alias after a deploy changes nothing in the running service (tested).

How this is guaranteed
----------------------
An alias is a NAME that can be moved; a registry version points to one run's exact bundle, whose
``model.joblib`` has a fixed SHA256. The two worlds meet only once, when a release is prepared:

    worker (#15) --register_candidate--> version N  <--alias "candidate" (moved by the worker)
    human approval / release (#19) --resolve_alias + download_version--> bundle folder (fixed SHA256)
    CI builds the image WITH that folder, deploys it by image digest
    API (create_app) reads PROMISEOPS_RELEASE from disk once at startup -- it never talks to MLflow

So after a deploy, moving any alias only changes what the NEXT release would pick; the running
service keeps the bytes baked into its image. tests/test_registry.py checks that the API code has no
path to MLflow at all; tests/test_registry_mlflow.py moves an alias under a running app.

Aliases used by this project
----------------------------
=================  ======================================  =========================================
alias              meaning                                 moved by
=================  ======================================  =========================================
``candidate``      latest candidate that passed the gates  the worker, after each accepted run
``production``     what is deployed now (information only) the release step, after deploy evidence
=================  ======================================  =========================================

Only ACCEPTED candidates are registered: the registry is the list of models a human may release.
A rejected candidate stays in its MLflow run (with its bundle and record) but is never a registry
version, so it cannot be picked by mistake. Registration is idempotent per run (a retried Job does not
create a second version for the same model).

MLflow is imported lazily, like promiseops.record: the API image does not install it.
Walkthrough (Persian): docs/model/05-registry-aliases.fa.md
"""

import json
import shutil
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from promiseops import bundle, record
from promiseops.contracts import ReleaseManifest

REGISTERED_MODEL = "promiseops-late-delivery"
ALIAS_CANDIDATE = "candidate"
ALIAS_PRODUCTION = "production"

# Version tags: the same keys as the run tags of promiseops.record, so one search works for both.
TAG_ARTIFACT_SHA256 = record.TAG_ARTIFACT_SHA256
TAG_MODEL_VERSION = record.TAG_MODEL_VERSION
TAG_GATE_DECISION = record.TAG_GATE_DECISION


class RegistryError(RuntimeError):
    """A registry operation would break the rules above (e.g. registering a rejected model)."""


@dataclass(frozen=True)
class RegisteredVersion:
    """One registry version and the immutable model it stands for."""

    name: str
    version: str              # MLflow's number ("1", "2", ...): never reused within a registered model
    run_id: str
    model_version: str        # our content-addressed identity, <approach>-<sha256[:12]>
    artifact_sha256: str      # what the API reports and what a release is checked against


def register_candidate(client: Any, run_id: str, logged: record.ModelRecord, *,
                       name: str = REGISTERED_MODEL) -> RegisteredVersion:
    """Register the bundle logged in ``run_id`` as a new version. Accepted candidates only.

    ``logged`` is the record returned by ``record.log_record`` for this run (already read back and
    verified), so the version tags describe exactly the bytes stored in the run.
    """
    if logged.lineage.gate_decision != "accepted":
        raise RegistryError(f"{logged.model_version} was {logged.lineage.gate_decision}: only accepted "
                            "candidates are registered")
    if logged.lineage.mlflow_run_id not in (None, run_id):
        raise RegistryError(f"record names run {logged.lineage.mlflow_run_id}, not {run_id}")
    _ensure_registered_model(client, name)

    for existing in _versions_of_run(client, name, run_id):   # retried Job: reuse, do not duplicate
        if existing.artifact_sha256 == logged.artifact_sha256:
            return existing
    created = client.create_model_version(
        name, f"runs:/{run_id}/{record.BUNDLE_ARTIFACT_DIR}", run_id=run_id,
        tags={TAG_ARTIFACT_SHA256: logged.artifact_sha256, TAG_MODEL_VERSION: logged.model_version,
              TAG_GATE_DECISION: logged.lineage.gate_decision},
        description=f"{logged.model_version} (gate: accepted vs {logged.lineage.champion_model_version})",
    )
    return _to_registered(created)


def move_alias(client: Any, alias: str, version: str, *, name: str = REGISTERED_MODEL) -> str | None:
    """Point ``alias`` at ``version`` and return the version it pointed at before (None if new).

    The target must be one of OUR versions (it has the SHA256 tag), so an alias never names a model
    nobody can verify. Moving an alias changes no deployment: see the module docstring.
    """
    target = _to_registered(client.get_model_version(name, version))
    previous = alias_version(client, alias, name=name)
    client.set_registered_model_alias(name, alias, target.version)
    return previous.version if previous else None


def alias_version(client: Any, alias: str, *, name: str = REGISTERED_MODEL) -> RegisteredVersion | None:
    """The version an alias points at now, or None if the alias is not set.

    Use it when preparing a release (a human decision), NEVER at service startup.
    """
    from mlflow.exceptions import MlflowException  # lazy: see module docstring

    try:
        found = client.get_model_version_by_alias(name, alias)
    except MlflowException as error:
        if error.error_code in {"RESOURCE_DOES_NOT_EXIST", "INVALID_PARAMETER_VALUE"}:
            return None  # MLflow answers "alias not found" with one of these two codes
        raise
    return _to_registered(found)


def download_version(client: Any, version: RegisteredVersion, target: str | Path) -> record.ModelRecord:
    """Copy the exact bundle of a registry version into ``target`` (a new folder) and verify it.

    This is where an alias stops mattering: the folder that comes out is identified by its SHA256 and
    is what a release image carries (#19). Trust order, as in record.load_logged_record: the version's
    SHA256 tag must equal the downloaded release.json BEFORE anything is unpickled.
    """
    target = Path(target)
    if target.exists():
        raise FileExistsError(f"refusing to overwrite existing folder: {target}")
    with tempfile.TemporaryDirectory() as folder:
        local = Path(client.download_artifacts(version.run_id, record.BUNDLE_ARTIFACT_DIR, folder))
        try:
            manifest = ReleaseManifest.model_validate(
                json.loads((local / bundle.RELEASE_FILE).read_text(encoding="utf-8")))
        except (OSError, ValueError) as error:
            raise RegistryError(f"version {version.version}: {bundle.RELEASE_FILE} missing or invalid") from error
        if manifest.artifact_sha256 != version.artifact_sha256:
            raise RegistryError(f"version {version.version}: stored bundle does not match its SHA256 tag")
        bundle.copy_bundle(local, target)  # verifies model.joblib against release.json, then copies
    try:
        return record.load_record(target)
    except record.RecordError:
        shutil.rmtree(target, ignore_errors=True)  # never leave an unverifiable release folder behind
        raise


# --- helpers ------------------------------------------------------------------------------------------
def _ensure_registered_model(client: Any, name: str) -> None:
    from mlflow.exceptions import MlflowException

    try:
        client.create_registered_model(name, description="PromiseOps late-delivery risk: accepted candidates. "
                                       "Aliases never change a running service (issue #20).")
    except MlflowException as error:
        if error.error_code != "RESOURCE_ALREADY_EXISTS":  # two Jobs may race here; both are fine
            raise


def _versions_of_run(client: Any, name: str, run_id: str) -> list[RegisteredVersion]:
    if not run_id.isalnum():  # MLflow run IDs are hex; checked before going into a filter string
        raise RegistryError(f"invalid MLflow run id: {run_id!r}")
    found = client.search_model_versions(f"name = '{name}' and run_id = '{run_id}'")
    return [_to_registered(item) for item in found]


def _to_registered(model_version: Any) -> RegisteredVersion:
    tags = model_version.tags or {}
    if TAG_ARTIFACT_SHA256 not in tags or TAG_MODEL_VERSION not in tags:
        raise RegistryError(f"{model_version.name} version {model_version.version} was not registered by "
                            "PromiseOps (no SHA256 / model_version tags); refusing to use it")
    return RegisteredVersion(name=model_version.name, version=str(model_version.version),
                             run_id=model_version.run_id, model_version=tags[TAG_MODEL_VERSION],
                             artifact_sha256=tags[TAG_ARTIFACT_SHA256])
