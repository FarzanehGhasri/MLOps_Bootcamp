"""Bounded temporal-validation study; no final-test access or registry mutation."""

import argparse
import hashlib
import json
import os
import sys
import time
from pathlib import Path

import numpy as np

from promiseops import (
    approaches,
    bundle,
    cohorts,
    data,
    db,
    experiment_log,
    features,
    gates,
    metrics,
    tracking,
)
from promiseops.maturity import FOLDS

EXPERIMENT = "promiseops-model-selection-audit"
# Fixed before any fit. Changes are relative to merged develop, not old model bytes.
VARIANTS = {
    "baseline": ("baseline", False, {}),
    "merged_lr": ("logistic_regression", False, {"model__C": 1.0}),
    "lr_C005": ("logistic_regression", False, {"model__C": .05}),
    "lr_C02": ("logistic_regression", False, {"model__C": .2}),
    "lr_C5": ("logistic_regression", False, {"model__C": 5.0}),
    "lr_no_target_encoding": ("logistic_regression", False, {"model__C": 1.0, "preprocess__target_enc": "drop"}),
    "lr_balanced": ("logistic_regression", False, {"model__C": 1.0, "model__class_weight": "balanced"}),
    "history_lr_C005": ("logistic_regression", True, {"model__C": .05}),
    "history_lr_C02": ("logistic_regression", True, {"model__C": .2}),
    "merged_hgb": ("hist_gradient_boosting", False, {}),
    "hgb_shallow": ("hist_gradient_boosting", False,
                    {"model__max_leaf_nodes": 7, "model__min_samples_leaf": 200, "model__l2_regularization": 20.0}),
}


def budget_curve(ids, y, risk):
    """Capacity sensitivity; 10% remains the primary contract budget."""
    ids, y, risk = np.asarray(ids, dtype=str), np.asarray(y, dtype=bool), np.asarray(risk, dtype=float)
    ranking = np.lexsort((ids, -risk))
    if not len(y) or not y.any():
        raise ValueError("need a nonempty cohort with positive labels")
    results = {}
    for fraction in (.05, .10, .20):
        k = max(1, int(np.ceil(fraction * len(y))))
        found = int(y[ranking[:k]].sum())
        results[str(fraction)] = {"k": k, "late_found": found, "false_positives": k - found,
                                  "late_missed": int(y.sum()) - found, "recall": found / int(y.sum()),
                                  "precision": found / k, "lift_over_random": (found / int(y.sum())) / (k / len(y))}
    return results


def fit_variant(name, x, y):
    approach, history, settings = VARIANTS[name]
    model = approaches.build(approach, with_history=history).set_params(**settings)
    return model.fit(x, y.to_numpy())


def study(connection, progress):
    folds = []
    for fold, train_end, validation_end, as_of in FOLDS:
        cutoffs = cohorts.Cutoffs(train_end=train_end, validation_end=validation_end, as_of=as_of)
        labels = cohorts.load_labels(connection, as_of=as_of)
        labels = labels[labels.approved_at <= cutoffs.validation_end].copy()
        split = cohorts.split(labels, cutoffs)
        for kind, ids in (("train", split.train), ("validation", split.validation)):
            cohorts.require_sufficient(kind, labels, ids)
        base = features.load_features(connection, split.train + split.validation, as_of=as_of)
        extended = features.load_features_with_history(connection, split.train + split.validation,
                                                       as_of=as_of, freeze_at=train_end)
        y = labels.set_index("order_id").late
        ty, vy = y.loc[list(split.train)].astype(bool), y.loc[list(split.validation)].astype(bool)
        scores, results = {}, []
        for name, (_, history, _) in VARIANTS.items():
            progress(fold, name, {"status": "started"})
            table = extended if history else base
            tx, vx = table.loc[list(split.train)], table.loc[list(split.validation)]
            started = time.perf_counter()
            fitted = fit_variant(name, tx, ty)
            risk = approaches.risk(fitted, vx)
            value = metrics.evaluate(list(vx.index), vy.tolist(), risk.tolist())
            scores[name] = value
            gate = gates.apply_gates(value, scores.get("merged_lr", value))
            # Explicitly distinguish cross-fitted training target encoding from serving transform.
            result = {"variant": name, "history": history, "metrics": value.model_dump(),
                      "gate_vs_merged_lr": {"decision": gate.decision, "reasons": gate.reasons},
                      "budget_curve": budget_curve(vx.index, vy, risk),
                      "mean_risk": float(risk.mean()), "observed_prevalence": float(vy.mean()),
                      "duration_seconds": time.perf_counter() - started,
                      "hyperparameters": approaches.hyperparameters(fitted)}
            estimator = fitted.named_steps["model"]
            if hasattr(estimator, "n_iter_"):
                result["iterations"] = np.asarray(estimator.n_iter_).tolist()
                result["iteration_limit"] = estimator.max_iter
            results.append(result)
            progress(fold, name, result)
        folds.append({"fold": fold, "cutoffs": cutoffs.model_dump(mode="json"),
                      "dataset_identity": data.dataset_identity(connection, as_of=as_of),
                      "train": cohorts.describe(labels, split.train), "validation": cohorts.describe(labels, split.validation),
                      "results": results})
    return {"dataset_kind": "real_olist", "folds": folds, "test_used": False, "registry_changed": False,
            "software_versions": bundle.collect_software_versions(),
            "limitations": ["Previously inspected, overlapping validation folds; exploratory selection optimism remains.",
                            "History mode is experimental; production release integration is incomplete.",
                            "Random cross-fit target encoding is not a point-in-time historical risk feature."]}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    client, run_id = None, None
    try:
        commit = tracking.source_commit_from_env(os.environ)
        if commit is None:
            raise ValueError("CI_COMMIT_SHA required")
        plan = {"base_commit": commit, "variants": VARIANTS, "folds": FOLDS, "test_used": False,
                "seed": 0, "primary_budget": .1, "history_policy": "frozen at training cutoff",
                "source_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                                  for p in sorted(Path(__file__).parent.glob("*.py"))}}
        client = tracking.create_client(tracking.TrackingConfig.from_env(os.environ))
        exp = tracking.ensure_experiment(client, EXPERIMENT)
        run_id = client.create_run(exp, tags=tracking.run_tags("selection-audit", commit)).info.run_id
        client.log_text(run_id, json.dumps(plan, indent=2), "plan-before-fit.json")

        def progress(fold, name, result):
            client.log_text(run_id, json.dumps(result), f"checks/{fold}.{name}-{'started' if 'status' in result else 'finished'}.json")
            print(json.dumps({"fold": fold, "variant": name, "metrics": result.get("metrics", "started")}), flush=True)

        with db.connect() as connection:
            connection.execute("SET default_transaction_read_only=on")
            report = study(connection, progress)
        report = json.loads(json.dumps({**report, "plan": plan, "mlflow_run_id": run_id}))
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
        values = {f"{f['fold']}.{r['variant']}.{k}": v for f in report["folds"]
                  for r in f["results"] for k, v in r["metrics"].items()}
        experiment_log.log_report(client, experiment=EXPERIMENT, kind="selection-audit", source_commit=commit,
                                 report=report, params={"test_used": "false", "variant_count": str(len(VARIANTS))},
                                 metrics=values, run_id=run_id)
        print(json.dumps({"status": "ok", "mlflow_run_id": run_id}))
        return 0
    # CLI boundary must sanitize third-party failures and return a nonzero exit code.
    except Exception as error:  # noqa: BLE001
        if client is not None and run_id is not None:
            tracking.close_failed_run(client, run_id, error)
        print(tracking.redact_error(error), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
