"""Shared release-aware feature materialization for serving, evaluation and champion scoring."""

from promiseops import data, features


def release_features(connection, order_ids, *, as_of, manifest, lineage):
    names = tuple(manifest.feature_names)
    if names == features.FEATURE_NAMES:
        return data.build_features(connection, order_ids, as_of=as_of)
    if names != features.EXTENDED_FEATURE_NAMES or lineage is None:
        raise ValueError("Unsupported release feature schema or missing history lineage")
    if lineage.history_policy != "frozen-at-train-end-v1":
        raise ValueError("Unsupported release history policy")
    if data.dataset_identity(connection, as_of=lineage.as_of) != lineage.dataset_identity:
        raise ValueError("Frozen history source does not match release lineage")
    return features.load_features_with_history(
        connection, order_ids, as_of=as_of, freeze_at=lineage.train_end, history_as_of=lineage.as_of)
