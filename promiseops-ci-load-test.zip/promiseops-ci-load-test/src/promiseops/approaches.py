"""The model approaches: each is ONE scikit-learn Pipeline (preprocessing + estimator).

The contract requires "one fitted preprocessing pipeline" for training and serving: the whole
Pipeline is what goes into ``model.joblib``, and the API only calls
``predict_proba(build_features(...))``. Nothing is preprocessed outside it.

Supports both the 15-column base contract (``FEATURE_NAMES``) and the 32-column extended contract
with point-in-time historical seller/route aggregates (``EXTENDED_FEATURE_NAMES``).
"""

from collections.abc import Callable

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import (
    FunctionTransformer,
    OneHotEncoder,
    OrdinalEncoder,
    SplineTransformer,
    StandardScaler,
    TargetEncoder,
)

from promiseops.features import CATEGORICAL_FEATURES, EXTENDED_FEATURE_NAMES, FEATURE_NAMES, NUMERIC_FEATURES
from promiseops.history_features import HISTORY_NAMES

BASELINE = "baseline"
CANDIDATE_APPROACHES: tuple[str, ...] = ("logistic_regression", "hist_gradient_boosting")
RANDOM_STATE = 0

ENGINEERED_NUMERIC: tuple[str, ...] = (
    "log_price",
    "log_freight",
    "log_weight",
    "log_promise_days",
    "price_per_item",
    "weight_per_item",
    "freight_to_price",
    "freight_per_kg",
    "payment_to_price",
    "installment_value",
    "promise_x_interstate",
    "is_weekend_approval",
    "is_night_approval",
)
ENGINEERED_CATEGORICAL: tuple[str, ...] = (
    "shipping_route",
    "state_category",
)
ALL_NUMERIC: tuple[str, ...] = NUMERIC_FEATURES + ENGINEERED_NUMERIC
ALL_NUMERIC_WITH_HISTORY: tuple[str, ...] = ALL_NUMERIC + HISTORY_NAMES
ALL_CATEGORICAL: tuple[str, ...] = CATEGORICAL_FEATURES + ENGINEERED_CATEGORICAL


def engineer_features(table: pd.DataFrame) -> pd.DataFrame:
    """Stateless, per-order approval-time feature expansion; never reads IDs, outcomes, or other rows."""
    out = table.copy()
    items = out["item_count"].clip(lower=1.0)
    installments = out["max_installments"].clip(lower=1.0)

    out["log_price"] = np.log1p(out["total_price"].clip(lower=0.0))
    out["log_freight"] = np.log1p(out["total_freight"].clip(lower=0.0))
    out["log_weight"] = np.log1p(out["total_weight_g"].clip(lower=0.0))
    out["log_promise_days"] = np.log1p(out["promise_days"].clip(lower=0.0))

    out["price_per_item"] = out["total_price"] / items
    out["weight_per_item"] = out["total_weight_g"] / items
    out["freight_to_price"] = out["total_freight"] / (1.0 + out["total_price"].clip(lower=0.0))
    out["freight_per_kg"] = out["total_freight"] / (1.0 + out["total_weight_g"].clip(lower=0.0) / 1000.0)
    out["payment_to_price"] = out["payment_total"] / (1.0 + out["total_price"].clip(lower=0.0))
    out["installment_value"] = out["payment_total"] / installments

    out["promise_x_interstate"] = out["promise_days"] * out["interstate_fraction"]
    out["is_weekend_approval"] = (out["approval_weekday"] >= 5.0).astype("float64")
    out["is_night_approval"] = ((out["approval_hour"] < 6.0) | (out["approval_hour"] >= 22.0)).astype("float64")

    out["shipping_route"] = out["primary_seller_state"].astype(str) + ">" + out["customer_state"].astype(str)
    out["state_category"] = out["primary_seller_state"].astype(str) + ":" + out["primary_category"].astype(str)
    return out


def _feature_step() -> FunctionTransformer:
    # Canonical module import ensures joblib artifacts load cleanly outside __main__.
    from promiseops.approaches import engineer_features as transform

    return FunctionTransformer(transform, validate=False)


def _baseline(*, with_history: bool = False) -> Pipeline:
    return Pipeline([("model", DummyClassifier(strategy="prior"))])


def _logistic_regression(*, with_history: bool = False) -> Pipeline:
    numeric_cols = list(ALL_NUMERIC_WITH_HISTORY if with_history else ALL_NUMERIC)
    transformers: list[tuple[str, object, list[str]]] = [
        ("numeric", StandardScaler(), numeric_cols),
        (
            "promise_spline",
            SplineTransformer(n_knots=5, degree=3, extrapolation="constant"),
            ["promise_days"],
        ),
    ]
    if not with_history:
        transformers.append(
            (
                "target_enc",
                TargetEncoder(
                    smooth=20.0,
                    cv=StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE),
                ),
                list(ALL_CATEGORICAL),
            )
        )
    transformers.append(
        (
            "categorical",
            OneHotEncoder(handle_unknown="infrequent_if_exist", min_frequency=20, sparse_output=False),
            list(ALL_CATEGORICAL),
        )
    )
    preprocess = ColumnTransformer(transformers, verbose_feature_names_out=False)
    # Both historical validation windows favor stronger regularization for the base schema.
    # Evidence: docs/model/13-selection-and-cutoff-audit.fa.md (no final-test tuning).
    c_value = 0.05
    model = LogisticRegression(C=c_value, max_iter=2000, random_state=RANDOM_STATE)
    return Pipeline([("engineer", _feature_step()), ("preprocess", preprocess), ("model", model)])


def _hist_gradient_boosting(*, with_history: bool = False) -> Pipeline:
    numeric_cols = list(ALL_NUMERIC_WITH_HISTORY if with_history else ALL_NUMERIC)
    preprocess = ColumnTransformer(
        [
            ("numeric", "passthrough", numeric_cols),
            (
                "target_enc",
                TargetEncoder(
                    smooth=20.0,
                    cv=StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE),
                ),
                list(ALL_CATEGORICAL),
            ),
            (
                "categorical",
                OrdinalEncoder(
                    handle_unknown="use_encoded_value",
                    unknown_value=-1,
                    encoded_missing_value=-1,
                    max_categories=200,
                ),
                list(CATEGORICAL_FEATURES),
            ),
        ],
        verbose_feature_names_out=False,
    )
    numeric_width = len(numeric_cols) + len(ALL_CATEGORICAL)
    categorical_mask = [False] * numeric_width + [True] * len(CATEGORICAL_FEATURES)
    model = HistGradientBoostingClassifier(
        learning_rate=0.05,
        max_iter=350,
        max_leaf_nodes=15,
        min_samples_leaf=120,
        l2_regularization=10.0,
        categorical_features=categorical_mask,
        early_stopping=False,
        random_state=RANDOM_STATE,
    )
    return Pipeline([("engineer", _feature_step()), ("preprocess", preprocess), ("model", model)])


_FACTORIES: dict[str, Callable[..., Pipeline]] = {
    BASELINE: _baseline,
    "logistic_regression": _logistic_regression,
    "hist_gradient_boosting": _hist_gradient_boosting,
}


def build(approach: str, *, with_history: bool = False) -> Pipeline:
    """A new, unfitted Pipeline for ``approach``."""
    try:
        return _FACTORIES[approach](with_history=with_history)
    except KeyError:
        raise ValueError(f"unknown approach {approach!r}; known: {sorted(_FACTORIES)}") from None


def fit(approach: str, features: pd.DataFrame, late: pd.Series) -> Pipeline:
    """Fit ``approach`` on either ``FEATURE_NAMES`` or ``EXTENDED_FEATURE_NAMES`` and boolean labels."""
    cols = list(features.columns)
    if cols == list(FEATURE_NAMES):
        with_history = False
    elif cols == list(EXTENDED_FEATURE_NAMES):
        with_history = True
    else:
        raise ValueError("features must have exactly the contract columns, in order")
    if len(features) != len(late):
        raise ValueError("features and labels must have the same number of rows")
    return build(approach, with_history=with_history).fit(features, late.astype(bool).to_numpy())


def hyperparameters(model: Pipeline) -> dict[str, str]:
    """The fitted Pipeline's settings as flat strings, for MLflow params."""
    flat = {}
    for key, value in model.get_params(deep=True).items():
        if key == "steps" or "__" not in key:
            continue
        if value is None or isinstance(value, (bool, int, float, str)):
            flat[key.replace("__", ".")] = str(value)
        elif isinstance(value, (list, tuple)) and all(isinstance(v, (bool, int, float, str)) for v in value):
            flat[key.replace("__", ".")] = ",".join(map(str, value))
        elif hasattr(value, "split") and hasattr(value, "get_n_splits"):
            prefix = key.replace("__", ".")
            flat[f"{prefix}.class"] = type(value).__name__
            for attribute in ("n_splits", "shuffle", "random_state"):
                if hasattr(value, attribute):
                    flat[f"{prefix}.{attribute}"] = str(getattr(value, attribute))
    return dict(sorted(flat.items()))


def risk(model, features: pd.DataFrame) -> pd.Series:
    """Probability of being late for each row (index kept), from any model with predict_proba."""
    probabilities = np.asarray(model.predict_proba(features), dtype=float)
    return pd.Series(probabilities[:, 1], index=features.index, name="risk")
