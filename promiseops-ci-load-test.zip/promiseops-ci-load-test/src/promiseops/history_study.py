"""Predeclared historical-signal experiment, with frozen and rolling knowledge controls."""

import argparse
import hashlib
import json
import os
import sys
import tempfile
from pathlib import Path

import joblib
import numpy as np

from promiseops import bundle, cohorts, data, db, experiment_log, features, gates, tracking
from promiseops.feature_study import build_engineered, engineer, evaluate
from promiseops.history_features import HISTORY_NAMES, build_history, load_order_groups
from promiseops.maturity import FOLDS

EXPERIMENT = "promiseops-history-study"


def transform(table):
    return engineer(table[list(features.FEATURE_NAMES)]).join(table[list(HISTORY_NAMES)])


def build_model(approach, *, rates_only=False):
    from promiseops.history_study import transform as canonical_transform

    model = build_engineered(approach)
    model.named_steps["engineer"].set_params(func=canonical_transform)
    preprocess = model.named_steps["preprocess"]
    selected = [name for name in HISTORY_NAMES if not rates_only or name.endswith("rate")]
    preprocess.transformers[0][2].extend(selected)
    if approach == "hist_gradient_boosting":
        numeric = len(preprocess.transformers[0][2])
        categorical = len(preprocess.transformers[1][2])
        model.named_steps["model"].set_params(categorical_features=[False] * numeric + [True] * categorical)
    return model


def study(connection, progress, save, *, rates_only=False):
    reports = []
    for name, t, v, a in FOLDS:
        cut = cohorts.Cutoffs(train_end=t, validation_end=v, as_of=a)
        labels = cohorts.load_labels(connection, as_of=a)
        labels = labels[labels.approved_at <= cut.validation_end].copy()
        split = cohorts.split(labels, cut)
        for kind, ids in (("train", split.train), ("validation", split.validation)):
            cohorts.require_sufficient(kind, labels, ids)
        groups = load_order_groups(connection, labels.order_id)
        base = features.load_features(connection, split.train + split.validation, as_of=a)
        y = labels.set_index("order_id").late
        tx, vx = base.loc[list(split.train)], base.loc[list(split.validation)]
        ty, vy = y.loc[tx.index].astype(bool), y.loc[vx.index].astype(bool)
        progress(name + ".reference", {"status": "started"})
        reference = build_engineered("logistic_regression").fit(tx, ty.to_numpy())
        reference_scores = evaluate(reference, vx, vy)
        results = []
        for mode in ("frozen", "rolling"):
            history = build_history(groups, labels, freeze_at=cut.train_end if mode == "frozen" else None)
            # Future labels must not change ANY training feature.
            past_only = labels[labels.label_available_at < cut.train_end]
            check = build_history(groups, past_only).loc[list(split.train)]
            np.testing.assert_array_equal(check.to_numpy(), history.loc[list(split.train)].to_numpy())
            x = base.join(history)
            for approach in ("logistic_regression", "hist_gradient_boosting"):
                key = f"{name}.{mode}.{approach}"
                progress(key, {"status": "started"})
                model = build_model(approach, rates_only=rates_only).fit(x.loc[list(split.train)], ty.to_numpy())
                validation_x = x.loc[list(split.validation)]
                scores = evaluate(model, validation_x, vy)
                gate = gates.apply_gates(scores, reference_scores)
                result = {"mode": mode, "approach": approach, "validation": scores.model_dump(),
                          "gate_vs_engineered_lr": {"decision": gate.decision, "reasons": gate.reasons},
                          "training_features_invariant_to_future_labels": True}
                results.append(result)
                save(key, model, validation_x, vy)
                progress(key, result)
        reports.append({"name": name, "cutoffs": cut.model_dump(mode="json"),
                        "dataset_identity": data.dataset_identity(connection, as_of=a),
                        "train": cohorts.describe(labels, split.train), "validation": cohorts.describe(labels, split.validation),
                        "reference": reference_scores.model_dump(), "results": results})
    return {"folds": reports, "dataset_kind": "real_olist", "test_used": False, "registry_changed": False,
            "software_versions": bundle.collect_software_versions(),
            "limitations": ["Rolling validation uses earlier available validation outcomes as operational state, never to refit the model.",
                            "Historical replay uses outcome knowledge times; batch release is a separate clock per CONTRACTS.",
                            "Repeated validation use and overlapping folds do not establish unbiased final-test performance."]}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--rates-only", action="store_true", help="Ablate count/workload inputs that can encode time")
    args = parser.parse_args(argv)
    client, run_id = None, None
    try:
        commit = tracking.source_commit_from_env(os.environ)
        if commit is None:
            raise ValueError("CI_COMMIT_SHA required")
        plan = {"base_commit": commit, "source_sha256": {
            p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(Path(__file__).parent.glob("*.py"))},
            "folds": FOLDS, "seed": 0, "smoothing": 20, "cold_start_prior": 0.05,
            "recent_days": 30, "workload_days": 7, "modes": ["frozen", "rolling"],
            "models": ["logistic_regression", "hist_gradient_boosting"], "test_used": False,
            "event_boundary": "label_available_at strictly less than approval; no future label means",
            "history_columns": [name for name in HISTORY_NAMES if not args.rates_only or name.endswith("rate")],
            "rates_only_ablation": args.rates_only,
            "selection": "report all variants; no automatic registration"}
        client = tracking.create_client(tracking.TrackingConfig.from_env(os.environ))
        exp = tracking.ensure_experiment(client, EXPERIMENT)
        run_id = client.create_run(exp, tags=tracking.run_tags("history-study", commit)).info.run_id
        client.log_text(run_id, json.dumps(plan, indent=2), "plan-before-fit.json")

        def progress(key, result):
            client.log_text(run_id, json.dumps(result), f"checks/{key}-{'started' if 'status' in result else 'finished'}.json")
            print(json.dumps({"check": key, **result}), flush=True)

        def save(key, model, x, y):
            with tempfile.TemporaryDirectory() as folder:
                path = Path(folder) / f"{key}.joblib"
                joblib.dump(model, path)
                client.log_artifact(run_id, str(path), "experimental-pipelines")
                restored = joblib.load(client.download_artifacts(run_id, f"experimental-pipelines/{path.name}"))
                np.testing.assert_array_equal(model.predict_proba(x.iloc[:10]), restored.predict_proba(x.iloc[:10]))
                # Prediction vectors permit later paired uncertainty checks without refitting or test use.
                evidence = x.copy()
                evidence["late"] = y
                evidence["risk"] = model.predict_proba(x)[:, 1]
                evidence.to_parquet(Path(folder) / f"{key}.parquet")
                client.log_artifact(run_id, str(Path(folder) / f"{key}.parquet"), "validation-evidence")

        with db.connect() as connection:
            connection.execute("SET default_transaction_read_only=on")
            report = study(connection, progress, save, rates_only=args.rates_only)
        report = json.loads(json.dumps({**report, "plan": plan, "mlflow_run_id": run_id}))
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
        values = {f"{f['name']}.{r['mode']}.{r['approach']}.{k}": value for f in report["folds"]
                  for r in f["results"] for k, value in r["validation"].items()}
        experiment_log.log_report(client, experiment=EXPERIMENT, kind="history-study", source_commit=commit,
                                 report=report, params={"test_used": "false"}, metrics=values, run_id=run_id)
        print(json.dumps({"status": "ok", "mlflow_run_id": run_id}))
        return 0
    # CLI boundary must sanitize third-party failures and return a nonzero exit code.
    except Exception as error:  # noqa: BLE001
        if client is not None and run_id is not None:
            tracking.close_failed_run(client, run_id, error)
        print(tracking.redact_error(error), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
