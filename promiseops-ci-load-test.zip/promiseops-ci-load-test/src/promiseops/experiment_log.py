"""Auditable diagnostic and software-test reports, kept apart from training/registry runs."""

import json
import tempfile
import time
from pathlib import Path
from typing import Any

from promiseops import bundle, tracking


def log_report(client: Any, *, experiment: str, kind: str, source_commit: str,
               report: dict, params: dict[str, str], metrics: dict[str, float],
               artifacts: dict[str, str] | None = None, successful: bool = True,
               run_id: str | None = None) -> str:
    """Persist a report and its evidence, verify read-back, and close with an honest status."""
    from mlflow.entities import Metric, Param

    versions = bundle.collect_software_versions()
    if run_id is None:
        experiment_id = tracking.ensure_experiment(client, experiment)
        run_id = client.create_run(experiment_id, tags=tracking.run_tags(kind, source_commit),
                                   run_name=f"{kind}-{source_commit[:8]}").info.run_id
    try:
        values = {f"software.{name}": value for name, value in versions.items()} | params
        client.log_batch(run_id, params=[Param(key, value) for key, value in values.items()],
                         metrics=[Metric(key, float(value), int(time.time() * 1000), 0)
                                  for key, value in metrics.items()])
        client.log_text(run_id, json.dumps(report, indent=2, sort_keys=True), "report.json")
        for name, content in (artifacts or {}).items():
            # Test failures and third-party tracebacks can contain credentialed URLs.
            client.log_text(run_id, tracking.redact_error(RuntimeError(content)), name)
        with tempfile.TemporaryDirectory() as folder:
            saved = Path(client.download_artifacts(run_id, "report.json", folder))
            if json.loads(saved.read_text(encoding="utf-8")) != report:
                raise ValueError("MLflow report read-back differs from the logged report")
        client.set_terminated(run_id, "FINISHED" if successful else "FAILED")
    except BaseException as error:
        tracking.close_failed_run(client, run_id, error)
        raise
    return run_id
