"""Investigate the frozen model on TRAIN/VALIDATION only; never tune on the final test.

python -m promiseops.diagnostics --bundle PATH --output report.json
Logs an auditable real-data diagnostic run, without registering/deploying any model.
"""

import argparse
import json
import math
import os
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

from promiseops import bundle, experiment_log, metrics, tracking

EXPERIMENT = "promiseops-diagnostics"


def manual_metric_check(order_ids, late, probability) -> dict:
    """Independent top-budget calculation to detect metric/alignment mistakes."""
    ids = np.asarray(order_ids, dtype=str)
    y = np.asarray(late, dtype=bool)
    risk = np.asarray(probability, dtype=float)
    # Validate through the contract implementation, then independently calculate the core values.
    measured = metrics.evaluate(ids.tolist(), y.tolist(), risk.tolist())
    k = max(1, (len(ids) + 9) // 10)
    ranked = np.lexsort((ids, -risk))[:k]
    positives = int(y.sum())
    found = int(y[ranked].sum())
    recall, precision = found / positives, found / k
    brier = float(np.mean((risk - y.astype(float)) ** 2))
    return {"n": len(ids), "k": k, "late": positives, "late_in_top_k": found,
            "recall_manual": recall, "precision_manual": precision, "brier_manual": brier,
            "matches": bool(np.allclose([recall, precision, brier],
                                        [measured.recall_at_10, measured.precision_at_10, measured.brier],
                                        rtol=0, atol=1e-12))}


def bootstrap_recall(order_ids, late, probability, *, repeats=300, seed=42) -> dict:
    """Paired bootstrap of validation orders; uncertainty estimate, not model selection."""
    if repeats < 1:
        raise ValueError("bootstrap repeats must be positive")
    manual_metric_check(order_ids, late, probability)
    ids, y, risk = np.asarray(order_ids, dtype=str), np.asarray(late, dtype=bool), np.asarray(probability)
    rng = np.random.default_rng(seed)
    k, values = max(1, math.ceil(len(ids) / 10)), []
    for _ in range(repeats):
        sampled = rng.integers(0, len(ids), len(ids))
        positives = int(y[sampled].sum())
        if not positives:
            continue
        # Duplicated sampled IDs are tied by stable sample position after ID/risk ordering.
        ranking = np.lexsort((np.arange(len(ids)), ids[sampled], -risk[sampled]))[:k]
        values.append(float(y[sampled[ranking]].sum() / positives))
    if not values:
        raise ValueError("bootstrap produced no samples with positive labels")
    low, high = np.quantile(values, [0.025, 0.975])
    return {"seed": seed, "requested_repeats": repeats, "valid_repeats": len(values),
            "recall_95_percentile_interval": [float(low), float(high)],
            "scope": "conditional uncertainty on validation orders; not temporal generalization"}


def split_audit(labels: pd.DataFrame, train_ids, validation_ids, cutoffs) -> dict:
    """Audit cohort membership and report label maturity without relaxing the cutoff."""
    indexed = labels.set_index("order_id")
    train, validation = indexed.loc[list(train_ids)], indexed.loc[list(validation_ids)]
    pool = labels[labels["approved_at"] <= cutoffs.train_end]
    known_at_train = pool["late"].notna() & (pool["label_available_at"] <= cutoffs.train_end)
    known_later = pool["late"].notna() & (pool["label_available_at"] <= cutoffs.as_of)
    checks = {
        "unique_source_order_ids": not labels["order_id"].duplicated().any(),
        "disjoint_train_validation": not bool(set(train_ids) & set(validation_ids)),
        "train_approval_cutoff": bool((train["approved_at"] <= cutoffs.train_end).all()),
        "train_label_cutoff": bool((train["label_available_at"] <= cutoffs.train_end).all()),
        "validation_approval_window": bool(((validation["approved_at"] > cutoffs.train_end)
                                              & (validation["approved_at"] <= cutoffs.validation_end)).all()),
        "validation_label_cutoff": bool((validation["label_available_at"] <= cutoffs.as_of).all()),
        "all_selected_labels_known": bool(train["late"].notna().all() and validation["late"].notna().all()),
    }
    def prevalence(rows):
        return float(rows["late"].astype(bool).mean()) if len(rows) else None

    monthly = []
    for month, rows in pool.groupby(pool["approved_at"].dt.strftime("%Y-%m")):
        eligible = rows["late"].notna() & (rows["label_available_at"] <= cutoffs.train_end)
        later = rows["late"].notna() & (rows["label_available_at"] <= cutoffs.as_of)
        monthly.append({"month": month, "approved": len(rows), "eligible_at_train_end": int(eligible.sum()),
                        "known_by_diagnostic_as_of": int(later.sum()),
                        "train_eligible_prevalence": prevalence(rows[eligible]),
                        "later_known_prevalence": prevalence(rows[later])})
    return {"split_method": "chronological", "checks": checks,
            "training_approved_orders": len(pool), "training_eligible_orders": int(known_at_train.sum()),
            "training_labels_not_known_at_cutoff": int((~known_at_train).sum()),
            "training_eligible_prevalence": prevalence(pool[known_at_train]),
            "training_later_known_prevalence": prevalence(pool[known_later]),
            "later_known_scope": "descriptive only; these later labels are never used to fit",
            "training_months": monthly}


def analyze(connection, bundle_path: Path, *, seeds=(0, 7, 42), progress=None) -> dict:
    from promiseops import approaches, cohorts, data, features, inference

    loaded = bundle.read_bundle(bundle_path)
    lineage = loaded.lineage
    if lineage is None:
        raise ValueError("diagnostics require a recorded frozen model")
    identity = data.dataset_identity(connection, as_of=lineage.as_of)
    if identity != lineage.dataset_identity:
        raise ValueError("diagnostic dataset differs from the frozen training snapshot")
    cutoffs = cohorts.Cutoffs(train_end=lineage.train_end, validation_end=lineage.validation_end, as_of=lineage.as_of)
    labels = cohorts.load_labels(connection, as_of=cutoffs.as_of)
    labels = labels[labels["approved_at"] <= cutoffs.validation_end].copy()
    split = cohorts.split(labels, cutoffs)
    cohorts.require_sufficient("train", labels, split.train)
    cohorts.require_sufficient("validation", labels, split.validation)
    table = inference.release_features(connection, split.train + split.validation, as_of=cutoffs.as_of,
                                       manifest=loaded.manifest, lineage=lineage)
    y = labels.set_index("order_id")["late"]
    train_x, validation_x = table.loc[list(split.train)], table.loc[list(split.validation)]
    train_y, validation_y = y.loc[train_x.index].astype(bool), y.loc[validation_x.index].astype(bool)
    frozen_risk = approaches.risk(loaded.model, validation_x)
    frozen = metrics.evaluate(list(validation_x.index), validation_y.tolist(), frozen_risk.tolist())
    audit = split_audit(labels, split.train, split.validation, cutoffs)
    audit["checks"]["recorded_validation_cohort"] = cohorts.cohort_sha256(split.validation) == lineage.validation_cohort_sha256
    audit["checks"]["recorded_validation_metrics"] = all(
        abs(float(value) - float(lineage.validation_metrics.model_dump()[key])) <= 1e-12
        for key, value in frozen.model_dump().items())
    audit["checks"]["feature_schema"] = list(table.columns) == list(loaded.manifest.feature_names)
    # Independently compute target dates in SQL to catch Python timezone/label mistakes.
    rows = connection.execute("""SELECT o.order_id,
        (y.delivered_at AT TIME ZONE 'America/Sao_Paulo')::date > o.promised_date AS late
        FROM promiseops.orders o JOIN promiseops.outcomes y USING(order_id)
        WHERE o.order_id = ANY(%s)""", (list(split.train + split.validation),)).fetchall()
    sql_labels = pd.Series(dict(rows)).reindex(list(split.train + split.validation))
    audit["checks"]["labels_match_independent_sql"] = bool(
        (sql_labels == y.reindex(sql_labels.index)).all())
    seed_results = []
    for name in approaches.CANDIDATE_APPROACHES:
        for seed in seeds:
            if progress:
                progress({"event": "started", "approach": name, "seed": seed})
            started = time.perf_counter()
            pipeline = approaches.build(
                name, with_history=tuple(table.columns) == features.EXTENDED_FEATURE_NAMES
            ).set_params(model__random_state=seed)
            pipeline.fit(train_x, train_y.to_numpy())
            risk = approaches.risk(pipeline, validation_x)
            values = metrics.evaluate(list(validation_x.index), validation_y.tolist(), risk.tolist())
            result = {"approach": name, "seed": seed, "validation": values.model_dump(),
                      "hyperparameters": approaches.hyperparameters(pipeline),
                      "duration_seconds": time.perf_counter() - started}
            seed_results.append(result)
            if progress:
                progress({"event": "finished", **result})
    return {"report_schema_version": "1.0", "dataset_kind": "real_olist", "phase": "train_validation_diagnostics",
            "model_version": loaded.manifest.model_version, "artifact_sha256": loaded.manifest.artifact_sha256,
            "training_run_id": lineage.mlflow_run_id, "training_source_commit": loaded.manifest.source_commit,
            "dataset_identity": identity, "software_versions": bundle.collect_software_versions(),
            "cutoffs": {key: value.isoformat() for key, value in cutoffs.model_dump().items()},
            "test_used_for_diagnostics": False, "registry_or_alias_changed": False,
            "split_audit": audit, "train": cohorts.describe(labels, split.train),
            "validation": cohorts.describe(labels, split.validation), "frozen_validation": frozen.model_dump(),
            "metric_check": manual_metric_check(validation_x.index, validation_y, frozen_risk),
            "validation_uncertainty": bootstrap_recall(validation_x.index, validation_y, frozen_risk),
            "seed_results": seed_results,
            "seed_policy": "all seeds reported; no best-seed selection, registration or tuning"}


def main(argv=None) -> int:
    from promiseops import db

    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--bundle", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    client, run_id = None, None
    try:
        commit = tracking.source_commit_from_env(os.environ)
        if commit is None:
            raise ValueError("CI_COMMIT_SHA is required")
        client = tracking.create_client(tracking.TrackingConfig.from_env(os.environ))
        experiment_id = tracking.ensure_experiment(client, EXPERIMENT)
        run_id = client.create_run(experiment_id, tags=tracking.run_tags("diagnostics", commit),
                                   run_name=f"recall-audit-{commit[:8]}").info.run_id

        def progress(event):
            client.set_tag(run_id, "promiseops.current_check", f"{event['approach']}:{event['seed']}:{event['event']}")
            client.log_text(run_id, json.dumps(event, indent=2),
                            f"checks/{event['approach']}-seed-{event['seed']}-{event['event']}.json")
            print(json.dumps({key: event[key] for key in ("event", "approach", "seed")}), file=sys.stderr)

        with db.connect() as connection:
            report = analyze(connection, args.bundle, progress=progress)
        report["diagnostic_source_commit"] = commit
        args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
        passed = all(report["split_audit"]["checks"].values()) and report["metric_check"]["matches"]
        values = {f"frozen_validation.{key}": value for key, value in report["frozen_validation"].items()}
        for result in report["seed_results"]:
            values.update({f"{result['approach']}.seed_{result['seed']}.{key}": value
                           for key, value in result["validation"].items()})
        run_id = experiment_log.log_report(
            client, experiment=EXPERIMENT, kind="diagnostics", source_commit=commit, report=report,
            params={"dataset_kind": report["dataset_kind"], "phase": report["phase"],
                    "model_version": report["model_version"], "dataset_identity": report["dataset_identity"],
                    "seeds": "0,7,42", "test_used": "false"}, metrics=values, successful=passed, run_id=run_id)
        print(json.dumps({"status": "ok" if passed else "checks_failed", "mlflow_run_id": run_id,
                          "checks": report["split_audit"]["checks"]}))
        return 0 if passed else 1
    # CLI boundary must sanitize third-party failures and return a nonzero exit code.
    except Exception as error:  # noqa: BLE001
        if client is not None and run_id is not None:
            tracking.close_failed_run(client, run_id, error)
        print(json.dumps({"status": "failed", "error": tracking.redact_error(error)}), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
