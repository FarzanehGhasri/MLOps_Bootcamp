"""Maturity-aware monitoring report: drift windows, delayed-label quality, retraining recommendation.

This module is the POLICY (windows, minimum samples, thresholds, decision). The distribution math
(PSI, TVD, reference histograms, data quality) is in promiseops.drift; the contract metrics are in
promiseops.metrics. Each can change without touching the others.

Contract (docs/CONTRACTS.md "Monitoring and retraining"), public reference values as constants:

* drift: >= 100 UNIQUE current orders in a 7-day feature window; numeric -> PSI, categorical -> TVD;
  0.2 is a review threshold. PERSISTENT drift needs two distinct, non-overlapping windows (here:
  the last 7 days and the 7 days before, the same feature drifting in both). Retries / re-scores of
  the same order count once.
* delayed labels: predictions are kept 60 company days; only outcomes available by ``as_of``;
  >= 100 unique mature orders with both classes.
* recommend retraining for: persistent drift WITH sufficient mature outcomes; recall@10% below the
  10% random-review baseline; or degradation versus the recorded validation reference
  (recall < 80% of it, PR-AUC down > 0.05, Brier up > 0.02).
  Insufficient labels suppress automatic retraining (the reason is recorded).

Inputs (no database here; the worker #21 builds them):
* ``predictions``: one row per prediction — ``order_id``, ``predicted_at`` (COMPANY time of the
  prediction, timezone-aware), ``risk_probability``, ``model_version`` and the FEATURE_NAMES columns
  the model saw (promiseops.features).
* ``released_outcomes``: ``order_id``, ``late``, ``label_available_at`` — exactly what
  ``promiseops.cohorts.load_labels(connection, as_of=...)`` returns; unknown labels are <NA>.
* ``reference``: the bundle's ``reference.json`` (promiseops.drift.build_reference at training time).

Walkthrough and reasons (Persian): docs/features/03-monitoring.fa.md
"""

import math
from collections.abc import Iterable
from datetime import datetime, timedelta
from typing import Literal

import pandas as pd
from pydantic import BaseModel, ConfigDict, Field

from promiseops import drift, metrics
from promiseops.bundle import EvaluationMetrics, ValidationReference
from promiseops.contracts import instant
from promiseops.features import FEATURE_NAMES

FEATURE_WINDOW = timedelta(days=7)
MIN_WINDOW_ORDERS = 100
DRIFT_THRESHOLD = 0.2
LABEL_RETENTION = timedelta(days=60)
MIN_MATURE_ORDERS = 100
RANDOM_REVIEW_RECALL = 0.10      # reviewing a random 10% finds ~10% of late orders
RECALL_MIN_SHARE_OF_REFERENCE = 0.80
PR_AUC_MAX_DROP = 0.05
BRIER_MAX_RISE = 0.02
# Not a contract rule — a warning only. Late orders get their label later (delivery is late), so a
# window where many labels are still unknown under-represents late orders and biases the metrics
# (measured on the real feed: 58% known -> late rate 1.2% seen vs 4.7% true). The decision still
# follows the public reference; the warning tells the reviewer how far to trust the numbers
# (project doc part 7: "state the lack of labels in the report").
LABEL_COVERAGE_WARNING = 0.90

PREDICTION_COLUMNS = ("order_id", "predicted_at", "risk_probability", "model_version", *FEATURE_NAMES)
OUTCOME_COLUMNS = ("order_id", "late", "label_available_at")


# ---------------------------------------------------------------------------------------------
# Report documents (JSON; the worker persists the report before any training, per the contract)
# ---------------------------------------------------------------------------------------------
class _Document(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class WindowDrift(_Document):
    start: datetime                                  # exclusive
    end: datetime                                    # inclusive
    unique_orders: int
    sufficient: bool                                 # unique_orders >= MIN_WINDOW_ORDERS
    scores: dict[str, float]                         # feature -> PSI (numeric) or TVD (categorical)
    drifted: list[str]                               # score >= DRIFT_THRESHOLD (only when sufficient)
    data_quality: dict[str, dict[str, float]]        # drift.data_quality: missing / out of range / unseen


class LabelEvaluation(_Document):
    start: datetime
    end: datetime
    model_version: str | None                        # the evaluated version (latest in the window)
    predicted_orders: int                            # unique orders of that version in the window
    mature_orders: int                               # ... whose label was known by as_of
    label_coverage: float                            # mature_orders / predicted_orders (0 when none)
    late: int
    sufficient: bool
    metrics: EvaluationMetrics | None
    reference_metrics: EvaluationMetrics


class MonitoringReport(_Document):
    report_schema_version: Literal["1.0"] = "1.0"
    as_of: datetime
    counts: dict[str, int]                           # received, future_ignored, duplicates_ignored, unique_orders
    windows: list[WindowDrift]                       # [previous, current]
    persistent_drift: bool
    persistent_features: list[str]
    labels: LabelEvaluation
    retrain_recommended: bool
    reasons: list[str] = Field(default_factory=list)


# ---------------------------------------------------------------------------------------------
# The report
# ---------------------------------------------------------------------------------------------
def build_report(predictions: pd.DataFrame, released_outcomes: pd.DataFrame, reference: ValidationReference,
                 *, as_of: datetime | str) -> MonitoringReport:
    """Use unique orders, separate drift/maturity windows, minimum samples and reasons."""
    cutoff = instant(as_of)
    _require(predictions, PREDICTION_COLUMNS, "predictions")
    _require(released_outcomes, OUTCOME_COLUMNS, "released_outcomes")
    if not released_outcomes["order_id"].is_unique:
        raise ValueError("released_outcomes order_id must be unique; labels must not multiply orders")

    received = predictions.copy()
    received["predicted_at"] = pd.to_datetime([instant(v) for v in received["predicted_at"]], utc=True)
    known = received[received["predicted_at"] <= cutoff]            # nothing from after as_of
    unique = first_prediction_per_order(known)

    previous = window_drift(unique, reference, cutoff - 2 * FEATURE_WINDOW, cutoff - FEATURE_WINDOW)
    current = window_drift(unique, reference, cutoff - FEATURE_WINDOW, cutoff)
    persistent = sorted(set(previous.drifted) & set(current.drifted))
    labels = label_evaluation(unique, released_outcomes, reference, cutoff)

    reasons = _drift_reasons(previous, current, persistent)
    triggers = _quality_triggers(labels) if labels.sufficient else []
    if not labels.sufficient:
        reasons.append(f"retraining suppressed: {labels.mature_orders} mature orders ({labels.late} late) in the "
                       f"{LABEL_RETENTION.days}-day label window; need >= {MIN_MATURE_ORDERS} and both classes")
    elif persistent:
        triggers.append(f"persistent drift with sufficient mature outcomes: {', '.join(persistent)}")
    if labels.sufficient and labels.label_coverage < LABEL_COVERAGE_WARNING:
        reasons.append(f"warning: only {labels.label_coverage:.0%} of predicted orders have a known label; late "
                       "orders mature later, so quality metrics are biased towards on-time orders")
    reasons.extend(triggers)

    return MonitoringReport(
        as_of=cutoff,
        counts={"received": len(received), "future_ignored": len(received) - len(known),
                "duplicates_ignored": len(known) - len(unique), "unique_orders": len(unique)},
        windows=[previous, current],
        persistent_drift=bool(persistent),
        persistent_features=persistent,
        labels=labels,
        retrain_recommended=labels.sufficient and bool(triggers),
        reasons=reasons,
    )


def first_prediction_per_order(predictions: pd.DataFrame) -> pd.DataFrame:
    """One row per order: its FIRST prediction (retries and re-scores must not inflate counts)."""
    ordered = predictions.sort_values(["order_id", "predicted_at"], kind="mergesort")
    return ordered.drop_duplicates("order_id", keep="first").reset_index(drop=True)


def window_drift(unique: pd.DataFrame, reference: ValidationReference, start: datetime,
                 end: datetime) -> WindowDrift:
    """Drift and data quality of the unique orders predicted in (start, end]."""
    rows = unique[(unique["predicted_at"] > start) & (unique["predicted_at"] <= end)]
    sufficient = len(rows) >= MIN_WINDOW_ORDERS
    scores = drift.feature_scores(reference, rows)
    drifted = sorted(name for name, score in scores.items() if score >= DRIFT_THRESHOLD) if sufficient else []
    return WindowDrift(start=start, end=end, unique_orders=len(rows), sufficient=sufficient, scores=scores,
                       drifted=drifted, data_quality=drift.data_quality(reference, rows))


def label_evaluation(unique: pd.DataFrame, outcomes: pd.DataFrame, reference: ValidationReference,
                     cutoff: datetime) -> LabelEvaluation:
    """Quality of the latest model on its predictions of the last 60 days whose label is known by cutoff."""
    start = cutoff - LABEL_RETENTION
    window = unique[(unique["predicted_at"] > start) & (unique["predicted_at"] <= cutoff)]
    # Quality belongs to ONE model: the version serving most recently (the one the reference describes).
    version = None
    if len(window):
        version = str(window.sort_values("predicted_at", kind="mergesort")["model_version"].iloc[-1])
        window = window[window["model_version"] == version]
    known = outcomes[outcomes["late"].notna()].copy()
    if not known["late"].isin([False, True]).all():
        raise ValueError("outcomes.late must contain known binary labels (boolean or 0/1)")
    known["label_available_at"] = pd.to_datetime([instant(v) for v in known["label_available_at"]], utc=True)
    known = known[known["label_available_at"] <= cutoff]          # outcome known by as_of only
    mature = window.merge(known[["order_id", "late"]], on="order_id", how="inner", validate="one_to_one")
    late = int(mature["late"].astype(bool).sum()) if len(mature) else 0
    sufficient = len(mature) >= MIN_MATURE_ORDERS and 0 < late < len(mature)
    scored = metrics.evaluate(mature["order_id"].astype(str).tolist(), mature["late"].astype(bool).tolist(),
                              mature["risk_probability"].astype(float).tolist()) if sufficient else None
    coverage = round(len(mature) / len(window), 4) if len(window) else 0.0
    return LabelEvaluation(start=start, end=cutoff, model_version=version, predicted_orders=len(window),
                           mature_orders=len(mature), label_coverage=coverage, late=late, sufficient=sufficient,
                           metrics=scored, reference_metrics=reference.validation_metrics)


def _drift_reasons(previous: WindowDrift, current: WindowDrift, persistent: list[str]) -> list[str]:
    reasons = []
    for name, window in (("previous", previous), ("current", current)):
        if not window.sufficient:
            reasons.append(f"{name} 7-day window: {window.unique_orders} unique orders (< {MIN_WINDOW_ORDERS}), "
                           "drift not assessed")
        elif window.drifted:
            listed = ", ".join(f"{f}={window.scores[f]:.3f}" for f in window.drifted)
            reasons.append(f"{name} 7-day window: drift >= {DRIFT_THRESHOLD} in {listed} "
                           f"({window.unique_orders} orders)")
    if (previous.drifted or current.drifted) and not persistent:
        reasons.append("drift is not persistent (not the same feature in both windows): review only")
    return reasons


def _quality_triggers(labels: LabelEvaluation) -> list[str]:
    live, ref = labels.metrics, labels.reference_metrics
    if live is None:
        return []
    counts = f"(N={live.n}, late={labels.late}, K={live.k})"
    triggers = []
    if live.recall_at_10 < RANDOM_REVIEW_RECALL:
        triggers.append(f"recall@10% {live.recall_at_10:.4f} below the random-review baseline "
                        f"{RANDOM_REVIEW_RECALL} {counts}")
    if live.recall_at_10 < RECALL_MIN_SHARE_OF_REFERENCE * ref.recall_at_10:
        triggers.append(f"recall@10% {live.recall_at_10:.4f} < 80% of reference {ref.recall_at_10:.4f} {counts}")
    if _beyond(ref.pr_auc - live.pr_auc, PR_AUC_MAX_DROP):
        triggers.append(f"PR-AUC {live.pr_auc:.4f} dropped more than {PR_AUC_MAX_DROP} from {ref.pr_auc:.4f} {counts}")
    if _beyond(live.brier - ref.brier, BRIER_MAX_RISE):
        triggers.append(f"Brier {live.brier:.4f} rose more than {BRIER_MAX_RISE} from {ref.brier:.4f} {counts}")
    return triggers


def _beyond(change: float, limit: float) -> bool:
    """``change > limit``, where a change equal to the limit (up to float noise) does not count."""
    return change > limit and not math.isclose(change, limit, abs_tol=1e-12)


def _require(frame: pd.DataFrame, columns: Iterable[str], name: str) -> None:
    missing = [c for c in columns if c not in frame.columns]
    if missing:
        raise ValueError(f"{name} is missing columns {missing}")
