"""Fixed-model temporal evaluation after correctness fixes; no test use or hyperparameter search."""

import argparse
import hashlib
import json
import os
import sys
import time
from datetime import timedelta
from pathlib import Path

import numpy as np
from sklearn.model_selection import StratifiedShuffleSplit

from promiseops import (
    approaches,
    bundle,
    cohorts,
    data,
    db,
    experiment_log,
    features,
    inference,
    metrics,
    tracking,
)
from promiseops.diagnostics import bootstrap_recall
from promiseops.maturity import FOLDS

EXPERIMENT = "promiseops-post-audit-fit"


def scores(model, x, y):
    risk = approaches.risk(model, x).to_numpy()
    measured = metrics.evaluate(list(x.index), y.tolist(), risk.tolist())
    return {"metrics": measured.model_dump(), "mean_risk": float(risk.mean()),
            "ap_over_prevalence": measured.pr_auc / measured.prevalence}, risk


def training_subset(ids, y, fraction):
    """Subsample eligible TRAIN rows only. Temporal validation membership never changes."""
    if fraction == 1.0:
        return tuple(ids)
    if not 0 < fraction < 1:
        raise ValueError("fraction must lie in (0,1]")
    selected, _ = next(StratifiedShuffleSplit(n_splits=1, train_size=fraction, random_state=42).split(ids, y))
    return tuple(sorted(ids[i] for i in selected))


def compare_reference(loaded, table, y, new_risk, cutoffs):
    """An artifact with different boundaries is not a valid before/after reference."""
    if loaded.lineage is None:
        raise ValueError("reference requires lineage")
    for name in ("train_end", "validation_end", "as_of"):
        if getattr(loaded.lineage, name) != getattr(cutoffs, name):
            raise ValueError("reference cutoffs differ from current fold")
    if cohorts.cohort_sha256(table.index) != loaded.lineage.validation_cohort_sha256:
        raise ValueError("reference validation IDs differ")
    previous, old_risk = scores(loaded.model, table, y)
    current = metrics.evaluate(list(table.index), y.tolist(), new_risk.tolist())
    return {"model_version": loaded.manifest.model_version,
            "artifact_sha256": loaded.manifest.artifact_sha256,
            "before_metrics": previous["metrics"],
            "after_minus_before": {k: float(v - previous["metrics"][k]) for k, v in current.model_dump().items()},
            "probabilities_equal_at_1e_12": bool(np.allclose(new_risk, old_risk, rtol=0, atol=1e-12)),
            "max_absolute_probability_change": float(np.max(np.abs(new_risk - old_risk)))}


def study(connection, reference, progress):
    reports = []
    for fold, t, v, a in FOLDS:
        cutoff = cohorts.Cutoffs(train_end=t, validation_end=v, as_of=a)
        labels = cohorts.load_labels(connection, as_of=a)
        labels = labels[labels.approved_at <= cutoff.validation_end].copy()
        split = cohorts.split(labels, cutoff)
        for name, ids in (("train", split.train), ("validation", split.validation)):
            cohorts.require_sufficient(name, labels, ids)
        table = features.load_features_with_history(connection, split.train + split.validation,
                                                   as_of=a, freeze_at=t)
        target = labels.set_index("order_id").late
        ty, vy = target.loc[list(split.train)].astype(bool), target.loc[list(split.validation)].astype(bool)
        vx = table.loc[list(split.validation)]
        # Inner chronological diagnostic: all of its evaluation labels must be known by outer train_end.
        # It is diagnostic only: no parameter or model is selected on this window.
        inner_end = cutoff.train_end - timedelta(days=61)
        inner_train = cohorts.select_window(labels, start=None, end=inner_end, label_cutoff=inner_end)
        inner_val = cohorts.select_window(labels, start=inner_end, end=cutoff.train_end,
                                         label_cutoff=cutoff.train_end)
        inner_table = features.load_features_with_history(connection, inner_train + inner_val,
                                                         as_of=a, freeze_at=inner_end)
        variants = []
        configs = [(name, 1.0) for name in (approaches.BASELINE, *approaches.CANDIDATE_APPROACHES)]
        if fold == "current":
            configs += [(name, .5) for name in approaches.CANDIDATE_APPROACHES]
        for name, fraction in configs:
            progress(f"{fold}.{name}.{fraction}", {"status": "started"})
            ids = training_subset(split.train, ty.to_numpy(), fraction)
            tx, selected_y = table.loc[list(ids)], target.loc[list(ids)].astype(bool)
            started = time.perf_counter()
            fitted = approaches.fit(name, tx, selected_y)
            train, _ = scores(fitted, tx, selected_y)
            validation, risk = scores(fitted, vx, vy)
            result = {"approach": name, "training_fraction": fraction, "train_n": len(ids),
                      "train_cohort_sha256": cohorts.cohort_sha256(ids), "apparent_train": train,
                      "temporal_validation": validation, "hyperparameters": approaches.hyperparameters(fitted),
                      "train_minus_validation": {k: train["metrics"][k] - validation["metrics"][k]
                                                 for k in ("recall_at_10", "precision_at_10", "pr_auc", "brier")},
                      "duration_seconds": time.perf_counter() - started}
            if fraction == 1.0 and name != approaches.BASELINE:
                result["validation_recall_uncertainty"] = bootstrap_recall(vx.index, vy, risk, repeats=1000, seed=42)
            if name == "logistic_regression" and fraction == 1.0 and fold == "current":
                reference_table = inference.release_features(connection, vx.index, as_of=a,
                                                              manifest=reference.manifest, lineage=reference.lineage)
                result["before_after"] = compare_reference(reference, reference_table, vy, risk, cutoff)
            estimator = fitted.named_steps["model"]
            if hasattr(estimator, "n_iter_"):
                result["iterations"] = np.asarray(estimator.n_iter_).tolist()
                result["iteration_limit"] = estimator.max_iter
            variants.append(result)
            progress(f"{fold}.{name}.{fraction}", result)
        inner = []
        cohorts.require_sufficient("inner_train", labels, inner_train)
        cohorts.require_sufficient("inner_validation", labels, inner_val)
        for name in approaches.CANDIDATE_APPROACHES:
            progress(f"{fold}.inner.{name}", {"status": "started"})
            ix, iy = inner_table.loc[list(inner_train)], target.loc[list(inner_train)].astype(bool)
            fitted = approaches.fit(name, ix, iy)
            measured, _ = scores(fitted, inner_table.loc[list(inner_val)], target.loc[list(inner_val)].astype(bool))
            inner.append({"approach": name, **measured})
            progress(f"{fold}.inner.{name}", measured)
        reports.append({"fold": fold, "cutoffs": cutoff.model_dump(mode="json"),
                        "dataset_identity": data.dataset_identity(connection, as_of=a),
                        "train": cohorts.describe(labels, split.train), "validation": cohorts.describe(labels, split.validation),
                        "variants": variants,
                        "inner_temporal_diagnostic": {"train_end": inner_end.isoformat(),
                                                       "validation_end": cutoff.train_end.isoformat(),
                                                       "label_cutoff": cutoff.train_end.isoformat(),
                                                       "train": cohorts.describe(labels, inner_train),
                                                       "validation": cohorts.describe(labels, inner_val), "models": inner}})
    return {"dataset_kind": "real_olist", "folds": reports, "test_used": False,
            "hyperparameters_changed": False, "registry_or_alias_changed": False,
            "software_versions": bundle.collect_software_versions(),
            "limitations": ["Apparent training scores are optimistic, especially full-state TargetEncoder transforms.",
                            "Temporal prevalence and label maturity differ; train/validation gaps are not pure capacity effects.",
                            "Inner labels are limited to outer train_end and can be maturity-biased.",
                            "Previously inspected, overlapping validation windows; no independent final-test claim.",
                            "No diagnostic can guarantee the absence of overfit or underfit."]}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference-bundle", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args(argv)
    client, run_id = None, None
    try:
        commit = tracking.source_commit_from_env(os.environ)
        if commit is None:
            raise ValueError("CI_COMMIT_SHA required")
        hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(Path(__file__).parent.glob("*.py"))}
        plan = {"base_commit": commit, "source_state": "uncommitted_audit_fixes", "source_sha256": hashes,
                "folds": FOLDS, "models": [approaches.BASELINE, *approaches.CANDIDATE_APPROACHES],
                "current_fold_training_fractions": [1.0, .5], "subsample_seed": 42,
                "inner_approval_gap_days": 61, "refit_hyperparameters": "unchanged current defaults",
                "test_used": False, "selection": "diagnosis only; no winner activation or tuning"}
        reference = bundle.read_bundle(args.reference_bundle)
        client = tracking.create_client(tracking.TrackingConfig.from_env(os.environ))
        exp = tracking.ensure_experiment(client, EXPERIMENT)
        run_id = client.create_run(exp, tags=tracking.run_tags("post-audit-fit", commit)).info.run_id
        client.log_text(run_id, json.dumps(plan, indent=2), "plan-before-fit.json")

        def progress(key, result):
            client.log_text(run_id, json.dumps(result), f"checks/{key}-{'started' if 'status' in result else 'finished'}.json")
            print(json.dumps({"check": key, "validation": result.get("temporal_validation", result.get("metrics", "started"))}), flush=True)

        with db.connect() as connection:
            connection.execute("SET default_transaction_read_only=on")
            report = study(connection, reference, progress)
        if hashes != {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(Path(__file__).parent.glob("*.py"))}:
            raise ValueError("source changed during study")
        report = json.loads(json.dumps({**report, "plan": plan, "mlflow_run_id": run_id}))
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
        values = {f"{f['fold']}.{r['approach']}.fraction_{r['training_fraction']}.{k}": v
                  for f in report["folds"] for r in f["variants"] for k, v in r["temporal_validation"]["metrics"].items()}
        experiment_log.log_report(client, experiment=EXPERIMENT, kind="post-audit-fit", source_commit=commit,
                                 report=report, params={"test_used": "false", "tuning": "false"},
                                 metrics=values, run_id=run_id)
        print(json.dumps({"status": "ok", "mlflow_run_id": run_id}))
        return 0
    # CLI boundary must sanitize third-party failures and return a nonzero exit code.
    except Exception as error:  # noqa: BLE001
        if client is not None and run_id is not None:
            tracking.close_failed_run(client, run_id, error)
        print(tracking.redact_error(error), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
