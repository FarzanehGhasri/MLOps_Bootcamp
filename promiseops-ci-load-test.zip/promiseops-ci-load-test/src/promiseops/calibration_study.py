"""Temporal calibration inside train, with frozen base estimators and unchanged outer validation."""

import argparse
import hashlib
import json
import os
import sys
import tempfile
from datetime import timedelta
from pathlib import Path

import joblib
import numpy as np
from sklearn.calibration import CalibratedClassifierCV
from sklearn.dummy import DummyClassifier
from sklearn.frozen import FrozenEstimator
from sklearn.metrics import log_loss

from promiseops import (
    approaches,
    bundle,
    cohorts,
    data,
    db,
    experiment_log,
    features,
    gates,
    metrics,
    tracking,
)
from promiseops.maturity import FOLDS

EXPERIMENT = "promiseops-temporal-calibration"


def reliability(y, risk):
    """Fixed-width reliability bins; ECE depends on this declared binning scheme."""
    target, probability = np.asarray(y, dtype=bool), np.asarray(risk, dtype=float)
    bins = 10
    assignment = np.minimum((probability * bins).astype(int), bins - 1)
    rows, error = [], 0.0
    for index in range(bins):
        chosen = assignment == index
        n = int(chosen.sum())
        if not n:
            continue
        predicted, observed = float(probability[chosen].mean()), float(target[chosen].mean())
        error += n / len(target) * abs(predicted - observed)
        rows.append({"lower": index / bins, "upper": (index + 1) / bins, "n": n,
                     "mean_risk": predicted, "observed_prevalence": observed})
    return {"ece_fixed_10_bins": error, "reliability": rows}


def measure(model, table, y):
    risk = approaches.risk(model, table).to_numpy()
    values = metrics.evaluate(list(table.index), y.tolist(), risk.tolist())
    return {"metrics": values.model_dump(), "mean_risk": float(risk.mean()),
            "observed_prevalence": float(np.asarray(y, dtype=bool).mean()),
            "log_loss": float(log_loss(y, risk, labels=[False, True])),
            "unique_probabilities": len(np.unique(risk)), **reliability(y, risk)}, risk


def temporal_ids(labels, cutoff, gap_days=61):
    """Separate base fitting, calibration fitting and outer evaluation by approval time."""
    base_end = cutoff.train_end - timedelta(days=gap_days)
    base = cohorts.select_window(labels, start=None, end=base_end, label_cutoff=base_end)
    calibration = cohorts.select_window(labels, start=base_end, end=cutoff.train_end,
                                       label_cutoff=cutoff.train_end)
    validation = cohorts.select_window(labels, start=cutoff.train_end, end=cutoff.validation_end,
                                      label_cutoff=cutoff.as_of)
    if set(base) & set(calibration) or set(base) & set(validation) or set(calibration) & set(validation):
        raise ValueError("calibration stages must not share order IDs")
    return base_end, base, calibration, validation


def calibrate(base_model, table, y, method):
    if method not in ("sigmoid", "isotonic"):
        raise ValueError("unsupported calibration method")
    before = joblib.hash(base_model)
    calibrated = CalibratedClassifierCV(FrozenEstimator(base_model), method=method, ensemble=False, n_jobs=1)
    calibrated.fit(table, np.asarray(y, dtype=bool))
    if joblib.hash(base_model) != before:
        raise ValueError("calibration unexpectedly changed the frozen base estimator")
    return calibrated


def study(connection, progress, persist):
    folds = []
    for fold, t, v, a in FOLDS:
        cutoff = cohorts.Cutoffs(train_end=t, validation_end=v, as_of=a)
        labels = cohorts.load_labels(connection, as_of=a)
        labels = labels[labels.approved_at <= cutoff.validation_end].copy()
        base_end, base_ids, calibration_ids, validation_ids = temporal_ids(labels, cutoff)
        for name, ids in (("base_train", base_ids), ("calibration_train", calibration_ids), ("validation", validation_ids)):
            cohorts.require_sufficient(name, labels, ids)
        table = features.load_features_with_history(connection, base_ids + calibration_ids + validation_ids,
                                                   as_of=a, freeze_at=base_end)
        target = labels.set_index("order_id").late
        bx, cx, vx = (table.loc[list(ids)] for ids in (base_ids, calibration_ids, validation_ids))
        by, cy, vy = (target.loc[x.index].astype(bool) for x in (bx, cx, vx))
        progress(f"{fold}.base", {"status": "started"})
        base = approaches.fit("logistic_regression", bx, by)
        base_calibration, _ = measure(base, cx, cy)
        base_validation, base_risk = measure(base, vx, vy)
        # Reference control: full eligible train and its own frozen history state, identical to worker LR.
        full_ids = cohorts.split(labels, cutoff).train
        full_table = features.load_features_with_history(connection, full_ids + validation_ids, as_of=a, freeze_at=t)
        full = approaches.fit("logistic_regression", full_table.loc[list(full_ids)], target.loc[list(full_ids)].astype(bool))
        reference, _ = measure(full, full_table.loc[list(validation_ids)], vy)
        reference_values = bundle.EvaluationMetrics(**reference["metrics"])
        models = {"prefix_uncalibrated": base}
        for method in ("sigmoid", "isotonic"):
            progress(f"{fold}.{method}", {"status": "started"})
            models[method] = calibrate(base, cx, cy, method)
        models["calibration_prior_baseline"] = DummyClassifier(strategy="prior").fit(cx, cy.to_numpy())
        results = []
        for method, fitted in models.items():
            apparent, _ = measure(fitted, cx, cy)
            validation, risk = measure(fitted, vx, vy)
            gate = gates.apply_gates(bundle.EvaluationMetrics(**validation["metrics"]), reference_values)
            result = {"method": method, "calibration_apparent": apparent, "outer_validation": validation,
                      "gate_vs_full_train_reference": {"decision": gate.decision, "reasons": gate.reasons},
                      "brier_change_vs_same_base": validation["metrics"]["brier"] - base_validation["metrics"]["brier"],
                      "top_k_ids_changed_vs_same_base": len(set(metrics.top_k(vx.index, risk, validation["metrics"]["k"]))
                                                           ^ set(metrics.top_k(vx.index, base_risk, validation["metrics"]["k"])))}
            persist(f"{fold}.{method}", fitted, vx, base_end.isoformat(), cutoff.train_end.isoformat())
            results.append(result)
            progress(f"{fold}.{method}", result)
        persist(f"{fold}.full_train_reference", full, full_table.loc[list(validation_ids)], t, None)
        calibration_pool = labels[(labels.approved_at > base_end) & (labels.approved_at <= cutoff.train_end)]
        folds.append({"fold": fold, "cutoffs": cutoff.model_dump(mode="json"), "base_train_end": base_end.isoformat(),
                      "history_freeze_at": base_end.isoformat(), "source_snapshot": a,
                      "dataset_identity": data.dataset_identity(connection, as_of=a),
                      "base_train": cohorts.describe(labels, base_ids),
                      "calibration_train": cohorts.describe(labels, calibration_ids),
                      "calibration_approved_pool": len(calibration_pool),
                      "calibration_labels_unavailable_by_training_cutoff": len(calibration_pool) - len(calibration_ids),
                      "outer_validation": cohorts.describe(labels, validation_ids),
                      "base_calibration_before_fit": base_calibration, "full_train_reference": reference,
                      "base_hyperparameters": approaches.hyperparameters(base), "results": results})
    return {"dataset_kind": "real_olist", "folds": folds, "test_used": False,
            "production_or_alias_changed": False, "software_versions": bundle.collect_software_versions(),
            "limitations": ["Calibration fitting labels are maturity-biased by the outer training cutoff.",
                            "The calibrated base is fit on an older prefix; it is never refit on calibration labels.",
                            "Isotonic introduces ties and may change top-K recall; calibration need not improve ranking.",
                            "Outer windows are previously inspected and overlapping; no untouched-test claim.",
                            "Calibrated artifacts are experimental and require distinct base/calibration/history cutoffs in release metadata."]}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args(argv)
    client, run_id = None, None
    try:
        commit = tracking.source_commit_from_env(os.environ)
        if commit is None:
            raise ValueError("CI_COMMIT_SHA required")
        hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(Path(__file__).parent.glob("*.py"))}
        plan = {"base_commit": commit, "source_sha256": hashes, "folds": FOLDS, "base_gap_days": 61,
                "methods": ["sigmoid", "isotonic"], "base_model": "unchanged LR C=0.05 with history",
                "calibration_label_cutoff": "outer train_end", "calibration_base": "FrozenEstimator; never refit on calibration rows",
                "test_used": False, "selection": "report both methods and controls; no production changes"}
        client = tracking.create_client(tracking.TrackingConfig.from_env(os.environ))
        exp = tracking.ensure_experiment(client, EXPERIMENT)
        run_id = client.create_run(exp, tags=tracking.run_tags("temporal-calibration", commit)).info.run_id
        client.log_text(run_id, json.dumps(plan, indent=2), "plan-before-fit.json")

        def progress(key, result):
            client.log_text(run_id, json.dumps(result), f"checks/{key}-{'started' if 'status' in result else 'finished'}.json")
            print(json.dumps({"check": key, "validation": result.get("outer_validation", "started")}), flush=True)

        def persist(key, fitted, vx, history_cutoff, calibration_cutoff):
            with tempfile.TemporaryDirectory() as folder:
                path = Path(folder) / f"{key}.joblib"
                joblib.dump(fitted, path)
                client.log_artifact(run_id, str(path), "experimental-models")
                saved = client.download_artifacts(run_id, f"experimental-models/{path.name}")
                np.testing.assert_array_equal(fitted.predict_proba(vx.iloc[:10]), joblib.load(saved).predict_proba(vx.iloc[:10]))
                client.log_text(run_id, json.dumps({"artifact_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                                                     "base_commit": commit, "schema": list(vx.columns),
                                                     "history_freeze_at": history_cutoff,
                                                     "calibration_label_cutoff": calibration_cutoff,
                                                     "params": {k: str(v) for k, v in fitted.get_params(deep=True).items()
                                                                if v is None or isinstance(v, (str, bool, int, float))}}),
                                f"experimental-models/{key}.metadata.json")

        with db.connect() as connection:
            connection.execute("SET default_transaction_read_only=on")
            report = study(connection, progress, persist)
        if hashes != {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(Path(__file__).parent.glob("*.py"))}:
            raise ValueError("source changed during calibration study")
        report = json.loads(json.dumps({**report, "plan": plan, "mlflow_run_id": run_id}))
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
        values = {f"{f['fold']}.{r['method']}.{k}": v for f in report["folds"]
                  for r in f["results"] for k, v in r["outer_validation"]["metrics"].items()}
        experiment_log.log_report(client, experiment=EXPERIMENT, kind="temporal-calibration", source_commit=commit,
                                 report=report, params={"test_used": "false", "methods": "sigmoid,isotonic"},
                                 metrics=values, run_id=run_id)
        print(json.dumps({"status": "ok", "mlflow_run_id": run_id}))
        return 0
    # CLI boundary must sanitize third-party failures and return a nonzero exit code.
    except Exception as error:  # noqa: BLE001
        if client is not None and run_id is not None:
            tracking.close_failed_run(client, run_id, error)
        print(tracking.redact_error(error), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
