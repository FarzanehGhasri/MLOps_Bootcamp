"""Model record (issue #16): one auditable description of a trained model, stored with it in MLflow.

What the contract asks (docs/CONTRACTS.md, "Evaluation and release")
--------------------------------------------------------------------
"A model record includes model artifact SHA256, immutable model identity, source commit, software
versions, dataset/schema identity, train/evaluation cutoffs, label cutoff, cohort hash, metrics and
gate decision." Issue #16 adds the acceptance test: from the record we must be able to *identify*
exactly that model and *reproduce* it. Course doc, section 3: "code and data version, cutoffs,
evaluation cohort and model checksum must be clear" in MLflow.

Where every item comes from (no new schema: the record is the bundle's own two documents, #12)
------------------------------------------------------------------------------------------------
=============================  ==============================================================
contract item                  field
=============================  ==============================================================
model artifact SHA256          release.json ``artifact_sha256`` (checked against model.joblib)
immutable model identity       release.json ``model_version`` = ``<approach>-<sha256[:12]>``
source commit                  ``source_commit`` (release.json and lineage.json must agree)
software versions              lineage.json ``software_versions``
dataset / schema identity      lineage ``dataset_identity`` (ingestion receipts up to as_of, MR !7)
                               + ``feature_schema_sha256`` (ordered feature list)
train / evaluation cutoffs     lineage ``train_end``, ``validation_end``, ``as_of``
label cutoff                   lineage ``training_label_cutoff``, ``validation_label_cutoff``
cohort hash                    lineage ``validation_cohort_sha256``
metrics                        lineage ``validation_metrics`` (N, prevalence, K, recall/precision@10%,
                               PR-AUC, Brier)
gate decision                  lineage ``gate_decision``, ``gate_reasons``, ``champion_model_version``
=============================  ==============================================================

Why no separate "record" schema: a second copy of the same facts can disagree with the bundle. The
record is *derived* from the bundle and checked for internal consistency (:class:`ModelRecord`).

How it is stored in MLflow (:func:`log_record`)
-----------------------------------------------
* **params** — facts fixed at training time (cutoffs, dataset/schema/cohort identity, versions).
  MLflow params cannot be changed later, which is exactly right for these.
* **metrics** — the validation metrics, so runs can be sorted/compared in the MLflow UI.
* **tags** — identity (artifact SHA256, model_version) for searching, and the gate decision, which is
  decided AFTER training (candidate vs champion) and may be set later; a param could not be updated.
* **artifacts** — the exact bundle bytes under ``bundle/`` (contract: "Persist the exact bundle and
  metadata to your own MLflow, not only ephemeral Job files") and ``record.json``.
* After uploading, the bundle is downloaded again and verified (:func:`load_logged_record`): an MLflow
  server can accept the run but have a broken artifact store.

Registering the model in the MLflow Model Registry is #20 (aliases), on purpose not here: the contract
says registration is not promotion, and keeping it separate keeps this step side-effect free.

This module imports MLflow lazily (only inside the logging functions), like ``promiseops.tracking``.
Explanation (Persian): docs/model/03-model-record.fa.md
"""

import json
import re
import tempfile
import time
from collections.abc import Iterable
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, model_validator

from promiseops.bundle import (
    LINEAGE_FILE,
    RELEASE_FILE,
    SHA256_PATTERN,
    BundleError,
    Lineage,
    feature_schema_sha256,
    read_bundle,
)
from promiseops.contracts import ReleaseManifest
from promiseops.tracking import run_tags

RECORD_FILE = "record.json"
BUNDLE_ARTIFACT_DIR = "bundle"

# Tag names used to find a model again (agree with #19/#20 before changing them).
TAG_ARTIFACT_SHA256 = "promiseops.artifact_sha256"
TAG_MODEL_VERSION = "promiseops.model_version"
TAG_GATE_DECISION = "promiseops.gate_decision"
TAG_CHAMPION = "promiseops.champion_model_version"


class RecordError(ValueError):
    """The record is incomplete or does not match its bundle / MLflow run."""


class ModelRecord(BaseModel):
    """The contract's model record: ``release.json`` + ``lineage.json`` of one bundle, cross-checked."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    record_schema_version: Literal["1.0"] = "1.0"
    manifest: ReleaseManifest
    lineage: Lineage

    @model_validator(mode="after")
    def _documents_describe_the_same_model(self) -> "ModelRecord":
        # write_bundle checks this when writing; a bundle can still be edited or mixed up afterwards.
        if self.manifest.source_commit != self.lineage.source_commit:
            raise ValueError("release.json and lineage.json name different source commits")
        if feature_schema_sha256(self.manifest.feature_names) != self.lineage.feature_schema_sha256:
            raise ValueError("lineage.feature_schema_sha256 does not match release.json feature_names")
        if not self.manifest.model_version.startswith(f"{self.lineage.approach}-"):
            raise ValueError("model_version does not start with the lineage approach")
        return self

    # --- identify ---------------------------------------------------------------------------------
    @property
    def artifact_sha256(self) -> str:
        return self.manifest.artifact_sha256

    @property
    def model_version(self) -> str:
        return self.manifest.model_version

    # --- reproduce --------------------------------------------------------------------------------
    def worker_command(self) -> list[str]:
        """The exact training command (docs/CONTRACTS.md) that rebuilds this model.

        Run it in an image built from ``source_commit``, against a database whose
        ``dataset-identity --as-of <as_of>`` equals ``dataset_identity``, with the recorded software
        versions. ``--mode train``: ``monitor-train`` only *decides* whether to fit; the fit is the same.
        """
        lineage = self.lineage
        return ["python", "-m", "promiseops.worker", "--mode", "train",
                "--train-end", _iso(lineage.train_end), "--validation-end", _iso(lineage.validation_end),
                "--as-of", _iso(lineage.as_of)]

    # --- MLflow mapping (pure, testable without MLflow) -------------------------------------------
    def mlflow_params(self) -> dict[str, str]:
        lineage = self.lineage
        params = {
            "approach": lineage.approach,
            "train_end": _iso(lineage.train_end),
            "validation_end": _iso(lineage.validation_end),
            "as_of": _iso(lineage.as_of),
            "training_label_cutoff": _iso(lineage.training_label_cutoff),
            "validation_label_cutoff": _iso(lineage.validation_label_cutoff),
            "dataset_identity": lineage.dataset_identity,
            "feature_schema_sha256": lineage.feature_schema_sha256,
            "feature_count": str(len(self.manifest.feature_names)),
            "validation_cohort_sha256": lineage.validation_cohort_sha256,
        }
        params.update({f"software.{name}": version for name, version in lineage.software_versions.items()})
        if lineage.history_policy is not None:
            params["history_policy"] = lineage.history_policy
            from promiseops.history_features import policy_parameters

            params.update({f"history.{key}": value for key, value in policy_parameters().items()})
        if lineage.dataset_manifest_sha256 is not None:
            params["dataset_manifest_sha256"] = lineage.dataset_manifest_sha256
            params["dataset_manifest_artifact"] = "bundle/dataset_manifest.json"
        return params

    def mlflow_metrics(self) -> dict[str, float]:
        metrics = self.lineage.validation_metrics
        return {f"validation_{name}": float(value) for name, value in metrics.model_dump().items()}

    def mlflow_tags(self) -> dict[str, str]:
        tags = run_tags("train", self.manifest.source_commit)
        tags.update({
            TAG_ARTIFACT_SHA256: self.artifact_sha256,
            TAG_MODEL_VERSION: self.model_version,
            TAG_GATE_DECISION: self.lineage.gate_decision,
        })
        if self.lineage.champion_model_version is not None:
            tags[TAG_CHAMPION] = self.lineage.champion_model_version
        if self.lineage.gate_reasons:
            tags["promiseops.gate_reasons"] = "; ".join(self.lineage.gate_reasons)
        return tags

    def to_json(self) -> str:
        document = self.model_dump(mode="json") | {"worker_command": self.worker_command()}
        return json.dumps(document, indent=2, sort_keys=True, ensure_ascii=False) + "\n"


def _iso(value: Any) -> str:
    return value.isoformat().replace("+00:00", "Z")


def load_record(bundle_path: str | Path) -> ModelRecord:
    """Build the record of a bundle on disk. The bundle is fully verified first (``read_bundle``).

    A bundle without ``lineage.json`` (e.g. the mock baseline) can be served, but it has no record:
    it cannot be audited or reproduced, so it is refused here.
    """
    loaded = read_bundle(bundle_path)
    if loaded.lineage is None:
        raise RecordError(f"{bundle_path} has no {LINEAGE_FILE}: the model is not auditable")
    try:
        return ModelRecord(manifest=loaded.manifest, lineage=loaded.lineage)
    except ValueError as error:
        raise RecordError(f"{bundle_path}: {error}") from error


# --- MLflow -----------------------------------------------------------------------------------------
def log_record(client: Any, run_id: str, bundle_path: str | Path) -> ModelRecord:
    """Store the bundle and its record in an existing MLflow run, then verify by reading back.

    The run is created by the caller (worker, #15) with ``tracking.ensure_experiment`` + ``create_run``,
    so the same run can also hold training logs. If ``lineage.mlflow_run_id`` is set it must be THIS
    run: a bundle that claims to come from another run is refused (mixed-up artifacts).
    """
    from mlflow.entities import Metric, Param, RunTag  # lazy: see module docstring

    record = load_record(bundle_path)
    claimed = record.lineage.mlflow_run_id
    if claimed is not None and claimed != run_id:
        raise RecordError(f"bundle lineage names MLflow run {claimed}, refusing to log it into run {run_id}")

    now_ms = int(time.time() * 1000)
    # One log_batch request: fewer round trips, and params/metrics/tags arrive together.
    client.log_batch(
        run_id,
        metrics=[Metric(key, value, now_ms, 0) for key, value in record.mlflow_metrics().items()],
        params=[Param(key, value) for key, value in record.mlflow_params().items()],
        tags=[RunTag(key, value) for key, value in record.mlflow_tags().items()],
    )
    client.log_artifacts(run_id, str(bundle_path), artifact_path=BUNDLE_ARTIFACT_DIR)
    client.log_text(run_id, record.to_json(), RECORD_FILE)

    stored = load_logged_record(client, run_id)
    if stored != record:
        raise RecordError(f"run {run_id}: the bundle read back from MLflow differs from the one logged")
    return record


def load_logged_record(client: Any, run_id: str) -> ModelRecord:
    """Download a run's bundle, verify it, and return its record ("identify this model").

    Trust order: the run's ``promiseops.artifact_sha256`` tag (written separately from the files) must
    equal the downloaded ``release.json``; only then ``read_bundle`` checks model.joblib against it and
    unpickles. So a swapped bundle in the artifact store is detected before any code is unpickled.
    """
    expected = client.get_run(run_id).data.tags.get(TAG_ARTIFACT_SHA256)
    if expected is None:
        raise RecordError(f"run {run_id} has no {TAG_ARTIFACT_SHA256} tag: no model record was logged")
    with tempfile.TemporaryDirectory() as folder:
        local = Path(client.download_artifacts(run_id, BUNDLE_ARTIFACT_DIR, folder))
        try:
            manifest = ReleaseManifest.model_validate_json((local / RELEASE_FILE).read_text(encoding="utf-8"))
        except (OSError, ValueError) as error:
            raise RecordError(f"run {run_id}: {RELEASE_FILE} missing or invalid in artifacts") from error
        if manifest.artifact_sha256 != expected:
            raise RecordError(f"run {run_id}: artifact {RELEASE_FILE} does not match the run's SHA256 tag")
        try:
            return load_record(local)
        except BundleError as error:
            raise RecordError(f"run {run_id}: logged bundle is invalid: {error}") from error


def find_runs_by_artifact(client: Any, artifact_sha256: str, experiment_ids: Iterable[str]) -> list[str]:
    """Run IDs that logged the model with this SHA256 (e.g. the ``artifact_sha256`` the API serves).

    The SHA256 is validated before it is put into the search filter (no filter injection).
    """
    if re.fullmatch(SHA256_PATTERN, artifact_sha256 or "") is None:
        raise RecordError("artifact_sha256 must be 64 lowercase hex characters")
    runs = client.search_runs(list(experiment_ids),
                              filter_string=f"tags.`{TAG_ARTIFACT_SHA256}` = '{artifact_sha256}'")
    return [run.info.run_id for run in runs]
