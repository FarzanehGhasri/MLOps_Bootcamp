"""Contract metrics of one model on one labeled cohort (docs/CONTRACTS.md "Evaluation and release").

    K            = max(1, ceil(0.1 * N))                    (bundle.top_k_size, integer arithmetic)
    top K        = highest risk first; equal risk -> ascending order_id (deterministic)
    recall@10%   = late orders in top K / all late orders
    precision@10%= late orders in top K / K
    PR-AUC       = average precision (scikit-learn average_precision_score)
    Brier        = mean squared probability error
N and prevalence are always reported with them (recall@10% alone is not interpretable).

The result is the same ``EvaluationMetrics`` document stored in the bundle's lineage (#12), so the
numbers computed here are exactly the numbers recorded — no second definition.
Used by training/gates (promiseops.model) and later by monitoring (#26).
"""

from collections.abc import Sequence

import numpy as np
from sklearn.metrics import average_precision_score, brier_score_loss

from promiseops.bundle import EvaluationMetrics, top_k_size


def top_k(order_ids: Sequence[str], risk: Sequence[float], k: int) -> list[str]:
    """The ``k`` order IDs with the highest risk; ties broken by ascending order ID.

    The same rule is required for the batch priority output, so it is a public helper.
    """
    ids = np.asarray(order_ids, dtype=str)
    scores = np.asarray(risk, dtype=float)
    # lexsort sorts by the LAST key first: primary = -risk (descending), secondary = id (ascending).
    order = np.lexsort((ids, -scores))
    return ids[order[:k]].tolist()


def evaluate(order_ids: Sequence[str], late: Sequence[bool], risk: Sequence[float]) -> EvaluationMetrics:
    """Contract metrics for one cohort. Needs N >= 1, both classes and probabilities in [0, 1].

    A cohort without both classes has no recall or PR-AUC; it is refused here (ValueError) — the
    caller reports it as an insufficient cohort instead of fabricating a number.
    """
    ids = np.asarray(order_ids, dtype=str)
    labels = np.asarray(late, dtype=object)
    p = np.asarray(risk, dtype=float)
    if any(array.ndim != 1 for array in (ids, labels, p)):
        raise ValueError("order_ids, late and risk must be one-dimensional")
    if any(not isinstance(value, (bool, int, float, np.bool_, np.integer, np.floating))
           or value not in (0, 1) for value in labels):
        raise ValueError("late must contain known binary labels (boolean or 0/1)")
    y = labels.astype(bool)
    if not (len(ids) == len(y) == len(p)):
        raise ValueError("order_ids, late and risk must have the same length")
    if len(set(ids.tolist())) != len(ids):
        raise ValueError("order_ids must be unique (each order counts once)")
    if not np.all(np.isfinite(p)) or p.min(initial=0) < 0 or p.max(initial=0) > 1:
        raise ValueError("risk must be finite probabilities in [0, 1]")
    n = len(ids)
    positives = int(y.sum())
    if n == 0 or positives in (0, n):
        raise ValueError(f"metrics need both classes: N={n}, late={positives}")

    k = top_k_size(n)
    chosen = set(top_k(ids, p, k))
    hits = int(sum(1 for order_id, is_late in zip(ids, y) if is_late and order_id in chosen))
    return EvaluationMetrics(
        n=n,
        prevalence=positives / n,
        k=k,
        recall_at_10=hits / positives,
        precision_at_10=hits / k,
        pr_auc=float(average_precision_score(y, p)),
        brier=float(brier_score_loss(y, p)),
    )
