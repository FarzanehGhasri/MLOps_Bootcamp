"""Batch validation: every accept/reject decision is made here, BEFORE any row is written.

Why a separate, database-free module
------------------------------------
* Only validated data reaches the database (the "staging" role is played by Python objects).
* Pure functions: each rejection rule is unit-tested without PostgreSQL, so CI always runs them.
* Readable reasons: a rejection lists *all* problems with order/row IDs, not a raw SQL error.

The few facts that need the database (does this customer already exist? was this order already
committed?) are passed in as an :class:`ExistingState`, which ``promiseops.data`` loads inside the
ingestion transaction while holding the ingestion lock, so it cannot change before the insert.

Contract source: ``docs/CONTRACTS.md`` "Dataset, replay and relational rows" and
``promiseops.contracts`` (row types). Walkthrough (Persian): ``docs/ingestion/01-ingestion.fa.md``.
"""

import hashlib
import json
import math
import re
from collections import Counter
from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field
from datetime import datetime
from decimal import Decimal
from enum import StrEnum
from typing import Any

from pydantic import ValidationError

from promiseops.contracts import Batch, digest, instant

SHA256_RE = re.compile(r"^[a-f0-9]{64}$")
# A rejection keeps every problem in the quarantine record, but the human-readable message and
# the stored detail are capped so that one huge broken batch cannot produce a huge log line.
MAX_REPORTED_PROBLEMS = 50


class Reason(StrEnum):
    """Machine-readable rejection reasons (stored in attempts/quarantine, used by alerts/tests)."""

    INVALID_JSON = "invalid_json"                    # not UTF-8, not JSON, NaN/Infinity, duplicate keys
    CHECKSUM_MISMATCH = "checksum_mismatch"          # payload or file SHA256 differs from the feed entry
    SCHEMA_INVALID = "schema_invalid"                # unknown column, bad ID/type/timezone, negative amount
    FUTURE_PUBLICATION = "future_publication"        # batch published after the chosen as_of
    BATCH_ID_CONFLICT = "batch_id_conflict"          # batch ID already committed with another payload
    DUPLICATE_KEY = "duplicate_key"                  # same primary key twice inside one batch
    MISSING_FOREIGN_KEY = "missing_foreign_key"      # reference to a row that exists nowhere
    INCOMPLETE_ORDER = "incomplete_order"            # order without at least one item and one payment
    APPEND_TO_COMMITTED_ORDER = "append_to_committed_order"  # new item/payment for an old order
    CHANGED_IMMUTABLE_ROW = "changed_immutable_row"  # known dimension row with different values
    ALREADY_COMMITTED = "already_committed"          # order/outcome fact already stored by another batch
    DELIVERY_BEFORE_APPROVAL = "delivery_before_approval"
    FEED_METADATA_MISMATCH = "feed_metadata_mismatch"  # index kind/available_at/batch_id != payload


@dataclass(frozen=True)
class Problem:
    """One reason why a batch cannot be accepted."""

    reason: Reason
    detail: str

    def as_dict(self) -> dict[str, str]:
        return {"reason": self.reason.value, "detail": self.detail}


class BatchRejected(Exception):
    """The batch violates the contract. Nothing from it is committed; it goes to quarantine."""

    def __init__(self, problems: Iterable[Problem], *, batch_id: str | None = None):
        self.problems: tuple[Problem, ...] = tuple(problems)
        if not self.problems:
            raise ValueError("BatchRejected needs at least one problem")
        self.batch_id = batch_id
        first = self.problems[0]
        more = f" (+{len(self.problems) - 1} more)" if len(self.problems) > 1 else ""
        super().__init__(f"{first.reason.value}: {first.detail}{more}")

    @property
    def reason(self) -> Reason:
        """The primary reason: the first problem found (checks run in a fixed, documented order)."""
        return self.problems[0].reason

    def detail_records(self) -> list[dict[str, str]]:
        return [problem.as_dict() for problem in self.problems[:MAX_REPORTED_PROBLEMS]]


# ---------------------------------------------------------------------------------------------
# Step 1 — bytes -> verified, typed Batch
# ---------------------------------------------------------------------------------------------
def parse_payload(raw: bytes, *, expected_sha256: str) -> Batch:
    """Decode, verify the checksum, then validate the schema. Raises :class:`BatchRejected`.

    Order of checks (each one is meaningless if the previous failed):
    1. UTF-8 + strict JSON (no NaN/Infinity, no duplicate object keys — ``json`` would silently
       keep the last duplicate, so ``{"price": 1, "price": -1}`` could hide a value).
    2. ``payload_sha256`` over canonical JSON (sorted keys, compact separators, ensure_ascii=False)
       — the contract's definition, implemented once in ``contracts.digest``.
    3. Row schema with pydantic in *strict* mode: a string is not silently turned into a number.
    """
    if not SHA256_RE.fullmatch(expected_sha256 or ""):
        # A caller bug (wrong argument), not a data problem: fail loudly instead of quarantining.
        raise ValueError("expected_sha256 must be 64 lowercase hex characters")
    document = decode_document(raw)
    batch_id = document.get("batch_id") if isinstance(document, dict) else None
    batch_id = batch_id if isinstance(batch_id, str) else None
    actual_sha256 = digest(document)
    if actual_sha256 != expected_sha256:
        detail = f"payload_sha256 is {actual_sha256}, feed says {expected_sha256}"
        raise BatchRejected([Problem(Reason.CHECKSUM_MISMATCH, detail)], batch_id=batch_id)

    try:
        return Batch.model_validate_json(raw, strict=True)  # raw is already known to be valid UTF-8
    except ValidationError as error:
        problems = [
            Problem(Reason.SCHEMA_INVALID, f"{_location(item['loc'])}: {item['msg']}")
            for item in error.errors(include_url=False)
        ]
        raise BatchRejected(problems, batch_id=batch_id) from error


def decode_document(raw: bytes) -> Any:
    """Bytes -> JSON value with the contract's strict rules (UTF-8, no NaN/Infinity, no duplicate
    keys). Raises :class:`BatchRejected` (``invalid_json``).

    Shared by :func:`parse_payload` and the feed pre-flight (``feed.first_inconsistent_entry``), so
    both read a file the same way and compute the same ``payload_sha256``.
    """
    try:
        text = raw.decode("utf-8")
        return json.loads(text, parse_float=_finite_float, parse_constant=_reject_constant,
                          object_pairs_hook=_no_duplicate_keys)
    except (UnicodeDecodeError, ValueError) as error:
        raise BatchRejected([Problem(Reason.INVALID_JSON, str(error))]) from error


def raw_sha256(raw: bytes) -> str:
    """SHA256 of the exact received bytes.

    This equals the feed's file_sha256; payload_sha256 is computed over canonical JSON instead."""
    return hashlib.sha256(raw).hexdigest()


def check_file_sha256(raw: bytes, expected_file_sha256: str | None) -> None:
    """Verify the feed's ``file_sha256`` (skipped when the caller has no file checksum, e.g. a
    payload that did not come from a feed file). Raises :class:`BatchRejected` on mismatch."""
    if expected_file_sha256 is None:
        return
    if not SHA256_RE.fullmatch(expected_file_sha256):
        raise ValueError("expected_file_sha256 must be 64 lowercase hex characters")
    actual = raw_sha256(raw)
    if actual != expected_file_sha256:
        raise BatchRejected(
            [Problem(Reason.CHECKSUM_MISMATCH, f"file_sha256 is {actual}, feed says {expected_file_sha256}")]
        )


def _reject_constant(name: str) -> Any:
    raise ValueError(f"non-finite number {name} is not allowed")


def _finite_float(text: str) -> float:
    """Keep normal JSON float/checksum semantics, rejecting exponent overflow before hashing."""
    value = float(text)
    if not math.isfinite(value):
        raise ValueError("non-finite numeric value is not allowed")
    return value


def _no_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    keys = [key for key, _ in pairs]
    duplicates = sorted(key for key, count in Counter(keys).items() if count > 1)
    if duplicates:
        raise ValueError(f"duplicate JSON object keys: {duplicates}")
    return dict(pairs)


def _location(loc: Iterable[Any]) -> str:
    return ".".join(str(part) for part in loc) or "batch"


# ---------------------------------------------------------------------------------------------
# Step 2 — cross-row and cross-batch rules
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class ExistingState:
    """What the database already holds for the keys this batch mentions.

    Loaded by ``promiseops.data`` under the ingestion lock. Only keys referenced by the batch are
    loaded (see :func:`referenced_keys`), never whole tables.
    """

    customers: Mapping[str, str] = field(default_factory=dict)                  # id -> state
    sellers: Mapping[str, str] = field(default_factory=dict)                    # id -> state
    products: Mapping[str, tuple[str, Decimal]] = field(default_factory=dict)   # id -> (category, weight)
    orders: Mapping[str, datetime] = field(default_factory=dict)                # id -> approved_at
    outcomes: frozenset[str] = frozenset()                                      # order ids with outcome


@dataclass(frozen=True)
class ReferencedKeys:
    """Every key a batch defines or points to; tells the loader which existing rows to fetch."""

    customers: frozenset[str]
    sellers: frozenset[str]
    products: frozenset[str]
    orders: frozenset[str]


def referenced_keys(batch: Batch) -> ReferencedKeys:
    return ReferencedKeys(
        customers=frozenset([c.customer_id for c in batch.customers] + [o.customer_id for o in batch.orders]),
        sellers=frozenset([s.seller_id for s in batch.sellers] + [i.seller_id for i in batch.items]),
        products=frozenset([p.product_id for p in batch.products] + [i.product_id for i in batch.items]),
        orders=frozenset(
            [o.order_id for o in batch.orders]
            + [i.order_id for i in batch.items]
            + [p.order_id for p in batch.payments]
            + [o.order_id for o in batch.outcomes]
        ),
    )


def to_decimal(value: float) -> Decimal:
    """Exact decimal of a JSON number: ``repr`` gives the shortest text that round-trips the float,
    so 19.9 becomes Decimal('19.9') and not Decimal('19.899999999999998578914528479799628257751')."""
    return Decimal(repr(value))


def publication_problems(batch: Batch, *, as_of: datetime | str) -> list[Problem]:
    """A batch published after ``as_of`` is not visible at ``as_of`` (temporal visibility rule).

    Separate function because ``promiseops.data`` must apply it BEFORE the replay short-circuit:
    a batch already committed by a later replay must still be rejected for an earlier ``as_of``
    (review of MR !7), otherwise a replay could return data that did not exist yet at ``as_of``.
    """
    cutoff = instant(as_of)
    if batch.available_at <= cutoff:
        return []
    return [Problem(
        Reason.FUTURE_PUBLICATION,
        f"batch available_at {batch.available_at.isoformat()} is after as_of {cutoff.isoformat()}",
    )]


@dataclass(frozen=True)
class ExpectedMetadata:
    """What the feed index says about a batch file; must agree with the payload itself.

    The index is used to ORDER batches and to FILTER them by ``as_of`` before any payload is read,
    so an index that disagrees with its payload could reorder, include or silently skip a batch.
    """

    kind: str
    available_at: datetime
    batch_id: str | None = None  # optional in the index


def metadata_problems(*, batch_id: Any, kind: Any, available_at: Any,
                      expected: ExpectedMetadata) -> list[Problem]:
    """Compare a payload's envelope with the index entry. Timestamps compare as instants
    (``2018-01-01T00:00:00Z`` equals ``2017-12-31T21:00:00-03:00``); an unreadable value is a mismatch."""
    problems: list[Problem] = []
    if kind != expected.kind:
        problems.append(Problem(Reason.FEED_METADATA_MISMATCH,
                                f"index kind {expected.kind!r}, payload {kind!r}"))
    try:
        same_time = instant(available_at) == instant(expected.available_at)
    except (AttributeError, TypeError, ValueError):  # missing, not a string, not a timestamp
        same_time = False
    if not same_time:
        problems.append(Problem(
            Reason.FEED_METADATA_MISMATCH,
            f"index available_at {instant(expected.available_at).isoformat()}, payload {available_at!r}",
        ))
    if expected.batch_id is not None and batch_id != expected.batch_id:
        problems.append(Problem(
            Reason.FEED_METADATA_MISMATCH, f"index batch_id {expected.batch_id!r}, payload {batch_id!r}"))
    return problems


def validate_batch(batch: Batch, existing: ExistingState, *, as_of: datetime) -> list[Problem]:
    """Return every contract problem of a schema-valid batch (empty list = accept).

    Row-level rules (types, ID pattern, nonnegative finite amounts, promise >= local approval date,
    available_at >= delivered_at, publication not before the facts it contains, kind rules) are
    already enforced by ``contracts.Batch`` in :func:`parse_payload`.
    """
    problems = publication_problems(batch, as_of=as_of)
    problems += _duplicate_keys(batch)
    if batch.kind == "orders":
        problems += _orders_batch_problems(batch, existing)
    else:
        problems += _outcomes_batch_problems(batch, existing)
    return problems


def _duplicate_keys(batch: Batch) -> list[Problem]:
    tables: dict[str, list[Any]] = {
        "customers": [c.customer_id for c in batch.customers],
        "sellers": [s.seller_id for s in batch.sellers],
        "products": [p.product_id for p in batch.products],
        "orders": [o.order_id for o in batch.orders],
        "items": [(i.order_id, i.item_id) for i in batch.items],
        "payments": [(p.order_id, p.sequence) for p in batch.payments],
        "outcomes": [o.order_id for o in batch.outcomes],
    }
    problems = []
    for table, keys in tables.items():
        for key, count in sorted(Counter(keys).items(), key=lambda kv: str(kv[0])):
            if count > 1:
                problems.append(Problem(Reason.DUPLICATE_KEY, f"{table} key {key} appears {count} times"))
    return problems


def _orders_batch_problems(batch: Batch, existing: ExistingState) -> list[Problem]:
    problems: list[Problem] = []

    # Dimensions: identical rows are reusable, changed rows are not (source rows are immutable).
    for c in batch.customers:
        known = existing.customers.get(c.customer_id)
        if known is not None and known != c.customer_state:
            problems.append(_changed("customer", c.customer_id, f"state {known} -> {c.customer_state}"))
    for s in batch.sellers:
        known = existing.sellers.get(s.seller_id)
        if known is not None and known != s.seller_state:
            problems.append(_changed("seller", s.seller_id, f"state {known} -> {s.seller_state}"))
    for p in batch.products:
        known_product = existing.products.get(p.product_id)
        new_values = (p.category, to_decimal(p.weight_g))
        if known_product is not None and known_product != new_values:
            problems.append(_changed("product", p.product_id, f"{known_product} -> {new_values}"))

    # Orders are facts: they arrive once, complete.
    batch_orders = {o.order_id for o in batch.orders}
    for order_id in sorted(batch_orders & set(existing.orders)):
        problems.append(Problem(Reason.ALREADY_COMMITTED,
                                f"order {order_id} was committed by an earlier batch"))

    customers = {c.customer_id for c in batch.customers} | set(existing.customers)
    products = {p.product_id for p in batch.products} | set(existing.products)
    sellers = {s.seller_id for s in batch.sellers} | set(existing.sellers)
    for o in sorted(batch.orders, key=lambda o: o.order_id):
        if o.customer_id not in customers:
            problems.append(_missing("order", o.order_id, "customer", o.customer_id))

    for item in sorted(batch.items, key=lambda i: (i.order_id, i.item_id)):
        label = f"{item.order_id}#{item.item_id}"
        problems += _order_reference("item", label, item.order_id, batch_orders, existing)
        if item.product_id not in products:
            problems.append(_missing("item", label, "product", item.product_id))
        if item.seller_id not in sellers:
            problems.append(_missing("item", label, "seller", item.seller_id))
    for payment in sorted(batch.payments, key=lambda p: (p.order_id, p.sequence)):
        label = f"{payment.order_id}#{payment.sequence}"
        problems += _order_reference("payment", label, payment.order_id, batch_orders, existing)

    with_items = {i.order_id for i in batch.items}
    with_payments = {p.order_id for p in batch.payments}
    for order_id in sorted(batch_orders):
        missing = [name for name, ids in (("item", with_items), ("payment", with_payments))
                   if order_id not in ids]
        if missing:
            problems.append(Problem(Reason.INCOMPLETE_ORDER,
                                    f"order {order_id} has no {' and no '.join(missing)}"))
    return problems


def _outcomes_batch_problems(batch: Batch, existing: ExistingState) -> list[Problem]:
    problems: list[Problem] = []
    for outcome in sorted(batch.outcomes, key=lambda o: o.order_id):
        approved_at = existing.orders.get(outcome.order_id)
        if approved_at is None:
            problems.append(_missing("outcome", outcome.order_id, "order", outcome.order_id))
            continue
        if outcome.order_id in existing.outcomes:
            problems.append(Problem(
                Reason.ALREADY_COMMITTED,
                f"outcome for order {outcome.order_id} was committed by an earlier batch",
            ))
        if outcome.delivered_at < approved_at:
            problems.append(Problem(
                Reason.DELIVERY_BEFORE_APPROVAL,
                f"order {outcome.order_id} delivered {outcome.delivered_at.isoformat()} "
                f"before approval {approved_at.isoformat()}",
            ))
    return problems


def _order_reference(kind: str, label: str, order_id: str, batch_orders: set[str],
                     existing: ExistingState) -> list[Problem]:
    if order_id in batch_orders:
        return []
    if order_id in existing.orders:
        detail = f"{kind} {label} adds to already committed order {order_id}"
        return [Problem(Reason.APPEND_TO_COMMITTED_ORDER, detail)]
    return [_missing(kind, label, "order", order_id)]


def _changed(table: str, key: str, change: str) -> Problem:
    return Problem(Reason.CHANGED_IMMUTABLE_ROW, f"{table} {key} changed: {change}")


def _missing(kind: str, label: str, target: str, target_id: str) -> Problem:
    return Problem(Reason.MISSING_FOREIGN_KEY, f"{kind} {label} references unknown {target} {target_id}")
