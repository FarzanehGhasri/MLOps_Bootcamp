"""Conditional paired-bootstrap uncertainty for saved validation predictions, never test tuning."""

import numpy as np


def recall_difference(order_ids, late, candidate, reference, *, repeats=1000, seed=42):
    ids = np.asarray(order_ids, dtype=str)
    y = np.asarray(late, dtype=bool)
    candidate, reference = np.asarray(candidate), np.asarray(reference)
    if not len(ids) or not y.any() or repeats < 1:
        raise ValueError("need nonempty positive cohort and positive repeats")
    if not (len(y) == len(candidate) == len(reference) == len(ids)):
        raise ValueError("unaligned predictions")
    rng = np.random.default_rng(seed)
    k = (len(ids) + 9) // 10
    changes = []
    for _ in range(repeats):
        positions = rng.integers(0, len(ids), len(ids))
        positives = y[positions].sum()
        if not positives:
            continue
        ranking_a = np.lexsort((ids[positions], -candidate[positions]))[:k]
        ranking_b = np.lexsort((ids[positions], -reference[positions]))[:k]
        changes.append(float((y[positions[ranking_a]].sum() - y[positions[ranking_b]].sum()) / positives))
    if not changes:
        raise ValueError("no valid bootstrap samples")
    return {"seed": seed, "repeats": repeats, "valid_repeats": len(changes),
            "recall_difference_95_percentile_interval": np.quantile(changes, [.025, .975]).tolist(),
            "scope": "Conditional on this validation cohort; ignores temporal dependence and model-selection bias."}
