"""Dataset fingerprints, signatures, slice/maturity reports and human-readable model evidence."""

import hashlib
import inspect
import json
import math
import os
import tempfile
from datetime import timedelta
from importlib import metadata
from pathlib import Path

import numpy as np

from promiseops import bundle, cohorts, features, history_features
from promiseops.contracts import digest, instant
from promiseops.ml_diagnostics import maturity_report, quality_report


def frame_fingerprint(table, labels):
    if not table.index.is_unique:
        raise ValueError("fingerprint needs unique order IDs")
    ordered = table.sort_index()
    target = labels.reindex(ordered.index)
    if target.isna().any():
        raise ValueError("fingerprint requires known aligned labels")

    def scalar(value):
        value = value.item() if isinstance(value, np.generic) else value
        if isinstance(value, float):
            if not math.isfinite(value):
                raise ValueError("fingerprint requires finite numeric features")
            return {"float64_hex": value.hex()}
        return value

    return digest({"columns": list(ordered.columns), "dtypes": [str(v) for v in ordered.dtypes],
                   "rows": [[str(oid), [scalar(v) for v in row], bool(target.loc[oid])]
                            for oid, row in zip(ordered.index, ordered.itertuples(index=False, name=None), strict=True)]})


def dataset_manifest(connection, candidate, *, dataset_identity, source_commit):
    cutoff = candidate.cutoffs
    receipts = connection.execute("""SELECT batch_id,kind,payload_sha256,available_at,file_sha256,schema_version
        FROM promiseops.ingest_batches WHERE available_at<=%s
        ORDER BY available_at,CASE kind WHEN 'orders' THEN 0 ELSE 1 END,batch_id""", (cutoff.as_of,)).fetchall()
    actual = "receipts-sha256:" + digest([[bid, kind, sha, instant(at).isoformat()]
                                          for bid, kind, sha, at, _, _ in receipts])
    if actual != dataset_identity:
        raise ValueError("source receipts changed during training; refusing inconsistent dataset manifest")
    labels = cohorts.load_labels(connection, as_of=cutoff.as_of,
                                 order_ids=tuple(candidate.training_features.index) + tuple(candidate.cohort.features.index))
    late = labels.set_index("order_id").late

    def split(table):
        y = late.reindex(table.index).astype(bool)
        return {"row_count": len(table), "positive_count": int(y.sum()), "positive_rate": float(y.mean()),
                "order_ids_sha256": cohorts.cohort_sha256(table.index), "data_frame_sha256": frame_fingerprint(table, y),
                "schema_signature": [{"name": name, "dtype": str(table[name].dtype), "null_count": int(table[name].isna().sum())}
                                     for name in table]}

    return {"manifest_schema_version": "1.0", "dataset_identity": actual, "git_commit_sha": source_commit,
            "as_of_watermark_utc": cutoff.as_of.isoformat(), "cutoffs": cutoff.model_dump(mode="json"),
            "history_policy": "frozen-at-train-end-v1", "embargo_days": 0,
            "feature_schema_sha256": bundle.feature_schema_sha256(candidate.training_features.columns),
            "sql_query_sha256": hashlib.sha256((features._ORDERS_SQL + features._ITEMS_SQL + features._PAYMENTS_SQL + cohorts._LABELS_SQL).encode()).hexdigest(),
            "feature_code_sha256": hashlib.sha256((inspect.getsource(features) + inspect.getsource(history_features)).encode()).hexdigest(),
            "batches": [{"batch_id": bid, "kind": kind, "payload_sha256": sha, "file_sha256": raw,
                         "available_at": instant(at).isoformat(), "schema_version": schema}
                        for bid, kind, sha, at, raw, schema in receipts],
            "train": split(candidate.training_features), "validation": split(candidate.cohort.features),
            "test": {"status": "not_loaded_or_scored_by_training"},
            "thread_settings": {key: os.environ.get(key) for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS")},
            "fingerprint_encoding": "sorted IDs; ordered feature schema; exact hexadecimal binary float values; aligned labels"}


def log_evidence(connection, client, run_id, candidate, record):
    from mlflow.models import infer_signature
    from mlflow.sklearn import load_model, save_model

    x, y = candidate.cohort.features, candidate.cohort.late
    risk = candidate.model.predict_proba(x)[:, 1]
    quality = quality_report(x, y, risk)
    labels = cohorts.load_labels(connection, as_of=candidate.cutoffs.as_of)
    maturity = maturity_report(labels, approved_end=candidate.cutoffs.train_end - timedelta(days=180), as_of=candidate.cutoffs.as_of)
    example = candidate.training_features.head(3).reset_index(drop=True)
    signature = infer_signature(example, candidate.model.predict_proba(example))
    payloads = {"model_signature.json": signature.to_dict(), "input_example.json": json.loads(example.to_json(orient="records")),
                "validation_diagnostics.json": quality, "label_maturity.json": maturity}
    for name, payload in payloads.items():
        client.log_text(run_id, json.dumps(payload, indent=2, sort_keys=True), name)
        with tempfile.TemporaryDirectory() as folder:
            saved = Path(client.download_artifacts(run_id, name, folder))
            if json.loads(saved.read_text()) != payload:
                raise ValueError(f"MLflow evidence read-back differs: {name}")
    with tempfile.TemporaryDirectory() as folder:
        model_dir = Path(folder) / "model"
        requirements = [f"{name}=={metadata.version(name)}" for name in
                        ("scikit-learn", "scipy", "skops", "pandas", "numpy", "joblib", "cloudpickle", "pydantic")]
        requirements.append(f"psycopg[binary]=={metadata.version('psycopg')}")
        save_model(candidate.model, str(model_dir), signature=signature, input_example=example,
                   pip_requirements=requirements, code_paths=[str(Path(__file__).parent)],
                   pyfunc_predict_fn="predict_proba",
                   skops_trusted_types=["promiseops.approaches.engineer_features",
                                        "scipy.interpolate._bsplines.BSpline",
                                        "scipy.interpolate._bsplines._BSpline"])
        client.log_artifacts(run_id, str(model_dir), artifact_path="sklearn-model")
        saved = client.download_artifacts(run_id, "sklearn-model")
        np.testing.assert_allclose(candidate.model.predict_proba(example), load_model(saved).predict_proba(example), rtol=0, atol=1e-12)
        import matplotlib

        matplotlib.use("Agg")
        from matplotlib import pyplot as plt

        fig, ax = plt.subplots(figsize=(5, 4))
        bins = quality["reliability"]
        ax.plot([0, 1], [0, 1], "--", color="gray", label="Ideal")
        ax.plot([b["mean_risk"] for b in bins], [b["observed_prevalence"] for b in bins], "o-", label="Validation")
        ax.set(xlabel="Mean predicted risk", ylabel="Observed late prevalence", xlim=(0, 1), ylim=(0, 1))
        ax.legend()
        fig.tight_layout()
        path = Path(folder) / "validation_reliability.png"
        fig.savefig(path, dpi=150)
        plt.close(fig)
        client.log_artifact(run_id, str(path))
    worst = quality["worst_supported_slice"]
    card = (f"# Model card\n\nModel: {record.model_version}\n\nSource: {record.manifest.source_commit}\n\n"
            f"SHA256: {record.artifact_sha256}\n\nDataset: {record.lineage.dataset_identity}\n\n"
            f"Cutoffs: {candidate.cutoffs.model_dump(mode='json')}\n\n"
            f"Validation: {quality['global_metrics']}\n\nO/E: {quality['observed_expected_ratio']}\n\n"
            f"Worst supported global-budget slice: {worst}\n\nGate: {record.lineage.gate_decision}\n\n"
            "Scope: completed delivered orders; predict at approval. Cancellations are excluded.\n\n"
            "Past outcomes enter history only before approval; the target order outcome is excluded.\n\n"
            "Validation is previously inspected; no untouched-test claim. Calibration and temporal drift remain limitations.\n\n"
            "Signature, example, dataset manifest, reliability plot and full slice/maturity reports are artifacts in this run.\n\n"
            "Reviewer: pending human review. Registry candidate status is not production approval.\n")
    client.log_text(run_id, card, "model-card.md")
