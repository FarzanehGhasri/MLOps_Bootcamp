"""Choose a bounded LR variant on train-only temporal windows; evaluate once on fixed validation."""

import argparse
import hashlib
import json
import os
import sys
import tempfile
from pathlib import Path

import joblib
import numpy as np

from promiseops import (
    approaches,
    bundle,
    cohorts,
    data,
    db,
    experiment_log,
    features,
    gates,
    metrics,
    tracking,
)
from promiseops.paired_validation import recall_difference

EXPERIMENT = "promiseops-presentation-study"
INNER = (
    ("2017-08-31T23:59:59Z", "2017-10-31T23:59:59Z"),
    ("2017-09-30T23:59:59Z", "2017-11-30T23:59:59Z"),
)
CUTOFFS = cohorts.Cutoffs(train_end="2017-12-31T23:59:59Z", validation_end="2018-02-28T23:59:59Z",
                          as_of="2018-04-30T00:00:00Z")
VARIANTS = {
    "reference": ("original", .05), "original_C002": ("original", .002),
    "original_C01": ("original", .01), "original_C02": ("original", .02),
    "rates_C01": ("rates", .01), "rates_C05": ("rates", .05),
    "nonlinear_rates_C01": ("nonlinear_rates", .01), "nonlinear_rates_C05": ("nonlinear_rates", .05),
    "nonlinear_full_C01": ("nonlinear_full", .01),
}
ADDITIONAL = tuple(
    name for group in ("global", "seller", "customer_state", "route")
    for name in (f"{group}_logit", f"{group}_recent_logit", f"{group}_rate_change",
                 f"{group}_promise_interaction", f"{group}_freight_interaction")
)


def engineering(table):
    """Only transform existing approval-time/past-known signals; no label or ID input."""
    result = approaches.engineer_features(table)
    for group in ("global", "seller", "customer_state", "route"):
        rate = result[f"history_{group}_rate"].clip(1e-5, 1 - 1e-5)
        recent = result[f"history_{group}_recent_rate"].clip(1e-5, 1 - 1e-5)
        result[f"{group}_logit"] = np.log(rate / (1 - rate))
        result[f"{group}_recent_logit"] = np.log(recent / (1 - recent))
        result[f"{group}_rate_change"] = recent - rate
        result[f"{group}_promise_interaction"] = rate * result.log_promise_days
        result[f"{group}_freight_interaction"] = rate * result.freight_to_price
    return result


def build_variant(name):
    from promiseops.presentation_study import engineering as transform

    mode, strength = VARIANTS[name]
    model = approaches.build("logistic_regression", with_history=True).set_params(model__C=strength)
    numeric = model.named_steps["preprocess"].transformers[0][2]
    if mode in ("rates", "nonlinear_rates"):
        numeric[:] = [name for name in numeric if not name.startswith("history_") or name.endswith("rate")]
        numeric.remove("seller_orders_7d")
    if mode.startswith("nonlinear"):
        model.named_steps["engineer"].set_params(func=transform)
        numeric.extend(ADDITIONAL)
    return model


def evaluate(model, x, y):
    risk = approaches.risk(model, x).to_numpy()
    return metrics.evaluate(list(x.index), y.tolist(), risk.tolist()), risk


def choose(inner, variant_names=None):
    """Predeclared aggregate rule, with AP/Brier and worst-window safeguards."""
    aggregate = {}
    for name in (VARIANTS if variant_names is None else variant_names):
        rows = [fold["models"][name] for fold in inner]
        aggregate[name] = {key: float(np.mean([r[key] for r in rows]))
                           for key in ("recall_at_10", "pr_auc", "brier")}
        aggregate[name]["worst_recall"] = min(r["recall_at_10"] for r in rows)
    reference = aggregate["reference"]
    eligible = [name for name, row in aggregate.items()
                if row["pr_auc"] >= reference["pr_auc"] - .02
                and row["brier"] <= reference["brier"] + .005
                and row["worst_recall"] >= reference["worst_recall"] - .02]
    selected = min(eligible, key=lambda name: (-aggregate[name]["recall_at_10"],
                                              -aggregate[name]["pr_auc"], aggregate[name]["brier"], name))
    return selected, aggregate


def study(connection, progress, persist, lock_selection, variants=None, builder=None, feature_loader=None, comparison_builder=None):
    variants = VARIANTS if variants is None else variants
    builder = build_variant if builder is None else builder
    feature_loader = features.load_features_with_history if feature_loader is None else feature_loader
    labels = cohorts.load_labels(connection, as_of=CUTOFFS.as_of)
    labels = labels[labels.approved_at <= CUTOFFS.validation_end].copy()
    target = labels.set_index("order_id").late
    inner = []
    for index, (t, v) in enumerate(INNER):
        train = cohorts.select_window(labels, start=None, end=t, label_cutoff=t)
        validation = cohorts.select_window(labels, start=t, end=v, label_cutoff=CUTOFFS.train_end)
        for phase, ids in (("inner_train", train), ("inner_validation", validation)):
            cohorts.require_sufficient(phase, labels, ids)
        x = feature_loader(connection, train + validation, as_of=CUTOFFS.as_of, freeze_at=t)
        tx, vx = x.loc[list(train)], x.loc[list(validation)]
        ty, vy = target.loc[tx.index].astype(bool), target.loc[vx.index].astype(bool)
        results = {}
        for name in variants:
            progress(f"inner_{index}.{name}", {"status": "started"})
            fitted = builder(name).fit(tx, ty.to_numpy())
            values, _ = evaluate(fitted, vx, vy)
            results[name] = values.model_dump()
            progress(f"inner_{index}.{name}", results[name])
        inner.append({"train_end": t, "validation_end": v, "label_cutoff": CUTOFFS.train_end.isoformat(),
                      "train": cohorts.describe(labels, train), "validation": cohorts.describe(labels, validation),
                      "models": results})
    selected, aggregate = choose(inner, variants)
    lock_selection({"selected": selected, "aggregate": aggregate, "outer_validation_evaluated": False})
    split = cohorts.split(labels, CUTOFFS)
    table = feature_loader(connection, split.train + split.validation,
                                               as_of=CUTOFFS.as_of, freeze_at=CUTOFFS.train_end)
    tx, vx = table.loc[list(split.train)], table.loc[list(split.validation)]
    ty, vy = target.loc[tx.index].astype(bool), target.loc[vx.index].astype(bool)
    fitted = {}
    for name in dict.fromkeys(("reference", selected)):
        progress(f"outer.{name}", {"status": "started"})
        fitted[name] = builder(name).fit(tx, ty.to_numpy())
    for name in ("baseline", "hist_gradient_boosting"):
        comparison = approaches.build(name, with_history=True) if comparison_builder is None else comparison_builder(name)
        fitted[name] = comparison.fit(tx, ty.to_numpy())
    results, risks = {}, {}
    for name, model in fitted.items():
        value, risk = evaluate(model, vx, vy)
        train_value, _ = evaluate(model, tx, ty)
        results[name] = {"validation": value.model_dump(), "apparent_train": train_value.model_dump(),
                         "mean_risk": float(risk.mean()), "hyperparameters": approaches.hyperparameters(model)}
        persist(name, model, vx, vy, risk)
        risks[name] = risk
        progress(f"outer.{name}", value.model_dump())
    decision = gates.apply_gates(bundle.EvaluationMetrics(**results[selected]["validation"]),
                                 bundle.EvaluationMetrics(**results["reference"]["validation"]))
    return {"dataset_kind": "real_olist", "test_used": False, "registry_or_production_changed": False,
            "inner_selection": inner, "inner_aggregate": aggregate, "selected": selected,
            "selection_uses_outer_validation": False, "cutoffs": CUTOFFS.model_dump(mode="json"),
            "dataset_identity": data.dataset_identity(connection, as_of=CUTOFFS.as_of),
            "train": cohorts.describe(labels, split.train), "validation": cohorts.describe(labels, split.validation),
            "results": results, "candidate_gate": {"decision": decision.decision, "reasons": decision.reasons},
            "paired_recall_difference": recall_difference(vx.index, vy, risks[selected], risks["reference"]),
            "software_versions": bundle.collect_software_versions(),
            "limitations": ["Outer validation has been inspected in earlier work; this is not an untouched final test.",
                            "Inner windows overlap and label maturity differs; uncertainty is not a future-performance guarantee.",
                            "Experimental variant needs versioned approach configuration before default worker integration."]}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--family", choices=("linear", "forest", "duration"), default="linear")
    args = parser.parse_args(argv)
    client, run_id = None, None
    try:
        commit = tracking.source_commit_from_env(os.environ)
        if commit is None:
            raise ValueError("CI_COMMIT_SHA required")
        variants, builder = VARIANTS, build_variant
        loader, comparison = None, None
        if args.family == "forest":
            from promiseops.forest_presentation import FORESTS, build_forest

            variants, builder = FORESTS, build_forest
        if args.family == "duration":
            from promiseops.duration_features import (
                DURATION_VARIANTS,
                build_duration,
                comparison_model,
                load_duration_features,
            )

            variants, builder, loader, comparison = DURATION_VARIANTS, build_duration, load_duration_features, comparison_model
        hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(Path(__file__).parent.glob("*.py"))}
        plan = {"base_commit": commit, "source_sha256": hashes, "family": args.family, "variants": variants, "inner": INNER,
                "cutoffs": CUTOFFS.model_dump(mode="json"), "seed": 0, "test_used": False,
                "selection": "inner mean recall; AP drop<=.02; Brier increase<=.005; worst recall drop<=.02"}
        client = tracking.create_client(tracking.TrackingConfig.from_env(os.environ))
        exp = tracking.ensure_experiment(client, EXPERIMENT)
        run_id = client.create_run(exp, tags=tracking.run_tags("presentation-study", commit)).info.run_id
        client.log_text(run_id, json.dumps(plan, indent=2), "plan-before-fit.json")

        def progress(key, result):
            client.log_text(run_id, json.dumps(result), f"checks/{key}-{'started' if 'status' in result else 'finished'}.json")
            print(json.dumps({"check": key, "result": result}), flush=True)

        def lock_selection(result):
            client.log_text(run_id, json.dumps(result, indent=2), "selection-before-outer-validation.json")

        def persist(name, model, x, y, risk):
            with tempfile.TemporaryDirectory() as folder:
                path = Path(folder) / f"{name}.joblib"
                joblib.dump(model, path)
                client.log_artifact(run_id, str(path), "experimental-models")
                saved = client.download_artifacts(run_id, f"experimental-models/{path.name}")
                np.testing.assert_allclose(model.predict_proba(x.iloc[:10]), joblib.load(saved).predict_proba(x.iloc[:10]), rtol=0, atol=1e-12)
                client.log_text(run_id, json.dumps({"artifact_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                                                     "feature_names": list(x.columns), "source_commit": commit}),
                                f"experimental-models/{name}.metadata.json")
                evidence = x.copy()
                evidence["late"], evidence["risk"] = y, risk
                output = Path(folder) / f"{name}.parquet"
                evidence.to_parquet(output)
                client.log_artifact(run_id, str(output), "validation-evidence")

        with db.connect() as connection:
            connection.execute("SET default_transaction_read_only=on")
            report = study(connection, progress, persist, lock_selection, variants, builder, loader, comparison)
        if hashes != {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(Path(__file__).parent.glob("*.py"))}:
            raise ValueError("source changed during study")
        report = json.loads(json.dumps({**report, "plan": plan, "mlflow_run_id": run_id}))
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
        values = {f"{name}.{k}": v for name, result in report["results"].items() for k, v in result["validation"].items()}
        experiment_log.log_report(client, experiment=EXPERIMENT, kind="presentation-study", source_commit=commit,
                                 report=report, params={"selected": report["selected"], "family": args.family, "test_used": "false"},
                                 metrics=values, run_id=run_id)
        print(json.dumps({"status": "ok", "mlflow_run_id": run_id, "selected": report["selected"]}))
        return 0
    # CLI boundary must sanitize third-party failures and return a nonzero exit code.
    except Exception as error:  # noqa: BLE001
        if client is not None and run_id is not None:
            tracking.close_failed_run(client, run_id, error)
        print(tracking.redact_error(error), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
