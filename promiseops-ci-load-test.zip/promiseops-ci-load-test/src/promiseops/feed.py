"""Feed reading: which batch files exist, in which order, and are their bytes intact?

Contract (docs/CONTRACTS.md): ``GET /feed`` lists entries, each with ``payload_sha256`` (over
canonical JSON) and ``file_sha256`` (over the file bytes) — two different checksums. Entries are
processed in publication order, orders before outcomes at an equal timestamp. An optional
``as_of`` selects entries published at or before it (team-controlled replay).

This module only *reads* (a local folder today: the extracted ``olist-course-data`` package; the
company gateway later, from the Airflow DAG). It never writes to the database, so the ingestion
logic in ``promiseops.data`` does not depend on where batches come from.

Index layout, verified against GitLab package ``olist-course-data`` 2026.11.06
(``student-company-feed.zip``, sha256 698c6d30...a9ffb): a ``manifest.json`` next to the batch
files, with the entries under ``"releases"``; each entry has ``file``, ``kind``, ``available_at``,
``payload_sha256``, ``file_sha256`` (+ row counts we do not need: the checksums already protect the
content). The gateway's ``GET /feed`` response lists ``"entries"`` (CONTRACTS.md); both are accepted.
"""

import json
from collections.abc import Iterable
from datetime import datetime
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

from promiseops.contracts import digest, instant
from promiseops.validation import (
    BatchRejected,
    ExpectedMetadata,
    check_file_sha256,
    decode_document,
    metadata_problems,
)

DEFAULT_INDEX_NAME = "manifest.json"
# "releases": the course data package manifest; "entries": the company gateway GET /feed response.
_ENTRY_LIST_KEYS = ("releases", "entries")
_SHA256 = r"^[a-f0-9]{64}$"
# File names in the index must be plain relative names: no "..", no absolute paths, no backslashes.
_SAFE_FILE = r"^[A-Za-z0-9][A-Za-z0-9_.-]*(/[A-Za-z0-9][A-Za-z0-9_.-]*)*$"
# At an equal publication time, orders must be committed before the outcomes that reference them.
_KIND_RANK = {"orders": 0, "outcomes": 1}


class FeedEntry(BaseModel):
    """One published batch file as listed by the feed index.

    ``extra="ignore"`` (unlike batch rows, which forbid unknown columns): the index is metadata
    from the gateway and may carry fields we do not use; the batch *content* is still strict.
    """

    model_config = ConfigDict(extra="ignore", frozen=True)

    file: str = Field(pattern=_SAFE_FILE, max_length=256)
    kind: Literal["orders", "outcomes"]
    available_at: datetime
    payload_sha256: str = Field(pattern=_SHA256)
    file_sha256: str = Field(pattern=_SHA256)
    batch_id: str | None = None

    @field_validator("available_at")
    @classmethod
    def _aware(cls, value: datetime) -> datetime:
        return instant(value)

    def expected(self) -> ExpectedMetadata:
        """What this entry claims about its payload; ``ingest_batch`` rejects a disagreeing payload."""
        return ExpectedMetadata(kind=self.kind, available_at=self.available_at, batch_id=self.batch_id)


def load_index(path: str | Path) -> list[FeedEntry]:
    """Read the feed index, in listed order.

    Accepts ``{"releases": [...]}`` (package manifest), ``{"entries": [...]}`` (gateway) or a bare list.
    An object with both keys is refused: we could not know which list is the real one.
    """
    document = json.loads(Path(path).read_text(encoding="utf-8"))
    if isinstance(document, list):
        entries = document
    elif isinstance(document, dict) and sum(key in document for key in _ENTRY_LIST_KEYS) == 1:
        entries = next(document[key] for key in _ENTRY_LIST_KEYS if key in document)
    else:
        entries = None
    if not isinstance(entries, list):
        raise TypeError(f"{path}: expected a list, or an object with exactly one of {_ENTRY_LIST_KEYS}")
    return [FeedEntry.model_validate(entry) for entry in entries]


def publication_order(entries: Iterable[FeedEntry]) -> list[FeedEntry]:
    """Sort by publication time, orders before outcomes at an equal time, then listed order.

    The final tie-breaker (original position) keeps the sort stable and therefore reproducible.
    """
    indexed = list(enumerate(entries))
    indexed.sort(key=lambda pair: (pair[1].available_at, _KIND_RANK[pair[1].kind], pair[0]))
    return [entry for _, entry in indexed]


def published_until(entries: Iterable[FeedEntry], as_of: datetime | str) -> list[FeedEntry]:
    """Entries whose publication is at or before ``as_of`` (the same rule as ``GET /feed?as_of=``)."""
    cutoff = instant(as_of)
    return [entry for entry in entries if entry.available_at <= cutoff]


def first_inconsistent_entry(feed_dir: str | Path, entries: Iterable[FeedEntry]) -> FeedEntry | None:
    """Pre-flight over the WHOLE index, before it is used for ordering or ``as_of`` filtering.

    Returns the first listed entry whose file is unreadable/corrupted (``file_sha256``), whose
    canonical JSON digest differs from ``payload_sha256``, or whose payload ``kind`` /
    ``available_at`` / ``batch_id`` disagrees with the index; ``None`` if all agree.
    Entries published after ``as_of`` are checked too: they are not passed to ``ingest_batch`` in this
    run, so without this their checksums would never be verified, and an index that shows a batch as
    "later" than its payload would make it silently skipped. This only DETECTS; the caller passes
    that entry to ``ingest_batch``, which gives the exact reason and records/quarantines it like any
    rejection. The JSON is read with the same strict rules as ingestion (``decode_document``).
    Cost: every file is read, parsed and hashed once (a few seconds for the whole course feed).
    """
    for entry in entries:
        try:
            raw = read_entry(feed_dir, entry)
            check_file_sha256(raw, entry.file_sha256)
            document = decode_document(raw)
            if digest(document) != entry.payload_sha256:
                return entry
            envelope = document if isinstance(document, dict) else {}
            if metadata_problems(batch_id=envelope.get("batch_id"), kind=envelope.get("kind"),
                                 available_at=envelope.get("available_at"), expected=entry.expected()):
                return entry
        except (OSError, ValueError, BatchRejected):  # missing file, unsafe path, bad JSON, file checksum
            return entry
    return None


def read_entry(feed_dir: str | Path, entry: FeedEntry) -> bytes:
    """Return the raw bytes of an entry's file.

    The checksums are NOT checked here on purpose: ``promiseops.data.ingest_batch`` checks both
    ``file_sha256`` and ``payload_sha256``, so every rejection — including a corrupted file — goes
    through one path that records the attempt and quarantines the bytes.
    """
    root = Path(feed_dir).resolve()
    path = (root / entry.file).resolve()
    if root not in path.parents:
        # Defence in depth: the pattern already forbids "..", this also catches symlink escapes.
        raise ValueError(f"feed entry {entry.file!r} points outside the feed folder")
    return path.read_bytes()
