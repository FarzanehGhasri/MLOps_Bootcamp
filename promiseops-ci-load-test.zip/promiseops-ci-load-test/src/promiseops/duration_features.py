"""Past-known delivery-duration aggregates, never the target order's delivery outcome."""

import numpy as np
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer

from promiseops import approaches, cohorts, features
from promiseops.contracts import LOCAL_TZ, instant
from promiseops.history_features import load_order_groups

DURATION_COLUMNS = tuple(f"duration_{group}_{stat}" for group in ("global", "seller", "customer_state", "route")
                         for stat in ("mean", "std", "promise_z"))
DURATION_VARIANTS = {"reference": {"C": .05, "duration": False},
                     "duration_C01": {"C": .01, "duration": True},
                     "duration_C05": {"C": .05, "duration": True}}


def duration_stats(groups, labels, base, *, freeze_at):
    """Smoothed first/second moments at strictly earlier knowledge times; fixed cold-start prior."""
    source = groups.set_index("order_id").copy()
    source["approved_at"] = pd.to_datetime(source.approved_at, utc=True)
    known = labels[labels.delivered_at.notna() & labels.label_available_at.notna()].set_index("order_id")
    events = source.join(known[["delivered_at", "label_available_at"]], how="inner")
    if (events.label_available_at <= events.approved_at).any():
        raise ValueError("duration outcome must become known after its own approval")
    delivered = events.delivered_at.dt.tz_convert(LOCAL_TZ).dt.tz_localize(None).dt.normalize()
    approved = events.approved_at.dt.tz_convert(LOCAL_TZ).dt.tz_localize(None).dt.normalize()
    events["duration"] = (delivered - approved).dt.days.astype(float)
    if (events.duration < 0).any():
        raise ValueError("negative historical delivery duration")
    query = source.loc[base.index].copy()
    query["global"], events["global"] = "all", "all"
    time = query.approved_at.clip(upper=instant(freeze_at))
    output = pd.DataFrame(index=base.index)
    for group in ("global", "seller", "customer_state", "route"):
        count, total, squared = (np.zeros(len(query)) for _ in range(3))
        for key, positions in query.groupby(group).indices.items():
            past = events[events[group] == key].sort_values("label_available_at")
            times = past.label_available_at.dt.as_unit("ns").astype("int64").to_numpy()
            right = np.searchsorted(times, time.iloc[positions].dt.as_unit("ns").astype("int64"), side="left")
            duration = past.duration.to_numpy()
            count[positions] = right
            total[positions] = np.r_[0., duration.cumsum()][right]
            squared[positions] = np.r_[0., (duration ** 2).cumsum()][right]
        prior_mean = 15. if group == "global" else output.duration_global_mean.to_numpy()
        prior_second = 325. if group == "global" else (
            output.duration_global_mean.to_numpy() ** 2 + output.duration_global_std.to_numpy() ** 2)
        mean = (total + 20 * prior_mean) / (count + 20)
        second = (squared + 20 * prior_second) / (count + 20)
        std = np.sqrt(np.maximum(second - mean ** 2, 1.))
        output[f"duration_{group}_mean"] = mean
        output[f"duration_{group}_std"] = std
        output[f"duration_{group}_promise_z"] = (base.promise_days.to_numpy() - mean) / std
    return output[list(DURATION_COLUMNS)]


def load_duration_features(connection, order_ids, *, as_of, freeze_at):
    base = features.load_features_with_history(connection, order_ids, as_of=as_of, freeze_at=freeze_at)
    labels = cohorts.load_labels(connection, as_of=as_of)
    groups = load_order_groups(connection, labels.order_id.tolist())
    return base.join(duration_stats(groups, labels, base, freeze_at=freeze_at))


def base_columns(table):
    return table[list(features.EXTENDED_FEATURE_NAMES)]


def comparison_model(name):
    from promiseops.duration_features import base_columns as transform

    return Pipeline([("base_schema", FunctionTransformer(transform, validate=False)),
                     ("pipeline", approaches.build(name, with_history=True))])


def build_duration(name):
    config = DURATION_VARIANTS[name]
    if not config["duration"]:
        return comparison_model("logistic_regression")
    model = approaches.build("logistic_regression", with_history=True).set_params(model__C=config["C"])
    model.named_steps["preprocess"].transformers[0][2].extend(DURATION_COLUMNS)
    return model
