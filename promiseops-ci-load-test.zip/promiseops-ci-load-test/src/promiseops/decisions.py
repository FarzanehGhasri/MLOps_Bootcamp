"""Monitoring decisions in PostgreSQL: written by monitor-train, read by the API for /metrics.

MLflow keeps the full monitoring report (promiseops.monitor_train). Prometheus only scrapes the API
pods, so the one value the staff alert ``RetrainingRecommended`` needs
(``promiseops_retraining_required``) is mirrored here: one row per monitoring run, written only
after that run is FINISHED in MLflow and read back (a run that fails finalization publishes nothing).

Which decisions may change the alert
------------------------------------
Only conclusive ones: ``status = 'assessed'`` AND enough mature labels to judge quality
(``monitor.MIN_MATURE_ORDERS``, both classes). A run without reference, without recorded prediction
history, or with too few mature labels cannot show that the model recovered, so its "no retrain"
neither clears an existing alert nor counts as a first decision. Such runs are still stored, for
audit. Automatic training stays suppressed in those runs either way (promiseops.monitor).
"""

from datetime import datetime
from typing import Any, Protocol

import psycopg


class Decision(Protocol):
    """The fields of ``monitor_train.MonitoringRecord`` stored here (no import: the API stays light)."""

    as_of: datetime
    incumbent_model_version: str
    status: str
    retrain_recommended: bool
    reasons: list[str]
    report: Any   # monitor.MonitoringReport | None; only ``report.labels.sufficient`` is read


def labels_sufficient(record: Decision) -> bool:
    """True when the run had enough mature labels to judge the model (False without a report)."""
    return record.status == "assessed" and record.report is not None and bool(record.report.labels.sufficient)


def record_decision(connection: psycopg.Connection, monitoring_run_id: str, record: Decision) -> None:
    """Store one monitoring run's decision. A retried run (same id) keeps its first row."""
    connection.execute(
        "INSERT INTO promiseops.monitoring_decisions (monitoring_run_id, as_of, incumbent_model_version, "
        "status, retrain_recommended, labels_sufficient, reasons_count) VALUES (%s, %s, %s, %s, %s, %s, %s) "
        "ON CONFLICT (monitoring_run_id) DO NOTHING",
        (monitoring_run_id, record.as_of, record.incumbent_model_version, record.status,
         record.retrain_recommended, labels_sufficient(record), len(record.reasons)),
    )


def latest_retrain_recommended(connection: psycopg.Connection, model_version: str) -> bool | None:
    """The newest conclusive decision (by as_of) about ``model_version``; None when there is none.

    Only decisions about the served model count: after a retrained model is deployed, the old
    model's recommendation must not keep the alert firing.
    """
    row = connection.execute(
        "SELECT retrain_recommended FROM promiseops.monitoring_decisions "
        "WHERE incumbent_model_version = %s AND status = 'assessed' AND labels_sufficient "
        "ORDER BY as_of DESC, recorded_at DESC LIMIT 1",
        (model_version,),
    ).fetchone()
    return None if row is None else bool(row[0])
