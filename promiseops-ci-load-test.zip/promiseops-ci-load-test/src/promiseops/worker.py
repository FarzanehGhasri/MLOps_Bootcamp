"""Required entry point invoked by the staff's bounded Job dispatcher.

    python -m promiseops.worker --mode train|monitor-train --train-end ... --validation-end ... --as-of ...

This module only ADAPTS the Job to the code: it reads the command line and the environment, opens the
database and the MLflow client, runs one mode and turns the outcome into a log line and an exit code.
The steps themselves are in promiseops.training (train, #15) and promiseops.monitor_train
(monitor-train, #21): single responsibility, testable without a Job.

Environment (docs/CONTRACTS.md, "Queued worker interface"):
    PROMISEOPS_DATABASE_URL   own-team PostgreSQL                         required
    MLFLOW_TRACKING_URI       own-team MLflow                             required
    CI_COMMIT_SHA             commit the image was built from (lineage)   required
    PROMISEOPS_ARTIFACTS      writable folder, default /tmp/artifacts
    PROMISEOPS_INCUMBENT      trusted serving bundle, default /opt/promiseops/release (local runs override it)
    PROMISEOPS_PREDICTION_HISTORY  optional explicit JSONL; otherwise export recorded snapshots from own-team DB

Exit codes: 0 = the mode completed: a candidate was trained and logged (accepted OR rejected: rejection is
a valid outcome), or a monitoring report was persisted (with or without retraining); 1 = failed (the error is printed; the MLflow run, if created, is marked FAILED with the reason).
Neither mode deploys production or changes its model alias.
Walkthrough (Persian): docs/model/04-worker-train.fa.md, docs/model/06-worker-monitor-train.fa.md
"""

import argparse
import json
import os
import sys
from collections.abc import Mapping, Sequence
from pathlib import Path

from promiseops import cohorts, db, monitor_train, tracking, training

ARTIFACTS_ENV = "PROMISEOPS_ARTIFACTS"
INCUMBENT_ENV = "PROMISEOPS_INCUMBENT"
PREDICTION_HISTORY_ENV = "PROMISEOPS_PREDICTION_HISTORY"


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(prog="python -m promiseops.worker")
    parser.add_argument("--mode", choices=["train", "monitor-train"], default="train")
    for name in ("train-end", "validation-end", "as-of"):
        parser.add_argument("--" + name, required=True)
    return parser.parse_args(argv)


def settings_from_env(environ: Mapping[str, str]) -> training.TrainingSettings:
    """Everything the run needs from the environment, checked before any work starts."""
    commit = tracking.source_commit_from_env(environ)
    if commit is None:
        # Without it the model cannot be traced back to its code: the contract's record would be incomplete.
        raise tracking.TrackingConfigError(f"{tracking.COMMIT_ENV} is not set; the worker needs the source commit")
    return training.TrainingSettings(
        source_commit=commit,
        artifacts=Path(environ.get(ARTIFACTS_ENV) or training.DEFAULT_ARTIFACTS),
        incumbent=Path(environ.get(INCUMBENT_ENV) or training.DEFAULT_INCUMBENT),
    )


def main(argv: Sequence[str] | None = None, environ: Mapping[str, str] | None = None) -> int:
    args = parse_args(argv)
    environ = os.environ if environ is None else environ
    try:
        # All inputs are validated before connecting anywhere: a bad call fails in milliseconds.
        cutoffs = cohorts.Cutoffs(train_end=args.train_end, validation_end=args.validation_end, as_of=args.as_of)
        settings = settings_from_env(environ)
        client = tracking.create_client(tracking.TrackingConfig.from_env(environ))
        with db.connect(environ.get(db.DATABASE_URL_ENV)) as connection:
            db.require_schema(connection)
            if args.mode == "monitor-train":   # report persisted first; trains only if recommended
                history = environ.get(PREDICTION_HISTORY_ENV)
                result = monitor_train.run_monitor_train(
                    connection, client, settings, cutoffs=cutoffs,
                    prediction_history=Path(history) if history else None)
            else:
                result = training.run_train(connection, client, settings, cutoffs=cutoffs)
    except Exception as error:  # noqa: BLE001  (one place that turns any failure into exit code 1)
        # Third-party errors can contain credentialed database or tracking URLs. Do not print
        # the raw exception chain: keep one sanitized, machine-readable failure record.
        print(json.dumps({"mode": args.mode, "status": "failed",
                          "error": f"{type(error).__name__}: {tracking.redact_error(error)}"}),
              file=sys.stderr)
        return 1
    print(json.dumps({"status": "ok", **result.summary()}, sort_keys=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())
