"""DAG behavior tests with a stub Airflow (docs/CONTRACTS.md §11, doc §13.1).

The repo's CI has no Airflow, so the DAG files are imported against a fake
``airflow.sdk``/``airflow.exceptions``: the ``dag`` decorator wires the task
graph (stub tasks return nodes and never execute at import), and the task
bodies are then called directly with a controlled context. This verifies the
three DAGs' structure, the exact POST /training payload (CONTRACTS.md "Queued
worker interface"), the request_id stability per DagRun, and the ingest exit
code handling — without Airflow, network or database.
"""

import json
import os
import sys
import types
from collections.abc import Mapping
from datetime import UTC, datetime
from pathlib import Path
from types import SimpleNamespace

import pytest

_REPOSITORY = Path(__file__).resolve().parents[1]
DAGS_DIR = _REPOSITORY / "dags"


class _StubAsset:
    def __init__(self, name):
        self.name = name
        self.uri = name

    def __hash__(self):
        return hash(self.name)

    def __eq__(self, other):
        return isinstance(other, _StubAsset) and self.name == other.name

    def __repr__(self):
        return f"Asset({self.name!r})"


class _StubParam:
    def __init__(self, default=None, **kwargs):
        self.default = default
        self.kwargs = kwargs


class _StubDag:
    def __init__(self, dag_id, kwargs):
        self.dag_id = dag_id
        self.schedule = kwargs.get("schedule")
        self.params = kwargs.get("params") or {}
        self.catchup = kwargs.get("catchup")
        self.max_active_runs = kwargs.get("max_active_runs")
        self.description = kwargs.get("description")
        self.tags = kwargs.get("tags") or []


class _StubTaskNode:
    def __init__(self, name, fn, kwargs):
        self.name = name
        self.fn = fn
        self.kwargs = kwargs

    def __call__(self, *args, **kwargs):
        # Airflow 3 task proxies wire dependencies when called with upstream
        # nodes; the stub returns a placeholder node without executing.
        return _StubTaskNode(f"{self.name}()", self.fn, self.kwargs)


# (dag_id, task_name) -> _StubTaskNode, filled while the DAG bodies are wired.
_TASKS: dict[tuple[str, str], _StubTaskNode] = {}
_CURRENT_DAG: list[str] = []


def _stub_task(*t_args, **t_kwargs):
    if len(t_args) == 1 and callable(t_args[0]) and not t_kwargs:
        return _make_task_node(t_args[0], {})

    def decorator(fn):
        return _make_task_node(fn, t_kwargs)

    return decorator


def _make_task_node(fn, t_kwargs):
    node = _StubTaskNode(fn.__name__, fn, t_kwargs)
    if _CURRENT_DAG:
        _TASKS[(_CURRENT_DAG[-1], fn.__name__)] = node
    return node


def _stub_dag(**d_kwargs):
    def decorator(fn):
        def wrapper():
            dag_id = d_kwargs.get("dag_id") or fn.__name__
            _CURRENT_DAG.append(dag_id)
            try:
                fn()
            finally:
                _CURRENT_DAG.pop()
            return _StubDag(dag_id, d_kwargs)

        return wrapper

    return decorator


def _install_airflow_stub():
    for name in [key for key in sys.modules if key == "airflow" or key.startswith("airflow.")]:
        del sys.modules[name]
    airflow = types.ModuleType("airflow")
    sdk = types.ModuleType("airflow.sdk")
    exceptions = types.ModuleType("airflow.exceptions")

    class StubVariable:
        @staticmethod
        def get(name):
            raise KeyError(f"Airflow Variable {name!r} is not configured in tests")

    class StubAirflowException(Exception):
        pass

    class StubAirflowFailException(StubAirflowException):
        pass

    class StubAirflowSkipException(StubAirflowException):
        pass

    sdk.Asset = _StubAsset
    sdk.Param = _StubParam
    sdk.Variable = StubVariable
    sdk.dag = _stub_dag
    sdk.task = _stub_task
    exceptions.AirflowException = StubAirflowException
    exceptions.AirflowFailException = StubAirflowFailException
    exceptions.AirflowSkipException = StubAirflowSkipException
    airflow.sdk = sdk
    airflow.exceptions = exceptions
    sys.modules["airflow"] = airflow
    sys.modules["airflow.sdk"] = sdk
    sys.modules["airflow.exceptions"] = exceptions


_install_airflow_stub()
sys.path.insert(0, str(DAGS_DIR))

import ingest as ingest_dag_module
import promiseops_gateway as gateway
import train as train_dag_module

INGEST_DAG = ingest_dag_module.ingest_feed_dag
TRAINING_DAG = train_dag_module.training_dag
MONITOR_TRAIN_DAG = train_dag_module.monitor_train_dag
ALL_DAGS = (INGEST_DAG, TRAINING_DAG, MONITOR_TRAIN_DAG)


def _task(dag_id, name):
    return _TASKS[(dag_id, name)]


def test_dag_ids_and_schedules_match_the_contract():
    assert INGEST_DAG.dag_id == "promiseops_ingest_feed"
    assert INGEST_DAG.schedule == "@daily"
    assert TRAINING_DAG.schedule == [ingest_dag_module.INGESTED_ASSET]
    assert MONITOR_TRAIN_DAG.schedule == "@weekly"
    for dag in ALL_DAGS:
        assert dag.catchup is False and dag.max_active_runs == 1
        assert "promiseops" in dag.tags


def test_ingest_dag_retries_and_asset_outlet():
    resolve = _task("promiseops_ingest_feed", "resolve_feed")
    ingest = _task("promiseops_ingest_feed", "ingest")
    assert resolve.kwargs == {}
    assert ingest.kwargs["retries"] == 2
    assert ingest.kwargs["outlets"] == [ingest_dag_module.INGESTED_ASSET]


def test_training_dag_params_and_cutoff_defaults():
    for dag in (TRAINING_DAG, MONITOR_TRAIN_DAG):
        assert set(dag.params) == {"as_of", "train_end", "validation_end", "image", "source_commit"}
        assert dag.params["train_end"].default is None
        assert dag.params["validation_end"].default is None
        assert dag.params["as_of"].default is None


def test_scheduler_never_fits_the_model():
    for name in ("ingest.py", "train.py", "promiseops_gateway.py"):
        source = (DAGS_DIR / name).read_text(encoding="utf-8")
        for forbidden in ("promiseops.training", "promiseops.monitor_train", "sklearn", "pandas", "numpy"):
            assert forbidden not in source, f"{name} must not {forbidden} in the scheduler"


def test_ingest_task_zero_exit_returns_receipts(monkeypatch):
    monkeypatch.setattr(gateway, "fetch_feed", lambda *args: None)
    receipt = {"batch_id": "orders-1", "status": "committed"}
    monkeypatch.setattr(gateway, "run_cli", lambda args: SimpleNamespace(
        returncode=0, stdout=json.dumps(receipt) + "\n", stderr=""))
    node = _task("promiseops_ingest_feed", "ingest")
    assert node.fn({"as_of": "2018-01-01T00:00:00Z", "dir": "/tmp/feed"}) == {
        "as_of": "2018-01-01T00:00:00Z", "receipts": [receipt]}


def test_ingest_task_rejected_batch_is_not_retried(monkeypatch):
    from airflow.exceptions import AirflowFailException

    monkeypatch.setattr(gateway, "fetch_feed", lambda *args: None)
    monkeypatch.setattr(gateway, "run_cli", lambda args: SimpleNamespace(
        returncode=3, stdout="", stderr="batch rejected"))
    with pytest.raises(AirflowFailException):
        _task("promiseops_ingest_feed", "ingest").fn({"as_of": "2018-01-01T00:00:00Z", "dir": "/tmp/feed"})


def test_ingest_task_transient_failure_is_retryable(monkeypatch):
    from airflow.exceptions import AirflowException, AirflowFailException

    monkeypatch.setattr(gateway, "fetch_feed", lambda *args: None)
    monkeypatch.setattr(gateway, "run_cli", lambda args: SimpleNamespace(
        returncode=1, stdout="", stderr="boom"))
    with pytest.raises(AirflowException) as raised:
        _task("promiseops_ingest_feed", "ingest").fn({"as_of": "2018-01-01T00:00:00Z", "dir": "/tmp/feed"})
    assert not isinstance(raised.value, AirflowFailException)


def test_resolve_feed_prefers_explicit_company_time_and_never_uses_wall_clock(monkeypatch):
    monkeypatch.setattr(gateway, "variable", lambda name: "2018-02-01T00:00:00Z")
    node = _task("promiseops_ingest_feed", "resolve_feed")
    assert node.fn(params={"as_of": "2018-01-01T00:00:00Z"}) == {"as_of": "2018-01-01T00:00:00Z"}
    assert node.fn(params={"as_of": None}, data_interval_end=datetime(2026, 11, 20, tzinfo=UTC)) == {
        "as_of": "2018-02-01T00:00:00Z"}


def _submit(monkeypatch, dag_id, dag_run, *, image=None, commit=None):
    node = _task(dag_id, "submit_job")
    overrides = {"image": image, "source_commit": commit}
    param_for_variable = {"promiseops_worker_image": "image", "promiseops_worker_commit": "source_commit"}
    captured = {}
    defaults = {"promiseops_worker_image": "registry/app@sha256:" + "1" * 64,
                "promiseops_worker_commit": "a" * 40}
    monkeypatch.setattr(gateway, "variable",
                        lambda name: overrides[param_for_variable[name]] or defaults[name])
    monkeypatch.setattr(gateway, "submit_training", lambda body: captured.setdefault("payload", body)
                        and {"job_name": "worker-1", "namespace": "g03-jobs"})
    cutoffs = {"train_end": "2017-10-31T23:59:59Z", "validation_end": "2017-12-31T23:59:59Z",
               "as_of": "2018-01-01T00:00:00Z", "dataset_identity": "receipts-sha256:x",
               **gateway.worker_reference(overrides)}
    context = {"dag_run": dag_run, "params": overrides}
    return node.fn(cutoffs, **context), captured["payload"]


def test_submit_job_payload_matches_the_queued_worker_contract(monkeypatch):
    dag_run = SimpleNamespace(dag_id="promiseops_training", run_id="scheduled__2026-11-18T00:00:00")
    result, payload = _submit(monkeypatch, "promiseops_training", dag_run)
    assert set(payload) == {"image", "source_commit", "train_end", "validation_end", "as_of",
                            "mode", "request_id"}
    assert payload["mode"] == "train"
    assert payload["image"] == "registry/app@sha256:" + "1" * 64
    assert payload["source_commit"] == "a" * 40
    assert payload["request_id"] == gateway.request_id_for(dag_run.dag_id, dag_run.run_id)
    assert result == {"request_id": payload["request_id"], "mode": "train",
                      "as_of": payload["as_of"], "job": {"job_name": "worker-1", "namespace": "g03-jobs"}}


def test_monitor_train_dag_submits_the_monitor_mode(monkeypatch):
    dag_run = SimpleNamespace(dag_id="promiseops_monitor_train", run_id="manual__2026-11-19T00:00:00")
    _, payload = _submit(monkeypatch, "promiseops_monitor_train", dag_run)
    assert payload["mode"] == "monitor-train"
    assert payload["request_id"] == gateway.request_id_for(dag_run.dag_id, dag_run.run_id)


def test_request_id_is_reused_across_retries_of_the_same_dag_run(monkeypatch):
    dag_run = SimpleNamespace(dag_id="promiseops_training", run_id="scheduled__2026-11-18T00:00:00")
    _, first = _submit(monkeypatch, "promiseops_training", dag_run)
    _, retry = _submit(monkeypatch, "promiseops_training", dag_run)
    _, other = _submit(monkeypatch, "promiseops_training",
                       SimpleNamespace(dag_id="promiseops_training", run_id="scheduled__2026-11-19T00:00:00"))
    assert first["request_id"] == retry["request_id"]
    assert first["request_id"] != other["request_id"]


def test_resolve_cutoffs_validates_locally_and_records_lineage(monkeypatch):
    node = _task("promiseops_training", "resolve_cutoffs")

    def fake_identity(args):
        assert args == ["dataset-identity", "--as-of", "2018-01-01T00:00:00Z"]
        return SimpleNamespace(returncode=0, stdout=json.dumps({"dataset_identity": "receipts-sha256:abc"}),
                               stderr="")

    monkeypatch.setattr(gateway, "run_cli", fake_identity)
    params = {"train_end": "2017-10-31T23:59:59Z", "validation_end": "2017-12-31T23:59:59Z",
              "as_of": "2018-01-01T00:00:00Z", "image": "registry/worker@sha256:" + "1" * 64,
              "source_commit": "a" * 40}
    result = node.fn(params=params)
    assert result["dataset_identity"] == "receipts-sha256:abc"


def test_resolve_cutoffs_rejects_an_inverted_split_before_any_cli_call():
    node = _task("promiseops_training", "resolve_cutoffs")
    with pytest.raises(ValueError):
        node.fn(params={"train_end": "2017-12-31T23:59:59Z", "validation_end": "2017-12-31T23:59:59Z",
                        "as_of": "2018-01-01T00:00:00Z"})


def _capture_cli_run(monkeypatch, gateway_dir, *, with_zip=True):
    if with_zip:
        (gateway_dir / "promiseops.zip").write_bytes(b"PK")
    monkeypatch.setattr(gateway, "__file__", str(gateway_dir / "promiseops_gateway.py"))
    captured = {}

    def fake_run(command, **kwargs):
        captured["command"], captured["env"] = command, kwargs["env"]
        return SimpleNamespace(returncode=0, stdout="", stderr="")

    monkeypatch.setattr(gateway.subprocess, "run", fake_run)
    monkeypatch.setenv("PYTHONPATH", "/pre/existing")
    return captured


def test_run_cli_imports_the_shipped_package_zip_not_the_starter_install(monkeypatch, tmp_path):
    captured = _capture_cli_run(monkeypatch, tmp_path)
    gateway.run_cli(["dataset-identity", "--as-of", "2018-01-01T00:00:00Z"])
    assert captured["command"][0] == sys.executable
    assert captured["command"][1:3] == ["-m", "promiseops.cli"]
    assert captured["env"]["PYTHONPATH"].split(os.pathsep)[:2] == [
        str(tmp_path / "promiseops.zip"), "/pre/existing"]


def test_run_cli_without_a_shipped_zip_leaves_pythonpath_alone(monkeypatch, tmp_path):
    captured = _capture_cli_run(monkeypatch, tmp_path, with_zip=False)
    gateway.run_cli(["dataset-identity", "--as-of", "2018-01-01T00:00:00Z"])
    assert captured["env"]["PYTHONPATH"] == "/pre/existing"


@pytest.mark.parametrize("company_url, expected", [
    ("postgresql+psycopg://app:secret@postgres/app", "postgresql://app:secret@postgres/app"),
    ("postgresql://app:secret@postgres/app", "postgresql://app:secret@postgres/app"),
])
def test_run_cli_translates_the_sqlalchemy_dialect_form_for_psycopg(
        monkeypatch, tmp_path, company_url, expected):
    captured = _capture_cli_run(monkeypatch, tmp_path)
    monkeypatch.setenv(gateway.ENV_DATABASE_URL, company_url)
    monkeypatch.delenv("PROMISEOPS_DATABASE_URL", raising=False)
    gateway.run_cli(["dataset-identity", "--as-of", "2018-01-01T00:00:00Z"])
    assert captured["env"]["PROMISEOPS_DATABASE_URL"] == expected


def test_worker_image_override_beats_the_variable(monkeypatch):
    dag_run = SimpleNamespace(dag_id="promiseops_training", run_id="manual__x")
    _, payload = _submit(monkeypatch, "promiseops_training", dag_run,
                         image="registry/app@sha256:" + "2" * 64, commit="b" * 40)
    assert payload["image"] == "registry/app@sha256:" + "2" * 64
    assert payload["source_commit"] == "b" * 40


def test_successful_ingestion_emits_company_cutoff_and_consumes_files_in_same_task(monkeypatch):
    seen = {}
    event = SimpleNamespace(extra={})
    asset = ingest_dag_module.INGESTED_ASSET
    def fetch(as_of, destination):
        (destination / "manifest.json").write_text("{}")
        seen["folder"] = destination
    def ingest(args):
        assert Path(args[1], "manifest.json").is_file()
        return SimpleNamespace(returncode=0, stdout="", stderr="")
    monkeypatch.setattr(gateway, "fetch_feed", fetch)
    monkeypatch.setattr(gateway, "run_cli", ingest)
    _task("promiseops_ingest_feed", "ingest").fn(
        {"as_of": "2018-04-30T00:00:00Z"}, outlet_events={asset: event})
    assert event.extra == {"as_of": "2018-04-30T00:00:00Z"}
    assert not seen["folder"].exists()


def test_rejected_ingestion_emits_no_success_metadata(monkeypatch):
    from airflow.exceptions import AirflowFailException
    event = SimpleNamespace(extra={})
    monkeypatch.setattr(gateway, "fetch_feed", lambda *a: None)
    monkeypatch.setattr(gateway, "run_cli", lambda *a: SimpleNamespace(returncode=3, stdout="", stderr=""))
    with pytest.raises(AirflowFailException):
        _task("promiseops_ingest_feed", "ingest").fn(
            {"as_of": "2018-04-30T00:00:00Z"}, outlet_events={ingest_dag_module.INGESTED_ASSET: event})
    assert event.extra == {}


def test_training_consumes_triggering_ingestion_time_and_freezes_worker_reference(monkeypatch):
    values = {gateway.VARIABLE_TRAINING_CUTOFFS: json.dumps({"train_end": "2017-12-31T23:59:59Z",
                "validation_end": "2018-02-28T23:59:59Z"}),
              gateway.VARIABLE_WORKER_IMAGE: "registry/worker@sha256:" + "1" * 64,
              gateway.VARIABLE_WORKER_COMMIT: "a" * 40}
    monkeypatch.setattr(gateway, "variable", values.__getitem__)
    monkeypatch.setattr(gateway, "run_cli", lambda args: SimpleNamespace(
        returncode=0, stdout=json.dumps({"dataset_identity": "receipts-sha256:abc"}), stderr=""))
    events = [SimpleNamespace(extra={"as_of": value}) for value in
              ("2018-04-01T00:00:00Z", "2018-04-30T00:00:00Z")]
    cutoffs = _task("promiseops_training", "resolve_cutoffs").fn(
        params={}, triggering_asset_events={ingest_dag_module.INGESTED_ASSET.uri: events})
    assert cutoffs["as_of"] == "2018-04-30T00:00:00Z"
    values[gateway.VARIABLE_WORKER_IMAGE] = "registry/worker@sha256:" + "2" * 64
    sent = []
    monkeypatch.setattr(gateway, "submit_training", lambda body: sent.append(body) or {"job_name": "worker"})
    run = SimpleNamespace(dag_id="promiseops_training", run_id="asset-run")
    _task("promiseops_training", "submit_job").fn(cutoffs, dag_run=run)
    _task("promiseops_training", "submit_job").fn(cutoffs, dag_run=run)
    assert sent[0] == sent[1]
    assert sent[0]["image"].endswith("1" * 64)


def test_training_reads_asset_keyed_triggering_events():
    """Real Airflow 3.1+ keys triggering_asset_events by Asset objects; string keys
    raise TypeError from its lazy mapping (the platform's observed failure)."""

    class _AssetKeyedMapping(Mapping):
        def __init__(self, data):
            self._data = data

        def __getitem__(self, key):
            if isinstance(key, str):
                raise TypeError("Key should be either an asset or an asset alias, not <class 'str'>")
            return self._data[key]

        def __iter__(self):
            return iter(self._data)

        def __len__(self):
            return len(self._data)

    value, source = train_dag_module._company_as_of({}, {
        "triggering_asset_events": _AssetKeyedMapping(
            {ingest_dag_module.INGESTED_ASSET: [SimpleNamespace(extra={"as_of": "2018-04-30T00:00:00Z"})]})})
    assert (value, source) == ("2018-04-30T00:00:00Z", "triggering_ingestion")


def test_weekly_monitor_uses_latest_ingestion_event_not_scheduler_date():
    asset = ingest_dag_module.INGESTED_ASSET
    value, source = train_dag_module._company_as_of({}, {
        "inlet_events": {asset: [SimpleNamespace(extra={"as_of": "2018-05-01T00:00:00Z"})]},
        "data_interval_end": datetime(2026, 11, 20, tzinfo=UTC)})
    assert (value, source) == ("2018-05-01T00:00:00Z", "latest_ingestion")


@pytest.mark.parametrize("context", [{}, {"inlet_events": {}},
    {"triggering_asset_events": {"promiseops://feed/ingested": [SimpleNamespace(extra={})]}}])
def test_missing_company_event_metadata_cannot_fall_back_to_wall_clock(context):
    with pytest.raises((ValueError, KeyError)):
        train_dag_module._company_as_of({}, context)


# --- Promotion lifecycle tasks (training DAG only) ------------------------------------------------------
REGISTERED = {"status": "registered", "run_id": "run1", "name": "promiseops-late-delivery", "version": "3",
              "model_version": "m-1", "artifact_sha256": "a" * 64}
CUTOFFS = {"train_end": "2017-10-31T23:59:59Z", "validation_end": "2017-12-31T23:59:59Z",
           "as_of": "2018-01-01T00:00:00Z"}


def _cli(monkeypatch, *, returncode=0, stdout="", stderr=""):
    calls = []

    def fake_run(arguments):
        calls.append(arguments)
        return SimpleNamespace(returncode=returncode, stdout=stdout, stderr=stderr)

    monkeypatch.setattr(gateway, "run_cli", fake_run)
    return calls


def test_promotion_tasks_exist_only_in_the_training_dag():
    assert ("promiseops_training", "register_candidate") in _TASKS
    assert ("promiseops_training", "evaluate_candidate") in _TASKS
    assert ("promiseops_training", "promotion_decision") in _TASKS
    for name in ("register_candidate", "evaluate_candidate", "promotion_decision"):
        assert ("promiseops_monitor_train", name) not in _TASKS, \
            "monitor-train must not promote: its candidates wait for a human release decision"
    register = _task("promiseops_training", "register_candidate")
    assert register.kwargs["retries"] == 6  # waits for the queued Job with retries, not with polling code


def test_register_candidate_passes_cutoffs_and_dagrun_start_to_the_cli(monkeypatch):
    calls = _cli(monkeypatch, stdout=json.dumps(REGISTERED) + "\n")
    dag_run = SimpleNamespace(dag_id="promiseops_training", run_id="r",
                              start_date=datetime(2026, 11, 23, 12, 0, tzinfo=UTC))
    node = _task("promiseops_training", "register_candidate")
    result = node.fn({"request_id": "x", "job": {"job_name": "worker-1"}}, CUTOFFS, dag_run=dag_run)
    assert result == REGISTERED
    arguments = calls[0]
    assert arguments[0] == "register-candidate"
    assert arguments[arguments.index("--train-end") + 1] == CUTOFFS["train_end"]
    assert arguments[arguments.index("--created-after") + 1] == "2026-11-23T11:50:00+00:00"


def test_register_candidate_without_a_dagrun_start_omits_created_after(monkeypatch):
    calls = _cli(monkeypatch, stdout=json.dumps(REGISTERED) + "\n")
    node = _task("promiseops_training", "register_candidate")
    node.fn({"request_id": "x"}, CUTOFFS, dag_run=SimpleNamespace(dag_id="d", run_id="r"))
    assert "--created-after" not in calls[0]


def test_register_candidate_retries_while_training_is_not_finished(monkeypatch):
    from airflow.exceptions import AirflowException, AirflowFailException

    _cli(monkeypatch, returncode=4, stderr="not ready")
    node = _task("promiseops_training", "register_candidate")
    with pytest.raises(AirflowException) as raised:
        node.fn({"request_id": "x"}, CUTOFFS, dag_run=SimpleNamespace(dag_id="d", run_id="r"))
    assert not isinstance(raised.value, AirflowFailException)  # transient: the Job may still finish


def test_register_candidate_ambiguity_fails_without_retry(monkeypatch):
    from airflow.exceptions import AirflowFailException

    _cli(monkeypatch, returncode=5, stderr="ambiguous")
    node = _task("promiseops_training", "register_candidate")
    with pytest.raises(AirflowFailException):
        node.fn({"request_id": "x"}, CUTOFFS, dag_run=SimpleNamespace(dag_id="d", run_id="r"))


def test_register_candidate_transient_failure_is_retryable(monkeypatch):
    from airflow.exceptions import AirflowException, AirflowFailException

    _cli(monkeypatch, returncode=1, stderr="mlflow down")
    node = _task("promiseops_training", "register_candidate")
    with pytest.raises(AirflowException) as raised:
        node.fn({"request_id": "x"}, CUTOFFS, dag_run=SimpleNamespace(dag_id="d", run_id="r"))
    assert not isinstance(raised.value, AirflowFailException)


def test_gate_rejected_candidate_skips_the_promotion_tasks(monkeypatch):
    from airflow.exceptions import AirflowSkipException

    rejected = {"status": "rejected", "run_id": "run1", "gate_decision": "rejected",
                "gate_reasons": ["FAIL: recall@10% candidate 0.2 vs champion 0.5 (must not decrease)"],
                "model_version": "m-2"}
    _cli(monkeypatch, stdout=json.dumps(rejected) + "\n")
    node = _task("promiseops_training", "register_candidate")
    with pytest.raises(AirflowSkipException, match="rejected by the worker's gate"):
        node.fn({"request_id": "x"}, CUTOFFS, dag_run=SimpleNamespace(dag_id="d", run_id="r"))


EVALUATION = {"name": "promiseops-late-delivery", "version": "3", "run_id": "run1",
              "model_version": "m-1", "artifact_sha256": "a" * 64, "cohort_sha256": "c" * 64,
              "decision": "promote", "reasons": ["pass: recall@10% vs champion"],
              "candidate_metrics": {"n": 100}, "champion_metrics": {"n": 100},
              "compared_champion_version": "baseline", "champion_alias_version": "2",
              "champion_alias_model_version": "m-0"}


def test_evaluate_candidate_passes_the_registry_reference_and_returns_the_result(monkeypatch):
    calls = _cli(monkeypatch, stdout=json.dumps(EVALUATION) + "\n")
    node = _task("promiseops_training", "evaluate_candidate")
    result = node.fn(REGISTERED)
    assert result == EVALUATION
    assert calls[0] == ["evaluate-candidate", "--name", REGISTERED["name"],
                        "--version", REGISTERED["version"]]


def test_evaluation_failure_is_retryable(monkeypatch):
    from airflow.exceptions import AirflowException

    _cli(monkeypatch, returncode=1, stderr="artifact store down")
    with pytest.raises(AirflowException):
        _task("promiseops_training", "evaluate_candidate").fn(REGISTERED)


OUTCOME = {"status": "promoted", "name": "promiseops-late-delivery", "version": "3", "model_version": "m-1",
           "previous_champion_version": "2", "new_champion_version": "3", "metadata_run_id": "run9",
           "decision": "promote", "reasons": [], "evaluation": None}


def test_promotion_decision_passes_the_candidate_reference_and_returns_the_outcome(monkeypatch):
    calls = _cli(monkeypatch, stdout=json.dumps(OUTCOME) + "\n")
    node = _task("promiseops_training", "promotion_decision")
    result = node.fn(EVALUATION)
    assert result == OUTCOME
    assert calls[0] == ["decide-promotion", "--name", EVALUATION["name"],
                        "--version", EVALUATION["version"]]


def test_promotion_decision_failure_is_retryable_so_a_changed_champion_is_rederived(monkeypatch):
    from airflow.exceptions import AirflowException

    _cli(monkeypatch, returncode=1, stderr="the champion alias moved while deciding")
    with pytest.raises(AirflowException):
        _task("promiseops_training", "promotion_decision").fn(EVALUATION)
