"""Promotion lifecycle tests without MLflow: these run in CI.

The MLflow SDK surface is stubbed (like the Airflow stub in tests/test_dag_behavior.py): the
in-memory client below implements exactly the calls promiseops.promotion and promiseops.registry
make, so the decision logic, retry idempotency and failure mapping are verified without a server.
Behaviour against a REAL MLflow (SQLite store): tests/test_promotion_mlflow.py.

Scenario map (the numbers are the task's required test scenarios):
  3/4/5  candidate better/worse than champion; absolute pass but relative fail -> apply_policy
  6      no champion yet (baseline comparison) -> promotion happens, alias is created
  7      missing / invalid recorded champion metrics -> rejected, never promoted
  8      failed artifact loading -> RegistryError, the task must fail
  9/10   promotion and rejection with alias/tag/metadata effects
  11     task retry does not create inconsistent registry state
  1/2    candidate registration success and failure (find_candidate_run + register_candidate)
"""

import json
import re
import sys
import types
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from importlib.util import find_spec
from pathlib import Path

import pytest
from test_bundle import lineage, write

from promiseops import promotion, record, registry, tracking
from promiseops.bundle import EvaluationMetrics

# --- MLflow SDK: the real package when installed (local runs), a stub in CI -----------------------------
try:  # find_spec does not import: no stub in sys.modules can fool it
    _MLFLOW_INSTALLED = find_spec("mlflow") is not None
except ModuleNotFoundError:  # an import-blocking environment counts as "not installed"
    _MLFLOW_INSTALLED = False
_STUB_MODULES: list[tuple[str, types.ModuleType]] = []

try:
    from mlflow.exceptions import RESOURCE_DOES_NOT_EXIST as _NOT_FOUND_CODE  # int constant
    from mlflow.exceptions import MlflowException as RegistryException
except ImportError:  # the CI test image has no MLflow: stub the lazy imports promiseops makes
    _mlflow = types.ModuleType("mlflow")
    _entities = types.ModuleType("mlflow.entities")
    _exceptions = types.ModuleType("mlflow.exceptions")

    class StubMlflowException(Exception):
        def __init__(self, message: str, error_code: str = "INTERNAL_ERROR"):
            super().__init__(message)
            self.error_code = error_code

    class StubMetric:
        def __init__(self, key, value, timestamp, step):
            self.key, self.value, self.timestamp, self.step = key, value, timestamp, step

    class StubParam:
        def __init__(self, key, value):
            self.key, self.value = key, value

    _entities.Metric = StubMetric
    _entities.Param = StubParam
    _exceptions.MlflowException = StubMlflowException
    _mlflow.entities = _entities
    _mlflow.exceptions = _exceptions
    _STUB_MODULES = [("mlflow", _mlflow), ("mlflow.entities", _entities),
                     ("mlflow.exceptions", _exceptions)]
    RegistryException = StubMlflowException
    _NOT_FOUND_CODE = "RESOURCE_DOES_NOT_EXIST"  # the stub keeps error codes as strings


@pytest.fixture(autouse=True)
def _mlflow_sdk():
    """Provide the stubbed SDK only WHILE these tests run — never at collection time.

    The other ``*_mlflow.py`` test files decide with ``pytest.importorskip("mlflow")`` whether they
    can run; a stub left in ``sys.modules`` at collection time would make them try (and fail) in the
    CI image, which installs only requirements.lock. Installing per test and removing it afterwards
    keeps that decision honest.
    """
    if _MLFLOW_INSTALLED:
        yield
        return
    for name, module in _STUB_MODULES:
        sys.modules.setdefault(name, module)
    yield
    for name, _ in _STUB_MODULES:
        sys.modules.pop(name, None)


# --- In-memory registry client ----------------------------------------------------------------------------
@dataclass
class FakeRun:
    run_id: str
    status: str = "FINISHED"
    start_time: int = 0
    params: dict = field(default_factory=dict)
    metrics: dict = field(default_factory=dict)
    tags: dict = field(default_factory=dict)


@dataclass
class FakeVersion:
    name: str
    version: str
    run_id: str
    tags: dict = field(default_factory=dict)
    source: str = ""


class FakeRegistryClient:
    """The slice of MlflowClient the promotion path uses, in memory."""

    def __init__(self):
        self.runs: dict[str, FakeRun] = {}
        self.versions: dict[str, dict[str, FakeVersion]] = {}
        self.aliases: dict[str, dict[str, str]] = {}
        self.experiments: dict[str, str] = {"promiseops-promotion": "1",
                                            tracking.TRAINING_EXPERIMENT: "2"}
        self._next_version = 0
        self._next_run = 0
        self.download_error: Exception | None = None

    # experiments
    def get_experiment_by_name(self, name):
        if name not in self.experiments:
            return None
        return types.SimpleNamespace(experiment_id=self.experiments[name], name=name)

    def create_experiment(self, name, tags=None):
        self.experiments[name] = str(len(self.experiments) + 1)
        return self.experiments[name]

    # runs
    def create_run(self, experiment_id, tags=None, run_name=None):
        self._next_run += 1
        run = FakeRun(run_id=f"run{self._next_run:012d}", tags=dict(tags or {}))
        self.runs[run.run_id] = run
        return types.SimpleNamespace(info=types.SimpleNamespace(run_id=run.run_id))

    def get_run(self, run_id):
        return types.SimpleNamespace(info=self.runs[run_id], data=self.runs[run_id])

    def set_terminated(self, run_id, status):
        self.runs[run_id].status = status

    def log_batch(self, run_id, metrics=(), params=(), tags=()):
        run = self.runs[run_id]
        for item in metrics:
            run.metrics[item.key] = item.value
        for item in params:
            run.params[item.key] = item.value
        for item in tags:
            run.tags[item.key] = item.value

    def log_text(self, run_id, text, artifact_file):
        self.runs[run_id].params[f"artifact:{artifact_file}"] = text

    def search_runs(self, experiment_ids, filter_string="", order_by=None):
        wanted = {}
        for key, value in re.findall(r"(?:tags|params)\.`([^`]+)`\s*=\s*'([^']*)'", filter_string):
            wanted[key] = value
        found = []
        for run in self.runs.values():
            source = run.tags | run.params
            if all(source.get(key) == value for key, value in wanted.items()):
                found.append(types.SimpleNamespace(info=run, data=run))
        return sorted(found, key=lambda run: -run.info.start_time)

    # model registry
    def create_registered_model(self, name, description=None):
        self.versions.setdefault(name, {})
        self.aliases.setdefault(name, {})

    def create_model_version(self, name, source, run_id, tags=None, description=None):
        self.create_registered_model(name)
        self._next_version += 1
        version = FakeVersion(name=name, version=str(self._next_version), run_id=run_id,
                              tags=dict(tags or {}), source=source)
        self.versions[name][version.version] = version
        return version

    def get_model_version(self, name, version):
        return self.versions[name][str(version)]

    def search_model_versions(self, filter_string):
        name = re.search(r"name = '([^']+)'", filter_string).group(1)
        run_id = re.search(r"run_id = '([^']+)'", filter_string).group(1)
        return [version for version in self.versions.get(name, {}).values() if version.run_id == run_id]

    def get_model_version_by_alias(self, name, alias):
        version = self.aliases.get(name, {}).get(alias)
        if version is None:
            raise RegistryException(f"alias {alias} not found", error_code=_NOT_FOUND_CODE)
        return self.versions[name][version]

    def set_registered_model_alias(self, name, alias, version):
        self.aliases.setdefault(name, {})[alias] = str(version)

    def set_model_version_tag(self, name, version, key, value):
        self.versions[name][str(version)].tags[key] = value

    # artifacts: serve the on-disk bundle folders per run
    def attach_bundle(self, run_id: str, bundle_folder: Path) -> None:
        self.runs[run_id].params["bundle_dir"] = str(bundle_folder)

    def download_artifacts(self, run_id, artifact_path, dst_path):
        if self.download_error is not None:
            raise self.download_error
        source = Path(self.runs[run_id].params["bundle_dir"])
        target = Path(dst_path) / Path(artifact_path).name
        target.mkdir(parents=True, exist_ok=True)
        for item in source.iterdir():
            (target / item.name).write_bytes(item.read_bytes())
        return str(target)


# --- Builders --------------------------------------------------------------------------------------------
CHAMPION_METRICS = {"n": 100, "prevalence": 0.1, "k": 10, "recall_at_10": 0.5, "precision_at_10": 0.5,
                    "pr_auc": 0.4, "brier": 0.10}


def candidate_metrics(**overrides) -> EvaluationMetrics:
    values = {"n": 100, "prevalence": 0.1, "k": 10, "recall_at_10": 0.6, "precision_at_10": 0.6,
              "pr_auc": 0.45, "brier": 0.09}
    return EvaluationMetrics(**{**values, **overrides})


def champion_metrics(**overrides) -> EvaluationMetrics:
    return EvaluationMetrics(**{**CHAMPION_METRICS, **overrides})


def champion_run_metrics() -> dict[str, float]:
    return {f"champion.{key}": float(value) for key, value in CHAMPION_METRICS.items()}


def registered_candidate(client: FakeRegistryClient, tmp_path: Path, *, run_id: str = "run000000000001",
                         gate_decision: str = "accepted", compared: str = "champ-v1",
                         validation=None, champion_metrics: dict[str, float] | None = None,
                         bundle_folder: str = "bundle") -> str:
    """One accepted candidate with its bundle on disk, its run and a registry version."""
    values = {"gate_decision": gate_decision, "champion_model_version": compared,
              "validation_metrics": validation or candidate_metrics()}
    write(tmp_path, lineage=lineage(**values))  # writes tmp_path/bundle/{release,lineage,model}.json
    manifest = json.loads((tmp_path / "bundle" / "release.json").read_text(encoding="utf-8"))
    run = FakeRun(run_id=run_id, params={"bundle_dir": str(tmp_path / "bundle_dir")})
    run.tags.update({record.TAG_ARTIFACT_SHA256: manifest["artifact_sha256"],
                     record.TAG_MODEL_VERSION: manifest["model_version"],
                     record.TAG_GATE_DECISION: gate_decision})
    client.runs[run_id] = run
    (tmp_path / "bundle_dir").mkdir()
    for item in (tmp_path / "bundle").iterdir():
        (tmp_path / "bundle_dir" / item.name).write_bytes(item.read_bytes())
    client.attach_bundle(run_id, tmp_path / "bundle_dir")
    if champion_metrics is not None:
        run.metrics.update(champion_metrics)
    version = client.create_model_version(registry.REGISTERED_MODEL, f"runs:/{run_id}/bundle", run_id,
                                          tags={registry.TAG_ARTIFACT_SHA256: manifest["artifact_sha256"],
                                                registry.TAG_MODEL_VERSION: manifest["model_version"],
                                                registry.TAG_GATE_DECISION: gate_decision})
    return version.version


# --- Configuration ----------------------------------------------------------------------------------------
def test_config_defaults_equal_the_public_gates():
    config = promotion.PromotionConfig()
    assert config.model_name == registry.REGISTERED_MODEL
    assert config.champion_alias == promotion.ALIAS_CHAMPION
    assert (config.max_pr_auc_decrease, config.max_brier_increase) == (0.02, 0.005)
    assert config.min_recall_improvement == 0.0  # recall may never decrease


def test_config_cannot_weaken_the_public_gates():
    with pytest.raises(promotion.PromotionError, match="max_pr_auc_decrease"):
        promotion.PromotionConfig(max_pr_auc_decrease=0.5)
    with pytest.raises(promotion.PromotionError, match="max_brier_increase"):
        promotion.PromotionConfig(max_brier_increase=1.0)
    with pytest.raises(promotion.PromotionError, match="min_recall_improvement"):
        promotion.PromotionConfig(min_recall_improvement=-0.1)


def test_config_from_env_overrides_every_setting(monkeypatch):
    monkeypatch.setenv("PROMISEOPS_PROMOTION_MODEL_NAME", "other-model")
    monkeypatch.setenv("PROMISEOPS_PROMOTION_CHAMPION_ALIAS", "prod-champion")
    monkeypatch.setenv("PROMISEOPS_PROMOTION_MIN_RECALL_AT_10", "0.4")
    monkeypatch.setenv("PROMISEOPS_PROMOTION_MAX_BRIER", "0.2")
    monkeypatch.setenv("PROMISEOPS_PROMOTION_MIN_RECALL_IMPROVEMENT", "0.01")
    monkeypatch.setenv("PROMISEOPS_PROMOTION_MAX_PR_AUC_DECREASE", "0.0")
    monkeypatch.setenv("PROMISEOPS_PROMOTION_MAX_BRIER_INCREASE", "0.0")
    config = promotion.PromotionConfig.from_env()
    assert (config.model_name, config.champion_alias) == ("other-model", "prod-champion")
    assert (config.min_recall_at_10, config.max_brier) == (0.4, 0.2)
    assert config.min_recall_improvement == 0.01
    assert (config.max_pr_auc_decrease, config.max_brier_increase) == (0.0, 0.0)


def test_config_from_env_rejects_a_non_numeric_threshold(monkeypatch):
    monkeypatch.setenv("PROMISEOPS_PROMOTION_MIN_RECALL_AT_10", "high")
    with pytest.raises(promotion.PromotionError, match="not a number"):
        promotion.PromotionConfig.from_env()


# --- Evaluation policy (scenarios 3, 4, 5, 6, 7) ----------------------------------------------------------
def test_candidate_better_than_champion_is_promoted():
    config = promotion.PromotionConfig(min_recall_at_10=0.5, max_brier=0.2)
    passed, reasons = promotion.apply_policy(candidate_metrics(), champion_metrics(),
                                             config=config)
    assert passed and all(reason.startswith("pass") for reason in reasons)


def test_candidate_worse_than_champion_is_rejected():
    worse = candidate_metrics(recall_at_10=0.4, pr_auc=0.3, brier=0.2)
    passed, reasons = promotion.apply_policy(worse, champion_metrics(),
                                             config=promotion.PromotionConfig())
    assert not passed
    assert any("recall@10% vs champion" in reason and "FAIL" in reason for reason in reasons)
    assert any("PR-AUC vs champion" in reason for reason in reasons)
    assert any("Brier vs champion" in reason for reason in reasons)


def test_absolute_pass_with_relative_fail_is_rejected():
    # recall 0.55 clears the absolute floor 0.5 but loses 0.1 recall against the champion's 0.65.
    config = promotion.PromotionConfig(min_recall_at_10=0.5, min_recall_improvement=0.0)
    champion = champion_metrics(recall_at_10=0.65)
    passed, reasons = promotion.apply_policy(candidate_metrics(recall_at_10=0.55), champion, config=config)
    assert not passed
    assert any("recall@10% vs champion" in reason and "FAIL" in reason for reason in reasons)
    assert any("absolute floor" in reason and reason.startswith("pass") for reason in reasons)


def test_required_improvement_margin_makes_equal_metrics_rejected():
    config = promotion.PromotionConfig(min_recall_improvement=0.01)
    passed, reasons = promotion.apply_policy(candidate_metrics(recall_at_10=0.5), champion_metrics(),
                                             config=config)
    assert not passed
    assert any("improvement >= 0.0100" in reason and "FAIL" in reason for reason in reasons)


def test_cohort_mismatch_is_rejected_not_raised():
    champion = champion_metrics(n=200, k=20)
    passed, reasons = promotion.apply_policy(candidate_metrics(), champion, config=promotion.PromotionConfig())
    assert not passed and any("different cohorts" in reason for reason in reasons)


# --- Evaluation against a registry client (scenarios 6, 7, 8) ---------------------------------------------
def test_evaluation_without_any_champion_promotes_the_first_candidate(tmp_path):
    client = FakeRegistryClient()
    version = registered_candidate(client, tmp_path, compared="baseline-training-prevalence",
                                   champion_metrics=champion_run_metrics())
    result = promotion.evaluate_candidate(client, version)
    assert result.decision == "promote"
    assert result.champion_alias_version is None  # no champion exists yet: initial registration
    assert result.compared_champion_version == "baseline-training-prevalence"


def bundle_model_version(folder: Path) -> str:
    """The content-addressed model_version of a bundle written by ``write``."""
    return json.loads((folder / "bundle" / "release.json").read_text(encoding="utf-8"))["model_version"]


def test_evaluation_of_a_better_candidate_beats_the_current_champion(tmp_path):
    client = FakeRegistryClient()
    champion_version = registered_candidate(client, tmp_path / "champion", run_id="run000000000009",
                                            compared="baseline-training-prevalence",
                                            champion_metrics=champion_run_metrics())
    promotion.decide_promotion(client, champion_version)
    candidate_version = registered_candidate(
        client, tmp_path / "candidate", run_id="run000000000010",
        compared=bundle_model_version(tmp_path / "champion"), champion_metrics=champion_run_metrics())
    result = promotion.evaluate_candidate(client, candidate_version)
    assert result.decision == "promote"
    assert result.champion_alias_version == champion_version
    assert result.champion_alias_model_version == bundle_model_version(tmp_path / "champion")


def test_missing_champion_metrics_reject_instead_of_raising(tmp_path):
    client = FakeRegistryClient()
    version = registered_candidate(client, tmp_path, champion_metrics=None)  # the run logs no comparison
    result = promotion.evaluate_candidate(client, version)
    assert result.decision == "reject"
    assert result.champion_metrics is None
    assert any("unusable" in reason and "missing run metrics" in reason for reason in result.reasons)


def test_invalid_champion_metrics_reject_instead_of_raising(tmp_path):
    client = FakeRegistryClient()
    invalid = champion_run_metrics() | {"champion.k": 7}  # k must be ceil(0.1*N)
    version = registered_candidate(client, tmp_path, champion_metrics=invalid)
    result = promotion.evaluate_candidate(client, version)
    assert result.decision == "reject"
    assert any("invalid values" in reason for reason in result.reasons)


def test_stale_comparison_against_a_moved_champion_is_rejected(tmp_path):
    client = FakeRegistryClient()
    version = registered_candidate(client, tmp_path, compared="champ-v1",
                                   champion_metrics=champion_run_metrics())
    client.create_model_version(registry.REGISTERED_MODEL, "runs:/other/bundle", "runother",
                                tags={registry.TAG_ARTIFACT_SHA256: "b" * 64,
                                      registry.TAG_MODEL_VERSION: "champ-v2"})
    client.set_registered_model_alias(registry.REGISTERED_MODEL, "champion", "2")
    result = promotion.evaluate_candidate(client, version)
    assert result.decision == "reject"
    assert any("stale comparison" in reason for reason in result.reasons)


def test_failed_artifact_loading_fails_the_evaluation(tmp_path):
    client = FakeRegistryClient()
    version = registered_candidate(client, tmp_path, champion_metrics=champion_run_metrics())
    client.download_error = registry.RegistryError("artifact store unreachable")
    with pytest.raises(registry.RegistryError, match="unreachable"):
        promotion.evaluate_candidate(client, version)


def test_evaluation_summary_is_small_and_json_friendly(tmp_path):
    client = FakeRegistryClient()
    version = registered_candidate(client, tmp_path, champion_metrics=champion_run_metrics())
    document = json.dumps(promotion.evaluate_candidate(client, version).summary())  # no dataclasses inside
    assert json.loads(document)["decision"] == "promote"


# --- Registration (scenarios 1, 2) -------------------------------------------------------------------------
def test_registered_candidate_gets_role_and_pending_status(tmp_path):
    client = FakeRegistryClient()
    version = registered_candidate(client, tmp_path)
    registered = promotion.register_candidate(client, "run000000000001", record.load_record(tmp_path / "bundle"))
    assert registered.version == version
    tags = client.get_model_version(registry.REGISTERED_MODEL, version).tags
    assert tags[promotion.TAG_ROLE] == promotion.ROLE_CANDIDATE
    assert tags[promotion.TAG_VALIDATION_STATUS] == promotion.STATUS_PENDING


def test_retry_of_registration_never_resets_a_decided_version(tmp_path):
    client = FakeRegistryClient()
    version = registered_candidate(client, tmp_path)
    promotion.register_candidate(client, "run000000000001", record.load_record(tmp_path / "bundle"))
    client.set_model_version_tag(registry.REGISTERED_MODEL, version, promotion.TAG_VALIDATION_STATUS,
                                 promotion.STATUS_APPROVED)
    promotion.register_candidate(client, "run000000000001", record.load_record(tmp_path / "bundle"))
    tags = client.get_model_version(registry.REGISTERED_MODEL, version).tags
    assert tags[promotion.TAG_VALIDATION_STATUS] == promotion.STATUS_APPROVED  # not reset to pending


def test_find_candidate_run_reports_not_ready_and_ambiguity(tmp_path):
    client = FakeRegistryClient()
    assert promotion.find_candidate_run(client, train_end="2017-10-31T23:59:59Z",
                                        validation_end="2017-12-31T23:59:59Z",
                                        as_of="2018-01-01T00:00:00Z") is None
    run = FakeRun(run_id="run000000000001")
    run.params.update({"requested.train_end": "2017-10-31T23:59:59+00:00",
                       "requested.validation_end": "2017-12-31T23:59:59+00:00",
                       "requested.as_of": "2018-01-01T00:00:00+00:00"})
    run.tags.update({record.TAG_ARTIFACT_SHA256: "a" * 64, record.TAG_MODEL_VERSION: "m-1",
                     record.TAG_GATE_DECISION: "accepted"})
    client.runs[run.run_id] = run
    found = promotion.find_candidate_run(client, train_end="2017-10-31T23:59:59Z",
                                         validation_end="2017-12-31T23:59:59Z",
                                         as_of="2018-01-01T00:00:00Z")
    assert found is not None and found.gate_decision == "accepted"

    other = FakeRun(run_id="run000000000002", start_time=1)
    other.params.update(run.params)
    other.tags.update({record.TAG_ARTIFACT_SHA256: "b" * 64, record.TAG_MODEL_VERSION: "m-2",
                       record.TAG_GATE_DECISION: "accepted"})
    client.runs[other.run_id] = other
    with pytest.raises(promotion.PromotionError, match="different models"):
        promotion.find_candidate_run(client, train_end="2017-10-31T23:59:59Z",
                                     validation_end="2017-12-31T23:59:59Z", as_of="2018-01-01T00:00:00Z")


def test_find_candidate_run_ignores_runs_of_earlier_dag_runs():
    client = FakeRegistryClient()
    old = FakeRun(run_id="run000000000001", start_time=0)
    old.params.update({"requested.train_end": "2017-10-31T23:59:59+00:00",
                       "requested.validation_end": "2017-12-31T23:59:59+00:00",
                       "requested.as_of": "2018-01-01T00:00:00+00:00"})
    old.tags.update({record.TAG_ARTIFACT_SHA256: "a" * 64, record.TAG_MODEL_VERSION: "m-1",
                     record.TAG_GATE_DECISION: "accepted"})
    client.runs[old.run_id] = old
    after = datetime.now(UTC) - timedelta(minutes=5)
    assert promotion.find_candidate_run(client, train_end="2017-10-31T23:59:59Z",
                                        validation_end="2017-12-31T23:59:59Z",
                                        as_of="2018-01-01T00:00:00Z", created_after=after) is None
    assert promotion.find_candidate_run(client, train_end="2017-10-31T23:59:59Z",
                                        validation_end="2017-12-31T23:59:59Z",
                                        as_of="2018-01-01T00:00:00Z") is not None


def test_find_candidate_run_refuses_filter_injection():
    with pytest.raises(promotion.PromotionError, match="invalid cutoff"):
        promotion.find_candidate_run(client=FakeRegistryClient(), train_end="2017-10-31' or '1'='1",
                                     validation_end="2017-12-31T23:59:59Z", as_of="2018-01-01T00:00:00Z")


# --- Decision (scenarios 9, 10, 11) ------------------------------------------------------------------------
def test_promotion_moves_the_alias_tags_versions_and_records_metadata(tmp_path):
    client = FakeRegistryClient()
    champion_version = registered_candidate(client, tmp_path / "champion", run_id="run000000000009",
                                            compared="baseline-training-prevalence",
                                            champion_metrics=champion_run_metrics())
    first = promotion.decide_promotion(client, champion_version, now=datetime(2026, 11, 23, tzinfo=UTC))
    assert first.status == "promoted"
    assert client.aliases[registry.REGISTERED_MODEL]["champion"] == champion_version
    tags = client.get_model_version(registry.REGISTERED_MODEL, champion_version).tags
    assert (tags[promotion.TAG_ROLE], tags[promotion.TAG_VALIDATION_STATUS]) == ("champion", "approved")
    assert tags[promotion.TAG_PROMOTED_AT] == "2026-11-23T00:00:00+00:00"

    candidate_version = registered_candidate(
        client, tmp_path / "candidate", run_id="run000000000010",
        compared=bundle_model_version(tmp_path / "champion"), champion_metrics=champion_run_metrics())
    outcome = promotion.decide_promotion(client, candidate_version, now=datetime(2026, 11, 24, tzinfo=UTC))
    assert outcome.status == "promoted" and outcome.previous_champion_version == champion_version
    assert client.aliases[registry.REGISTERED_MODEL]["champion"] == candidate_version
    assert client.get_model_version(registry.REGISTERED_MODEL, champion_version).tags[
        promotion.TAG_ROLE] == promotion.ROLE_FORMER_CHAMPION  # the previous champion is preserved
    metadata = client.runs[outcome.metadata_run_id]
    assert metadata.tags[promotion.TAG_DECISION] == "promote"
    assert metadata.params["previous_champion_version"] == champion_version
    assert metadata.params["new_champion_version"] == candidate_version
    assert metadata.params["decided_at"] == "2026-11-24T00:00:00+00:00"
    assert json.loads(metadata.params["artifact:evaluation.json"])["decision"] == "promote"


def test_rejection_leaves_the_champion_alias_untouched_and_records_the_reason(tmp_path):
    client = FakeRegistryClient()
    champion_version = registered_candidate(client, tmp_path / "champion", run_id="run000000000009",
                                            compared="baseline-training-prevalence",
                                            champion_metrics=champion_run_metrics())
    promotion.decide_promotion(client, champion_version)
    alias_before = dict(client.aliases[registry.REGISTERED_MODEL])

    worse = candidate_metrics(recall_at_10=0.1)
    candidate_version = registered_candidate(
        client, tmp_path / "candidate", run_id="run000000000010",
        compared=bundle_model_version(tmp_path / "champion"), champion_metrics=champion_run_metrics(),
        validation=worse)
    outcome = promotion.decide_promotion(client, candidate_version)
    assert outcome.status == "rejected"
    assert client.aliases[registry.REGISTERED_MODEL] == alias_before  # the champion did not change
    tags = client.get_model_version(registry.REGISTERED_MODEL, candidate_version).tags
    assert tags[promotion.TAG_VALIDATION_STATUS] == promotion.STATUS_REJECTED
    assert "recall@10% vs champion" in tags[promotion.TAG_REJECTION_REASON]
    assert client.runs[outcome.metadata_run_id].tags[promotion.TAG_DECISION] == "reject"
    assert client.get_model_version(registry.REGISTERED_MODEL, candidate_version).tags[
        promotion.TAG_PROMOTION_RUN] == outcome.metadata_run_id


def test_retried_decision_returns_the_recorded_outcome_without_acting_again(tmp_path):
    client = FakeRegistryClient()
    version = registered_candidate(client, tmp_path, compared="baseline-training-prevalence",
                                   champion_metrics=champion_run_metrics())
    promotion.decide_promotion(client, version, now=datetime(2026, 11, 23, tzinfo=UTC))
    alias_after_first = dict(client.aliases[registry.REGISTERED_MODEL])
    metadata_runs = [run for run in client.runs.values() if "artifact:evaluation.json" in run.params]

    again = promotion.decide_promotion(client, version, now=datetime(2026, 11, 24, tzinfo=UTC))
    assert again.status == "already_promoted"
    assert client.aliases[registry.REGISTERED_MODEL] == alias_after_first
    assert [run for run in client.runs.values() if "artifact:evaluation.json" in run.params] == metadata_runs
    assert client.get_model_version(registry.REGISTERED_MODEL, version).tags[
        promotion.TAG_PROMOTED_AT] == "2026-11-23T00:00:00+00:00"  # not overwritten by the retry

    assert promotion.decide_promotion(client, version).status == "already_promoted"


def test_retry_after_a_mid_promotion_crash_completes_the_bookkeeping(tmp_path):
    client = FakeRegistryClient()
    champion_version = registered_candidate(client, tmp_path / "champion", run_id="run000000000009",
                                            compared="baseline-training-prevalence",
                                            champion_metrics=champion_run_metrics())
    promotion.decide_promotion(client, champion_version)
    candidate_version = registered_candidate(
        client, tmp_path / "candidate", run_id="run000000000010",
        compared=bundle_model_version(tmp_path / "champion"), champion_metrics=champion_run_metrics())
    promotion.evaluate_candidate(client, candidate_version)
    # Crash right after the alias move, before any other tag was written. A real promotion records
    # the intended previous champion on the version BEFORE moving the alias; reproduce that state:
    client.set_model_version_tag(registry.REGISTERED_MODEL, candidate_version,
                                 promotion.TAG_PREVIOUS_CHAMPION, champion_version)
    client.set_registered_model_alias(registry.REGISTERED_MODEL, "champion", candidate_version)
    outcome = promotion.decide_promotion(client, candidate_version)
    assert outcome.status == "promoted" and outcome.previous_champion_version == champion_version
    tags = client.get_model_version(registry.REGISTERED_MODEL, candidate_version).tags
    assert tags[promotion.TAG_VALIDATION_STATUS] == promotion.STATUS_APPROVED


class AliasFlippingClient:
    """Simulates another DagRun promoting between the evaluation and the alias move."""

    def __init__(self, inner, *, flip_on_read: int, new_version: str):
        self._inner = inner
        self._flip_on_read = flip_on_read
        self._new_version = new_version
        self.alias_reads = 0

    def __getattr__(self, name):
        return getattr(self._inner, name)

    def get_model_version_by_alias(self, name, alias):
        self.alias_reads += 1
        if self.alias_reads == self._flip_on_read:
            self._inner.set_registered_model_alias(name, alias, self._new_version)
        return self._inner.get_model_version_by_alias(name, alias)


def test_alias_moved_while_deciding_raises_a_conflict(tmp_path):
    client = FakeRegistryClient()
    champion_version = registered_candidate(client, tmp_path / "champion", run_id="run000000000009",
                                            compared="baseline-training-prevalence",
                                            champion_metrics=champion_run_metrics())
    promotion.decide_promotion(client, champion_version)
    candidate_version = registered_candidate(
        client, tmp_path / "candidate", run_id="run000000000010",
        compared=bundle_model_version(tmp_path / "champion"), champion_metrics=champion_run_metrics())
    other = registered_candidate(client, tmp_path / "other", run_id="run000000000011",
                                 compared="baseline-training-prevalence",
                                 champion_metrics=champion_run_metrics())
    # decide_promotion reads the alias twice: during evaluation and before the move. The flip lands
    # on the second read: another run promoted while this one was deciding.
    flipping = AliasFlippingClient(client, flip_on_read=2, new_version=other)
    with pytest.raises(promotion.PromotionConflict, match="re-derived"):
        promotion.decide_promotion(flipping, candidate_version)
    tags = client.get_model_version(registry.REGISTERED_MODEL, candidate_version).tags
    assert promotion.TAG_VALIDATION_STATUS not in tags  # nothing was written
    assert client.aliases[registry.REGISTERED_MODEL]["champion"] == other


def test_rejections_are_idempotent_across_retries(tmp_path):
    client = FakeRegistryClient()
    version = registered_candidate(client, tmp_path, compared="m-1",
                                   champion_metrics=champion_run_metrics(),
                                   validation=candidate_metrics(recall_at_10=0.1))
    first = promotion.decide_promotion(client, version)
    runs_before = len(client.runs)
    again = promotion.decide_promotion(client, version)
    assert (first.status, again.status) == ("rejected", "already_rejected")
    assert len(client.runs) == runs_before
