"""Real database + real serialized pipeline parity for /predict, including a 32-column release."""

import json

import joblib
import numpy as np
import pytest
from fastapi.testclient import TestClient
from test_ingestion_db import URL, conn, ingest  # noqa: F401
from test_model_db import AS_OF, TRAIN_END, VALIDATION_END, history  # noqa: F401

from promiseops import api, bundle, cli, data, model, training
from promiseops.contracts import instant
from promiseops.features import EXTENDED_FEATURE_NAMES

pytestmark = pytest.mark.skipif(not URL, reason="PROMISEOPS_TEST_DATABASE_URL is not set")


@pytest.fixture
def trained_release(tmp_path, history):  # noqa: F811
    connection, _, _ = history
    candidate = model.train_candidate(connection, train_end=TRAIN_END, validation_end=VALIDATION_END,
                                      as_of=AS_OF, include_history=True)
    decision = model.compare_candidate(candidate, None, candidate.cohort)
    lineage = training.build_lineage(candidate, decision, source_commit="a" * 40,
                                     dataset_identity=data.dataset_identity(connection, as_of=AS_OF), run_id="api-test")
    release = tmp_path / "release"
    bundle.write_bundle(release, candidate.model, approach=candidate.approach,
                        feature_names=list(EXTENDED_FEATURE_NAMES), source_commit="a" * 40, lineage=lineage)
    return connection, candidate, release


def client_for(monkeypatch, release, as_of=AS_OF):
    monkeypatch.setenv("PROMISEOPS_DATABASE_URL", URL)
    monkeypatch.setenv("PROMISEOPS_RELEASE", str(release))
    monkeypatch.setenv("PROMISEOPS_AS_OF", as_of)
    monkeypatch.setenv("PROMISEOPS_API_KEY", "test-key")
    return TestClient(api.create_app())


def test_32_column_release_predictions_match_training_pipeline(trained_release, monkeypatch):
    _, candidate, release = trained_release
    client = client_for(monkeypatch, release)
    assert client.get("/readyz").status_code == 200
    requests = candidate.cohort.order_ids[:10]
    observed = []
    for oid in requests:
        response = client.post("/predict", headers={"X-API-Key": "test-key"},
                               json={"order_id": oid, "request_id": "request-" + oid})
        assert response.status_code == 200, response.text
        observed.append(response.json()["risk_probability"])
        assert response.json()["request_id"] == "request-" + oid
    expected = candidate.model.predict_proba(candidate.cohort.features.loc[requests])[:, 1]
    np.testing.assert_allclose(observed, expected, rtol=0, atol=1e-12)
    assert len(set(observed)) > 1  # distinct actual order features, not dummy zeros


def test_unknown_and_unreleased_orders_return_404(trained_release, monkeypatch):
    _, candidate, release = trained_release
    client = client_for(monkeypatch, release)
    headers = {"X-API-Key": "test-key"}
    assert client.post("/predict", headers=headers, json={"order_id": "missing"}).status_code == 404
    # Restrict company replay time: validation orders have not been published yet.
    # A historical model snapshot later than replay cannot be served; safely refused as 503.
    early = client_for(monkeypatch, release, TRAIN_END)
    assert early.post("/predict", headers=headers,
                      json={"order_id": candidate.cohort.order_ids[0]}).status_code == 503


def test_changed_history_receipts_refuse_serving(trained_release, monkeypatch):
    connection, candidate, release = trained_release
    connection.execute("UPDATE promiseops.ingest_batches SET payload_sha256=repeat('f',64)")
    client = client_for(monkeypatch, release)
    response = client.post("/predict", headers={"X-API-Key": "test-key"},
                           json={"order_id": candidate.cohort.order_ids[0]})
    assert response.status_code == 503
    assert "postgresql" not in response.text


def test_startup_warms_the_feature_cache(trained_release, monkeypatch):
    """Startup warms in the background: the table lands shortly after, requests never build it."""
    import time

    _, candidate, release = trained_release
    client = client_for(monkeypatch, release)
    with client:  # entering the client runs the app lifespan (background warm)
        for _ in range(100):
            if client.app.state.frozen_feature_cache:
                break
            time.sleep(0.1)
        assert len(client.app.state.frozen_feature_cache) == 1
        oid = candidate.cohort.order_ids[0]
        response = client.post("/predict", headers={"X-API-Key": "test-key"},
                               json={"order_id": oid, "request_id": "warm-startup"})
        assert response.status_code == 200, response.text
        expected = candidate.model.predict_proba(candidate.cohort.features.loc[[oid]])[0, 1]
        assert response.json()["risk_probability"] == pytest.approx(expected, abs=1e-12)
        assert len(client.app.state.frozen_feature_cache) == 1  # predict reused the warm table


def test_startup_is_not_blocked_by_a_hanging_database(trained_release, monkeypatch):
    """The warm runs off the startup path: even a hanging database cannot delay readiness."""
    import time

    _, _, release = trained_release

    def hanging_connect(*args, **kwargs):
        time.sleep(60)  # far past any probe window
        raise RuntimeError("unreachable database")

    monkeypatch.setenv("PROMISEOPS_DATABASE_URL", "postgresql://slow-unreachable/db")
    monkeypatch.setattr(api.db, "connect", hanging_connect)
    monkeypatch.setenv("PROMISEOPS_RELEASE", str(release))
    monkeypatch.setenv("PROMISEOPS_API_KEY", "test-key")
    app = api.create_app()
    started = time.perf_counter()
    with TestClient(app):
        pass
    assert time.perf_counter() - started < 10  # lifespan returned immediately, warm still in background


def test_persisted_retry_survives_restart_and_conflicts(trained_release, monkeypatch):
    connection, candidate, release = trained_release
    client = client_for(monkeypatch, release)
    headers = {"X-API-Key": "test-key"}
    oid = candidate.cohort.order_ids[0]
    payload = {"order_id": oid, "request_id": "persistent-retry"}
    first = client.post("/predict", headers=headers, json=payload)
    assert first.status_code == 200, first.text
    restarted = client_for(monkeypatch, release)
    restarted.app.state.model = None  # restore below with a model that must never run
    class NeverScore:
        def predict_proba(self, X):
            raise AssertionError("Retry must not rescore")
    restarted.app.state.model = NeverScore()
    restarted.app.state.manifest = restarted.app.state.manifest.model_copy(update={"model_version": "new-version"})
    assert restarted.post("/predict", headers=headers, json=payload).json() == first.json()
    conflict = restarted.post("/predict", headers=headers,
                              json={"order_id": candidate.cohort.order_ids[1], "request_id": "persistent-retry"})
    assert conflict.status_code == 409
    assert connection.execute("SELECT count(*) FROM promiseops.predictions").fetchone()[0] == 1


def test_concurrent_request_ids_keep_original_result(trained_release, monkeypatch):
    from concurrent.futures import ThreadPoolExecutor
    connection, candidate, release = trained_release
    client = client_for(monkeypatch, release)
    ids = candidate.cohort.order_ids[:2]
    def send(oid):
        return client.post("/predict", headers={"X-API-Key": "test-key"},
                           json={"order_id": oid, "request_id": "concurrent-id"})
    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(send, ids))
    assert sorted(r.status_code for r in results) == [200, 409]
    assert connection.execute("SELECT count(*) FROM promiseops.predictions").fetchone()[0] == 1


def test_priority_scoring_uses_same_32_features(trained_release, monkeypatch):
    connection, candidate, release = trained_release
    ids = list(candidate.cohort.order_ids)
    monkeypatch.setattr(cli, "_select_cohort_order_ids", lambda *args, **kwargs: ids)
    report = cli.score_cohort(connection, bundle.read_bundle(release), as_of=instant(AS_OF))
    expected = dict(zip(ids, candidate.model.predict_proba(candidate.cohort.features.loc[ids])[:, 1], strict=True))
    ranked = sorted(ids, key=lambda oid: (-expected[oid], oid))[:bundle.top_k_size(len(ids))]
    assert [row["order_id"] for row in report["priority_orders"]] == ranked
    for row in report["priority_orders"]:
        assert row["risk_probability"] == pytest.approx(expected[row["order_id"]], abs=1e-12)


def test_legacy_15_column_release_uses_real_features(trained_release, tmp_path, monkeypatch):
    connection, _, _ = trained_release
    candidate = model.train_candidate(connection, train_end=TRAIN_END, validation_end=VALIDATION_END, as_of=AS_OF)
    release = tmp_path / "legacy"
    release.mkdir()
    joblib.dump(candidate.model, release / "model.joblib")
    manifest = {"model_version": "legacy-test", "feature_names": list(candidate.training_features.columns),
                "artifact_sha256": bundle.sha256_file(release / "model.joblib"), "source_commit": "a" * 40}
    (release / "release.json").write_text(json.dumps(manifest))
    client = client_for(monkeypatch, release)
    oid = candidate.cohort.order_ids[0]
    result = client.post("/predict", headers={"X-API-Key": "test-key"}, json={"order_id": oid})
    assert result.status_code == 200
    assert result.json()["risk_probability"] == pytest.approx(candidate.model.predict_proba(
        candidate.cohort.features.loc[[oid]])[0, 1])
    early = client_for(monkeypatch, release, TRAIN_END)
    assert early.post("/predict", headers={"X-API-Key": "test-key"}, json={"order_id": oid}).status_code == 404
