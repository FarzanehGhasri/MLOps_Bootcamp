"""Promotion lifecycle against a REAL MLflow with a temporary SQLite store.

These tests prove the parts a fake client cannot: the ``search_runs`` filter on the worker's
``requested.*`` params (how the DAG finds ITS training run), real alias moves, real version tags and
the artifact trust chain (download -> SHA256 check -> unpickle). Nothing is sent to any server.
Skipped when MLflow is not installed (the CI test image installs only requirements.lock).
"""

import json
from datetime import UTC, datetime, timedelta
from pathlib import Path

import numpy as np
import pytest
from sklearn.dummy import DummyClassifier
from test_bundle import lineage, write
from test_promotion import CHAMPION_METRICS, candidate_metrics

from promiseops import promotion, record, registry, tracking
from promiseops.tracking import TRAINING_EXPERIMENT, TrackingConfig, create_client, ensure_experiment

mlflow = pytest.importorskip("mlflow")


@pytest.fixture
def client(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)  # SQLite backend writes artifacts under the current folder
    monkeypatch.setenv("MLFLOW_DISABLE_TELEMETRY", "true")
    return create_client(TrackingConfig(f"sqlite:///{(tmp_path / 'mlflow.db').as_posix()}"))


CUTOFFS = {"train_end": "2017-10-31T23:59:59+00:00", "validation_end": "2017-12-31T23:59:59+00:00",
           "as_of": "2018-01-01T00:00:00+00:00"}


def training_run(client, folder, *, gate_decision="accepted", compared="baseline-training-prevalence",
                 validation=None, late_share=2, cutoffs=CUTOFFS) -> tuple[str, record.ModelRecord]:
    """One training run exactly as the worker leaves it (#15/#16): record, requested params, champion scores."""
    run_id = client.create_run(ensure_experiment(client, TRAINING_EXPERIMENT),
                               run_name="train-as-of-20180101").info.run_id
    for name, value in cutoffs.items():
        client.log_param(run_id, f"requested.{name}", value)
    model = DummyClassifier(strategy="prior").fit(
        np.zeros((10, 1)), [0] * (10 - late_share) + [1] * late_share)
    write(folder, model=model, lineage=lineage(
        gate_decision=gate_decision, champion_model_version=compared,
        validation_metrics=validation or candidate_metrics(), mlflow_run_id=run_id))
    logged = record.log_record(client, run_id, folder / "bundle")
    for key, value in CHAMPION_METRICS.items():
        client.log_metric(run_id, f"champion.{key}", float(value))
    client.set_terminated(run_id, "FINISHED")  # the worker closes the run when training succeeded
    return run_id, logged


def test_find_and_register_the_run_of_this_dag_run(tmp_path, client):
    run_id, _ = training_run(client, tmp_path / "a")
    found = promotion.find_candidate_run(client, train_end=CUTOFFS["train_end"],
                                         validation_end=CUTOFFS["validation_end"],
                                         as_of=CUTOFFS["as_of"])
    assert found is not None and found.run_id == run_id and found.gate_decision == "accepted"
    logged = record.load_logged_record(client, found.run_id)
    version = promotion.register_candidate(client, found.run_id, logged)
    tags = client.get_model_version(registry.REGISTERED_MODEL, version.version).tags
    assert tags[promotion.TAG_ROLE] == "candidate"
    assert tags[promotion.TAG_VALIDATION_STATUS] == "pending"


def test_no_finished_run_yet_is_not_ready(tmp_path, client):
    run_id, _ = training_run(client, tmp_path / "a")
    client.set_terminated(run_id, "RUNNING")  # the Job is still training
    assert promotion.find_candidate_run(client, train_end=CUTOFFS["train_end"],
                                        validation_end=CUTOFFS["validation_end"],
                                        as_of=CUTOFFS["as_of"]) is None


def test_cutoffs_of_another_replay_do_not_match(tmp_path, client):
    training_run(client, tmp_path / "a")
    assert promotion.find_candidate_run(client, train_end=CUTOFFS["train_end"],
                                        validation_end=CUTOFFS["validation_end"],
                                        as_of="2018-06-01T00:00:00+00:00") is None


def test_created_after_excludes_the_previous_dag_runs_model(tmp_path, client):
    training_run(client, tmp_path / "a")  # an earlier DagRun's model with identical cutoffs
    future = datetime.now(UTC) + timedelta(days=1)
    assert promotion.find_candidate_run(client, train_end=CUTOFFS["train_end"],
                                        validation_end=CUTOFFS["validation_end"],
                                        as_of=CUTOFFS["as_of"], created_after=future) is None


def test_gate_rejected_run_is_found_but_not_registered(tmp_path, client):
    rejected_run, _ = training_run(client, tmp_path / "a", gate_decision="rejected")
    found = promotion.find_candidate_run(client, train_end=CUTOFFS["train_end"],
                                         validation_end=CUTOFFS["validation_end"],
                                         as_of=CUTOFFS["as_of"])
    assert found.gate_decision == "rejected" and found.run_id == rejected_run
    with pytest.raises(registry.RegistryError, match="only accepted"):
        promotion.register_candidate(client, found.run_id,
                                     record.load_logged_record(client, found.run_id))


def test_first_promotion_and_then_a_better_candidate(tmp_path, client):
    first_run, _ = training_run(client, tmp_path / "a", compared="baseline-training-prevalence")
    first = promotion.register_candidate(client, first_run, record.load_logged_record(client, first_run))
    outcome = promotion.decide_promotion(client, first.version)
    assert outcome.status == "promoted" and outcome.previous_champion_version is None
    assert registry.alias_version(client, "champion") == first

    second_run, _ = training_run(client, tmp_path / "b", compared=first.model_version)
    second = promotion.register_candidate(client, second_run, record.load_logged_record(client, second_run))
    evaluation = promotion.evaluate_candidate(client, second.version)
    assert evaluation.decision == "promote"
    assert evaluation.champion_alias_version == first.version
    outcome = promotion.decide_promotion(client, second.version)
    assert outcome.status == "promoted" and outcome.previous_champion_version == first.version
    assert registry.alias_version(client, "champion") == second
    former = client.get_model_version(registry.REGISTERED_MODEL, first.version)
    assert former.tags[promotion.TAG_ROLE] == promotion.ROLE_FORMER_CHAMPION  # preserved, not deleted
    metadata = client.get_run(outcome.metadata_run_id)
    assert metadata.data.params["previous_champion_version"] == first.version
    assert metadata.data.params["new_champion_version"] == second.version
    assert metadata.data.metrics["candidate.recall_at_10"] == pytest.approx(candidate_metrics().recall_at_10)
    evaluation_artifact = Path(client.download_artifacts(
        outcome.metadata_run_id, promotion.EVALUATION_FILE, str(tmp_path / "download")))
    assert json.loads(evaluation_artifact.read_text(encoding="utf-8"))["decision"] == "promote"


def test_worse_candidate_is_rejected_and_the_champion_stays(tmp_path, client):
    first_run, _ = training_run(client, tmp_path / "a", compared="baseline-training-prevalence")
    first = promotion.register_candidate(client, first_run, record.load_logged_record(client, first_run))
    assert promotion.decide_promotion(client, first.version).status == "promoted"

    worse = candidate_metrics(recall_at_10=0.2)
    second_run, _ = training_run(client, tmp_path / "b", compared=first.model_version, validation=worse)
    second = promotion.register_candidate(client, second_run, record.load_logged_record(client, second_run))
    outcome = promotion.decide_promotion(client, second.version)
    assert outcome.status == "rejected"
    assert registry.alias_version(client, "champion") == first  # the champion is untouched
    tags = client.get_model_version(registry.REGISTERED_MODEL, second.version).tags
    assert tags[promotion.TAG_VALIDATION_STATUS] == "rejected"
    assert "recall@10% vs champion" in tags[promotion.TAG_REJECTION_REASON]


def test_task_retries_do_not_create_inconsistent_registry_state(tmp_path, client):
    run_id, _ = training_run(client, tmp_path / "a", compared="baseline-training-prevalence")
    logged = record.load_logged_record(client, run_id)
    first = promotion.register_candidate(client, run_id, logged)
    again = promotion.register_candidate(client, run_id, logged)  # retried registration task
    assert again == first
    assert len(client.search_model_versions(f"name = '{registry.REGISTERED_MODEL}'")) == 1

    decided = promotion.decide_promotion(client, first.version)
    retried = promotion.decide_promotion(client, first.version)  # retried decision task
    assert (decided.status, retried.status) == ("promoted", "already_promoted")
    assert retried.metadata_run_id == decided.metadata_run_id
    promotions = client.search_runs([tracking.ensure_experiment(client, promotion.PROMOTION_EXPERIMENT)],
                                    filter_string=f"tags.`{promotion.TAG_CANDIDATE_VERSION}` = '{first.version}'")
    assert len(promotions) == 1  # one metadata run, not one per retry
    assert registry.alias_version(client, "champion") == first


def test_tampered_artifact_fails_the_evaluation_before_any_decision(tmp_path, client):
    run_id, _ = training_run(client, tmp_path / "a", compared="baseline-training-prevalence")
    version = promotion.register_candidate(client, run_id, record.load_logged_record(client, run_id))
    client.set_model_version_tag(registry.REGISTERED_MODEL, version.version,
                                 registry.TAG_ARTIFACT_SHA256, "f" * 64)
    with pytest.raises(registry.RegistryError, match="does not match its SHA256 tag"):
        promotion.evaluate_candidate(client, version.version)
    tags = client.get_model_version(registry.REGISTERED_MODEL, version.version).tags
    assert tags[promotion.TAG_VALIDATION_STATUS] == promotion.STATUS_PENDING  # no decision was recorded
    assert registry.alias_version(client, "champion") is None


def test_champion_metrics_of_the_run_drive_the_decision(tmp_path, client):
    """The evaluation trusts the run's recorded same-cohort comparison, not the champion's own record."""
    run_id, _ = training_run(client, tmp_path / "a", compared="baseline-training-prevalence")
    version = promotion.register_candidate(client, run_id, record.load_logged_record(client, run_id))
    client.log_metric(run_id, "champion.recall_at_10", 0.9)  # an implausibly strong champion
    outcome = promotion.decide_promotion(client, version.version)
    assert outcome.status == "rejected"
    assert any("recall@10% vs champion" in reason for reason in outcome.reasons)
