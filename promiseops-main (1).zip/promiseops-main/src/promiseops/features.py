"""Shared order features for training AND serving, computed as known at the prediction time (approval).

Feature list: ``contracts/features.json`` (FEATURE_NAMES below must stay identical — a test checks it;
the JSON file itself is not inside the Docker image, so the list also lives in Python).

Two layers (one job each):

* ``compute_features(orders, items, payments)`` — pure pandas, no database. All leakage and
  aggregation rules live here, so they are tested in CI (which has no PostgreSQL).
* ``load_features(connection, order_ids, *, as_of)`` — reads only what the company knew at
  ``as_of`` (orders whose batch was published by then) with three SEPARATE queries, then calls
  ``compute_features``.

``promiseops.data.build_features`` (the public contract entry point) delegates here, so training,
validation, batch scoring and the API all go through the same code.

Rules from docs/CONTRACTS.md "Prediction and labels":
* no outcome field (delivered_at, outcome available_at) and no final state is read here;
* ``order_id`` is an identifier, never a feature (it is the index, not a column);
* items and payments are aggregated INDEPENDENTLY before combining: joining them first would
  repeat each item once per payment and multiply the sums.

Walkthrough and reasons (Persian): docs/features/01-features-labels-split.fa.md
"""

from collections.abc import Iterable
from datetime import datetime

import pandas as pd
import psycopg

from promiseops.contracts import LOCAL_TZ, instant
from promiseops.history_features import HISTORY_NAMES, build_history

FEATURE_NAMES: tuple[str, ...] = (
    "item_count",
    "seller_count",
    "total_price",
    "total_freight",
    "total_weight_g",
    "payment_total",
    "max_installments",
    "promise_days",
    "approval_hour",
    "approval_weekday",
    "interstate_fraction",
    "customer_state",
    "primary_seller_state",
    "primary_category",
    "primary_payment_type",
)
CATEGORICAL_FEATURES: tuple[str, ...] = (
    "customer_state", "primary_seller_state", "primary_category", "primary_payment_type",
)
NUMERIC_FEATURES: tuple[str, ...] = tuple(name for name in FEATURE_NAMES if name not in CATEGORICAL_FEATURES)
EXTENDED_FEATURE_NAMES: tuple[str, ...] = FEATURE_NAMES + HISTORY_NAMES

ORDER_COLUMNS = ("order_id", "approved_at", "promised_date", "customer_state")
ITEM_COLUMNS = ("order_id", "item_id", "price", "freight", "weight_g", "category", "seller_id", "seller_state")
PAYMENT_COLUMNS = ("order_id", "sequence", "payment_type", "installments", "value")


class FeatureError(ValueError):
    """Input rows cannot give contract features (e.g. an order without items). Never silently filled."""


# ---------------------------------------------------------------------------------------------
# Pure layer
# ---------------------------------------------------------------------------------------------
def compute_features(orders: pd.DataFrame, items: pd.DataFrame, payments: pd.DataFrame) -> pd.DataFrame:
    """One row per order (index ``order_id``, sorted), columns exactly ``FEATURE_NAMES``.

    ``orders``: ORDER_COLUMNS (approved_at timezone-aware, promised_date a Brazilian date);
    ``items``: ITEM_COLUMNS (product and seller attributes already attached, one row per item);
    ``payments``: PAYMENT_COLUMNS. Rows of other orders in items/payments are ignored.
    Numeric features are float64, categorical features are strings.
    """
    _require(orders, ORDER_COLUMNS, "orders")
    _require(items, ITEM_COLUMNS, "items")
    _require(payments, PAYMENT_COLUMNS, "payments")
    if orders["order_id"].duplicated().any():
        raise FeatureError("orders contain duplicate order_id")

    base = orders.set_index("order_id").sort_index()
    if base.empty:
        return _empty_features()
    if items.empty or payments.empty:
        raise FeatureError("order(s) without items or payments")
    # Contract: timestamps must carry an offset. instant() refuses naive values instead of guessing
    # (a naive value would otherwise be read as UTC and shift the local hour/date).
    approved_utc = pd.to_datetime([instant(value) for value in base["approved_at"]], utc=True)
    # Always convert explicitly: PostgreSQL returns timestamptz in the SESSION time zone, which may
    # differ between our Docker DB (UTC) and the cluster. Brazil had daylight saving in 2016-2018,
    # so a fixed -03:00 offset would be wrong — zoneinfo handles it.
    approved_local = approved_utc.tz_convert(LOCAL_TZ)
    local_date = approved_local.tz_localize(None).normalize()
    promised = pd.to_datetime(pd.Series(list(base["promised_date"]), dtype="object").astype(str))

    features = pd.DataFrame(index=base.index)
    features = features.join(_item_features(items, base["customer_state"]))
    features = features.join(_payment_features(payments))
    missing = features["item_count"].isna() | features["payment_total"].isna()
    if missing.any():
        # The ingestion contract guarantees >= 1 item and payment; a gap means a loader bug.
        raise FeatureError(f"{int(missing.sum())} order(s) without items or payments, e.g. "
                           f"{features.index[missing][0]!r}")

    features["promise_days"] = (promised.to_numpy() - local_date.to_numpy()).astype("timedelta64[D]").astype(float)
    features["approval_hour"] = approved_local.hour.astype(float)
    features["approval_weekday"] = approved_local.weekday.astype(float)  # Monday = 0
    features["customer_state"] = base["customer_state"].astype(str)

    features = features[list(FEATURE_NAMES)]
    features[list(NUMERIC_FEATURES)] = features[list(NUMERIC_FEATURES)].astype("float64")
    for name in CATEGORICAL_FEATURES:
        features[name] = features[name].astype(str)
    features.index.name = "order_id"
    return features


def _empty_features() -> pd.DataFrame:
    """The feature contract still applies when no orders can be materialized."""
    return pd.DataFrame(
        {name: pd.Series(dtype="float64" if name in NUMERIC_FEATURES else "str") for name in FEATURE_NAMES},
        index=pd.Index([], name="order_id", dtype="str"),
    )


def _item_features(items: pd.DataFrame, customer_state: pd.Series) -> pd.DataFrame:
    """Aggregate items alone (one row per item; product and seller are 1:1 per item, no fan-out)."""
    rows = items[items["order_id"].isin(customer_state.index)].copy()
    for column in ("price", "freight", "weight_g"):
        rows[column] = rows[column].astype(float)  # PostgreSQL numeric arrives as Decimal
    rows["interstate"] = (rows["seller_state"].to_numpy()
                          != customer_state.reindex(rows["order_id"]).to_numpy()).astype(float)
    totals = rows.groupby("order_id").agg(
        item_count=("item_id", "size"),
        seller_count=("seller_id", "nunique"),
        total_price=("price", "sum"),
        total_freight=("freight", "sum"),
        total_weight_g=("weight_g", "sum"),
        interstate_fraction=("interstate", "mean"),  # share of ITEMS shipped from another state
    )
    totals["primary_seller_state"] = _primary(rows, "seller_state", "price")
    totals["primary_category"] = _primary(rows, "category", "price")
    return totals


def _payment_features(payments: pd.DataFrame) -> pd.DataFrame:
    """Aggregate payments alone (independently of items, see module docstring)."""
    rows = payments.copy()
    rows["value"] = rows["value"].astype(float)
    totals = rows.groupby("order_id").agg(payment_total=("value", "sum"), max_installments=("installments", "max"))
    totals["primary_payment_type"] = _primary(rows, "payment_type", "value")
    return totals


def _primary(rows: pd.DataFrame, key: str, amount: str) -> pd.Series:
    """Per order, the ``key`` value with the largest summed ``amount``; ties -> alphabetically first.

    Amounts are summed per group and rounded to cents first, so float noise (0.1 + 0.2) cannot
    break a real tie. The fixed tie rule keeps the feature reproducible.
    """
    groups = rows.groupby(["order_id", key], as_index=False)[amount].sum()
    groups[amount] = groups[amount].round(2)
    groups = groups.sort_values(["order_id", amount, key], ascending=[True, False, True], kind="mergesort")
    return groups.drop_duplicates("order_id").set_index("order_id")[key].astype(str)


def _require(frame: pd.DataFrame, columns: Iterable[str], name: str) -> None:
    missing = [column for column in columns if column not in frame.columns]
    if missing:
        raise FeatureError(f"{name} is missing columns {missing}")


# ---------------------------------------------------------------------------------------------
# Database layer
# ---------------------------------------------------------------------------------------------
# Orders the company knew at as_of: the order's batch was published on/before as_of
# (same rule as the promiseops.order_releases view used by the API for 404).
# ids=NULL (serving full-table cache) selects every order released by as_of.
_ORDERS_SQL = """
SELECT o.order_id, o.approved_at, o.promised_date, c.customer_state
FROM promiseops.orders AS o
JOIN promiseops.ingest_batches AS b ON b.batch_id = o.batch_id
JOIN promiseops.customers AS c ON c.customer_id = o.customer_id
WHERE (%(ids)s::text[] IS NULL OR o.order_id = ANY(%(ids)s)) AND b.available_at <= %(as_of)s
"""
# Items and payments always arrive in the same batch as their order (adding rows to a committed
# order is rejected at ingestion), so restricting them to the released order IDs is enough.
_ITEMS_SQL = """
SELECT i.order_id, i.item_id, i.price, i.freight, p.weight_g, p.category, s.seller_id, s.seller_state
FROM promiseops.order_items AS i
JOIN promiseops.products AS p ON p.product_id = i.product_id
JOIN promiseops.sellers AS s ON s.seller_id = i.seller_id
WHERE i.order_id = ANY(%(ids)s)
"""
_PAYMENTS_SQL = """
SELECT order_id, sequence, payment_type, installments, value
FROM promiseops.order_payments
WHERE order_id = ANY(%(ids)s)
"""


def load_features(connection: psycopg.Connection, order_ids: Iterable[str], *,
                  as_of: datetime | str) -> pd.DataFrame:
    """Features of the requested orders that were released by ``as_of``.

    Unknown or not-yet-released orders are simply absent from the result (the API turns that into
    404). The result does not depend on which other orders were requested (tested), so a single
    API request and a training batch give the same row.
    """
    ids = sorted({str(order_id) for order_id in order_ids})
    cutoff = instant(as_of)
    if not ids:
        return _empty_features()
    orders = query_frame(connection, _ORDERS_SQL, {"ids": ids, "as_of": cutoff}, ORDER_COLUMNS)
    released = orders["order_id"].tolist()
    if not released:
        return _empty_features()
    items = query_frame(connection, _ITEMS_SQL, {"ids": released}, ITEM_COLUMNS)
    payments = query_frame(connection, _PAYMENTS_SQL, {"ids": released}, PAYMENT_COLUMNS)
    return compute_features(orders, items, payments)


def query_frame(connection: psycopg.Connection, sql: str, params: dict, columns: Iterable[str]) -> pd.DataFrame:
    """Run a query and return a DataFrame with the given columns (also when there are no rows)."""
    rows = connection.execute(sql, params).fetchall()
    return pd.DataFrame(rows, columns=list(columns))


def compute_features_with_history(
    orders: pd.DataFrame,
    items: pd.DataFrame,
    payments: pd.DataFrame,
    labels: pd.DataFrame,
    *,
    freeze_at: datetime | str | None = None,
    history_source_ids: Iterable[str] | None = None,
    history_query_ids: Iterable[str] | None = None,
) -> pd.DataFrame:
    """Contract features joined with strict point-in-time historical seller/route aggregates."""
    base = compute_features(orders, items, payments)
    item_rows = items[items["order_id"].isin(base.index)].copy()
    item_rows["price"] = item_rows["price"].astype(float)
    ranked = (
        item_rows.groupby(["order_id", "seller_id", "seller_state"], as_index=False)["price"]
        .sum()
        .sort_values(["order_id", "price", "seller_id"], ascending=[True, False, True], kind="mergesort")
        .drop_duplicates("order_id")
    )
    groups = (
        orders[["order_id", "approved_at", "customer_state"]]
        .merge(ranked[["order_id", "seller_id", "seller_state"]], on="order_id")
        .rename(columns={"seller_id": "seller"})
    )
    groups["route"] = groups["seller_state"].astype(str) + ">" + groups["customer_state"].astype(str)
    groups = groups[["order_id", "approved_at", "seller", "customer_state", "route"]]
    history = build_history(groups, labels, freeze_at=freeze_at, source_order_ids=history_source_ids,
                            query_order_ids=history_query_ids)
    combined = base.join(history)
    return combined[list(EXTENDED_FEATURE_NAMES)]


def load_features_with_history(
    connection: psycopg.Connection,
    order_ids: Iterable[str] | None,
    *,
    as_of: datetime | str,
    freeze_at: datetime | str | None = None,
    history_as_of: datetime | str | None = None,
) -> pd.DataFrame:
    """Load contract + point-in-time historical features using only records known at ``as_of``.

    With ``order_ids=None`` the FULL dataset released by ``as_of`` is materialized: per-order
    feature values do not depend on which other orders are requested (same contract as
    :func:`load_features`), so serving builds this one table and slices each request out of it.
    """
    from promiseops import cohorts

    ids = None if order_ids is None else sorted({str(order_id) for order_id in order_ids})
    cutoff = instant(as_of)
    source_cutoff = instant(history_as_of) if history_as_of is not None else cutoff
    if source_cutoff > cutoff:
        raise FeatureError("history snapshot cannot be later than prediction snapshot")
    labels = cohorts.load_labels(connection, as_of=source_cutoff)
    # Historical source rows must be independent of the scoring request IDs.
    history_ids = None if ids is None else sorted(set(labels["order_id"]) | set(ids))
    orders = query_frame(connection, _ORDERS_SQL, {"ids": history_ids, "as_of": cutoff}, ORDER_COLUMNS)
    released = orders["order_id"].tolist()
    items = query_frame(connection, _ITEMS_SQL, {"ids": released}, ITEM_COLUMNS)
    payments = query_frame(connection, _PAYMENTS_SQL, {"ids": released}, PAYMENT_COLUMNS)
    table = compute_features_with_history(orders, items, payments, labels, freeze_at=freeze_at,
                                          history_source_ids=labels["order_id"].tolist(), history_query_ids=ids)
    if ids is None:
        return table
    return table.loc[table.index.isin(ids)]
