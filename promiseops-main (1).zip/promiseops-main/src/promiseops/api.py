import contextlib
import json
import logging
import math
import os
import secrets
import sys
import threading
import time
import uuid
from pathlib import Path

from fastapi import FastAPI, Header, HTTPException, Request, Response, status
from fastapi.exception_handlers import request_validation_exception_handler
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from prometheus_client import (
    CONTENT_TYPE_LATEST,
    CollectorRegistry,
    Counter,
    Gauge,
    Histogram,
    generate_latest,
)

from promiseops import bundle, db, decisions, inference, prediction_history, record
from promiseops.contracts import PredictionRequest, PredictionResponse, instant
from promiseops.features import EXTENDED_FEATURE_NAMES, FEATURE_NAMES

logger = logging.getLogger("promiseops.api")
ALLOWED_FEATURES = EXTENDED_FEATURE_NAMES


class _StdoutHandler(logging.StreamHandler):
    """Writes to whatever sys.stdout is at emit time (pytest swaps it per test)."""

    _promiseops_stdout = True

    def __init__(self):
        super().__init__(sys.stdout)

    @property
    def stream(self):
        return sys.stdout

    @stream.setter
    def stream(self, value):
        pass


def configure_logging() -> None:
    """Send the API's JSON log lines to stdout (container logs) at PROMISEOPS_LOG_LEVEL.

    uvicorn configures only its own loggers, so without this the INFO prediction logs are
    dropped. Idempotent: create_app() runs once per test. propagate stays on for caplog.
    """
    name = os.getenv("PROMISEOPS_LOG_LEVEL", "INFO").strip().upper()
    # A name (DEBUG, info, WARN) or a number ("10"); getLevelName("10") returns the string "Level 10".
    level = int(name) if name.isascii() and name.isdigit() else logging.getLevelName(name)
    if not isinstance(level, int) or level <= logging.NOTSET:
        # A typo must not crash-loop the pod; NOTSET would inherit root's WARNING and drop INFO.
        level = logging.INFO
    logger.setLevel(level)
    if not any(getattr(h, "_promiseops_stdout", False) for h in logger.handlers):
        handler = _StdoutHandler()
        handler.setFormatter(logging.Formatter("%(message)s"))  # messages are already JSON
        logger.addHandler(handler)


def _load_release(PROMISEOPS_RELEASE: str = "release"):
    """Load the model bundle from the release directory."""
    base = Path(PROMISEOPS_RELEASE)
    if base.name == "release.json":
        base = base.parent
    manifest_path = base / "release.json"
    model_path = base / "model.joblib"

    if not manifest_path.is_file() or not model_path.is_file():
        return None, None, None

    try:
        loaded = bundle.read_bundle(base)
        if loaded.lineage is not None:
            record.ModelRecord(manifest=loaded.manifest, lineage=loaded.lineage)
        return loaded.manifest, loaded.model, loaded.lineage
    # Fail closed at the API boundary; never expose arbitrary backend exception text.
    except Exception:  # noqa: BLE001
        return None, None, None


def load_bundle(PROMISEOPS_RELEASE: str = "release"):
    manifest, model, _ = _load_release(PROMISEOPS_RELEASE)
    return manifest, model


# promiseops_retraining_required: how often /metrics re-reads the latest monitoring decision, and how
# long it may wait for the database (a hanging scrape would look like the API being down).
RETRAINING_CHECK_SECONDS = 60
RETRAINING_DB_TIMEOUT_SECONDS = 2
# /readyz is probed every 5s with a 2s timeout: an unbounded database connect there would hang
# the probe and unrout the pod exactly when the database is struggling.
READYZ_DB_TIMEOUT_SECONDS = 2
_clock = time.monotonic  # replaced in tests


def _db_pool_size() -> int:
    """PROMISEOPS_DB_POOL_SIZE, default 8; a typo must not crash-loop the pod."""
    raw = os.getenv("PROMISEOPS_DB_POOL_SIZE", "8").strip()
    try:
        return max(1, int(raw))
    except ValueError:
        return 8


def validate_header(api_key: str | None):
    """Validate the API key from the request header."""
    expected_key = os.getenv("PROMISEOPS_API_KEY")

    if not expected_key or not api_key:
        return False

    return secrets.compare_digest(api_key, expected_key)
def _warm_frozen_feature_cache(app: FastAPI) -> None:
    """Build the frozen feature table once per process, before any request pays for it.

    Fail-open: a failure here only means the first /predict builds it lazily instead; a slow
    or unreachable database must never keep the pod from serving.
    """
    manifest, lineage = app.state.manifest, app.state.lineage
    if manifest is None or lineage is None or not app.state.database_url:
        return
    if tuple(manifest.feature_names) != EXTENDED_FEATURE_NAMES:
        return
    if lineage.history_policy != "frozen-at-train-end-v1":
        return
    cutoff = app.state.as_of if app.state.as_of is not None else lineage.as_of
    started = time.perf_counter()
    try:
        # Direct bounded connect, not the pool: warm-up must never queue behind requests
        # that do not exist yet, and a hanging database must not hold the build forever.
        with db.connect(app.state.database_url, connect_timeout=5, statement_timeout_ms=120_000) as connection:
            inference.release_features(connection, ["cache-warmup"], as_of=cutoff,
                                       manifest=manifest, lineage=lineage,
                                       table_cache=app.state.frozen_feature_cache)
    except Exception as exc:  # noqa: BLE001
        logger.warning(json.dumps({"event": "feature_cache_warm_failed", "error_type": type(exc).__name__},
                                  sort_keys=True))
        return
    logger.info(json.dumps({"event": "feature_cache_warmed", "as_of": cutoff.isoformat(),
                            "duration_ms": round((time.perf_counter() - started) * 1000)}, sort_keys=True))


def create_app():
    """Implement /predict, /healthz, /readyz, /metrics and the public error/auth contract."""

    @contextlib.asynccontextmanager
    async def lifespan(app: FastAPI):
        # Off the startup path: uvicorn binds and readiness passes immediately, while the
        # one-time build runs in the background. A first request that arrives before it
        # finishes simply waits on the build lock (load-test warmup retries cover that).
        threading.Thread(target=_warm_frozen_feature_cache, args=(app,), daemon=True,
                         name="feature-cache-warm").start()
        yield
        app.state.db_pool.close()  # graceful drain: checked-out connections close at their own exit

    configure_logging()
    app = FastAPI(title="PromiseOps — implement your team's service", lifespan=lifespan)
    PROMISEOPS_RELEASE = os.getenv("PROMISEOPS_RELEASE", "release")

    manifest, model, lineage = _load_release(PROMISEOPS_RELEASE)
    app.state.manifest = manifest
    app.state.model = model
    app.state.lineage = lineage
    app.state.database_url = os.getenv("PROMISEOPS_DATABASE_URL", "")
    # Pooled connections for /predict (bounded, verified on reuse); /readyz and /metrics keep
    # their own direct short-timeout connects so probes never wait behind request traffic.
    app.state.db_pool = db.ConnectionPool(app.state.database_url, max_size=_db_pool_size())
    # Frozen full-history feature tables per (cutoff, lineage): built once, sliced per request.
    app.state.frozen_feature_cache = {}
    # Company replay time, not wall clock. If omitted, use the last committed batch timestamp.
    replay = os.getenv("PROMISEOPS_AS_OF")
    app.state.as_of = instant(replay) if replay else None

    registry = CollectorRegistry()
    requests = Counter("promiseops_http_requests_total", "HTTP requests.", ["route", "status"], registry=registry)
    latency = Histogram("promiseops_http_request_duration_seconds", "HTTP latency.",
                        ["route", "status"], registry=registry)
    observations = Counter("promiseops_feature_observations_total", "Feature observations.",
                           ["feature"], registry=registry)
    model_info = Gauge("promiseops_model_info", "Loaded model.", ["model_version"], registry=registry)
    model_info.labels(model_version=manifest.model_version if manifest else "unloaded").set(int(manifest is not None))
    readiness = Gauge("promiseops_ready", "1 when the last /readyz check passed (validated model and reachable DB), "
                      "else 0.", registry=registry)
    readiness.set(0)  # until the first /readyz check (the kubelet probes it every few seconds after start)
    for name in ALLOWED_FEATURES:
        observations.labels(feature=name)
    retraining_required = Gauge(
        "promiseops_retraining_required",
        "1 when the latest conclusive monitoring decision about the served model recommends retraining, else 0.",
        registry=registry,
    )
    retraining_checked_at = [float("-inf")]  # _clock() time of the last database read

    def refresh_retraining_required() -> None:
        """Mirror the latest monitor-train decision (promiseops.decisions), read at most once a minute."""
        now = _clock()
        if now - retraining_checked_at[0] < RETRAINING_CHECK_SECONDS:
            return
        retraining_checked_at[0] = now
        if not app.state.database_url or app.state.manifest is None:
            # Nothing to read the decision from: keep the last value (0 at startup), as on a DB error
            # below. Only a newer monitoring decision may clear the alert.
            return
        try:
            with db.connect(app.state.database_url, connect_timeout=RETRAINING_DB_TIMEOUT_SECONDS,
                            statement_timeout_ms=RETRAINING_DB_TIMEOUT_SECONDS * 1000) as connection:
                recommended = decisions.latest_retrain_recommended(connection, app.state.manifest.model_version)
        # Keep the last value: a DB blip must neither fire nor clear the alert. Log the type only:
        # the message can contain the database URL with its password.
        except Exception as exc:  # noqa: BLE001
            logger.warning(json.dumps({"event": "retraining_check_failed", "error_type": type(exc).__name__},
                                      sort_keys=True))
            return
        retraining_required.set(1 if recommended else 0)

    def require_model():
        if app.state.model is None or app.state.manifest is None:
            raise HTTPException(status_code=503, detail="Model not loaded")
        if tuple(app.state.manifest.feature_names) not in (FEATURE_NAMES, EXTENDED_FEATURE_NAMES):
            raise HTTPException(status_code=503, detail="Unsupported serving feature schema")
        if tuple(app.state.manifest.feature_names) == EXTENDED_FEATURE_NAMES and app.state.lineage is None:
            raise HTTPException(status_code=503, detail="History lineage not loaded")

    def route_label(request: Request) -> str:
        """Route TEMPLATE, never the raw path (bounded labels); both predict paths count as /predict."""
        path = getattr(request.scope.get("route"), "path", "unmatched")
        return "/predict" if path in ("/predict", "/v1/predict") else path

    # 422 and unhandled 500 responses are produced outside the route functions, so the counts in
    # POST_predict never see them. Count them here, with the same labels.
    @app.exception_handler(RequestValidationError)
    async def count_validation_error(request: Request, exc: RequestValidationError):
        requests.labels(route=route_label(request), status="422").inc()
        return await request_validation_exception_handler(request, exc)

    @app.exception_handler(Exception)
    async def count_server_error(request: Request, exc: Exception):
        route = route_label(request)
        requests.labels(route=route, status="500").inc()
        # Type only: exception messages can contain connection strings or other secrets.
        logger.error(json.dumps({"event": "unhandled_error", "route": route, "error_type": type(exc).__name__},
                                sort_keys=True))
        return JSONResponse(status_code=500, content={"detail": "Internal Server Error"})

    @app.get("/healthz", status_code=status.HTTP_200_OK)
    def GET_healthz():
        """Return 200 OK if the service is running."""
        return Response(status_code=status.HTTP_200_OK)

    @app.get("/readyz", status_code=status.HTTP_200_OK)
    def GET_readyz():
        """Return 200 OK if the service is ready to serve predictions."""
        try:
            require_model()
            try:
                with db.connect(app.state.database_url, connect_timeout=READYZ_DB_TIMEOUT_SECONDS,
                                statement_timeout_ms=READYZ_DB_TIMEOUT_SECONDS * 1000) as connection:
                    connection.execute("SELECT 1")
            # Fail closed at the API boundary; never expose arbitrary backend exception text.
            except Exception:  # noqa: BLE001
                raise HTTPException(status_code=503, detail="Database unavailable") from None
        except HTTPException:
            readiness.set(0)
            raise
        readiness.set(1)
        return Response(status_code=status.HTTP_200_OK)

    @app.get("/metrics", status_code=status.HTTP_200_OK)
    def GET_metrics(x_api_key: str | None = Header(default=None, alias="X-API-Key")):
        if not validate_header(x_api_key):
            raise HTTPException(status_code=401, detail="Invalid API key")
        refresh_retraining_required()
        return Response(generate_latest(registry), media_type=CONTENT_TYPE_LATEST)

    @app.post("/v1/predict", response_model=PredictionResponse, status_code=status.HTTP_200_OK)
    @app.post("/predict", response_model=PredictionResponse, status_code=status.HTTP_200_OK)
    def POST_predict(request: PredictionRequest, x_api_key: str | None = Header(default=None, alias="X-API-Key")):
        """Return a prediction for the given order_id and request_id (supports both /v1/predict and legacy /predict)."""
        req_id = request.request_id or uuid.uuid4().hex
        started = time.perf_counter()
        code = 503
        try:
            if not validate_header(x_api_key):
                raise HTTPException(status_code=401, detail="Invalid API key")
            require_model()
            with app.state.db_pool.connection() as connection:
                # Lock before opening the repeatable-read snapshot. A competing retry waits
                # here, then sees the committed original result, even after a deployment.
                lock_key = "prediction:" + req_id
                connection.execute("SELECT pg_advisory_lock(hashtextextended(%s, 0))", (lock_key,))
                try:
                    with connection.transaction():
                        connection.execute("SET TRANSACTION ISOLATION LEVEL REPEATABLE READ")
                        existing = connection.execute(
                            "SELECT order_id, risk_probability, model_version FROM promiseops.predictions WHERE request_id=%s",
                            (req_id,),
                        ).fetchone()
                        if existing:
                            if existing[0] != request.order_id:
                                raise HTTPException(status_code=409, detail="request_id already used for a different order_id")
                            code = 200
                            return PredictionResponse(order_id=existing[0], request_id=req_id,
                                                      risk_probability=existing[1], model_version=existing[2])
                        cutoff = app.state.as_of
                        if cutoff is None and app.state.lineage is not None:
                            # A frozen-history release is bound to the company time it was
                            # trained and evaluated at: replay predictions at lineage.as_of —
                            # the only snapshot where its frozen history is neither from the
                            # future nor stale. New batches beyond it require a new release.
                            cutoff = app.state.lineage.as_of
                        if cutoff is None:
                            cutoff = connection.execute(
                                "SELECT max(available_at) FROM promiseops.ingest_batches"
                            ).fetchone()[0]
                        if cutoff is None:
                            raise HTTPException(status_code=404, detail="Order not available")
                        table = inference.release_features(connection, [request.order_id], as_of=cutoff,
                                                           manifest=app.state.manifest, lineage=app.state.lineage,
                                                           table_cache=app.state.frozen_feature_cache)
                        if table.empty:
                            raise HTTPException(status_code=404, detail="Order not available")
                        risk_probability = float(app.state.model.predict_proba(
                            table.loc[[request.order_id], app.state.manifest.feature_names]
                        )[0][1])
                        if not math.isfinite(risk_probability) or not 0 <= risk_probability <= 1:
                            raise ValueError("Invalid model probability")
                        connection.execute(
                            "INSERT INTO promiseops.predictions (request_id, order_id, risk_probability, model_version) "
                            "VALUES (%s, %s, %s, %s)",
                            (req_id, request.order_id, risk_probability, app.state.manifest.model_version),
                        )
                        prediction_history.record_snapshot(
                            connection, request_id=req_id, predicted_at=cutoff,
                            feature_row=table.loc[[request.order_id], app.state.manifest.feature_names],
                            artifact_sha256=app.state.manifest.artifact_sha256,
                        )
                finally:
                    # The lock is session-scoped: release it explicitly so a pooled connection
                    # never carries it into an unrelated request. A connection that cannot
                    # release it is closed, which drops the lock with its session.
                    try:
                        connection.execute("SELECT pg_advisory_unlock(hashtextextended(%s, 0))", (lock_key,))
                    except Exception:  # noqa: BLE001
                        with contextlib.suppress(Exception):
                            connection.close()
            for name in app.state.manifest.feature_names:
                if name in ALLOWED_FEATURES:
                    observations.labels(feature=name).inc()
            code = 200
            return PredictionResponse(order_id=request.order_id, request_id=req_id,
                                      risk_probability=risk_probability, model_version=app.state.manifest.model_version)
        except HTTPException as exc:
            code = exc.status_code
            raise
        except ValueError as exc:
            # Our own raised reasons (feature schema, frozen history) are credential-free
            # strings: surface them so a 503 is diagnosable from the pod log alone.
            code = 503
            logger.warning(json.dumps({"event": "prediction_failed", "reason": str(exc)}, sort_keys=True))
            raise HTTPException(status_code=503, detail="Prediction unavailable") from None
        # Fail closed at the API boundary; never expose arbitrary backend exception text.
        except Exception:  # noqa: BLE001
            # Database exceptions can contain DSNs; expose a stable, credential-free response.
            code = 503
            raise HTTPException(status_code=503, detail="Prediction unavailable") from None

        finally:
            elapsed = time.perf_counter() - started
            requests.labels(route="/predict", status=str(code)).inc()
            latency.labels(route="/predict", status=str(code)).observe(elapsed)
            logger.info(json.dumps({"event": "prediction", "request_id": req_id, "status": code,
                                    "model_version": app.state.manifest.model_version if app.state.manifest else "unloaded",
                                    "latency_ms": round(elapsed * 1000, 2)}, sort_keys=True))
    return app
