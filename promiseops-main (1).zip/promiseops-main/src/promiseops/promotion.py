"""Model promotion lifecycle: candidate -> champion in the MLflow Model Registry.

What this module is (and is deliberately NOT)
---------------------------------------------
The queued worker (#15) trains a candidate, compares it with the champion on identical validation
IDs and logs the comparison into the training run. This module is the NEXT lifecycle step, driven by
the Airflow DAG (promiseops_training): register the finished run as a registry version, verify the
recorded comparison against configurable policy thresholds, and decide whether the candidate becomes
the new champion. Promotion is a REGISTRY operation only:

    * it moves the ``champion`` alias and writes role/status tags and a promotion-metadata run;
    * it NEVER deploys anything: no Kubernetes, no FastAPI service, no release image
      (docs/CONTRACTS.md: "MLflow candidate registration does not promote production"; the running
      service reads its bundle from disk baked into the image and never resolves a mutable alias).

Roles and statuses (model version tags, ``promiseops.*`` like the rest of the project)
--------------------------------------------------------------------------------------
===============  ============================================  ==============================
tag              meaning                                       set by
===============  ============================================  ==============================
``role``         candidate | champion | former_champion        promotion tasks
``validation_``  pending | approved | rejected                 promotion tasks
``status``
===============  ============================================  ==============================

The champion is the version the ``champion`` alias points at; the previous champion version stays in
the registry (tagged ``former_champion``), it is never deleted. The challenger is simply the
candidate under evaluation: a registered version with ``role=candidate``.

Why the evaluation reads the training run instead of re-scoring
---------------------------------------------------------------
The worker already scored candidate AND champion on the same validation cohort and logged both
(``validation_*`` metrics of the record, ``champion.*`` metrics of the run). Re-scoring in the DAG
would need the database and the feature code in the scheduler and could disagree with the recorded
cohort. The evaluation here therefore verifies the RECORDED numbers against the promotion policy:
absolute floors (configurable) plus relative criteria versus the compared champion (recall must not
decrease, PR-AUC/Brier drift bounded — defaults are exactly the public gates of promiseops.gates,
and the policy can only be STRICTER than them). A candidate the worker's gate rejected is never
registered, so it never reaches this decision.

Retry and concurrency rules
---------------------------
* Registration is idempotent per run (same-run retries reuse the version, tests/test_registry_mlflow.py).
* A decided version (``validation_status`` approved/rejected) is never re-decided or reset: retries
  return the recorded outcome instead of acting again.
* The alias move is the single commitment point and is done first; a crash after it is recovered on
  retry (the candidate sees the alias already pointing at itself and completes the bookkeeping).
* A promotion is refused when the champion alias moved between evaluation and decision
  (:class:`PromotionConflict`): another run promoted meanwhile; the task must be retried so the
  decision is derived against the new champion. Within one DAG, ``max_active_runs=1`` serializes runs.

MLflow is imported lazily by the CLI path, like promiseops.record/registry.
"""

import json
import os
import tempfile
import time
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Literal

from promiseops import bundle, gates, record, registry, tracking

ALIAS_CHAMPION = "champion"
PROMOTION_EXPERIMENT = "promiseops-promotion"
EVALUATION_FILE = "evaluation.json"

ROLE_CANDIDATE = "candidate"
ROLE_CHAMPION = "champion"
ROLE_FORMER_CHAMPION = "former_champion"

STATUS_PENDING = "pending"
STATUS_APPROVED = "approved"
STATUS_REJECTED = "rejected"

TAG_ROLE = "promiseops.role"
TAG_VALIDATION_STATUS = "promiseops.validation_status"
TAG_PROMOTED_AT = "promiseops.promoted_at"
TAG_REJECTION_REASON = "promiseops.rejection_reason"
TAG_PROMOTION_RUN = "promiseops.promotion_run_id"

TAG_DECISION = "promiseops.promotion_decision"
TAG_CANDIDATE_VERSION = "promiseops.candidate_registry_version"
TAG_PREVIOUS_CHAMPION = "promiseops.previous_champion_version"
TAG_NEW_CHAMPION = "promiseops.new_champion_version"

# Tolerance for float comparisons of recorded metrics (same idea as promiseops.gates).
_TOLERANCE = 1e-12


class PromotionError(RuntimeError):
    """A promotion operation cannot be done as asked (bad configuration, ambiguous state)."""


class PromotionConflict(PromotionError):
    """The champion changed between evaluation and decision: the decision must be re-derived."""


# --- Configuration ---------------------------------------------------------------------------------------
_ENV_PREFIX = "PROMISEOPS_PROMOTION_"


@dataclass(frozen=True)
class PromotionConfig:
    """Policy thresholds and registry names. Defaults == the public gates (promiseops.gates).

    Every value is overridable through ``PROMISEOPS_PROMOTION_*`` environment variables (see
    :meth:`from_env`), so no model name, alias, experiment or threshold is hardcoded in the DAG.
    The relative criteria can only be stricter than the contract gates: recall may never decrease,
    and the PR-AUC/Brier allowances are capped at the public gate values.
    """

    model_name: str = registry.REGISTERED_MODEL
    champion_alias: str = ALIAS_CHAMPION
    experiment: str = PROMOTION_EXPERIMENT
    # Absolute floors: a candidate must be good on its own, not only "better than a bad champion".
    min_recall_at_10: float = 0.0
    min_pr_auc: float = 0.0
    max_brier: float = 1.0
    # Relative criteria versus the compared champion (the training run's recorded comparison).
    min_recall_improvement: float = 0.0        # recall must not decrease; > 0 demands real improvement
    max_pr_auc_decrease: float = gates.PR_AUC_MAX_DECREASE
    max_brier_increase: float = gates.BRIER_MAX_INCREASE

    def __post_init__(self) -> None:
        _check_fraction("min_recall_at_10", self.min_recall_at_10)
        _check_fraction("min_pr_auc", self.min_pr_auc)
        if not 0.0 <= self.max_brier <= 1.0:
            raise PromotionError("max_brier must be within [0, 1]")
        if self.min_recall_improvement < 0.0:
            raise PromotionError("min_recall_improvement must be >= 0: recall may never decrease")
        if not 0.0 <= self.max_pr_auc_decrease <= gates.PR_AUC_MAX_DECREASE:
            raise PromotionError(f"max_pr_auc_decrease must be within [0, {gates.PR_AUC_MAX_DECREASE}] "
                                 "(the public gate; lowering it further is allowed, widening it is not)")
        if not 0.0 <= self.max_brier_increase <= gates.BRIER_MAX_INCREASE:
            raise PromotionError(f"max_brier_increase must be within [0, {gates.BRIER_MAX_INCREASE}] "
                                 "(the public gate; lowering it further is allowed, widening it is not)")
        if not self.model_name.strip() or not self.champion_alias.strip():
            raise PromotionError("model_name and champion_alias must not be empty")

    @classmethod
    def from_env(cls, environ: Mapping[str, str] | None = None, *,
                 model_name: str | None = None) -> "PromotionConfig":
        """Build the configuration from ``PROMISEOPS_PROMOTION_*`` environment variables.

        ``model_name`` (the CLI ``--name`` flag) overrides the environment/model default.
        """
        env = os.environ if environ is None else environ

        def text(name: str, default: str) -> str:
            value = env.get(_ENV_PREFIX + name, "").strip()
            return value or default

        def number(name: str, default: float) -> float:
            raw = env.get(_ENV_PREFIX + name, "").strip()
            if not raw:
                return default
            try:
                return float(raw)
            except ValueError as error:
                raise PromotionError(f"{_ENV_PREFIX}{name}={raw!r} is not a number") from error

        return cls(
            model_name=model_name or text("MODEL_NAME", registry.REGISTERED_MODEL),
            champion_alias=text("CHAMPION_ALIAS", ALIAS_CHAMPION),
            experiment=text("EXPERIMENT", PROMOTION_EXPERIMENT),
            min_recall_at_10=number("MIN_RECALL_AT_10", 0.0),
            min_pr_auc=number("MIN_PR_AUC", 0.0),
            max_brier=number("MAX_BRIER", 1.0),
            min_recall_improvement=number("MIN_RECALL_IMPROVEMENT", 0.0),
            max_pr_auc_decrease=number("MAX_PR_AUC_DECREASE", gates.PR_AUC_MAX_DECREASE),
            max_brier_increase=number("MAX_BRIER_INCREASE", gates.BRIER_MAX_INCREASE),
        )


def _check_fraction(name: str, value: float) -> None:
    if not 0.0 <= value <= 1.0:
        raise PromotionError(f"{name} must be within [0, 1]")


# --- Registration ----------------------------------------------------------------------------------------
def register_candidate(client: Any, run_id: str, logged: record.ModelRecord, *,
                       config: PromotionConfig | None = None) -> registry.RegisteredVersion:
    """Register the accepted candidate of a finished training run and mark it ``role=candidate``.

    Idempotent: a retried task reuses the existing version of the same run (registry.register_candidate)
    and NEVER resets a version that was already decided (approved/rejected) back to ``pending``.
    """
    cfg = config or PromotionConfig()
    version = registry.register_candidate(client, run_id, logged, name=cfg.model_name)
    tags = client.get_model_version(cfg.model_name, version.version).tags or {}
    if not tags.get(TAG_VALIDATION_STATUS):
        client.set_model_version_tag(cfg.model_name, version.version, TAG_ROLE, ROLE_CANDIDATE)
        client.set_model_version_tag(cfg.model_name, version.version, TAG_VALIDATION_STATUS, STATUS_PENDING)
    return version


@dataclass(frozen=True)
class CandidateRun:
    """One finished training run found for the DAG's cutoffs, before registration."""

    run_id: str
    gate_decision: str
    gate_reasons: tuple[str, ...]
    model_version: str
    artifact_sha256: str


def find_candidate_run(client: Any, *, train_end: datetime | str, validation_end: datetime | str,
                       as_of: datetime | str, created_after: datetime | None = None) -> CandidateRun | None:
    """The finished training run this DagRun produced, matched by its ``requested.*`` params.

    The worker logs ``requested.train_end`` / ``requested.validation_end`` / ``requested.as_of`` on
    its run (promiseops.training), so the DAG can find the run it submitted without trusting wall
    clocks. ``created_after`` (the DagRun start) excludes runs of EARLIER DagRuns with identical
    cutoffs. Several matching runs are acceptable only when they describe the SAME model bytes
    (same artifact SHA256 tag, e.g. deduplicated reruns); otherwise the state is ambiguous and the
    caller must not guess which model to promote.
    """
    wanted = [_param_value(value) for value in (train_end, validation_end, as_of)]
    experiment = client.get_experiment_by_name(tracking.TRAINING_EXPERIMENT)
    if experiment is None:
        return None  # nothing was ever trained: keep waiting instead of creating an experiment
    runs = client.search_runs(
        [experiment.experiment_id],
        filter_string=(f"params.`requested.train_end` = '{wanted[0]}' and "
                       f"params.`requested.validation_end` = '{wanted[1]}' and "
                       f"params.`requested.as_of` = '{wanted[2]}'"),
        order_by=["attributes.start_time DESC"],
    )
    finished = [run for run in runs if run.info.status == "FINISHED"]
    if created_after is not None:
        floor_ms = int((created_after.astimezone(UTC).timestamp() - _CLOCK_SKEW_S) * 1000)
        finished = [run for run in finished if run.info.start_time >= floor_ms]
    if not finished:
        return None
    identities = {(run.data.tags.get(record.TAG_ARTIFACT_SHA256), run.data.tags.get(record.TAG_MODEL_VERSION))
                  for run in finished}
    if len(identities) > 1:
        raise PromotionError(
            f"{len(finished)} finished runs match cutoffs {'/'.join(wanted)} but describe different models "
            f"({sorted(sha or '?' for sha, _ in identities)}); refusing to guess which one to promote")
    run = finished[0]
    return CandidateRun(
        run_id=run.info.run_id,
        gate_decision=run.data.tags.get(record.TAG_GATE_DECISION, "not_evaluated"),
        gate_reasons=tuple((run.data.tags.get("promiseops.gate_reasons") or "").split("; ")) if
        run.data.tags.get("promiseops.gate_reasons") else (),
        model_version=run.data.tags.get(record.TAG_MODEL_VERSION, ""),
        artifact_sha256=run.data.tags.get(record.TAG_ARTIFACT_SHA256, ""),
    )


_CLOCK_SKEW_S = 600  # scheduler/MLflow server clock difference tolerated by created_after


def _param_value(value: str) -> str:
    """Normalize a cutoff the way the worker logs it (UTC isoformat), and refuse filter injection."""
    from promiseops.contracts import instant

    try:
        parsed = instant(value)
    except ValueError as error:
        raise PromotionError(f"invalid cutoff value: {value!r}") from error
    normalized = parsed.astimezone(UTC).isoformat()
    if any(character in normalized for character in ("'", "`", "\\")):
        raise PromotionError(f"invalid cutoff value: {value!r}")
    return normalized


# --- Evaluation ------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class EvaluationResult:
    """Outcome of verifying the recorded candidate-vs-champion comparison against the policy."""

    name: str
    version: str
    run_id: str
    model_version: str
    artifact_sha256: str
    cohort_sha256: str
    decision: Literal["promote", "reject"]
    reasons: tuple[str, ...]
    candidate_metrics: bundle.EvaluationMetrics
    champion_metrics: bundle.EvaluationMetrics | None
    compared_champion_version: str | None       # what the run was compared against (baseline name or version)
    champion_alias_version: str | None          # registry version the champion alias pointed at during evaluation
    champion_alias_model_version: str | None

    def summary(self) -> dict[str, Any]:
        """Small JSON-friendly form for XCom and logs (no bundles, no datasets)."""
        return {"name": self.name, "version": self.version, "run_id": self.run_id,
                "model_version": self.model_version, "artifact_sha256": self.artifact_sha256,
                "cohort_sha256": self.cohort_sha256, "decision": self.decision,
                "reasons": list(self.reasons),
                "candidate_metrics": {key: round(value, 6)
                                      for key, value in self.candidate_metrics.model_dump().items()},
                "champion_metrics": None if self.champion_metrics is None else
                {key: round(value, 6) for key, value in self.champion_metrics.model_dump().items()},
                "compared_champion_version": self.compared_champion_version,
                "champion_alias_version": self.champion_alias_version,
                "champion_alias_model_version": self.champion_alias_model_version}


def evaluate_candidate(client: Any, version: str, *, config: PromotionConfig | None = None) -> EvaluationResult:
    """Verify the recorded comparison of one registered candidate against the promotion policy.

    Read-only. Downloads and verifies the candidate bundle (a broken or swapped artifact fails here,
    before any decision), reads the ``champion.*`` comparison metrics the worker logged on the run,
    cross-checks the champion alias, and applies the policy. Missing or invalid recorded metrics are
    a REJECTION (never an exception): the only safe answer to "cannot verify quality" is "no".
    """
    cfg = config or PromotionConfig()
    stored = client.get_model_version(cfg.model_name, str(version))
    run_id = stored.run_id
    champion_alias = registry.alias_version(client, cfg.champion_alias, name=cfg.model_name)
    with tempfile.TemporaryDirectory(prefix="promiseops-evaluate-") as folder:
        # RegistryError (artifact missing/tampered) propagates: an unverifiable candidate must fail
        # the task, not silently decide about it.
        loaded = registry.download_version(client, _as_registered(stored), Path(folder) / "candidate")
    candidate_metrics = loaded.lineage.validation_metrics
    compared = loaded.lineage.champion_model_version
    run = client.get_run(run_id)
    champion_metrics, metric_error = _champion_metrics_from_run(run.data.metrics)
    reasons: list[str] = []
    if champion_metrics is None:  # missing or invalid recorded comparison: never promote on trust
        decision = "reject"
        reasons.append(f"FAIL: recorded champion comparison unusable ({metric_error})")
    else:
        passed, gate_reasons = apply_policy(candidate_metrics, champion_metrics, config=cfg)
        reasons.extend(gate_reasons)
        decision = "promote" if passed else "reject"
    if champion_alias is not None and compared != champion_alias.model_version:
        decision = "reject"
        reasons.append(f"FAIL: stale comparison: the run was compared against {compared!r} but the "
                       f"'{cfg.champion_alias}' alias currently points at "
                       f"{champion_alias.model_version!r} (version {champion_alias.version}); "
                       "a changed champion requires reevaluation")
    return EvaluationResult(
        name=cfg.model_name, version=str(version), run_id=run_id,
        model_version=loaded.model_version, artifact_sha256=loaded.artifact_sha256,
        cohort_sha256=loaded.lineage.validation_cohort_sha256, decision=decision, reasons=tuple(reasons),
        candidate_metrics=candidate_metrics, champion_metrics=champion_metrics,
        compared_champion_version=compared,
        champion_alias_version=champion_alias.version if champion_alias else None,
        champion_alias_model_version=champion_alias.model_version if champion_alias else None)


def _as_registered(stored: Any) -> registry.RegisteredVersion:
    """Rebuild the validated RegisteredVersion from a stored model version (tags must be ours)."""
    tags = stored.tags or {}
    if record.TAG_ARTIFACT_SHA256 not in tags or record.TAG_MODEL_VERSION not in tags:
        raise registry.RegistryError(f"{stored.name} version {stored.version} was not registered by "
                                     "PromiseOps (no SHA256 / model_version tags); refusing to use it")
    return registry.RegisteredVersion(name=stored.name, version=str(stored.version), run_id=stored.run_id,
                                      model_version=tags[record.TAG_MODEL_VERSION],
                                      artifact_sha256=tags[record.TAG_ARTIFACT_SHA256])


_CHAMPION_METRIC_KEYS = ("n", "prevalence", "k", "recall_at_10", "precision_at_10", "pr_auc", "brier")


def _champion_metrics_from_run(metrics: Mapping[str, float]
                               ) -> tuple[bundle.EvaluationMetrics | None, str | None]:
    """The champion scores the worker logged on the candidate's own validation cohort.

    Returns (None, reason) when the comparison is missing or invalid: the caller rejects instead of
    promoting on unverifiable numbers.
    """
    values = {key[len("champion."):]: value for key, value in metrics.items() if key.startswith("champion.")}
    missing = sorted(set(_CHAMPION_METRIC_KEYS) - set(values))
    if missing:
        return None, f"missing run metrics: champion.{', champion.'.join(missing)}"
    try:
        return bundle.EvaluationMetrics.model_validate(values), None
    except ValueError as error:
        return None, f"invalid values: {error}"


def apply_policy(candidate: bundle.EvaluationMetrics, champion: bundle.EvaluationMetrics, *,
                 config: PromotionConfig) -> tuple[bool, list[str]]:
    """Absolute floors + relative criteria. Mirrors promiseops.gates with configurable margins."""
    checks: list[tuple[bool, str]] = [
        _check("recall@10% absolute floor", candidate.recall_at_10 >= config.min_recall_at_10 - _TOLERANCE,
               f"candidate {candidate.recall_at_10:.4f} must be >= {config.min_recall_at_10:.4f}"),
        _check("PR-AUC absolute floor", candidate.pr_auc >= config.min_pr_auc - _TOLERANCE,
               f"candidate {candidate.pr_auc:.4f} must be >= {config.min_pr_auc:.4f}"),
        _check("Brier absolute ceiling", candidate.brier <= config.max_brier + _TOLERANCE,
               f"candidate {candidate.brier:.4f} must be <= {config.max_brier:.4f}"),
    ]
    if (candidate.n, candidate.prevalence) != (champion.n, champion.prevalence):
        mismatch = ("FAIL: candidate and champion metrics come from different cohorts "
                    f"(candidate N={candidate.n} prevalence={candidate.prevalence:.4f}, "
                    f"champion N={champion.n} prevalence={champion.prevalence:.4f})")
        checks.append((False, mismatch))
    else:
        checks.extend([
            _check("recall@10% vs champion",
                   candidate.recall_at_10 >= champion.recall_at_10 + config.min_recall_improvement - _TOLERANCE,
                   f"candidate {candidate.recall_at_10:.4f} vs champion {champion.recall_at_10:.4f} "
                   f"(must not decrease; improvement >= {config.min_recall_improvement:.4f})"),
            _check("PR-AUC vs champion",
                   candidate.pr_auc >= champion.pr_auc - config.max_pr_auc_decrease - _TOLERANCE,
                   f"candidate {candidate.pr_auc:.4f} vs champion {champion.pr_auc:.4f} "
                   f"(may decrease by at most {config.max_pr_auc_decrease:.4f})"),
            _check("Brier vs champion",
                   candidate.brier <= champion.brier + config.max_brier_increase + _TOLERANCE,
                   f"candidate {candidate.brier:.4f} vs champion {champion.brier:.4f} "
                   f"(may increase by at most {config.max_brier_increase:.4f})"),
        ])
    return all(ok for ok, _ in checks), [text for _, text in checks]


def _check(name: str, ok: bool, detail: str) -> tuple[bool, str]:
    return ok, f"{'pass' if ok else 'FAIL'}: {name}: {detail}"


# --- Decision --------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class PromotionOutcome:
    """What the decision did (or had already done). ``summary`` is the XCom/log form."""

    status: Literal["promoted", "rejected", "already_promoted", "already_rejected"]
    name: str
    version: str
    model_version: str
    previous_champion_version: str | None
    new_champion_version: str | None
    metadata_run_id: str | None
    decision: Literal["promote", "reject"]
    reasons: tuple[str, ...]
    evaluation: EvaluationResult | None = None

    def summary(self) -> dict[str, Any]:
        return {"status": self.status, "name": self.name, "version": self.version,
                "model_version": self.model_version,
                "previous_champion_version": self.previous_champion_version,
                "new_champion_version": self.new_champion_version,
                "metadata_run_id": self.metadata_run_id, "decision": self.decision,
                "reasons": list(self.reasons),
                "evaluation": self.evaluation.summary() if self.evaluation else None}


def decide_promotion(client: Any, version: str, *, config: PromotionConfig | None = None,
                     now: datetime | None = None) -> PromotionOutcome:
    """Apply the promotion decision for one registered candidate version. Safe to retry.

    State is re-read from the registry on every call:
    * already decided -> the recorded outcome is returned, nothing is acted on again;
    * reject -> the candidate is tagged ``validation_status=rejected`` with the reason, the champion
      alias is untouched, and the rejection is recorded;
    * promote -> the ``champion`` alias is moved FIRST (the commitment point), then the role/status
      tags, then the previous champion is tagged ``former_champion`` (its version is preserved), and
      the promotion metadata (timestamp, previous/new champion, evaluation results) is recorded in a
      dedicated run of the promotion experiment. A crash between these steps is completed by the
      next retry; if the alias moved elsewhere meanwhile, :class:`PromotionConflict` is raised so
      the decision is re-derived against the new champion.
    """
    cfg = config or PromotionConfig()
    version = str(version)
    stored = client.get_model_version(cfg.model_name, version)
    tags = stored.tags or {}
    decided_at = (now or datetime.now(UTC)).astimezone(UTC)
    if (status := tags.get(TAG_VALIDATION_STATUS)) in (STATUS_APPROVED, STATUS_REJECTED):
        alias = registry.alias_version(client, cfg.champion_alias, name=cfg.model_name)
        if status == STATUS_APPROVED and (alias is None or alias.version != version):
            raise PromotionConflict(
                f"{cfg.model_name} version {version} is approved but the '{cfg.champion_alias}' alias points "
                f"at {alias.version if alias else '<nothing>'}; resolve this manually before promoting again")
        outcome_status = "already_promoted" if status == STATUS_APPROVED else "already_rejected"
        return PromotionOutcome(status=outcome_status, name=cfg.model_name, version=version,
                                model_version=tags.get(record.TAG_MODEL_VERSION, ""),
                                previous_champion_version=None,
                                new_champion_version=version if status == STATUS_APPROVED else None,
                                metadata_run_id=tags.get(TAG_PROMOTION_RUN),
                                decision="promote" if status == STATUS_APPROVED else "reject",
                                reasons=("decision already recorded in the registry",))
    evaluation = evaluate_candidate(client, version, config=cfg)
    if evaluation.decision == "reject":
        return _record_rejection(client, evaluation, config=cfg, now=decided_at)
    return _record_promotion(client, evaluation, config=cfg, now=decided_at)


def _record_rejection(client: Any, evaluation: EvaluationResult, *, config: PromotionConfig,
                      now: datetime) -> PromotionOutcome:
    """Tag the candidate rejected and record why. The champion alias is never touched here."""
    cfg = config or PromotionConfig()
    reason = "; ".join(evaluation.reasons)[:500]
    client.set_model_version_tag(cfg.model_name, evaluation.version, TAG_VALIDATION_STATUS, STATUS_REJECTED)
    client.set_model_version_tag(cfg.model_name, evaluation.version, TAG_REJECTION_REASON, reason)
    metadata_run_id = _log_promotion_metadata(client, evaluation, config=cfg, now=now, decision="reject",
                                              previous_champion_version=None)
    client.set_model_version_tag(cfg.model_name, evaluation.version, TAG_PROMOTION_RUN, metadata_run_id)
    return PromotionOutcome(status="rejected", name=cfg.model_name, version=evaluation.version,
                            model_version=evaluation.model_version, previous_champion_version=None,
                            new_champion_version=None, metadata_run_id=metadata_run_id,
                            decision="reject", reasons=evaluation.reasons, evaluation=evaluation)


def _record_promotion(client: Any, evaluation: EvaluationResult, *, config: PromotionConfig,
                      now: datetime) -> PromotionOutcome:
    """Commit the promotion: alias first, then tags, then metadata; recoverable at every point."""
    cfg = config or PromotionConfig()
    stored = client.get_model_version(cfg.model_name, evaluation.version)
    current = registry.alias_version(client, cfg.champion_alias, name=cfg.model_name)
    if current is not None and current.version == evaluation.version:
        # Crash recovery: a retry already moved the alias to this candidate. The intended previous
        # champion was recorded on the version BEFORE the move, so the metadata stays complete.
        previous = (stored.tags or {}).get(TAG_PREVIOUS_CHAMPION) or None
    else:
        expected = evaluation.champion_alias_version
        if current is not None and current.version != expected:
            raise PromotionConflict(
                f"the '{cfg.champion_alias}' alias moved from version {expected!r} to {current.version!r} "
                f"while {cfg.model_name} version {evaluation.version} was being decided; the decision must "
                "be re-derived against the new champion")
        previous = current.version if current else None
        # Record the intent BEFORE the commitment point, so a crash after the alias move is recoverable.
        client.set_model_version_tag(cfg.model_name, evaluation.version, TAG_PREVIOUS_CHAMPION, previous or "")
        previous = registry.move_alias(client, cfg.champion_alias, evaluation.version, name=cfg.model_name)
    decided_at = now.astimezone(UTC).isoformat()
    client.set_model_version_tag(cfg.model_name, evaluation.version, TAG_ROLE, ROLE_CHAMPION)
    client.set_model_version_tag(cfg.model_name, evaluation.version, TAG_VALIDATION_STATUS, STATUS_APPROVED)
    client.set_model_version_tag(cfg.model_name, evaluation.version, TAG_PROMOTED_AT, decided_at)
    if previous is not None:
        client.set_model_version_tag(cfg.model_name, previous, TAG_ROLE, ROLE_FORMER_CHAMPION)
    metadata_run_id = _log_promotion_metadata(client, evaluation, config=cfg, now=now, decision="promote",
                                              previous_champion_version=previous)
    client.set_model_version_tag(cfg.model_name, evaluation.version, TAG_PROMOTION_RUN, metadata_run_id)
    return PromotionOutcome(status="promoted", name=cfg.model_name, version=evaluation.version,
                            model_version=evaluation.model_version, previous_champion_version=previous,
                            new_champion_version=evaluation.version, metadata_run_id=metadata_run_id,
                            decision="promote", reasons=evaluation.reasons, evaluation=evaluation)


def _log_promotion_metadata(client: Any, evaluation: EvaluationResult, *, config: PromotionConfig,
                            now: datetime, decision: str, previous_champion_version: str | None) -> str:
    """One MLflow run in the promotion experiment: timestamp, versions, reasons, evaluation results.

    Idempotent: the run is found by its candidate-version tag, so a retried task extends the
    existing record instead of writing a second one.
    """
    experiment_id = tracking.ensure_experiment(client, config.experiment)
    existing = client.search_runs([experiment_id], filter_string=f"tags.`{TAG_CANDIDATE_VERSION}` = "
                                  f"'{evaluation.version}'", order_by=["attributes.start_time DESC"])
    if existing:
        return existing[0].info.run_id
    run_id = client.create_run(experiment_id, tags=tracking.run_tags("promotion", None) | {
        TAG_DECISION: decision, TAG_CANDIDATE_VERSION: evaluation.version,
        TAG_PREVIOUS_CHAMPION: previous_champion_version or "",
        TAG_NEW_CHAMPION: evaluation.version if decision == "promote" else "",
    }, run_name=f"{decision}-{config.model_name}-v{evaluation.version}").info.run_id
    params = {
        "decided_at": now.astimezone(UTC).isoformat(),
        "candidate_registry_version": evaluation.version,
        "candidate_run_id": evaluation.run_id,
        "candidate_model_version": evaluation.model_version,
        "candidate_artifact_sha256": evaluation.artifact_sha256,
        "validation_cohort_sha256": evaluation.cohort_sha256,
        "compared_champion_version": evaluation.compared_champion_version or "",
        "champion_alias_version_at_evaluation": evaluation.champion_alias_version or "",
        "previous_champion_version": previous_champion_version or "",
        "new_champion_version": evaluation.version if decision == "promote" else "",
    }
    metric_values = {f"candidate.{key}": float(value)
                     for key, value in evaluation.candidate_metrics.model_dump().items()}
    if evaluation.champion_metrics is not None:
        metric_values |= {f"champion.{key}": float(value)
                          for key, value in evaluation.champion_metrics.model_dump().items()}
    from mlflow.entities import Metric, Param  # lazy, like promiseops.record

    now_ms = int(time.time() * 1000)
    client.log_batch(run_id, metrics=[Metric(key, value, now_ms, 0) for key, value in metric_values.items()],
                     params=[Param(key, value) for key, value in params.items()])
    client.log_text(run_id, json.dumps(evaluation.summary(), indent=2, sort_keys=True) + "\n", EVALUATION_FILE)
    client.set_terminated(run_id, "FINISHED")
    return run_id
