"""PostgreSQL connection and schema setup (small on purpose: no ORM, no migration framework).

* psycopg 3 directly (already pinned in requirements.lock): explicit SQL and explicit
  transactions are easier to review than ORM magic. SQLAlchemy stays available to others.
* Plain idempotent SQL (``schema.sql``) instead of Alembic: Alembic is not in the app image's
  locked dependencies, and one versioned, re-runnable file is enough for one schema version.
* The database URL comes only from ``PROMISEOPS_DATABASE_URL`` (staff runtime secret in the
  cluster) and is never logged, because it contains the password.
"""

import contextlib
import os
import threading
from collections.abc import Iterator
from importlib import resources

import psycopg
from psycopg import pq

DATABASE_URL_ENV = "PROMISEOPS_DATABASE_URL"
SCHEMA_VERSION = 4
# Serialises concurrent `db-init` runs (e.g. two pods starting at once). Arbitrary fixed number.
_SCHEMA_LOCK_KEY = 0x50524F4D_53434845  # "PROMSCHE"


class SchemaNotReady(RuntimeError):
    """The worker image and database migration are not ready to run together."""


def require_schema(connection: psycopg.Connection) -> None:
    """Read-only preflight; a worker must never apply a production migration implicitly."""
    required = ("schema_version", "ingest_batches", "customers", "sellers", "products", "orders",
                "order_items", "order_payments", "outcomes", "predictions", "prediction_snapshots",
                "monitoring_decisions")
    missing = [name for name, relation in connection.execute(
        "SELECT name, to_regclass('promiseops.' || name) FROM unnest(%s::text[]) AS name", (list(required),))
        if relation is None]
    if missing:
        raise SchemaNotReady(f"Missing promiseops tables: {', '.join(missing)}; deploy owner must run "
                             "the reviewed promiseops db-init migration before enabling workers")
    version = connection.execute("SELECT max(version) FROM promiseops.schema_version").fetchone()[0]
    if version != SCHEMA_VERSION:
        raise SchemaNotReady(f"Database schema version {version} does not match worker {SCHEMA_VERSION}; "
                             "coordinate the reviewed migration/image; no migration was attempted")


def connect(url: str | None = None, *, connect_timeout: int | None = None,
            statement_timeout_ms: int | None = None) -> psycopg.Connection:
    """Open an autocommit connection; transactions are opened explicitly with ``conn.transaction()``.

    ``connect_timeout`` (seconds) and ``statement_timeout_ms`` (also used as the lock timeout) bound
    callers that must not hang on an unreachable, slow or locked database, such as the API's /metrics.
    """
    url = url or os.environ.get(DATABASE_URL_ENV)
    if not url:
        raise RuntimeError(f"{DATABASE_URL_ENV} is not set")
    scheme, _, rest = url.partition("://")
    if scheme.startswith("postgresql+"):
        # Platform DB secrets arrive in SQLAlchemy dialect form ("postgresql+psycopg://…");
        # libpq's conninfo parser only understands the plain "postgresql://" scheme.
        url = f"postgresql://{rest}"
    options: dict[str, object] = {} if connect_timeout is None else {"connect_timeout": connect_timeout}
    if statement_timeout_ms is not None:
        limit = f"{statement_timeout_ms}"
        options["options"] = f"-c statement_timeout={limit} -c lock_timeout={limit}"
    return psycopg.connect(url, autocommit=True, application_name="promiseops", **options)


def require_autocommit(connection: psycopg.Connection) -> None:
    """Refuse a connection unless our next ``connection.transaction()`` will be a real top-level one.

    Otherwise that block becomes a *savepoint* inside the caller's transaction: the receipt would
    only commit if the caller commits, and a quarantine record could be rolled back together with
    the caller's work. Both break the contract. Two ways this can happen, both refused:

    * ``autocommit`` is off (psycopg then opens a transaction implicitly);
    * ``autocommit`` is on, but the caller is inside ``with connection.transaction():`` — the
      setting alone does not show this, the server-side transaction status does (review of MR !7).
    """
    if not connection.autocommit:
        raise ValueError("ingestion needs an autocommit connection (use promiseops.db.connect)")
    status = connection.info.transaction_status
    if status != pq.TransactionStatus.IDLE:
        raise ValueError(f"ingestion needs a connection outside any transaction (status: {status.name})")


def schema_sql() -> str:
    return resources.files("promiseops").joinpath("schema.sql").read_text(encoding="utf-8")


def apply_schema(connection: psycopg.Connection) -> None:
    """Create or complete the ``promiseops`` schema. Safe to run any number of times."""
    require_autocommit(connection)
    with connection.transaction():
        connection.execute("SELECT pg_advisory_xact_lock(%s)", (_SCHEMA_LOCK_KEY,))
        connection.execute(schema_sql())


class _Lease:
    """One checked-out slot: the connection to yield, plus the exit of a context-managed double.

    Real psycopg connections are pooled as bare objects. Test doubles may return a context
    manager from ``connect`` (the ``with db.connect(...) as c`` shape); the pool enters it to
    expose the inner "connection" and treats the lease as single-use, exactly like the plain
    ``with``-block it replaces.
    """

    __slots__ = ("connection", "context_exit")

    def __init__(self, connection, context_exit=None):
        self.connection = connection
        self.context_exit = context_exit

    @property
    def broken(self) -> bool:
        return getattr(self.connection, "closed", False) or getattr(self.connection, "broken", False)

    def release(self) -> None:
        """End the lease: leave any entered context, then close the connection."""
        if self.context_exit is not None:
            with contextlib.suppress(Exception):
                self.context_exit(None, None, None)
            self.context_exit = None
        with contextlib.suppress(Exception):
            self.connection.close()


class ConnectionPool:
    """Bounded, lazy pool of reusable psycopg connections (psycopg_pool is not in the image).

    Why: opening one connection per request storms the database with TCP + auth
    handshakes and, under load, exhausts its connection/backlog limits (the connect
    storms seen in load acceptance). The pool opens connections on demand through
    :func:`connect` (so tests can patch it), never more than ``max_size`` at once;
    checkouts beyond that block on the semaphore instead of piling up new connects.
    Connections that die while idle (database restart, network drop) are detected with
    a cheap ``SELECT 1`` on reuse and replaced, never handed out.
    """

    def __init__(self, url: str | None = None, *, max_size: int = 8):
        if max_size < 1:
            raise ValueError("max_size must be at least 1")
        self._url = url
        self._max_size = max_size
        self._idle: list[_Lease] = []
        self._lock = threading.Lock()
        self._slots = threading.BoundedSemaphore(max_size)

    @contextlib.contextmanager
    def connection(self) -> Iterator[psycopg.Connection]:
        """Exclusive checkout; the connection is returned (or discarded if broken) at exit."""
        self._slots.acquire()
        try:
            lease = self._checkout()
            try:
                yield lease.connection
            finally:
                self._checkin(lease)
        finally:
            self._slots.release()

    def _checkout(self) -> _Lease:
        for _ in range(2):  # one stale pooled connection is tolerated; the retry opens fresh
            with self._lock:
                lease = self._idle.pop() if self._idle else None
            if lease is None:
                break
            if _is_usable(lease.connection):
                return lease
            lease.release()
        return _open_lease(self._url)

    def _checkin(self, lease: _Lease) -> None:
        if lease.context_exit is not None or lease.broken:
            lease.release()  # context-managed doubles are single-use, like a with-block connect
            return
        with self._lock:
            self._idle.append(lease)

    def close(self) -> None:
        """Close all idle connections (called on app shutdown); checked-out ones close at their own exit."""
        with self._lock:
            idle, self._idle = self._idle, []
        for lease in idle:
            lease.release()


def _open_lease(url: str | None) -> _Lease:
    opened = connect(url)
    if isinstance(opened, psycopg.Connection):
        return _Lease(opened)
    return _Lease(opened.__enter__(), getattr(opened, "__exit__", None))


def _is_usable(connection) -> bool:
    """True when the connection object reports itself healthy; also answers for test doubles."""
    if getattr(connection, "closed", False) or getattr(connection, "broken", False):
        return False
    try:
        connection.execute("SELECT 1")
    except Exception:  # noqa: BLE001 - any failure means: replace, never serve a stale connection
        return False
    return not getattr(connection, "closed", False) and not getattr(connection, "broken", False)
