"""Shared release-aware feature materialization for serving, evaluation and champion scoring."""

import threading

from promiseops import data, features
from promiseops.contracts import instant

# Serving builds the FULL frozen-history feature table once per (cutoff, lineage) and slices
# every request out of it. Recomputing per request re-read and re-aggregated the whole dataset
# for one row (seconds per predict), which saturated the database under load. Per-order values
# do not depend on which other orders are requested (the contract load_features is tested for),
# so the full table is exactly what each per-request build would return for its own orders.
# The cap bounds memory if one process ever serves several cutoffs; in practice there is one.
_FULL_TABLE_CACHE_LIMIT = 2
_full_table_build_lock = threading.Lock()


def release_features(connection, order_ids, *, as_of, manifest, lineage, table_cache=None):
    names = tuple(manifest.feature_names)
    if names == features.FEATURE_NAMES:
        return data.build_features(connection, order_ids, as_of=as_of)
    if names != features.EXTENDED_FEATURE_NAMES or lineage is None:
        raise ValueError("Unsupported release feature schema or missing history lineage")
    if lineage.history_policy != "frozen-at-train-end-v1":
        raise ValueError("Unsupported release history policy")
    # Checked on EVERY call, cache hit or not: a dataset that no longer matches the release
    # lineage must never be served, cached table or not (fail closed).
    if data.dataset_identity(connection, as_of=lineage.as_of) != lineage.dataset_identity:
        raise ValueError("Frozen history source does not match release lineage")
    if table_cache is None:
        # Batch scoring/evaluation pass explicit id lists; the cache is the serving path only.
        return features.load_features_with_history(connection, order_ids, as_of=as_of,
                                                   freeze_at=lineage.train_end, history_as_of=lineage.as_of)
    key = (instant(as_of), lineage.as_of, lineage.train_end, lineage.dataset_identity)
    table = table_cache.get(key)
    if table is None:
        with _full_table_build_lock:  # one build at a time; concurrent misses wait for it
            table = table_cache.get(key)
            if table is None:
                table = features.load_features_with_history(
                    connection, None, as_of=as_of,
                    freeze_at=lineage.train_end, history_as_of=lineage.as_of)
                table_cache[key] = table
                while len(table_cache) > _FULL_TABLE_CACHE_LIMIT:
                    del table_cache[next(iter(table_cache))]  # oldest first (insertion order)
    ids = sorted({str(order_id) for order_id in order_ids})
    return table.loc[table.index.isin(ids)]
