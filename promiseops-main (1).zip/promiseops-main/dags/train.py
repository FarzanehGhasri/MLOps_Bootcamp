"""Training DAGs: submit the queued worker Job via the company gateway.

One factory, two DAGs (same gateway contract, different mode):

    promiseops_training        triggered by the ingestion asset; mode=train
    promiseops_monitor_train   weekly; mode=monitor-train (report first, fit only if recommended)

No fit call happens in the scheduler: the DAG resolves cutoffs, records the
dataset identity as lineage, and POSTs /training with a request_id hashed from
the DagRun identity (retries reuse it; a new run gets a new one — CONTRACTS.md).
The 202 response means submitted, not completed: observe the Job in your own
jobs namespace.

Promotion lifecycle (promiseops_training only; docs/CONTRACTS.md "Evaluation and release")
------------------------------------------------------------------------------------------
submit_job (training) -> register_candidate -> evaluate_candidate -> promotion_decision

The queued Job finishes AFTER the 202, so ``register_candidate`` waits with task
retries until the FINISHED training run for THIS DagRun's cutoffs appears in MLflow
(matched by the worker's ``requested.*`` params, never by wall clock alone), registers
it as a candidate version and hands only small metadata (run id, registry version,
evaluation results) through XCom. ``evaluate_candidate`` verifies the recorded
candidate-vs-champion comparison against the configurable promotion policy, and
``promotion_decision`` moves the MLflow ``champion`` alias, tags the versions and
records the promotion metadata — or marks the candidate rejected. All three run
``python -m promiseops.cli`` (like the ingest DAG): the scheduler never imports the
model code. Promotion is a REGISTRY operation only: no deployment, no Kubernetes, no
change to the running FastAPI service — deployment stays a separate, human-approved
release step. A candidate the worker's gate rejected skips the downstream tasks.
"""

from __future__ import annotations

import json
from datetime import UTC, datetime, timedelta

import promiseops_gateway as gateway
from airflow.exceptions import AirflowException, AirflowFailException, AirflowSkipException
from airflow.sdk import Param, dag, task
from ingest import INGESTED_ASSET

# Exit codes of the promotion CLI commands (promiseops.cli docstring).
_EXIT_NOT_READY = 4  # finished training run not there yet: retry
_EXIT_REFUSED = 5  # ambiguous registry state / invalid configuration: do not retry


def _company_as_of(params, context):
    if params.get("as_of"):
        return params["as_of"], "explicit"
    events = context.get("triggering_asset_events") or {}
    try:
        events = events.get(INGESTED_ASSET.uri, [])
    except TypeError:
        # Airflow 3.1+ keys triggering_asset_events by Asset objects, not URI strings.
        events = events.get(INGESTED_ASSET, [])
    if events:
        return gateway.event_as_of(events), "triggering_ingestion"
    inlet = context.get("inlet_events")
    if inlet is None:
        raise ValueError("Company as_of is required: supply it explicitly or consume an ingestion event")
    history = inlet[INGESTED_ASSET]
    if not history:
        raise ValueError("No successful ingestion event; company as_of is unknown")
    return gateway.event_as_of([history[-1]]), "latest_ingestion"


def _build_training_dag(*, dag_id: str, schedule, mode: str, description: str):
    @dag(
        dag_id=dag_id,
        schedule=schedule,
        start_date=datetime(2026, 11, 18, tzinfo=UTC),
        catchup=False,
        max_active_runs=1,
        params={
            "as_of": Param(None, type=["null", "string"], format="date-time",
                           description="Company cutoff; default: successful ingestion event metadata"),
            "train_end": Param(None, type=["null", "string"], format="date-time",
                               description="Reviewed split; default: Variable promiseops_training_cutoffs"),
            "validation_end": Param(None, type=["null", "string"], format="date-time"),
            "image": Param(
                None,
                type=["null", "string"],
                description="worker image ref; default: Variable promiseops_worker_image",
            ),
            "source_commit": Param(
                None,
                type=["null", "string"],
                description="40-hex commit of the image; default: Variable promiseops_worker_commit",
            ),
        },
        tags=["promiseops", "training"],
        description=description,
    )
    def pipeline():
        @task(inlets=[INGESTED_ASSET])
        def resolve_cutoffs(**context):
            params = context["params"]
            as_of, source = _company_as_of(params, context)
            cutoffs = gateway.training_cutoffs(params, as_of)
            worker = gateway.worker_reference(params)
            identity = gateway.run_cli(["dataset-identity", "--as-of", cutoffs["as_of"]])
            if identity.returncode != 0:
                raise RuntimeError(f"dataset-identity failed: {identity.stderr[-500:]}")
            lineage = json.loads(identity.stdout)
            print(json.dumps({"event": "training_lineage", "mode": mode, **cutoffs, **worker,
                              "as_of_source": source,
                              "dataset_identity": lineage["dataset_identity"]}, sort_keys=True))
            return cutoffs | worker | {"dataset_identity": lineage["dataset_identity"]}

        @task(retries=2, retry_delay=timedelta(minutes=5))
        def submit_job(cutoffs: dict, **context):
            dag_run = context["dag_run"]
            payload = {
                "image": cutoffs["image"],
                "source_commit": cutoffs["source_commit"],
                "train_end": cutoffs["train_end"],
                "validation_end": cutoffs["validation_end"],
                "as_of": cutoffs["as_of"],
                "mode": mode,
                "request_id": gateway.request_id_for(dag_run.dag_id, dag_run.run_id),
            }
            job = gateway.submit_training(payload)
            print(json.dumps({"event": "training_submitted", "mode": mode, **payload, "job": job},
                             sort_keys=True))
            return {"request_id": payload["request_id"], "mode": mode, "as_of": cutoffs["as_of"], "job": job}

        cutoffs_info = resolve_cutoffs()
        submitted = submit_job(cutoffs_info)
        if mode == "train":
            @task(retries=6, retry_delay=timedelta(minutes=5))
            def register_candidate(submission: dict, cutoffs: dict, **context):
                """Wait for this DagRun's finished training run and register it as the candidate version."""
                arguments = ["register-candidate",
                             "--train-end", cutoffs["train_end"],
                             "--validation-end", cutoffs["validation_end"],
                             "--as-of", cutoffs["as_of"]]
                started = getattr(context.get("dag_run"), "start_date", None)
                if started is not None:
                    # Excludes finished runs of EARLIER DagRuns with identical cutoffs (10 min slack).
                    arguments += ["--created-after", (started - timedelta(minutes=10)).isoformat()]
                result = gateway.run_cli(arguments)
                if result.returncode == _EXIT_NOT_READY:
                    raise AirflowException(f"training run not finished yet (exit {_EXIT_NOT_READY}); retrying: "
                                           f"{result.stderr[-300:]}")
                if result.returncode == _EXIT_REFUSED:
                    raise AirflowFailException(f"register-candidate refused (exit {_EXIT_REFUSED}): "
                                               f"{result.stderr[-500:]}")
                if result.returncode != 0:
                    raise AirflowException(f"register-candidate failed (exit {result.returncode}): "
                                           f"{result.stderr[-500:]}")
                outcome = json.loads(result.stdout.splitlines()[-1])
                if outcome["status"] == "rejected":
                    # The worker's gate rejected the candidate: a valid lifecycle outcome, no version was
                    # created; the rejection stays recorded in the training run and nothing is promoted.
                    raise AirflowSkipException(
                        f"candidate {outcome.get('model_version')} was rejected by the worker's gate "
                        f"({'; '.join(outcome.get('gate_reasons', []))[:300]}); promotion tasks are skipped")
                print(json.dumps({"event": "candidate_registered", "request_id": submission["request_id"],
                                  **outcome}, sort_keys=True))
                return outcome

            @task(retries=2, retry_delay=timedelta(minutes=5))
            def evaluate_candidate(candidate: dict):
                """Verify the recorded candidate-vs-champion comparison against the promotion policy."""
                result = gateway.run_cli(["evaluate-candidate", "--name", candidate["name"],
                                          "--version", candidate["version"]])
                if result.returncode != 0:
                    raise AirflowException(f"evaluate-candidate failed (exit {result.returncode}): "
                                           f"{result.stderr[-500:]}")
                evaluation = json.loads(result.stdout.splitlines()[-1])
                print(json.dumps({"event": "candidate_evaluated", **evaluation}, sort_keys=True))
                return evaluation

            @task(retries=2, retry_delay=timedelta(minutes=5))
            def promotion_decision(evaluation: dict):
                """Apply the decision in the MLflow Registry. Deployment is NOT part of this task."""
                result = gateway.run_cli(["decide-promotion", "--name", evaluation["name"],
                                          "--version", evaluation["version"]])
                if result.returncode != 0:
                    raise AirflowException(f"decide-promotion failed (exit {result.returncode}): "
                                           f"{result.stderr[-500:]}")
                outcome = json.loads(result.stdout.splitlines()[-1])
                print(json.dumps({"event": "promotion_decided", **outcome}, sort_keys=True))
                return outcome

            # Promotion lifecycle for trained candidates only; monitor-train reports/decides retraining,
            # and its registered candidates stay pending a human release decision.
            promotion_decision(evaluate_candidate(register_candidate(submitted, cutoffs_info)))

    return pipeline()


training_dag = _build_training_dag(
    dag_id="promiseops_training",
    schedule=[INGESTED_ASSET],
    mode="train",
    description="Queued candidate training after ingestion (gateway POST /training, mode=train)",
)
monitor_train_dag = _build_training_dag(
    dag_id="promiseops_monitor_train",
    schedule="@weekly",
    mode="monitor-train",
    description="Maturity-aware monitoring/retraining (gateway POST /training, mode=monitor-train)",
)
